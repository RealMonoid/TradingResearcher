# Open Decisions, Contradictions and Approval Boundaries

The current user explicitly authorized completion with documented source gaps. None of the items below prevents delivery of these documents. They block only the specified future implementation or scientific claim. No approval is presumed and no question needs to be repeated to finish the present task.

## Open register

| ID / priority | Problem and affected work | Proposed resolution / options | Authority and approval boundary |
|---|---|---|---|
| OPEN-01 / blocking P1 | Original M0072 states are prospective and combine concepts later separated; historical-first requires a coherent lifecycle | Versioned historical/forward execution branch; orthogonal execution validity, primary evidence, origin, replication and applicability; retain legacy definitions | **PROPOSED CHANGE — USER APPROVAL REQUIRED.** D008, D020, D067; no migration performed |
| OPEN-02 / blocking affected policy support | M0144 assumes subset scope is safe; aggregate evidence may not support a subgroup | Scope inclusion checks set membership only; separately require transportability/coverage/heterogeneity conditions before evidence-backed designation | **PROPOSED CHANGE — USER APPROVAL REQUIRED.** D066; preserve historical wording |
| OPEN-03 / blocking numerical family priors | Replicated/tested ratio is confounded by power, censoring and selected replication | Keep rates as descriptive diagnostics; use no truth-probability or posterior until an estimator and calibration are specified | **PROPOSED CHANGE — USER APPROVAL REQUIRED.** D024; no new numerical prior |
| OPEN-04 / blocking P1 | Five claim forms, boolean structure, continuous outcomes and adaptive policies lack complete executable grammar | Define typed expressions, estimands, time/units/missingness and language-extension conformance; preserve unsupported ideas | Technical choice under D002–D004; semantic changes need D008 approval |
| OPEN-05 / blocking confirmation | Alpha/error policy, family assignment, effect sizes, N_min/precision, stopping and replication rules are unspecified | Select hypothesis-appropriate policies before outcomes; define negative versus inconclusive and case dependence | D006, D031, D062; examples are not defaults |
| OPEN-06 / blocking real data | Initial market/instruments, providers, history, PIT availability, revisions, costs and fill models are unspecified | Choose a bounded initial universe with auditable data rights and execution conventions; keep broad-domain capability extensible | D012, D018, D042; new data authority may require user choice |
| OPEN-07 / before runtime adoption | Hermes is a candidate; exact version, invocation model, isolation and license/dependency inventory untested | Compare narrow adapter conformance and operational cost before dependency adoption; do not build a second platform | D022, D041, D063 |
| OPEN-08 / before persistence implementation | Database/file layout, schema migrations, hash serialization and crash recovery are unspecified | Prefer a simple transaction-capable index and immutable payloads; define serialization, retention, backup and restore | New engineering proposal, not accepted historical stack |
| OPEN-09 / before scaled discovery | Agent count, models, search modes, budgets and material overrun thresholds remain open | Measure a small isolated multi-perspective run with same allowed snapshot; use D070's method-versioned coverage/diversity diagnostics and cost/latency before scale; no compulsory modes or novelty reward | D005, D028, D030, D061, D070 |
| OPEN-10 / blocking live capital | Deployment thresholds, risk ownership, capital limits and operational authority absent | Keep research/paper simulation separate; define explicit risk limits, withdrawal, promotion and rollback before live action | D020, D064; current task authorizes no trades |
| OPEN-11 / blocking claims of framework success | Numeric calibration/economic gates, stop criteria and acceleration/version-assessment designs remain unspecified | Use D069-D070's purpose-specific contract: absolute profitably usable hypotheses need economic/cost/risk criteria, not competing-generator superiority; acceleration/version claims name the relevant reference and matched information/resources. Specify uncertainty, pending cohorts, budget and a review checkpoint before assessment outcomes; positive benefit is not a build/run prerequisite | D025, D068-D070, REQ-027/029; contract structure is adopted in document 13, numerical choices remain open; D015 is unchanged |
| OPEN-12 / before confirmation allocation | Evidence-budget allocation and overlapping candidate-family treatment not finalized | Preserve free ideas; specify ex-ante selection, quotas/queue, simultaneous-testing dependencies and reuse rules. D070 requires an availability/latency/dependence inventory and sensitivity or precision justification; it supplies no automatic allocation rule | D023, D038, D049, D070 |
| OPEN-13 / before current-knowledge monitoring | Applicability/decay thresholds and typed scientific dependency consequences are incomplete | Distinguish hard infrastructure invalidation, applicability review, scientific contradiction and operational degradation | D009, D020, D037 |
| OPEN-14 / before feature/language changes | Early routine autonomous certification versus later approval of material changes needs a clear boundary | Existing-language feature composition can follow approved certification; new semantics/compiler/language or evidence rules need material-change review | D004, D026; interpretation requires explicit policy before automation |
| OPEN-15 / source confidence | Missing images, cited files, incomplete M0302 and absent original export | Continue with current source limits; later add versioned recovery, compare provenance and re-audit affected decisions | SRC-001 through SRC-008; continuation explicitly authorized, no fabricated replacement |

## Protocol choices required before confirmation

The October 23 review makes existing OPEN-05/11/12 work actionable without selecting its answers. The [scientific supplement](07_SCIENTIFIC_EVALUATION.md#overfitting-controls-across-the-research-process) explains the academic basis and limits. These questions concern the scoped experiment; they do not require resolving unrelated future capabilities before useful preparation.

| Open item | Concrete choice and reviewable closure evidence |
|---|---|
| OPEN-05: evaluation design | State whether the target is a fixed selected claim/policy or a selection/adaptation procedure. Choose an appropriate held-out, forward, nested or other justified design, with all fitting/selection placed inside the permitted information boundary. Bind the estimand, meaningful effect, dependence/sampling unit, uncertainty, negative/inconclusive rules and fixed-horizon or valid sequential stopping. Validate against declared failure cases; no universal CV, DSR, PBO or alpha default. |
| OPEN-12: allocation and release | Specify admissible candidate cohorts, selection timing, shared-observation/dependence treatment, multiplicity budget and assessment-feedback release/access. Show how a rank or pass/fail result used by a descendant propagates exposure. State what happens when evidence or budget is insufficient. Neither permanent data retirement for every unrelated use nor unlimited adaptive reuse is inferred. |
| OPEN-11: process assessment | Name the question, scoped process versions, relevant selection opportunities, calibration worlds, development versus final assessment, success/stop thresholds and uncertainty. Choose independent repetitions/information appropriate to the claim. Include costs and pending cohorts; a comparison reference is required only for a comparative claim. |

Resolve these alongside the relevant data/availability contract in OPEN-06 and any applicable lifecycle/certification dependencies. A reviewable protocol proposal identifies assumptions, affected decisions/requirements, validation, versioning and rollback. D008/D026 approval applies to material scientific changes; ordinary implementation details within an authorized scope do not acquire a new approval gate. No choice above is silently marked accepted by this documentation revision.

## Resolved historical tensions

| Earlier position | Later resolution | What must not return |
|---|---|---|
| Forward-only primary evaluation | User M0101 chooses historical-first; M0153–M0156 preserves strongest clean forward confirmation | Treating all historical OOS as model-unseen, or removing forward evidence |
| No generator tools | M0110–M0112 permits measured queries; M0181–M0184 explicitly permits targeted sourced research | Unlogged exploratory queries or unrestricted historical future-source access |
| Broad semantic knowledge graph | M0090 retracts mandatory interpreted graph; M0092 preserves minimal consequential relations | Treating model-inferred contradiction as automatic invalidation |
| Per-hypothesis Python testing | M0066–M0068/M0074 favor declarative compiler | Uncertified generated evaluation code as verdict authority |
| Fixed status-to-capital ladder | M0148 separates evidence and action under uncertainty | Automatic deployment amount from one evidence label |
| 5-minute examples | M0097–M0098 sets v1 observation minimum to 15 minutes | Mistaking old examples for current scope |
| A simple comparator generator | M0107 directly rejects it | Reintroducing it under the label of necessary baseline; statistical controls still remain |

## Changes requiring approval

OPEN-01 through OPEN-03 are the concrete semantic change proposals in this review. They have not been applied as historical decisions or implemented. Other entries are missing technical/risk selections whose decision owner must be assigned before affected work. No accepted goal change is proposed. Any future removal of free invention, independent code judgment, evidence separation or the accepted research scope must carry **GOAL CHANGE — USER APPROVAL REQUIRED**.

The architecture cannot resolve the private conversation's unavailable material by inference. If new primary sources contradict a contextual reconstruction, preserve both versions and record the correction with affected IDs instead of quietly replacing history.

## October 23 concrete closure proposal

The current user requested systematic reconstruction, scientific research and complete resolution/implementation, emphasizing retail economics and avoiding mandatory days or months of forward waiting. The [research assessment](../reviews/OPEN_DECISION_RESEARCH_2026-10-23.md) maps every item above to a concrete section of the [version 0.1 closure proposal](../reviews/RETAIL_RESEARCH_CONTRACT_PROPOSAL_2026-10-23.md). The proposal distinguishes design choices, run-specific required inputs, future capabilities and factual source gaps; resolving one does not establish the others.

**Status: proposed, not adopted.** D008/D026 and AGENTS.md require explicit approval of the reviewable scientific changes before activation. No OPEN item, decision, definition or statistical policy is silently closed by adding these links. Approval would be followed by the proposal's canonical integration and versioning plan, with separately reported implementation and empirical evidence.
