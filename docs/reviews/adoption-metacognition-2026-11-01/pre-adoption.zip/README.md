# TradingResearcher

An autonomous market-research framework under construction: an LLM freely invents nontrivial hypotheses, preserves the original idea, formalizes executable claims, and submits them to independent deterministic evaluation. The goal is faster useful research and economically usable hypotheses after realistic costs. The LLM cannot judge its own empirical success.

## Start here

1. Read the short [Current State](docs/architecture/CURRENT_STATE.md#resume-handoff).
2. Follow the [single operational work plan](docs/reviews/integration-research-2026-10-24/IMPLEMENTATION_SEQUENCE_2026-10-25.md#current-execution-priority-october-31-2026): bounded AmiBroker preflight closeout, then scientific bottlenecks in packages 3-5. Read the selected package and its owning sources; avoid loading all history.
3. Follow [AGENTS.md](AGENTS.md) for repository work and the plan's [Codex session/handoff workflow](docs/reviews/integration-research-2026-10-24/IMPLEMENTATION_SEQUENCE_2026-10-25.md#codex-build-sessions-and-context). A session is a distinct chat in the same project. A recommended switch must include an explicit notice and a copyable handoff prompt.

**Status:** executable coordination, provider/tool loops, formalization/certification components and descriptive development reports exist. The complete scientific research cycle, applicable calibration/information profile, protected assessment/freeze, policy qualification and reporting/delivery remain incomplete. Zero/one-condition descriptive outcomes demonstrate no reliable population effect or trading edge. See Current State for qualified current evidence rather than older capability summaries.

## Governing sources

- [Problem and goals](docs/architecture/01_PROBLEM_DEFINITION.md), [master architecture](docs/architecture/06_MASTER_ARCHITECTURE.md), [requirements](docs/architecture/05_REQUIREMENTS.md) and [traceability](docs/architecture/12_TRACEABILITY_MATRIX.md).
- [Accepted decisions](docs/architecture/02_DECISION_REGISTER.md), [rejections](docs/architecture/03_REJECTED_DECISIONS.md), [definitions](docs/architecture/04_DEFINITIONS.md) and [current open-item dispositions](docs/architecture/11_OPEN_DECISIONS.md).
- [Scientific evaluation](docs/architecture/07_SCIENTIFIC_EVALUATION.md), [generator feedback contract](docs/architecture/13_GENERATOR_FEEDBACK_AND_EVALUATION.md), [retail research contract](docs/architecture/14_RETAIL_RESEARCH_CONTRACT.md), [inquiry discipline](docs/architecture/15_AGENT_INQUIRY_DISCIPLINE.md), [temporal invocation](docs/architecture/16_TEMPORAL_DIAGNOSTIC_INVOCATION.md) and [monitoring/reporting](docs/architecture/17_MONITORING_VISIBILITY_AND_REPORTING.md).
- [Engineering review](docs/architecture/08_ENGINEERING_REVIEW.md), [blueprint](docs/architecture/09_IMPLEMENTATION_BLUEPRINT.md), [local runtime](trading_researcher/README.md) and [AmiBroker CLI](tools/amibroker/README.md). The [roadmap](docs/architecture/10_IMPLEMENTATION_ROADMAP.md) proposes phases; it is not another operational plan.

For framework-wide assessment, follow [REVIEWING.md](REVIEWING.md): reconstruct goals, actual flow/feedback, authority, open boundaries and ordinary/failure paths before critique. A compact handoff does not replace the required system reconstruction.

## Evidence and limits

The [exact captured transcript](sources/full_conversation.md), [capture manifest](sources/capture_manifest.json), [source audit](docs/architecture/00_SOURCE_AUDIT.md) and [review index](docs/architecture/SOURCE_REVIEW_INDEX.md) retain provenance and known gaps. The archive has 305 message blocks from 304 numbered turns; missing images/documents/export and one incomplete response prevent a full-source-completeness claim. Preserve source bytes and verify their manifest hashes. Project-authored documents are English (en-US); original quotations keep their language.

Current software checks and historical reports establish only their stated scope. [Documentation verification](docs/architecture/DOCUMENTATION_VERIFICATION.json) and dated implementation evidence do not certify scientific validity, profitability or construction-token savings. The [complete pre-compaction README](README_SNAPSHOT_2026-10-31.md) preserves the earlier capability chronology and all its evidence links; consult it for a specific historical question.

## Adopted open-decision resolutions

D071-D085 adopt [research-contract/1.0](docs/architecture/14_RETAIL_RESEARCH_CONTRACT.md) after explicit user approval. The [research review](docs/reviews/OPEN_DECISION_RESEARCH_2026-10-23.md), [immutable preapproval proposal](docs/reviews/RETAIL_RESEARCH_CONTRACT_PROPOSAL_2026-10-23.md) and [adoption verification](docs/reviews/adoption-2026-10-23/verification.json) retain rationale and exact evidence. Scoped design dispositions do not establish implemented or empirically validated capabilities.
