"""Freeze bounded adapter evidence; read-only live accounting, no provider calls."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import unquote
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
OUT = ROOT / 'docs/reviews/implementation-2026-10-25'
TARGET = OUT / 'anthropic-provider-verification.json'
ARCHIVE = OUT / 'anthropic-provider-evidence.zip'
assert not TARGET.exists() and not ARCHIVE.exists(), 'Never overwrite an accepted checkpoint'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


pins = {
    'trading_researcher/anthropic_provider.py': '5768871ceedd293436c8c3ffb85a9362db6c866ae1a085c88ff5043150fdbb1f',
    'trading_researcher/openai_provider.py': '9576950722832ec7f7139f3b5054410af8d5e545b870b84d6c19d94454e80980',
    'trading_researcher/provider_usage.py': 'b916b40cc06057638a1896db14b4a0282f9ad3c0f19d619f2abcc08f8665a045',
    'trading_researcher/__main__.py': '781a2ea6d387287ff51fe262b849f1aee5b761d9eed975690857425f3457506d',
    'tests/test_anthropic_provider_adversarial.py': 'a637ea2e3441edb554b199895e3c6b7e02012e20f1eb740e0b13481fa8302ab5',
}
assert all(sha(ROOT / name) == digest for name, digest in pins.items())
baseline = json.loads((WORK / 'baseline.json').read_text(encoding='utf-8'))
allowed = {'trading_researcher/openai_provider.py', 'trading_researcher/provider_usage.py',
           'trading_researcher/__main__.py', 'docs/reviews/implementation-2026-10-25/progress.json'}
preserved = {name: digest for name, digest in baseline.items() if name not in allowed}
assert all(sha(ROOT / name) == digest for name, digest in preserved.items()), 'Earlier artifacts or live ledger changed'
review_path = OUT / 'anthropic-provider-review.json'
review = json.loads(review_path.read_text(encoding='utf-8'))
assert sha(review_path) == 'b39fe9dd22143fbf7c35628d7db6bf64aff0b1ee35cc75ce0990fb7f6965392d'
usage_path = WORK / 'existing-openai-usage-report.json'
alias_path = WORK / 'existing-openai-usage-alias.json'
usage = json.loads(usage_path.read_text(encoding='utf-8'))
alias = json.loads(alias_path.read_text(encoding='utf-8'))
assert usage == alias, 'Neutral and legacy CLI report content differs'
assert usage['schema'] == 'framework-provider-usage-report/3' and usage['provider'] == 'openai'
assert usage['totals']['calls'] == 10 and usage['totals']['exact_total_tokens'] == 35084
assert usage['money']['charged_nano'] == 95105000 and usage['money']['cap_nano'] == 5000000000
assert not usage['money']['halted']

changed = list(pins) + [
    'tests/test_anthropic_provider.py', 'tests/test_anthropic_integration.py',
    'tests/test_provider_identity_adversarial.py',
    'trading_researcher/ANTHROPIC.md', 'trading_researcher/OPENAI.md', 'trading_researcher/RESEARCHER.md',
    'README.md', 'docs/architecture/CURRENT_STATE.md',
    'docs/reviews/integration-research-2026-10-24/IMPLEMENTATION_SEQUENCE_2026-10-25.md',
    'docs/reviews/implementation-2026-10-25/ANTHROPIC_TRANSPORT_2026-10-25.md',
    'docs/reviews/implementation-2026-10-25/IMPLEMENTATION_SUMMARY_2026-10-25.md',
    'docs/reviews/implementation-2026-10-25/progress.json',
    'docs/reviews/implementation-2026-10-25/anthropic-provider-review.json',
]
links = 0
for name in changed:
    path = ROOT / name
    body = path.read_text(encoding='utf-8')
    assert all(line == line.rstrip() for line in body.splitlines()), name + ': trailing whitespace'
    if path.suffix == '.json':
        json.loads(body)
    if path.suffix != '.md':
        continue
    for target in re.findall(r'\]\(([^\s)]+)\)', body):
        if target.startswith(('https://', 'http://', '#')):
            continue
        destination = (path.parent / unquote(target.split('#', 1)[0])).resolve()
        assert destination.exists() or destination == TARGET, (name, target)
        links += 1

record = {
    'schema': 'anthropic-transport-engineering-verification/1', 'status': 'FINAL_DOC_CHECKS_PENDING',
    'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
    'scope': 'Offline protocol/accounting and mixed-controller fixture; not live provider/scientific validation.',
    'unique_tests_passed': 79,
    'completed_checks': [
        {'command': "python -B -m unittest discover -s tests -p 'test_anthropic*.py'", 'tests': 35,
         'seconds': 3.313, 'exit_code': 0, 'tool_chunk': '32e82b'},
        {'command': "python -B -m unittest discover -s tests -p 'test_provider*.py'", 'tests': 19,
         'seconds': 1.079, 'exit_code': 0, 'tool_chunk': 'd81f93'},
        {'command': "python -B -m unittest discover -s tests -p 'test_openai*.py'", 'tests': 25,
         'seconds': 2.209, 'exit_code': 0, 'tool_chunk': '9f9791'},
        {'command': 'python -B -m trading_researcher provider-usage --ledger .trf-runtime/openai-integration-budget.sqlite3',
         'exit_code': 0, 'tool_chunk': '623c10'},
        {'command': 'python -B -m trading_researcher openai-usage --ledger .trf-runtime/openai-integration-budget.sqlite3',
         'exit_code': 0, 'tool_chunk': '55c7ae'},
    ],
    'independent_review': {'file': review_path.name, 'sha256': sha(review_path),
                           'tests': 23, 'seconds': 0.457, 'exit_code': 0},
    'changed_files': changed + [str(TARGET.relative_to(ROOT)).replace('\\', '/'),
                                str(ARCHIVE.relative_to(ROOT)).replace('\\', '/')],
    'ignored_helpers': ['.trf-runtime/anthropic-provider-checks-2026-10-25/baseline.py',
                        '.trf-runtime/anthropic-provider-checks-2026-10-25/finalize.py'],
    'checked_files_sha256': {name: sha(ROOT / name) for name in changed},
    'preserved_baseline_files': len(preserved),
    'live_openai_ledger_sha256': sha(ROOT / '.trf-runtime/openai-integration-budget.sqlite3'),
    'live_ledger_unchanged': True, 'live_calls_this_continuation': 0,
    'existing_usage': {'calls': 10, 'tokens': 35084, 'conservative_nano_usd': 95105000,
                       'aggregate_cap_nano_usd': 5000000000},
    'mixed_fixture': {'calls': 4, 'inclusive_tokens': 680, 'conservative_nano_usd': 2900000,
                      'actual_network': False, 'scientific_authority': False},
    'authored_checks': {'whitespace': 'PASS', 'local_link_targets': links, 'json': 'PASS',
                        'cli_alias_same_json_content': 'PASS',
                        'cli_alias_comparison_note': 'Initial byte comparison failed only on JSON object key order; parsed reports match without changing either report.'},
    'unverified': ['Actual Anthropic credentials, billing and live compatibility',
        'Real mixed-model research, semantic quality, scientific validity or cost advantage',
        'Guaranteed provider invoice cap; token counting is an estimate',
        'Provider execution timestamps and immutable backend revision',
        'Scientific data/semantic admission, nuisance adequacy, information/calibration and atomic freeze',
        'Complete seven-package objective and any live-capital authority'],
}
TARGET.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
command = [sys.executable, '-B', 'docs/reviews/verify_retail_contract.py']
check = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=60)
(WORK / 'documentation.log').write_text(check.stdout + check.stderr, encoding='utf-8')
assert check.returncode == 0, check.stdout + check.stderr
docs = json.loads(check.stdout)
assert docs['status'] == 'PASS' and not docs['errors']
record['completed_checks'].append({'command': 'python -B docs/reviews/verify_retail_contract.py',
    'exit_code': check.returncode, 'includes': 'verify_system_model and git diff --check',
    'local_links': docs['checks']['local_links']})
with zipfile.ZipFile(ARCHIVE, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    files = set(ROOT.glob('trading_researcher/*.py')) | set(ROOT.glob('tests/*.py'))
    files |= {ROOT / name for name in changed}
    files |= {WORK / 'baseline.json', WORK / 'documentation.log', usage_path, Path(__file__)}
    for path in sorted(files):
        archive.write(path, str(path.relative_to(ROOT)).replace('\\', '/'))
record['evidence_archive_sha256'] = sha(ARCHIVE)
record['evidence_archive_scope'] = 'Current Python source/tests, changed guides, review, baseline and check output; not a full workspace or data backup.'
record['status'] = 'PASS_BOUNDED_OFFLINE_TRANSPORT'
TARGET.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
final = subprocess.run(['git', 'diff', '--check'], cwd=ROOT, capture_output=True, text=True)
(WORK / 'git-diff-check.log').write_text(final.stdout + final.stderr, encoding='utf-8')
assert final.returncode == 0, final.stdout + final.stderr
assert all(sha(ROOT / name) == digest for name, digest in pins.items())
assert all(sha(ROOT / name) == digest for name, digest in preserved.items())
assert json.loads(TARGET.read_text(encoding='utf-8'))['status'] == record['status']
print(json.dumps({'status': record['status'], 'tests': 79, 'independent_tests': 23,
                  'documentation_exit': check.returncode, 'git_diff_check_exit': final.returncode,
                  'preserved_files': len(preserved), 'live_ledger_unchanged': True, 'new_live_calls': 0}))
