"""Save bounded calibration-count evidence without simulations or API calls."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import unquote
import zipfile

root = Path(__file__).resolve().parents[2]
work = Path(__file__).resolve().parent
out = root / 'docs/reviews/implementation-2026-10-25'
target = out / 'calibration-count-verification.json'
archive = out / 'calibration-count-evidence.zip'
assert not target.exists() and not archive.exists(), 'Do not overwrite a prior checkpoint'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


pins = {
    'trading_researcher/calibration.py': '2a402d21f01911a308083e8ddaa461f73ddddb9e9f0c2186696ac4a0a6906c0b',
    'tests/test_calibration_adversarial.py': '55b1e863ba4dc8d4d2fe8982880564d96d8c765d356473f9b6300d82077c7572',
    'tests/fixtures/reference_calibration_counts.json': 'c1c7d41e24b20c4b3c170e7051fb597c1e6b761712274c287d008c485ac27ae9',
    'tests/fixtures/reference_calibration_counts.md': '04e272af558ff9b7c0c469aa5290217a9966c9a3c1807f42f0acb25d6163b303',
    'docs/reviews/implementation-2026-10-25/calibration-count-review.json': 'c1e0c08c56ac3ebaef170d7599cbc34d384a7356d42d62e56bd739b16fde146f',
}
assert all(sha(root / name) == value for name, value in pins.items())
baseline = json.loads((work / 'baseline.json').read_text(encoding='utf-8'))
allowed = {'trading_researcher/__main__.py', 'docs/architecture/CURRENT_STATE.md',
           'docs/architecture/09_IMPLEMENTATION_BLUEPRINT.md',
           'docs/reviews/implementation-2026-10-25/progress.json'}
preserved = {name: value for name, value in baseline.items() if name not in allowed}
assert all(sha(root / name) == value for name, value in preserved.items()), 'Prior source or evidence changed'
prior = json.loads((out / 'anthropic-role-handoff-verification.json').read_text(encoding='utf-8'))
assert sha(root / '.trf-runtime/openai-integration-budget.sqlite3') == prior['live_ledger_sha256']
changed = list(pins) + ['trading_researcher/__main__.py', 'tests/test_calibration.py',
    'tests/test_calibration_cli.py', 'trading_researcher/CALIBRATION.md',
    'trading_researcher/INFORMATION_STUDIES.md', 'README.md',
    'docs/architecture/CURRENT_STATE.md', 'docs/architecture/09_IMPLEMENTATION_BLUEPRINT.md',
    'docs/reviews/implementation-2026-10-25/IMPLEMENTATION_SUMMARY_2026-10-25.md',
    'docs/reviews/implementation-2026-10-25/progress.json']
links = 0
for name in changed:
    path = root / name
    body = path.read_text(encoding='utf-8')
    assert all(line == line.rstrip() for line in body.splitlines()), name
    if path.suffix == '.json':
        json.loads(body)
    if path.suffix == '.md':
        for link in re.findall(r'\]\(([^\s)]+)\)', body):
            if link.startswith(('https://', 'http://', '#')):
                continue
            destination = (path.parent / unquote(link.split('#', 1)[0])).resolve()
            assert destination.exists() or destination == target, (name, link)
            links += 1
record = {
    'schema': 'calibration-count-engineering-verification/1', 'status': 'DOCUMENTATION_CHECK_PENDING',
    'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
    'scope': 'Executable adopted count thresholds and read-only CLI; no authenticated final-calibration runner.',
    'checks': [
        {'command': "python -B -m unittest discover -s tests -p 'test_calibration*.py'",
         'tests': 23, 'seconds': 3.631, 'exit_code': 0, 'tool_chunk': 'f917ae'},
        {'command': "python -B -m unittest discover -s tests -p 'test_information_study*.py'",
         'tests': 19, 'seconds': 0.626, 'exit_code': 0, 'tool_chunk': '287bb1'},
        {'command': "python -B -m unittest discover -s tests -p 'test_provider_usage*.py'",
         'tests': 11, 'seconds': 0.395, 'exit_code': 0, 'tool_chunk': 'f697f8'}],
    'unique_tests_passed': 53,
    'independent_review': {'file': 'calibration-count-review.json', 'tests': 17,
        'seconds': 1.231, 'exit_code': 0, 'scope': 'Count kernel, not CLI',
        'sha256': pins['docs/reviews/implementation-2026-10-25/calibration-count-review.json']},
    'red_checks': [
        {'tool_chunk': 'b7e253', 'exit_code': 1, 'reason': 'Production module absent before implementation'},
        {'tool_chunk': '4ab212', 'exit_code': 1, 'reason': 'CLI command absent before implementation'}],
    'changed_files': changed + [str(target.relative_to(root)).replace('\\', '/'),
                                str(archive.relative_to(root)).replace('\\', '/')],
    'changed_files_sha256': {name: sha(root / name) for name in changed},
    'ignored_helpers': [str(path.relative_to(root)).replace('\\', '/')
                        for path in (work / 'baseline.py', Path(__file__))],
    'preserved_baseline_files': len(preserved),
    'authored_checks': {'whitespace': 'PASS', 'json': 'PASS', 'local_link_targets': links},
    'live_ledger_unchanged': True, 'live_ledger_sha256': prior['live_ledger_sha256'],
    'new_provider_calls': 0, 'new_simulated_worlds': 0, 'existing_live_usage': prior['existing_live_usage'],
    'unverified': ['Authenticated event extraction and complete final-calibration execution',
        'Fresh reserved final seeds and independence from development/tuning',
        'Declared event meanings, stress applicability and nuisance/population model adequacy',
        'Actual independent semantic judgment and scientific data admission',
        'N_min, scientific freeze/allocation, complete historical research cycle',
        'Scientific validity, full-process calibration, policy/backtest quality, live capital and full seven-package completion'],
    'next_action': 'Bind the count assessment to owned frozen final-calibration events after establishing the development model/information target; preserve remaining semantic/data/freeze gates.'}
target.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
check = subprocess.run([sys.executable, '-B', 'docs/reviews/verify_retail_contract.py'],
                       cwd=root, capture_output=True, text=True, timeout=60)
(work / 'documentation.log').write_text(check.stdout + check.stderr, encoding='utf-8')
assert check.returncode == 0, check.stdout + check.stderr
docs = json.loads(check.stdout)
assert docs['status'] == 'PASS' and not docs['errors']
record['checks'].append({'command': 'python -B docs/reviews/verify_retail_contract.py',
    'exit_code': 0, 'includes': 'verify_system_model and git diff --check',
    'local_links': docs['checks']['local_links']})
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as bundle:
    paths = set(root.glob('trading_researcher/*.py')) | {root / name for name in changed}
    paths |= {work / 'baseline.json', work / 'documentation.log', Path(__file__)}
    for path in sorted(paths):
        bundle.write(path, str(path.relative_to(root)).replace('\\', '/'))
record['evidence_archive_sha256'] = sha(archive)
record['archive_scope'] = 'Current application source, new tests/fixtures, changed guides and independent review; no credentials or market data.'
record['status'] = 'PASS_BOUNDED_COUNT_ASSESSMENT'
target.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
final = subprocess.run(['git', 'diff', '--check'], cwd=root, capture_output=True, text=True)
(work / 'git-diff-check.log').write_text(final.stdout + final.stderr, encoding='utf-8')
assert final.returncode == 0, final.stdout + final.stderr
assert all(sha(root / name) == value for name, value in pins.items())
assert all(sha(root / name) == value for name, value in preserved.items())
print(json.dumps({'status': record['status'], 'tests': 53, 'independent_tests': 17,
    'documentation_exit': check.returncode, 'git_diff_check_exit': final.returncode,
    'preserved_files': len(preserved), 'new_provider_calls': 0, 'new_simulated_worlds': 0}))
