"""Retain one bounded engineering checkpoint; no provider or scientific study dispatch."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import unquote
import zipfile

root=Path(__file__).resolve().parents[2]
work=Path(__file__).resolve().parent
out=root/'docs/reviews/implementation-2026-10-25'
target=out/'calibration-run-verification.json'
archive=out/'calibration-run-evidence.zip'
assert not target.exists() and not archive.exists(), 'Checkpoint already exists'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

review_path=out/'calibration-run-review.json'
assert sha(review_path)=='52af14f60ef041eefe6a8509aae70c899bde6eaa44745e7db3ca4123348fc86c'
review=json.loads(review_path.read_text(encoding='utf-8'))
pins={**review['source_sha256'],**review['test_sha256'],**review['earlier_count_fixture_and_test_sha256']}
assert all(sha(root/name)==value for name,value in pins.items()), 'Reviewed source differs'
baseline=json.loads((work/'baseline.json').read_text(encoding='utf-8'))
allowed={'trading_researcher/coordination.py','trading_researcher/information_study.py',
    'trading_researcher/study_runs.py','trading_researcher/memory.py','trading_researcher/storage.py',
    'docs/architecture/CURRENT_STATE.md','docs/architecture/09_IMPLEMENTATION_BLUEPRINT.md',
    'docs/reviews/implementation-2026-10-25/progress.json'}
preserved={name:value for name,value in baseline.items() if name not in allowed}
assert all(sha(root/name)==value for name,value in preserved.items()), 'Unrelated prior source/evidence changed'
changed=sorted(allowed|{'trading_researcher/calibration_runs.py','trading_researcher/calibration_study.py',
    'tests/test_calibration_runs.py','tests/test_calibration_study.py','tests/test_calibration_access_adversarial.py',
    'README.md','trading_researcher/CALIBRATION.md','trading_researcher/INFORMATION_STUDIES.md',
    'docs/reviews/implementation-2026-10-25/IMPLEMENTATION_SUMMARY_2026-10-25.md',
    'docs/reviews/implementation-2026-10-25/calibration-run-review.json'})
links=0
for name in changed:
    path=root/name;body=path.read_text(encoding='utf-8')
    assert all(line==line.rstrip() for line in body.splitlines()), name
    if path.suffix=='.json':json.loads(body)
    if path.suffix=='.md':
        for link in re.findall(r'\]\(([^\s)]+)\)',body):
            if link.startswith(('https://','http://','#')):continue
            destination=(path.parent/unquote(link.split('#',1)[0])).resolve()
            assert destination.exists() or destination==target,(name,link)
            links+=1
checks=[
    {'pattern':'test_calibration*.py','tests':42,'seconds':'142.442','exit_code':0,'tool_chunk':'672721'},
    {'pattern':'test_study_runs*.py','tests':13,'seconds':'243.717','exit_code':0,'tool_chunk':'de1d9a'},
    {'pattern':'test_information_study*.py','tests':19,'seconds':'0.694','exit_code':0,'tool_chunk':'3dd317'},
    {'pattern':'test_memory.py','tests':17,'seconds':'7.941','exit_code':0,'tool_chunk':'5b6ae6'},
    {'pattern':'test_coordination.py','tests':21,'seconds':'10.506','exit_code':0,'tool_chunk':'ddea73'},
    {'pattern':'test_local_runtime.py','tests':8,'seconds':'17.163','exit_code':0,'tool_chunk':'3c8ce4'}]
for check in checks:check['command']="python -B -m unittest discover -s tests -p '"+check['pattern']+"'"
previous=json.loads((out/'calibration-count-verification.json').read_text(encoding='utf-8'))
record={'schema':'owned-calibration-engineering-verification/1','status':'FINAL_CHECKS_PENDING',
    'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
    'scope':'Protected fixed single-claim final-series orchestration; no completed scientific calibration.',
    'checks':checks,'unique_tests_passed':sum(c['tests'] for c in checks),
    'independent_review':{'path':'calibration-run-review.json','sha256':sha(review_path),
        'new_tests':10,'seconds':'3.427','exit_code':0,'included_in_parent_test_count':True},
    'development_history':[
        {'tool_chunk':'64f24a','exit_code':1,'reason':'New pure final-manifest module absent before implementation'},
        {'tool_chunk':'00bd4b','exit_code':1,'reason':'Integration fixture used wrong compiled_id field; fixed fixture and cleanup; no product failure claimed'},
        {'tool_chunk':'0f318b','exit_code':1,'reason':'Owned runner module absent before implementation'},
        {'tool_chunk':'e54ea2','exit_code':0,'tests':3,'seconds':'132.440','reason':'Initial actual development/final replay integration before review fixes'},
        {'source':'calibration-run-review.json','reason':'Independent alias red and oversized unavailable-event reproduction; both fixed without changing expectations'}],
    'changed_files':changed+[str(target.relative_to(root)).replace('\\','/'),str(archive.relative_to(root)).replace('\\','/')],
    'changed_files_sha256':{name:sha(root/name) for name in changed},
    'preserved_baseline_files':len(preserved),
    'authored_file_checks':{'whitespace':'PASS','json':'PASS','local_links':links},
    'live_ledger_unchanged':True,'live_ledger_sha256':sha(root/'.trf-runtime/openai-integration-budget.sqlite3'),
    'new_provider_calls':0,'existing_live_usage':previous['existing_live_usage'],
    'simulation_evidence':{'scope':'Disposable local integration fixtures only; no completed final cohort or admitted market study.',
        'actual_flow':'Complete three-world development fixture plus one protected final world, each generated and separately replayed; additional existing lifecycle regressions also execute local fixtures.',
        'faults':'Known attempt failure before successful retry; full-reservation orphan recovery on actual Broker reopen while assessment source differs.',
        'complete_final_calibration_cohorts':0,'total_simulation_invocations_across_all_test_runs':'not_aggregated'},
    'unverified':['Population/stress adequacy and applicability declarations','Independent PRNG sampling and external tuning history',
        'Coherent mixed-truth multi-claim worlds and complete passing final calibration',
        'Meaningful N_min, scientific data/semantic admission and atomic freeze/allocation',
        'Actual mixed-provider research quality and live Claude access/billing',
        'OS resource quotas or arbitrary future schema migrations','Full seven-package objective, policy/backtest quality and economic efficacy'],
    'ignored_helpers':[str(p.relative_to(root)).replace('\\','/') for p in (work/'baseline.py',Path(__file__))],
    'next_action':'Continue scientific prerequisites and mixed-truth simulation support under the accepted contract; do not spend final worlds on an unjustified population/target or claim a completed research cycle.'}
assert record['unique_tests_passed']==120
assert record['live_ledger_sha256']==previous['live_ledger_sha256']
target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
doc=subprocess.run([sys.executable,'-B','docs/reviews/verify_retail_contract.py'],cwd=root,capture_output=True,text=True,timeout=60)
(work/'documentation.log').write_text(doc.stdout+doc.stderr,encoding='utf-8')
assert doc.returncode==0,doc.stdout+doc.stderr
record['checks'].append({'command':'python -B docs/reviews/verify_retail_contract.py','exit_code':0,
    'includes':'verify_system_model and git diff --check','result':json.loads(doc.stdout)})
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
    paths=set(root.glob('trading_researcher/*.py'))|{root/name for name in changed}
    paths|={work/'baseline.json',work/'documentation.log',Path(__file__)}
    for path in sorted(paths):bundle.write(path,str(path.relative_to(root)).replace('\\','/'))
record['evidence_archive_sha256']=sha(archive)
record['archive_scope']='Application source, affected tests/guides, independent review and preservation/check metadata; no credentials, raw registry or private market data.'
record['status']='PASS_BOUNDED_OWNED_SINGLE_CLAIM_RUNNER'
target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
# Fresh check after the last authored code/document helper; no product mutation follows.
fresh=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','tests','-p','test_calibration_study.py'],
    cwd=root,capture_output=True,text=True,timeout=60)
(work/'final-focused.log').write_text(fresh.stdout+fresh.stderr,encoding='utf-8')
assert fresh.returncode==0,fresh.stdout+fresh.stderr
git=subprocess.run(['git','diff','--check'],cwd=root,capture_output=True,text=True)
(work/'git-diff-check.log').write_text(git.stdout+git.stderr,encoding='utf-8')
assert git.returncode==0,git.stdout+git.stderr
assert all(sha(root/name)==value for name,value in pins.items())
assert all(sha(root/name)==value for name,value in preserved.items())
print(json.dumps({'status':record['status'],'unique_tests_passed':120,'independent_new_tests':10,
    'preserved_baseline_files':len(preserved),'documentation_exit':doc.returncode,
    'fresh_focused_exit':fresh.returncode,'git_diff_check_exit':git.returncode,'new_provider_calls':0}))
