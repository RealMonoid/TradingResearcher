"""Author fixed compilation expectations from contracts, never a calculator result.

Only standard-library JSON/copy/time/hash operations are used. Do not import the
compiler, validator, expression engine, outcome engine, or existing TestCases.
"""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
fixture_path = root / 'tests/fixtures/composition_conformance_cases.json'
note_path = root / 'tests/fixtures/composition_conformance_expectations.md'
old_path = root / 'tests/fixtures/reference_binding_cases.json'
old_bytes = old_path.read_bytes()
assert hashlib.sha256(old_bytes).hexdigest() == '484bf3f73850760502e41d1cdf070c4cd666dc2c384805cfed99cfc3598859f6'
baseline = json.loads(old_bytes)['baseline']
catalog = deepcopy(baseline['catalog'])
close = 'BTCUSDT.close@binance-spot-15m-v1'
volume = 'BTCUSDT.volume@binance-spot-15m-v1'
price_unit = 'USDT/BTC'

def identity(value):
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    return hashlib.sha256(raw).hexdigest()

def literal(value, kind='real', unit=price_unit):
    return {'op': 'literal', 'type': kind, 'unit': unit, 'value': value}

def feature(ref=close):
    return {'op': 'feature', 'ref': ref}

def binary(op, left, right):
    return {'op': op, 'left': left, 'right': right}

def shift(op, bars, arg):
    return {'op': op, 'bars': bars, 'arg': arg}

def program(expression):
    return {'schema': 'research-ast/1', 'catalog_hash': identity(catalog), 'expression': deepcopy(expression)}

def description(kind, unit, refs, paths):
    # Values are supplied explicitly by each handwritten case, never inferred.
    return {'type': kind, 'unit': unit, 'feature_refs': refs, 'parameter_paths': paths}

scope_expr = literal(True, 'boolean', None)
condition_expr = binary('gt', feature(), literal('101'))
outcome_expr = feature()
scope_desc = description('boolean', None, [], ['/expression/value'])
condition_desc = description('boolean', None, [close], ['/expression/right/value'])
outcome_desc = description('real', price_unit, [close], [])
cases = []

def accepted(name, *, scope=scope_expr, condition=condition_expr, outcome=outcome_expr,
             descriptions=None, refs=None, scale='quantity', unit=price_unit, horizon=1,
             start='2020-01-01T01:00:00Z', end='2020-01-01T02:00:00Z', instruments=None,
             data_start='2020-01-01T00:00:00Z', data_end='2020-01-01T03:00:00Z',
             data_instruments=None, row_start='2020-01-01T01:00:00Z', warmup=0,
             unavailable=0, rows=4, count=4, rationale):
    refs = [close] if refs is None else refs
    instruments = ['BTCUSDT'] if instruments is None else instruments
    data_instruments = instruments if data_instruments is None else data_instruments
    descriptions = [scope_desc, condition_desc, outcome_desc] if descriptions is None else descriptions
    candidate = deepcopy(baseline['candidate'])
    candidate.update(scope_ast=program(scope), condition_ast=program(condition),
        outcome={'program': program(outcome), 'scale': scale}, feature_refs=deepcopy(refs),
        test_universe={'start': start, 'end': end, 'instruments': deepcopy(instruments),
                       'data_snapshot_ref': 'fixture:composition-data'},
        horizons={'grid_seconds': 900, 'outcome_bars': horizon})
    candidate['estimand']['unit'] = unit
    paths = ['/horizons/outcome_bars']
    for prefix, desc in zip(('/scope_ast', '/condition_ast', '/outcome/program'), descriptions):
        paths.extend(prefix + path for path in desc['parameter_paths'])
    candidate['parameter_origins'] = [
        {'path': path, 'basis': 'preexisting_specification', 'source_refs': [],
         'rationale': 'Independently fixed synthetic composition case; no observed outcome selection.'}
        for path in paths]
    payload = {'formalization_id': 'fixture:composition-formalization', 'candidate': candidate,
        'catalog': deepcopy(catalog), 'data_manifest': {'universe': {'start': data_start,
            'end': data_end, 'instruments': deepcopy(data_instruments)}},
        'as_of': '2024-01-01T00:00:00Z', 'max_steps': 10000}
    # Request identity is a declared field mapping, not a computed result oracle.
    request = {'schema': 'reference-case-request/1', 'candidate_ref': payload['formalization_id'],
        'data_snapshot_ref': candidate['test_universe']['data_snapshot_ref'],
        'scope_program': deepcopy(candidate['scope_ast']),
        'condition_program': deepcopy(candidate['condition_ast']),
        'outcome_program': deepcopy(candidate['outcome']['program']), 'outcome_scale': scale,
        'horizon_bars': horizon, 'universe': {'start': start, 'end': end, 'instruments': deepcopy(instruments)},
        'as_of': payload['as_of'], 'max_steps': payload['max_steps']}
    expected = {'request': request, 'candidate_hash': identity(candidate),
        'programs': dict(zip(('scope_program', 'condition_program', 'outcome_program'), deepcopy(descriptions))),
        'feature_refs': sorted(refs), 'row_window': {'start': row_start, 'end': end, 'instruments': sorted(instruments)},
        'warmup_seconds': warmup, 'unavailable_warmup_seconds': unavailable,
        'maximum_input_rows': rows, 'expected_case_count': count, 'outcome_unit': unit,
        'scientific_readiness': False}
    entry = {'name': name, 'payload': payload, 'expected': expected, 'derivation': rationale}
    cases.append(entry)
    return entry

base = accepted('direct_price_quantity', rationale='Four decision instants, no lookback: [01:00,02:00), one instrument, four loaded rows. Boolean scope/condition have null units; quantity outcome retains USDT/BTC.')
decision = binary('gt', shift('lag', 2, shift('trailing_mean', 3, feature())), literal('101'))
decision_desc = description('boolean', None, [close],
    ['/expression/left/bars', '/expression/left/arg/bars', '/expression/right/value'])
accepted('nested_decision_lag_window', condition=decision,
    descriptions=[scope_desc, decision_desc, outcome_desc], row_start='2020-01-01T00:00:00Z',
    warmup=3600, rows=8,
    rationale='Lag 2 plus trailing window 3 needs 2+(3-1)=4 prior bars = 3600 seconds. At start 01:00 this begins 00:00; eight rows to 02:00, four decision cases.')
accepted('clamped_decision_warmup_remains_explicit', condition=decision,
    descriptions=[scope_desc, decision_desc, outcome_desc], data_start='2020-01-01T00:30:00Z',
    row_start='2020-01-01T00:30:00Z', warmup=3600, unavailable=1800, rows=6,
    rationale='The same four-bar requirement begins at 00:00 but the retained snapshot begins 00:30. Keep 3600 required seconds and 1800 unavailable seconds, load six rows, and do not invent earlier data.')
future_expression = shift('lag', 4, shift('trailing_mean', 4, feature()))
future_desc = description('real', price_unit, [close], ['/expression/bars', '/expression/arg/bars'])
accepted('outcome_lookback_relative_to_future_anchor', outcome=future_expression,
    descriptions=[scope_desc, condition_desc, future_desc], horizon=2,
    start='2020-01-01T01:30:00Z', end='2020-01-01T02:30:00Z', row_start='2020-01-01T00:15:00Z',
    warmup=4500, rows=9,
    rationale='Outcome lag 4 plus window 4 spans seven bars before its future anchor. Horizon two leaves five pre-decision bars = 4500 seconds. From 01:30 load back to 00:15: nine rows to 02:30. Existing runtime REVIEW_REQUIRED rules remain unchanged.')
accepted('horizon_offsets_all_outcome_lookback', outcome=future_expression,
    descriptions=[scope_desc, condition_desc, future_desc], horizon=9,
    start='2020-01-01T01:30:00Z', end='2020-01-01T02:30:00Z', row_start='2020-01-01T01:30:00Z',
    rationale='Nine future-anchor bars exceed the seven-bar outcome lookback, so none is required before the decision. This does not assert that any outcome fits the partition or is mature.')
accepted('decision_and_outcome_require_maximum_not_sum', condition=decision, outcome=future_expression,
    descriptions=[scope_desc, decision_desc, future_desc], horizon=2,
    start='2020-01-01T01:30:00Z', end='2020-01-01T02:30:00Z', row_start='2020-01-01T00:15:00Z',
    warmup=4500, rows=9,
    rationale='The four-bar decision dependency and five-bar pre-decision outcome dependency share the same available history. Their union needs max(4,5)=5 bars, not nine.')
binary_outcome = binary('gt', feature(), shift('lag', 1, feature()))
accepted('binary_outcome_keeps_boolean_program_and_ratio_estimand', outcome=binary_outcome,
    descriptions=[scope_desc, condition_desc,
        description('boolean', None, [close], ['/expression/right/bars'])], scale='binary_probability', unit='ratio',
    rationale='The future-anchor comparison is Boolean with null program unit. The resulting probability contrast is explicitly dimensionless ratio. One lag at a one-bar future anchor adds no pre-decision warmup.')
separate_scope = binary('gt', feature(volume), literal('0', unit='BTC'))
return_expression = binary('sub', binary('div', feature(), shift('lag', 1, feature())), literal('1', unit='ratio'))
accepted('per_program_feature_units_and_parameter_paths', scope=separate_scope, outcome=return_expression,
    descriptions=[description('boolean', None, [volume], ['/expression/right/value']), condition_desc,
        description('real', 'ratio', [close], ['/expression/left/right/bars', '/expression/right/value'])],
    refs=[close, volume], unit='ratio',
    rationale='Volume appears only in scope, price in condition/outcome. Same-price-unit division gives ratio, then subtract ratio one. Exact per-program closures and pointer paths must not be replaced by the common union.')
hidden = binary('and', literal(False, 'boolean', None),
    binary('gt', shift('lag', 3, feature()), literal('101')))
accepted('nondecisive_boolean_branch_stays_in_static_closure', condition=hidden,
    descriptions=[scope_desc, description('boolean', None, [close],
        ['/expression/left/value', '/expression/right/left/bars', '/expression/right/right/value']), outcome_desc],
    row_start='2020-01-01T00:15:00Z', warmup=2700, rows=7,
    rationale='False AND a comparison may determine a value, but static validation and declared dependencies include both branches. The three-bar lag needs 2700 seconds and seven input rows; no branch erasure is allowed.')
literal_desc = description('real', 'ratio', [], ['/expression/value'])
literal_case = accepted('typed_null_literal_does_not_invent_a_feature', condition=scope_expr,
    outcome=literal(None, unit='ratio'), descriptions=[scope_desc, scope_desc, literal_desc], refs=[], unit='ratio',
    rationale='A typed missing ratio literal has a real ratio type and its own parameter pointer, but no feature dependency. Compilation makes no claim that the missing outcome becomes eligible.')
accepted('request_order_and_sorted_row_window_are_distinct', condition=scope_expr,
    outcome=literal(None, unit='ratio'), descriptions=[scope_desc, scope_desc, literal_desc], refs=[], unit='ratio',
    instruments=['ETHUSDT', 'BTCUSDT'], rows=8, count=8,
    rationale='Keep the original requested instrument order in the immutable request. The loader window is sorted BTCUSDT,ETHUSDT. Four grid instants times two instruments produce eight input rows and cases.')
origin = datetime(2020, 1, 1, tzinfo=timezone.utc)
stamp = lambda bars: (origin + timedelta(seconds=900 * bars)).strftime('%Y-%m-%dT%H:%M:%SZ')
edge = accepted('exact_input_row_limit_without_warmup', condition=scope_expr,
    outcome=literal(None, unit='ratio'), descriptions=[scope_desc, scope_desc, literal_desc], refs=[], unit='ratio',
    instruments=['BTCUSDT', 'ETHUSDT'], start=stamp(1), end=stamp(50001), data_end=stamp(50001),
    row_start=stamp(1), rows=100000, count=100000,
    rationale='Exactly 50000 decision instants times two instruments equals the existing 100000-row limit. No input rows are added when all programs have zero lookback. UTC formatting uses only standard-library calendar arithmetic.')

def rejected(name, mutate, error_type='Invalid', code=None, original=base, rationale=''):
    payload = deepcopy(original['payload'])
    mutate(payload)
    error = {'type': error_type}
    if code is not None:
        error['code'] = code
    cases.append({'name': name, 'payload': payload, 'error': error, 'derivation': rationale})

rejected('program_catalog_identity_mismatch', lambda p: p['candidate']['condition_ast'].update(catalog_hash='0' * 64),
    'ExpressionGap', 'FEATURE_GAP', rationale='Every program must bind the exact supplied catalog, independently of whether its features appear in another program.')
rejected('future_access_cannot_hide_in_false_branch', lambda p: p['candidate']['condition_ast'].update(
    expression=binary('and', literal(False, 'boolean', None), {'op': 'future', 'arg': feature()})),
    'ExpressionGap', 'TEMPORAL_GAP', rationale='The existing temporal prohibition is static and applies even in a nondecisive Boolean branch.')
rejected('unknown_feature_cannot_hide_in_false_branch', lambda p: p['candidate']['condition_ast'].update(
    expression=binary('and', literal(False, 'boolean', None), binary('gt', feature('unregistered@1'), literal('101')))),
    'ExpressionGap', 'FEATURE_GAP', rationale='A missing version definition remains a feature gap even when Boolean values could short-circuit.')
rejected('incompatible_units_in_composed_outcome', lambda p: p['candidate']['outcome']['program'].update(
    expression=binary('add', feature(), feature(volume))),
    'ExpressionGap', 'TYPE_GAP', rationale='USDT/BTC plus BTC is not the approved same-unit addition.')
rejected('estimand_unit_must_match_quantity_program', lambda p: p['candidate']['estimand'].update(unit='ratio'),
    rationale='A price quantity outcome cannot silently become a dimensionless contrast.')
rejected('declared_feature_closure_has_unused_member', lambda p: p['candidate'].update(feature_refs=[close, volume]),
    rationale='Declaring an unused extra feature is not exact dependency closure.')
rejected('declared_feature_closure_omits_used_member', lambda p: p['candidate'].update(feature_refs=[]),
    rationale='A used versioned price feature cannot disappear from the declared closure.')
rejected('real_scope_is_not_boolean_scope', lambda p: p['candidate'].update(scope_ast=program(literal('1', unit='ratio'))),
    rationale='Scalar one cannot be coerced into Boolean true at the composition boundary.')
rejected('binary_scale_rejects_real_outcome', lambda p: (p['candidate']['outcome'].update(scale='binary_probability'),
    p['candidate']['estimand'].update(unit='ratio')),
    rationale='Binary probability requires an actual Boolean outcome program; a real-valued price is not implicitly converted.')
rejected('off_grid_universe_is_not_rounded', lambda p: p['candidate']['test_universe'].update(start='2020-01-01T01:00:01Z'),
    rationale='The binding loader requires exact 900-second boundaries; it must not silently round the declared candidate start.')
rejected('candidate_universe_cannot_precede_snapshot', lambda p: p['data_manifest']['universe'].update(start='2020-01-01T01:15:00Z'),
    rationale='The exact candidate interval must lie inside the retained snapshot interval.')
rejected('candidate_instrument_must_belong_to_snapshot', lambda p: p['candidate']['test_universe'].update(instruments=['ETHUSDT']),
    rationale='The compiler cannot select an instrument absent from the supplied snapshot universe.')
def add_one_warmup_bar(p):
    p['candidate']['condition_ast'] = program(shift('lag', 1, scope_expr))
rejected('warmup_cannot_silently_exceed_input_row_limit', add_one_warmup_bar, original=edge,
    rationale='The 100000 expected cases already use 50000 grid instants for two instruments. One earlier warmup instant adds two rows, so the required 100002 inputs exceed the existing limit. Do not truncate or label the plan complete.')
rejected('boolean_step_budget_is_not_integer_budget', lambda p: p.update(max_steps=True),
    'ExpressionGap', 'RESOURCE_GAP', rationale='Python Boolean/integer compatibility must not override the explicit positive integer resource contract.')

source_paths = ['trading_researcher/EXPRESSIONS.md', 'trading_researcher/OUTCOMES.md',
    'trading_researcher/BINDING.md', 'docs/architecture/14_RETAIL_RESEARCH_CONTRACT.md',
    'tests/fixtures/reference_binding_cases.json', 'tests/fixtures/reference_binding_expectations.md']
result = {'schema': 'composition-conformance-cases/1',
    'scope': 'Static composition of existing research-ast/1 primitives and bound-reference/1 request/window mapping only.',
    'authorship': 'Independently derived from contracts and hand-counted grid intervals. The reviewer had inspected the existing implementation before authorship; no compiler or calculator was invoked to generate expected results.',
    'source_sha256': {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in source_paths},
    'cases': cases}
assert len(cases) == 26 and sum('expected' in c for c in cases) == 12
with fixture_path.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')

note = '''# Independent static composition expectations

The fixed `composition-conformance-cases/1` bundle contains twelve accepted static
compilations and fourteen explicit rejections. It covers the extra binding driver;
it does not replace the already pinned expression, outcome or raw-feature cases.
All expected program types, units, feature closures, parameter-pointer lists and
window counts were assigned from the existing specifications and simple grid
arithmetic. No compiler, calculator, validator or existing TestCase was invoked
to produce an expected value. The author had already read the current binding
implementation while identifying the missing certification boundary; that prior
inspection is disclosed, not described as a blind implementation review.

## Fixed derivation

The ordinary universe [01:00,02:00) has four 15-minute decision instants per
instrument. A lag of L bars adds L prior bars; a trailing window of W bars adds
W-1 prior bars. Nested operators add along their path; alternative branches need
the maximum span, not the sum. A future outcome anchor H bars after the decision
offsets H bars of the outcome expression's lookback when choosing pre-decision
input rows. Therefore required warmup is the maximum of decision span and the
nonnegative outcome span minus H, multiplied by 900 seconds.

Lag 2 around a trailing mean of 3 needs four prior bars. At 01:00 this reaches
00:00, hence eight input rows through 02:00. If the snapshot begins at 00:30,
required warmup remains 3600 seconds, unavailable warmup is 1800 seconds, and six
rows may be loaded. Outcome lag 4 around a window of 4 needs seven bars before its
anchor. Horizon two leaves five pre-decision bars. At 01:30 this reaches 00:15;
nine rows reach the 02:30 exclusive end. Combining that outcome with four-bar
decision warmup still needs five bars, not nine. A horizon of nine leaves no
pre-decision outcome warmup. These calculations do not remove existing outcome
`REVIEW_REQUIRED`, partition-boundary or missing-value behavior.

Per-program feature sets are distinct from their combined union. The volume-scope
and price-condition case verifies their separate attribution. Program Boolean
units are null; a binary-probability contrast nevertheless uses `ratio`. Price
divided by same-unit lagged price yields ratio, and subtracting ratio one preserves
that unit. Literal and shift/window pointers name their exact positions in each
program. The explicit false-AND branch retains both its declared feature and lag:
static validation cannot drop branches based on potentially nondecisive values.

The typed-null literal has a known real/ratio type but no feature dependency; this
does not convert a missing outcome into an eligible observation. Two-instrument
cases preserve request ordering but sort the row-loader universe and multiply
grid counts by two. Exactly 50000 decision instants for two instruments meet the
100000-row bound; adding one pre-decision warmup instant requires 100002 rows and
must reject without truncation. Calendar strings are formatted using standard
UTC date arithmetic, not an implementation calculation.

## Harness and identity contract

Each case has a complete six-field `compile_payload` input. The synthetic
`data_manifest` contains the static universe projection consumed by that compiler;
it is not an admitted data snapshot or a claim about source rights/availability.
Candidates retain the existing H_exec field shape. Accepted-case parameter
origins are populated from the separately assigned expected pointer lists; the
bundle does not assert natural-language equivalence or genuine registry ownership.
Artifact aliases are fixed input strings for pure compilation only. A controller
integration must separately bind genuine immutable owned records.

Catalog/program/candidate hashes use the documented sorted compact JSON identity
encoding. Those hashes only bind inputs. The expected request maps the declared
input fields directly and copies the original programs without rewriting them.
The rest of each accepted expected object is a fixed independent oracle. Compare
all listed fields, including every program's complete metadata; checking only a
global feature union or self-consistent row count is insufficient.

Rejection cases name `Invalid` or `ExpressionGap` and, where fixed by the existing
expression/outcome interface, its exact gap code. Arbitrary exceptions, crashes,
timeouts or missing cases are not successful expected rejections. Validations must
exercise every named case and preserve the fixture bytes. These cases supplement
rather than weaken the existing fixed primitive resource and temporal checks.

## Certification boundary

A passing fixed driver suite establishes only its exercised static composition
contract under research-contract/1.0 section 14. Separately recompiling the exact
candidate with that same retained package checks binding/replay, not an independent
oracle. A genuine host certificate must also bind the original compiled object,
the exact feature definitions/certificate, reference certificate, binding package,
validator and this unchanged fixture; check their current usable dependencies and
retain interrupted/failing attempts. No row or outcome access is needed here.

Composition conformance must not infer H_idea/H_exec meaning equivalence, data/PIT
truth, rights, training exposure, dependence adequacy, empirical support, complete
scientific readiness or capital authority. Unknown/new primitive meanings stay a
gap for review. Existing numerical, time, missingness and estimator definitions
are unchanged. Unsupported original ideas and all historical failures remain.
'''
with note_path.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(note)
print(json.dumps({'cases': len(cases), 'accepted': 12, 'rejected': 14,
    'fixture_sha256': hashlib.sha256(fixture_path.read_bytes()).hexdigest(),
    'note_sha256': hashlib.sha256(note_path.read_bytes()).hexdigest()}))
