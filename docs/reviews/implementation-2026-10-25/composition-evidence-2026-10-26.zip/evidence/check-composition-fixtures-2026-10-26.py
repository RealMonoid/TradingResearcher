"""Check already frozen independent expectations; never regenerate them."""
import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
path = root / 'tests/fixtures/composition_conformance_cases.json'
raw = path.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'b28025c09fb9292998328fc698aa06f2ab0275ced8a74d0370d38437551baa64'
from trading_researcher.binding import compile_payload
from trading_researcher.codec import Invalid

results = []
for case in json.loads(raw)['cases']:
    expected_error = case.get('error')
    try:
        result = compile_payload(case['payload'])
    except Invalid as exc:
        passed = expected_error is not None and type(exc).__name__ == expected_error['type']
        if expected_error and 'code' in expected_error:
            passed = passed and getattr(exc, 'code', None) == expected_error['code']
        results.append({'name': case['name'], 'passed': passed, 'actual_error': type(exc).__name__,
                        'code': getattr(exc, 'code', None), 'message': str(exc)})
    else:
        differences = [] if expected_error else [key for key, value in case['expected'].items() if result.get(key) != value]
        results.append({'name': case['name'], 'passed': expected_error is None and not differences,
                        'differing_fields': differences})
assert hashlib.sha256(path.read_bytes()).hexdigest() == hashlib.sha256(raw).hexdigest()
record = {'schema': 'independent-composition-fixture-observation/1',
    'fixture_sha256': hashlib.sha256(raw).hexdigest(), 'total': len(results),
    'passed': sum(row['passed'] for row in results), 'results': results}
out = root / '.trf-runtime/composition-fixture-observation-2026-10-26.json'
with out.open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(record, indent=2) + '\n')
print(json.dumps({'total': record['total'], 'passed': record['passed'],
                  'failures': [r for r in results if not r['passed']]}))
raise SystemExit(0 if all(row['passed'] for row in results) else 1)
