"""Freeze the bounded source-view and candidate-research checkpoint."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import unquote
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
OUT = ROOT / 'docs/reviews/implementation-2026-10-25'


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, obj): path.write_text(json.dumps(obj, indent=2) + '\n', encoding='utf-8')


def main():
    target = OUT / 'context-efficiency-verification.json'
    if target.exists(): raise RuntimeError('Frozen checkpoint must not be overwritten')
    protected = {str(p.relative_to(ROOT)): sha(p) for p in OUT.iterdir()
                 if p.suffix in ('.json', '.zip') and p.name != 'progress.json'}
    baseline = json.loads((WORK / 'baseline.json').read_text(encoding='utf-8-sig'))
    modified = {'trading_researcher/researcher.py', 'trading_researcher/research_calls.py'}
    preserved_runtime = {}
    for row in baseline:
        p = Path(row['path']); relative = p.relative_to(ROOT).as_posix()
        if relative not in modified:
            assert sha(p) == row['sha256'], relative
            preserved_runtime[relative] = row['sha256']
    observation = json.loads((WORK / 'preflight.json').read_text(encoding='utf-8'))
    ledger = ROOT / '.trf-runtime/openai-integration-budget.sqlite3'
    assert sha(ledger) == observation['paid_ledger_sha256']
    (OUT / 'context-efficiency-observation.json').write_bytes((WORK / 'preflight.json').read_bytes())
    progress = json.loads((OUT / 'progress.json').read_text(encoding='utf-8'))
    next_action = ('Evaluate bounded genuine provider/measurement behavior with explicit source-access gaps; '
        'the optional view removes the initial context bottleneck but equal research quality remains unverified. '
        'Retain the same aggregate OpenAI spend ledger, exact identities/times and scientific admission boundaries. '
        'Continue the remaining seven packages without treating a retrieval benchmark as scientific evidence.')
    progress['next_action'] = next_action
    progress['packages'][1]['remaining_action'] = next_action
    progress['packages'][1]['evidence'] += [str((OUT / name).relative_to(ROOT)).replace('\\', '/') for name in (
        'context-efficiency-verification.json', 'TOKEN_EFFICIENCY_RESEARCH_2026-10-25.md',
        'USER_TOOL_CANDIDATES_2026-10-25.md')]
    progress['continuation_audit']['basis'] = ('Measured 43730 full versus 3456 optional-view initial tokens; '
        'implemented exact authenticated provenance pages and reviewed four user-supplied tools. '
        'No new inference or software installation. Complete seven-package objective remains active.')
    progress['controls']['evidence-gate'] = {'status': 'CHECKING', 'evidence': 'Final bounded context checks running.'}
    progress['token_usage']['context_efficiency_observation'] = 'docs/reviews/implementation-2026-10-25/context-efficiency-observation.json'
    write(OUT / 'progress.json', progress)
    summary = OUT / 'IMPLEMENTATION_SUMMARY_2026-10-25.md'
    with summary.open('a', encoding='utf-8') as stream:
        stream.write('\n## Token efficiency and user-supplied software candidates\n\n'
            'Reviewed official caching/counting documentation, academic prompt-compression/context studies, '
            'and the user-supplied OmniRoute, Codesight, Boost and Code Context Engine repositories. '
            'The [candidate review](USER_TOOL_CANDIDATES_2026-10-25.md) separates development navigation '
            'from research-runtime changes; none of the four was installed or connected. '
            'Added optional versioned source views and authenticated exact list pages without changing '
            'legacy profiles, source artifacts, inherited exposure or calculator code. '
            'The same real-data initial input counted 3,456 rather than 43,730 tokens including the additional tool, '
            'with exact local reconstruction and no inference dispatch. This does not establish whole-epoch savings '
            'or unchanged research quality. The [verification record](context-efficiency-verification.json) '
            'retains independent cases, integration checks, corrected test-fixture errors, a fixed schema-admission '
            'type inconsistency, and remaining boundaries. The USD5 aggregate ledger remains unchanged.\n')
    changed = [
        'trading_researcher/context_views.py', 'trading_researcher/researcher.py',
        'trading_researcher/research_calls.py', 'trading_researcher/RESEARCHER.md',
        'tests/test_context_views.py', 'tests/test_context_views_adversarial.py',
        'docs/architecture/CURRENT_STATE.md', *[str((OUT / name).relative_to(ROOT)).replace('\\', '/') for name in (
            'TOKEN_EFFICIENCY_RESEARCH_2026-10-25.md', 'USER_TOOL_CANDIDATES_2026-10-25.md',
            'context-views-review.json', 'context-efficiency-observation.json',
            'context-efficiency-verification.json', 'context-efficiency-evidence.zip',
            'progress.json', 'IMPLEMENTATION_SUMMARY_2026-10-25.md')]]
    report = {'schema': 'context-efficiency-verification/1', 'status': 'CHECKING', 'changed_files': changed,
        'scope': 'Explicit optional presentation and exact authorized list retrieval; web/GitHub candidate review.',
        'observed_at_utc': datetime.now(timezone.utc).isoformat(), 'checks': [],
        'prior_runtime_files_unchanged': preserved_runtime, 'protected_prior_artifacts': protected,
        'observed_initial_tokens': {'full': 43730, 'view_with_section_tool': 3456, 'difference': 40274},
        'inference_calls_added': 0, 'reported_consumed_tokens_unchanged': 2172,
        'conservative_nano_usd_unchanged': 6435000, 'software_installed': [],
        'initial_failures': [
            {'kind': 'test invocation', 'exit_code': 1, 'cause': 'tests is not an importable package; corrected to unittest discovery.'},
            {'kind': 'parent fixture', 'exit_code': 1, 'cases': 3,
             'cause': 'Scope metadata requires strings; changed fixture resolution_seconds from integer to string.'},
            {'kind': 'independent fixture and admitted schema type mismatch', 'evidence': 'context-views-review.json'}],
        'unverified': ['Equal research quality and complete relevant-source access under finite budgets',
            'Total tokens/cost over a genuine multi-turn research epoch', 'Provider cache-hit economics and invoice reconciliation',
            'Immutable served model snapshot for count-only responses', 'Full backtest/scientific validity',
            'Installation, security, integration and quality claims of the four external candidate projects']}
    write(target, report)
    checks = [(name, [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tests', '-p', pattern])
              for name, pattern in [('context-tests', 'test_context_views*.py'),
                                    ('research-regressions', 'test_research*.py'),
                                    ('measurement-regressions', 'test_measurements*.py')]]
    checks += [('retail-contract', [sys.executable, '-B', 'docs/reviews/verify_retail_contract.py']),
               ('system-model', [sys.executable, '-B', 'docs/reviews/verify_system_model.py']),
               ('git-diff-check', ['git', 'diff', '--check']),
               ('usage-cli', [sys.executable, '-B', '-m', 'trading_researcher', 'openai-usage', '--ledger', str(ledger)])]
    unique_tests = 0
    for name, command in checks:
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, encoding='utf-8', errors='replace')
        log = result.stdout + result.stderr
        (WORK / (name + '.log')).write_text(log, encoding='utf-8')
        check = {'name': name, 'command': command, 'exit_code': result.returncode,
                 'log': str((WORK / (name + '.log')).relative_to(ROOT)).replace('\\', '/')}
        match = re.search(r'Ran (\d+) tests in ([\d.]+)s', log)
        if match:
            check.update(tests=int(match[1]), seconds=match[2]); unique_tests += int(match[1])
        report['checks'].append(check); write(target, report)
        if result.returncode: raise RuntimeError(name + ' failed; evidence retained')
        if name == 'usage-cli':
            previous = json.loads((OUT / 'provider-identity-observation.json').read_text(encoding='utf-8'))
            assert json.loads(result.stdout) == previous['report']
    assert unique_tests == 65, unique_tests
    for relative in changed:
        p = ROOT / relative
        if p.suffix not in ('.py', '.md'): continue
        source = p.read_text(encoding='utf-8')
        assert all(line == line.rstrip() for line in source.splitlines()), relative
        if p.suffix == '.md':
            for link in re.findall(r'\]\(([^)]+)\)', source):
                link = link.strip('<>').split('#')[0]
                if not link or re.match(r'^[a-z]+://', link): continue
                assert (p.parent / unquote(link)).exists(), (relative, link)
    assert sha(ledger) == observation['paid_ledger_sha256']
    assert all(sha(ROOT / name) == expected for name, expected in protected.items())
    progress['controls']['evidence-gate'] = {'status': 'SATISFIED', 'evidence':
        '65 unique focused/regression cases passed, including21 independently authored cases. '
        'Exact real-source reconstruction and actual count-only HTTP comparison passed; paid ledger unchanged. '
        'Documentation checks passed; quality equivalence and whole-epoch savings remain unverified.'}
    write(OUT / 'progress.json', progress)
    sources = [*ROOT.joinpath('trading_researcher').glob('*.py'), *ROOT.joinpath('tests').glob('*.py'),
               *WORK.glob('*.py'), *WORK.glob('*.json'), *WORK.glob('*.log'),
               *ROOT.joinpath('.trf-runtime/context-views-independent-review-2026-10-25').glob('*'),
               ROOT / '.trf-runtime/openai-adapter-checks-2026-10-25/full-context-preflight.json',
               *[ROOT / name for name in changed if (ROOT / name).exists()
                 and not name.endswith(('context-efficiency-verification.json', '.zip'))]]
    sources = sorted(set(p for p in sources if p.is_file()))
    archive = OUT / 'context-efficiency-evidence.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as bundle:
        for p in sources: bundle.write(p, p.relative_to(ROOT).as_posix())
    report.update(status='PASS_BOUNDED_CONTEXT_PRESENTATION', unique_tests=65, independent_subset=21,
        evidence_archive_sha256=sha(archive),
        source_hashes={p.relative_to(ROOT).as_posix(): sha(p) for p in sources},
        authored_whitespace_and_links='PASS', paid_ledger_bytes_preserved=True)
    write(target, report)
    final = subprocess.run(['git', 'diff', '--check'], cwd=ROOT, capture_output=True, text=True)
    assert final.returncode == 0
    print(json.dumps({'status': report['status'], 'unique_tests': 65, 'independent_subset': 21,
        'documentation_exit_code': 0, 'prior_runtime_files_unchanged': len(preserved_runtime),
        'protected_artifacts_unchanged': len(protected), 'paid_ledger_unchanged': True,
        'report': str(target)}))


if __name__ == '__main__': main()
