"""Count the optional view through owned RPC; never dispatch inference."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import threading
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from trading_researcher.codec import canonical, decode, digest, integer
from trading_researcher.context_views import DEFER_PATHS, VIEW_VERSION, source_section, source_view
from trading_researcher.coordination import Broker
from trading_researcher.openai_provider import OpenAIResponsesProvider, _key, _post, provider_identity, wire_request
from trading_researcher.researcher import CONTEXT_TOOL_DEFINITIONS, run_research_once
from trading_researcher.server import Client, LocalServer


class CountOnlyProvider(OpenAIResponsesProvider):
    def complete(self, request, ordinal, timeout):
        wire = wire_request(request, self.config)
        data = {key: wire[key] for key in ('model', 'input', 'tools', 'reasoning', 'text', 'parallel_tool_calls')}
        result, request_id = _post('/v1/responses/input_tokens', data, _key(self.key_file), time.monotonic() + timeout)
        assert result['object'] == 'response.input_tokens'
        return {'response': {'status': 'preflight_complete', 'provider_id': 'openai.responses.input_tokens/1',
            'counted_input_tokens': integer(result['input_tokens'], 'count'), 'transport_request_id': request_id,
            'count_request_sha256': digest(data), 'model_identity': provider_identity(),
            'observed_at_utc': datetime.now(timezone.utc).isoformat(), 'inference_dispatched': False},
            'usage': {'input_tokens': 0, 'output_tokens': 0, 'cost_units': 0}}


def main():
    work = Path(__file__).resolve().parent
    target = work / 'preflight.json'
    if target.exists():
        raise RuntimeError('Retained comparison must not be repeated or overwritten')
    old_path = ROOT / '.trf-runtime/openai-adapter-checks-2026-10-25/full-context-preflight.json'
    old = json.loads(old_path.read_text(encoding='utf-8'))
    original = decode(old['request']['messages'][1]['content'])
    reconstruction = []
    projected = []
    for artifact in original['sources']:
        view = source_view(artifact)
        rebuilt = deepcopy(view['content'])
        for path in DEFER_PATHS:
            parent = rebuilt
            try:
                for key in path[:-1]: parent = parent[key]
                marker = parent[path[-1]]
            except KeyError: continue
            if type(marker) is not dict or marker.get('schema') != 'deferred-source-list/1': continue
            values, offset, pages = [], 0, 0
            while True:
                section = source_section(artifact, list(path), offset, 64)
                values.extend(section['values']); pages += 1
                if section['next_offset'] is None: break
                offset = section['next_offset']
            assert len(values) == marker['count'] and digest(values) == marker['sha256']
            parent[path[-1]] = values
            reconstruction.append({'artifact_id': artifact['id'], 'path': list(path),
                'items': len(values), 'pages': pages, 'sha256': digest(values), 'exact': True})
        assert canonical(rebuilt) == canonical(artifact)
        projected.append(view)
    ledger = ROOT / '.trf-runtime/openai-integration-budget.sqlite3'
    ledger_hash = hashlib.sha256(ledger.read_bytes()).hexdigest()
    broker = Broker(ROOT / '.trf-runtime/binance-normalized-registry-2026-10-25')
    server = LocalServer(broker)
    thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
    try:
        admin = Client(server.url, broker.admin_token, timeout=120)
        names = ['context-view-count-first', 'context-view-count-second']
        workers = {name: admin.call('register_worker', name=name, role='discovery',
                                   capabilities=['research-record/v1']) for name in names}
        context = admin.call('create_context', role='discovery', epoch=1,
                             artifact_ids=[s['id'] for s in original['sources']])
        profile = deepcopy(old['profile'])
        profile.update(source_presentation=VIEW_VERSION, tools=CONTEXT_TOOL_DEFINITIONS,
                       prompts={name: old['request']['messages'][0]['content'] for name in names})
        epoch = admin.call('create_research_epoch', key='context-view-count/1', context_id=context['id'],
                          workers=names, profile=profile)
        admin.call('enqueue', key='context-view-count/1', spec={
            'kind': 'research-record/v1', 'context_id': context['id'], 'purpose': original['purpose'],
            'allowed_workers': [names[0]], 'max_attempts': 1, 'lease_seconds': 30,
            'deadline': int(time.time()) + 180, 'dependencies': [], 'research_epoch_id': epoch['id']})
        config = profile['generation_parameters']['openai_responses']
        outcome = run_research_once(Client(server.url, workers[names[0]]['token'], timeout=120),
            CountOnlyProvider(ROOT / '.env.local', ledger, config, epoch_id=epoch['id'], worker=names[0]))
        state = admin.call('inspect_research_epoch', epoch_id=epoch['id'])
        assert len(state['calls']) == 1
        call = state['calls'][0]; response = call['reply']['response']
        assert response['status'] == 'preflight_complete' and response['inference_dispatched'] is False
        assert outcome['accepted'] is False
        expected = deepcopy(old['request'])
        expected['tools'] = CONTEXT_TOOL_DEFINITIONS
        expected['messages'][1]['content'] = canonical({**original, 'sources': projected})
        assert canonical(call['request']) == canonical(expected)
        assert hashlib.sha256(ledger.read_bytes()).hexdigest() == ledger_hash
        before = old['response']['counted_input_tokens']; after = response['counted_input_tokens']
        report = {'schema': 'context-efficiency-count-observation/1', 'status': 'PASS_COUNT_ONLY',
            'observed_at_utc': response['observed_at_utc'], 'model_identity': response['model_identity'],
            'baseline_report_sha256': hashlib.sha256(old_path.read_bytes()).hexdigest(),
            'baseline_request_sha256': digest(old['request']), 'baseline_input_tokens': before,
            'projected_input_tokens': after, 'saved_initial_input_tokens': before - after,
            'original_wire_bytes': old['wire_input_bytes'],
            'projected_wire_bytes': len(canonical(wire_request(call['request'], config)).encode('utf-8')),
            'reconstruction': reconstruction, 'epoch_id': epoch['id'], 'profile': profile,
            'request': call['request'], 'response': response, 'outcome': outcome,
            'paid_ledger_unchanged': True, 'paid_ledger_sha256': ledger_hash, 'inference_calls': 0,
            'qualification': 'Initial context only, including the new section tool. Same model, instructions, purpose and source IDs. Exact local reconstruction, not equal LLM quality or whole-epoch savings. Needed sections cost additional tokens.'}
        with target.open('x', encoding='utf-8') as stream:
            json.dump(report, stream, indent=2); stream.write('\n')
        print(json.dumps({key: report[key] for key in ('status', 'baseline_input_tokens',
            'projected_input_tokens', 'saved_initial_input_tokens', 'projected_wire_bytes',
            'paid_ledger_unchanged', 'inference_calls')}))
    finally:
        server.shutdown(); server.server_close(); thread.join(5); broker.close()


if __name__ == '__main__': main()
