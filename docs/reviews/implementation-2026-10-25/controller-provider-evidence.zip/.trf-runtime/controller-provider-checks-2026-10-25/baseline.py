"""Retain the pre-change inventory without reading credentials or runtime data."""
import hashlib
import json
from pathlib import Path

root = Path.cwd()
work = root / '.trf-runtime/controller-provider-checks-2026-10-25'
paths = [p for folder in ('trading_researcher', 'tests', 'docs/reviews/implementation-2026-10-25')
         for p in (root / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
record = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
with (work / 'baseline.json').open('x', encoding='utf-8') as out:
    json.dump(record, out, indent=2)
print(json.dumps({'files': len(record), 'output': 'baseline.json'}))
