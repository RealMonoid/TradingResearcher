"""Record this bounded checkpoint without modifying prior frozen evidence."""
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from trading_researcher.codec import canonical, digest


def save(path, value):
    with path.open('x',encoding='utf-8') as stream:
        json.dump(value,stream,indent=2)
        stream.write('\n')


def main():
    work = Path(__file__).parent
    docs = ROOT / 'docs/reviews/implementation-2026-10-25'
    live = json.loads((work/'live-result.json').read_text(encoding='utf-8'))
    review_path = docs/'controller-provider-review.json'
    assert hashlib.sha256(review_path.read_bytes()).hexdigest() == 'e54c3857bfc2856a7aceb6bed2a946d67a6b8c5f49aa3822de6739ec76cbb71c'
    assert len(live['new_provider_calls']) == 2 and all(o['accepted'] for o in live['outcomes'])
    calls = {c['dispatch_id']:c for c in live['new_provider_calls']}
    db_path = Path(live['registry'])/'registry.sqlite3'
    with sqlite3.connect(db_path.as_uri()+'?mode=ro',uri=True) as db:
        assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        def artifact(identity):
            result = json.loads(db.execute('SELECT envelope FROM artifacts WHERE id=?',(identity,)).fetchone()[0])
            assert digest(result) == identity
            return result
        for call_id,input_id,result_id in db.execute('SELECT call_id,input_id,result_id FROM provider_invocations'):
            source,result = artifact(input_id)['body'],artifact(result_id)['body']
            response = artifact(result['response_id'])['body']
            public = response['response']
            ledger = calls[public['aggregate_dispatch_id']]
            assert source['call_id'] == result['call_id'] == response['call_id'] == call_id
            assert result['input_id'] == input_id and result['response_usable'] is True
            assert result['installed_sources_unchanged'] is True
            assert source['adapter_run_id']+':0' == ledger['dispatch_id']
            assert source['request_sha256'] == digest(artifact(source['request_id'])['body']['request'])
            assert canonical(ledger['receipt']['usage']) == canonical(response['usage'])
            assert ledger['receipt']['provider_request_id'] == public['provider_request_id']
            assert ledger['receipt']['transport_request_id'] == public['transport_request_id']
            assert ledger['model_identity']['requested_model'] == ledger['model_identity']['reported_model'] == 'gpt-6.1-sol'
            assert ledger['admitted_at_utc'] and ledger['settled_at_utc']
    usage = live['aggregate_usage']
    assert usage['totals']['exact_total_tokens'] == 37372 and usage['money']['charged_nano'] == 102272500
    save(docs/'controller-provider-usage.json',usage)
    save(docs/'controller-provider-live.json',{
        'schema':'controller-provider-live-observation/1','status':'PASS_SYNTHETIC_UNSUPPORTED_IDEA_HANDOFF',
        'elapsed_seconds':live['elapsed_seconds'],'new_calls':live['new_provider_calls'],
        'epoch_usage':live['epoch_usage'],'invocation_ids':[x['id'] for x in live['invocations']],
        'formalization_id':live['outcomes'][0]['artifact_id'],'review_id':live['outcomes'][1]['artifact_id'],
        'model_review':live['artifacts'][1]['body']['review'],
        'retained_review_actual_independence_status':live['artifacts'][1]['body']['actual_independent_model_review'],
        'registry_integrity':'ok','ledger_and_request_response_binding':'PASS',
        'aggregate_ledger_sha256':live['aggregate_ledger_after_sha256'],
        'qualification':live['qualification']})
    paragraph = ('The [controller-owned provider path](../../trading_researcher/CONTROLLER_PROVIDERS.md) now binds auxiliary calls to '
        'host-selected direct adapters, exact frozen inputs, shared budgets and protected invocation records. Worker replies cannot '
        'forge these records. Two genuine OpenAI calls retained an unsupported synthetic idea and a separate model-generated review '
        'in 10.835789 seconds, using 2,288 tokens and a conservative USD 0.0071675. The aggregate ledger now contains 12 calls, '
        '37,372 tokens and USD 0.1022725 inside the approved USD 5 cap. [Verification](../reviews/implementation-2026-10-25/controller-provider-verification.json) '
        'separates software checks, actual provider execution and unresolved semantic/scientific admission. No first historical '
        'research cycle, mixed-provider live run or general research-quality claim follows.\n\n')
    path = ROOT/'docs/architecture/CURRENT_STATE.md'
    content = path.read_text(encoding='utf-8')
    content = content.replace('## Repository and existing artifacts\n\n','## Repository and existing artifacts\n\n'+paragraph,1)
    content = content.replace('the shared ledger now totals 35,084 tokens','the shared ledger at that checkpoint totaled 35,084 tokens',1)
    path.write_text(content,encoding='utf-8')
    path = ROOT/'README.md'
    content = path.read_text(encoding='utf-8').replace('## Start here\n\n',
        '## Start here\n\nThe [controller-owned direct provider path](trading_researcher/CONTROLLER_PROVIDERS.md) now retains genuine auxiliary invocation provenance independently of worker-submitted replies. Two actual OpenAI calls exercised an unsupported-idea handoff and a separate review. Total recorded framework usage is 37,372 tokens and a conservative USD 0.1022725; scientific admission remains unfinished.\n\n',1)
    content = content.replace('Cumulative provider usage is now 35,084 tokens','At that checkpoint cumulative provider usage was 35,084 tokens',1)
    path.write_text(content,encoding='utf-8')
    path = docs/'IMPLEMENTATION_SUMMARY_2026-10-25.md'
    with path.open('a',encoding='utf-8') as stream:
        stream.write('\n## Controller-owned auxiliary dispatch checkpoint\n\n'
            'Added an optional trusted-controller path for the existing OpenAI/Claude adapters, protected invocation artifacts, '
            'durable request identity and duplicate/crash handling. Worker-supplied answers cannot settle host calls. '
            'Late, changed-source, unknown-accounting and overrun results remain retained but cannot supply auxiliary completion. '
            'Exact canonical configuration comparison fixes a Boolean/integer alias found by the independent reviewer.\n\n'
            'The [live observation](controller-provider-live.json) records two real OpenAI calls on synthetic unsupported-idea input: '
            '2,288 tokens, USD 0.0071675 conservative bound, 10.835789 seconds. This gives 37,372 cumulative tokens and USD 0.1022725. '
            'Model name/catalog version/unknown immutable snapshot and per-call UTC times are in [the usage snapshot](controller-provider-usage.json). '
            'The first output was deliberately constrained; the separate review was model-generated. '
            'This is not free discovery, semantic certification, mixed-provider research or a scientific backtest. '
            '[Verification](controller-provider-verification.json) records changed files, checks and outstanding boundaries.\n')
    path = ROOT/'docs/reviews/integration-research-2026-10-24/IMPLEMENTATION_SEQUENCE_2026-10-25.md'
    content = path.read_text(encoding='utf-8').replace('verified real-provider provenance and substantive independent model assessment remain open, alongside the scientific evaluation/freeze gates.',
        'a later [controller-owned invocation path](../../../trading_researcher/CONTROLLER_PROVIDERS.md) and two actual OpenAI calls now establish bounded host-observed direct execution on a synthetic gap handoff. General semantic admission remains open, alongside scientific evaluation/freeze and the first mixed-provider research cycle.')
    path.write_text(content,encoding='utf-8')
    path = docs/'progress.json'
    progress = json.loads(path.read_text(encoding='utf-8'))
    progress['controls']['evidence-gate'] = {'status':'SATISFIED','evidence':
        '105 unique current tests PASS, including14 independently authored controller-provenance cases; two actual OpenAI auxiliary calls accepted on a synthetic unsupported-idea handoff. Exact command outcomes, source identity, usage and remaining limits are in controller-provider-verification.json. No scientific admission or full research cycle.'}
    step = next(p for p in progress['packages'] if p['step']==3)
    step['evidence'].extend(['trading_researcher/CONTROLLER_PROVIDERS.md',
        'docs/reviews/implementation-2026-10-25/controller-provider-review.json',
        'docs/reviews/implementation-2026-10-25/controller-provider-verification.json',
        'docs/reviews/implementation-2026-10-25/controller-provider-live.json'])
    step['remaining_action'] = ('Host-owned direct invocation is implemented and exercised with actual OpenAI calls on synthetic unsupported-idea input. '
        'Substantive general semantic admission, scientific data/exposure acceptance, calibrated information/evaluation profiles and atomic allocation/freeze remain open. '
        'The legacy review schema deliberately remains UNVERIFIED rather than conflating invocation provenance with semantic certification.')
    progress['continuation_audit']['basis'] = ('This continuation closes the auxiliary worker-response provenance gap with host-owned direct dispatch, '
        'independent adversarial checks and actual bounded OpenAI handoff calls. The full seven-package goal remains incomplete; scientific prerequisites remain open.')
    progress['token_usage'].update(snapshot='docs/reviews/implementation-2026-10-25/controller-provider-usage.json',
        reported_tokens=37372,conservative_nano_usd=102272500)
    path.write_text(json.dumps(progress,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'registry_and_ledger_binding':'PASS','new_calls':2,'aggregate_tokens':37372,'aggregate_nano_usd':102272500}))


if __name__=='__main__':main()
