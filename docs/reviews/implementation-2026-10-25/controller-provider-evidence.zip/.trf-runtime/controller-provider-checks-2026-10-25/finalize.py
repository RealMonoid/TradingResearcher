"""Fresh bounded gates and immutable evidence for the controller dispatch change."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import unquote
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).parent
DOCS = ROOT/'docs/reviews/implementation-2026-10-25'
REPORT = DOCS/'controller-provider-verification.json'
CHANGED = [
    'trading_researcher/controller_providers.py','trading_researcher/coordination.py',
    'trading_researcher/research_calls.py','trading_researcher/auxiliary.py',
    'trading_researcher/storage.py','trading_researcher/memory.py',
    'tests/controller_provider_support.py','tests/test_controller_providers.py',
    'tests/test_controller_providers_adversarial.py','trading_researcher/CONTROLLER_PROVIDERS.md',
    'trading_researcher/AUXILIARY_RESEARCH.md','README.md','docs/architecture/CURRENT_STATE.md',
    'docs/reviews/integration-research-2026-10-24/IMPLEMENTATION_SEQUENCE_2026-10-25.md',
    'docs/reviews/implementation-2026-10-25/IMPLEMENTATION_SUMMARY_2026-10-25.md',
    'docs/reviews/implementation-2026-10-25/progress.json',
    'docs/reviews/implementation-2026-10-25/controller-provider-review.json',
    'docs/reviews/implementation-2026-10-25/controller-provider-live.json',
    'docs/reviews/implementation-2026-10-25/controller-provider-usage.json']


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def run(name, arguments):
    result = subprocess.run(arguments,cwd=ROOT,capture_output=True,text=True,encoding='utf-8',errors='replace')
    with (WORK/(name+'.log')).open('x',encoding='utf-8') as out:
        out.write(result.stdout+result.stderr)
    if result.returncode:
        raise RuntimeError(name+' failed with exit '+str(result.returncode))
    return {'command':arguments,'exit_code':result.returncode,'log':str((WORK/(name+'.log')).relative_to(ROOT))}


def main():
    if REPORT.exists():raise RuntimeError('Verification already frozen; do not overwrite')
    review = json.loads((DOCS/'controller-provider-review.json').read_text(encoding='utf-8'))
    for name, expected in review['source_sha256'].items():
        assert sha(ROOT/name)==expected, name
    baseline = json.loads((WORK/'baseline.json').read_text(encoding='utf-8'))
    changed = set(CHANGED)
    unchanged = [name for name, value in baseline.items() if name not in changed]
    for name in unchanged:assert sha(ROOT/name)==baseline[name],name
    for name in CHANGED:
        path = ROOT/name
        content = path.read_text(encoding='utf-8')
        assert all(line==line.rstrip() for line in content.splitlines()),name
        if path.suffix=='.py':ast.parse(content,filename=name)
        if path.suffix=='.md':
            for match in re.finditer(r'\]\(([^)]+)\)',content):
                ref = match.group(1).strip('<>')
                if re.match(r'[A-Za-z]+:',ref):continue
                target = unquote(ref.split('#',1)[0])
                if not target:continue
                resolved=(path.parent/target).resolve()
                assert resolved.exists() or resolved==REPORT, (name,target)
    # The documentation validator follows this report's link. Create an explicitly
    # unfinished record before validation, then freeze the result only on success.
    with REPORT.open('x',encoding='utf-8') as out:
        json.dump({'schema':'controller-provider-verification/1','status':'IN_PROGRESS'},out)
        out.write('\n')
    fresh = [run('focused-final-2',[sys.executable,'-B','-m','unittest','discover','-s','tests','-p','test_controller_providers*.py']),
        run('retail-contract-2',[sys.executable,'-B','docs/reviews/verify_retail_contract.py']),
        run('system-model-2',[sys.executable,'-B','docs/reviews/verify_system_model.py']),
        run('git-diff-check-2',['git','diff','--check'])]
    regressions = [
        ('test_auxiliary*.py',24,146.857,'57d285'),('test_research_calls.py',10,4.611,'58d78a'),
        ('test_local_runtime.py',8,16.727,'ac321d'),('test_memory.py',17,8.391,'d65db2'),
        ('test_storage.py',12,9.016,'8d8300'),('test_researcher.py',10,12.548,'85c744'),
        ('test_openai_provider.py',6,0.118,'3bb5d9')]
    usage = json.loads((DOCS/'controller-provider-usage.json').read_text(encoding='utf-8'))
    result = {'schema':'controller-provider-verification/1','status':'PASS_BOUNDED_CONTROLLER_DISPATCH',
        'checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'purpose':'Distinguish host-owned direct adapter execution from worker-submitted or merely live-labeled responses without altering scientific authority.',
        'changed_files':CHANGED+[str(REPORT.relative_to(ROOT)),str((DOCS/'controller-provider-evidence.zip').relative_to(ROOT))],
        'runtime_helpers':[str(p.relative_to(ROOT)) for p in sorted(WORK.glob('*.py'))],
        'source_sha256':{name:sha(ROOT/name) for name in CHANGED},
        'fresh_checks':fresh,'syntax_whitespace_and_local_links':'PASS',
        'regression_checks':[{'command':[sys.executable,'-B','-m','unittest','discover','-s','tests','-p',pattern],
            'tests':count,'seconds':seconds,'exit_code':0,'observed_tool_chunk':chunk} for pattern,count,seconds,chunk in regressions],
        'unique_tests_passed':105,'focused_tests':18,'independently_authored_tests':14,
        'earlier_observations':[
            'Initial heavy-fixture red: 3 tests, exit1, 207.533s; two missing constructor-argument errors plus one source-drift fixture failure while editing. Not a clean three-case feature red.',
            'Intermediate old harness: 3 tests, exit1, 312.226s, stale fixture cleanup/source issues. Replaced with a small owned-registry fixture and explicit cleanup; no production rule relaxed.',
            'Independent initial run:14 tests, exit1; one real bool/int configuration alias and four sequential-fixture setup errors. Canonical route comparison and isolated fixture branch handling resolve them.',
            'An initial combined documentation patch did not apply because a heading anchor was absent; no partial mutation. Corrected patch applied before final checks.',
            'Initial finalizer:18 focused tests PASS in7.797s; contract validation exit1 solely because its link pointed to this not-yet-created report. An explicit IN_PROGRESS record now precedes link validation; original failed log retained.'],
        'preservation':{'unchanged_baseline_files':len(unchanged),
            'unchanged_application_files':sum(name.startswith('trading_researcher/') and name.endswith('.py') for name in unchanged),
            'unchanged_prior_frozen_review_artifacts':sum(name.startswith('docs/reviews/implementation-2026-10-25/') and name.endswith(('.json','.zip')) for name in unchanged)},
        'live_probe':{'calls':2,'tokens':2288,'conservative_nano_usd':7167500,'elapsed_seconds':10.835789,
            'source':'controller-provider-live.json','binding_check':'PASS exact request/response/provider-ledger IDs, usage, model and UTC timestamps; registry integrity ok'},
        'aggregate_usage':{'calls':usage['totals']['calls'],'tokens':usage['totals']['exact_total_tokens'],
            'conservative_nano_usd':usage['money']['charged_nano'],'cap_nano_usd':usage['money']['cap_nano']},
        'not_verified':['General semantic admission or arbitrary hypothesis faithfulness',
            'Live Claude/Gemini/Chinese-model compatibility or model diversity',
            'Complete scientific calibration, atomic scientific freeze, first historical cycle, backtest validity or profitability',
            'Remote cryptographic model attestation, immutable vendor weights, OS sandbox or resistance to a malicious local operator',
            'Full-workload speed or token-quality equivalence; the 10.835789s observation covers this small handoff only',
            'Remote cancellation/refund, automatic orphan reconciliation, cloud delivery or GitHub publication'],
        'next_action':'Keep the full seven-package goal active; connect substantive independent meaning review to scientific admission within approved semantics, then resolve data/exposure, information/calibration and atomic freeze prerequisites.'}
    with REPORT.open('w',encoding='utf-8') as out:
        json.dump(result,out,indent=2);out.write('\n')
    archive=DOCS/'controller-provider-evidence.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as out:
        for name in CHANGED+[str(REPORT.relative_to(ROOT))]:out.write(ROOT/name,name)
        for path in sorted(WORK.glob('*.py')):out.write(path,str(path.relative_to(ROOT)))
        for path in sorted(WORK.glob('*.log')):out.write(path,str(path.relative_to(ROOT)))
        out.write(WORK/'baseline.json',str((WORK/'baseline.json').relative_to(ROOT)))
    print(json.dumps({'status':result['status'],'unique_tests':105,'fresh_checks':[c['exit_code'] for c in fresh],
        'preservation':result['preservation'],'report_sha256':sha(REPORT),'evidence_sha256':sha(archive)}))


if __name__=='__main__':main()
