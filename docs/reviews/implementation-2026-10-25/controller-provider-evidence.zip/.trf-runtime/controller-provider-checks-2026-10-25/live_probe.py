"""Two bounded direct auxiliary calls on synthetic input; no scientific trial."""
import hashlib
import json
from pathlib import Path
import sys
import threading
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from trading_researcher.auxiliary import run_auxiliary_once
from trading_researcher.coordination import Broker
from trading_researcher.openai_provider import MODEL, configuration, cost_bound
from trading_researcher.provider_usage import read_usage_report
from trading_researcher.server import Client, LocalServer


def main():
    work = Path(__file__).parent
    registry = work / 'real-registry'
    if registry.exists():
        raise RuntimeError('Exclusive probe already started; inspect rather than rerun')
    ledger = ROOT / '.trf-runtime/openai-integration-budget.sqlite3'
    before_hash = hashlib.sha256(ledger.read_bytes()).hexdigest()
    before = read_usage_report(ledger)
    config = configuration(input_token_limit=10000, output_token_limit=1024)
    maximum = 2 * cost_bound(10000, 1024)
    if before['money']['halted'] or before['money']['available_nano'] < maximum:
        raise RuntimeError('Existing approved aggregate budget cannot admit both probe calls')
    broker = Broker(registry, provider_routes={MODEL: {'provider':'openai',
        'key_file':str(ROOT / '.env.local'), 'budget_file':str(ledger), 'config':config}})
    server = LocalServer(broker)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    started = time.time()
    try:
        admin = Client(server.url, broker.admin_token)
        for name in ('first', 'second'):
            admin.call('register_worker', name=name, role='discovery', capabilities=['research-record/v1'])
        idea = admin.call('add_research', kind='idea', content={'text':
            "Research whether a trader's unrecorded private mood predicts the next BTCUSDT closing-price change at 15-minute observations."},
            scope={'purpose':'Synthetic unsupported-idea transport probe, not market evidence'}, source_refs=[])['id']
        catalog = admin.call('add_source', body={'schema':'feature-catalog/1','features':{}}, data_class='development')['id']
        context = admin.call('create_context',role='discovery',epoch=1,artifact_ids=[idea,catalog])['id']
        common = {'model':MODEL,'prompt_version':'controller-auxiliary-probe/1',
            'generation_parameters':{'openai_responses':config}, 'max_output_tokens':1024,
            'call_timeout_seconds':120,'max_retries':0}
        profile = {**common,'mode':'live','currency':'USD','max_calls':2,'max_tokens':80000,
            'max_seconds':600,'max_cost_units':maximum,'tools':[],
            'prompts':{'first':'Unused discovery role in a technical probe','second':'Unused discovery role in a technical probe'}}
        epoch = admin.call('create_research_epoch',key='owned-auxiliary-probe',context_id=context,
                          workers=['first','second'],profile=profile)['id']
        formal_context = admin.call('create_context',role='formalizer',epoch=1,artifact_ids=[idea,catalog])['id']
        formalizer = admin.call('register_worker',name='formalizer',role='formalizer',capabilities=['formalization/v1'])['token']
        spec = {'kind':'formalization/v1','context_id':formal_context,'purpose':'Real API unsupported-idea handoff probe',
            'allowed_workers':['formalizer'],'max_attempts':1,'lease_seconds':30,'deadline':int(time.time())+600,
            'dependencies':[],'research_epoch_id':epoch,'research_call_profile':{**common,'prompt':
                'Assess the exact supplied idea using only the supplied catalog. This is a technical unsupported-idea probe, '
                'not a scientific verdict. The empty catalog supplies no mood or price measurement. Do not substitute a different '
                'question or invent features. Return one JSON object with status="final", candidate=null and semantic_report=null '
                'to preserve this unsupported idea as a gap. No tools or additional fields.'},
            'research_inputs':{'idea_id':idea,'catalog_id':catalog,'definition_ids':[]}}
        job = admin.call('enqueue',key='formalizer',spec=spec)['id']
        outcomes = [run_auxiliary_once(Client(server.url,formalizer))]
        if outcomes[0].get('accepted'):
            target = outcomes[0]['artifact_id']
            batch = admin.call('inspect',job_id=job)['batch_id']
            admin.call('release_batch',batch_id=batch,target_epoch=2)
            review_context = admin.call('create_context',role='formalizer',epoch=2,artifact_ids=[target,idea,catalog])['id']
            reviewer = admin.call('register_worker',name='reviewer',role='formalizer',capabilities=['semantic-review/v1'])['token']
            review_prompt = ('Independently compare the preserved original idea, its formalization or retained gap, and supplied catalog. '
                'This is a technical meaning-review probe, no empirical success verdict. Do not invent measurements. Return JSON '
                '{"status":"final","review":{"judgment":"faithful|different|uncertain","reason":"your substantive reason",'
                '"added_assumptions":[],"omitted_assumptions":[],"conflicts":[],"unresolved_meaning":[],"mapping_checks":[]}}. '
                'Choose one judgment; populate the string lists when relevant. mapping_checks has one segment index, judgment and '
                'reason per supplied mapping segment (an empty list if there are none). A faithful judgment requires no stated '
                'unresolved differences. A retained unsupported idea is not a negative scientific result. No other fields or tools.')
            review_spec = {**spec,'kind':'semantic-review/v1','context_id':review_context,'allowed_workers':['reviewer'],
                'purpose':'Independently inspect a retained unsupported idea','dependencies':[job],
                'research_call_profile':{**common,'prompt_version':'controller-auxiliary-review-probe/1','prompt':review_prompt},
                'research_inputs':{'formalization_id':target,'definition_ids':[]}}
            admin.call('enqueue',key='reviewer',spec=review_spec)
            outcomes.append(run_auxiliary_once(Client(server.url,reviewer)))
        state = admin.call('inspect_research_epoch',epoch_id=epoch)
        with broker._mutex:
            ids = [row[0] for row in broker._db.execute('SELECT result_id FROM provider_invocations')]
        retained = [admin.call('get_artifact',artifact_id=identity) for identity in ids]
        artifacts = [admin.call('get_artifact',artifact_id=o['artifact_id']) for o in outcomes if o.get('accepted')]
        after = read_usage_report(ledger)
        before_ids = {c['dispatch_id'] for c in before['calls']}
        calls = [c for c in after['calls'] if c['dispatch_id'] not in before_ids]
        result = {'schema':'controller-auxiliary-live-probe/1','elapsed_seconds':round(time.time()-started,6),
            'registry':str(registry),'aggregate_ledger_before_sha256':before_hash,
            'aggregate_ledger_after_sha256':hashlib.sha256(ledger.read_bytes()).hexdigest(),
            'outcomes':outcomes,'epoch_usage':state['usage'],'invocations':retained,'artifacts':artifacts,
            'new_provider_calls':calls,'aggregate_usage':after,
            'qualification':'Genuine direct API transport on synthetic unsupported-idea input. Formalization output was explicitly constrained; '
                'the separate review is model-generated. No free discovery, scientific evidence, general semantic correctness or mixed-provider result.'}
        with (work / 'live-result.json').open('x',encoding='utf-8') as out:
            json.dump(result,out,indent=2)
            out.write('\n')
        print(json.dumps({'accepted':[o.get('accepted') for o in outcomes],'new_calls':len(calls),
            'epoch_usage':state['usage'],'elapsed_seconds':result['elapsed_seconds'],'result':'live-result.json'}))
        if len(outcomes)!=2 or not all(o.get('accepted') for o in outcomes):
            raise SystemExit(2)
    finally:
        server.shutdown()
        thread.join(5)
        server.server_close()
        broker.close()


if __name__ == '__main__':
    main()
