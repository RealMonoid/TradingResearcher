"""Compare owned retained provider-document bytes with the reviewed upstream text."""
import datetime,hashlib,json,sqlite3,sys,urllib.request
from pathlib import Path
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root))
from trading_researcher.data_use import REVIEWED_DOCUMENTS
from trading_researcher.binance_archive import README_URL,TERMS_URL
registry=root/'.trf-runtime/binance-normalized-registry-2026-10-25'
with sqlite3.connect((registry/'registry.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    rows=db.execute("SELECT id,envelope FROM artifacts WHERE json_extract(envelope,'$.body.schema')='binance-provider-documents/1'").fetchall()
    assert rows
    reports=[]
    for identity,envelope in rows:
        artifact=json.loads(envelope);files=artifact['body']['files'];checks=[]
        for name,url in [('README.md',README_URL),('TERMS_AND_CONDITIONS.md',TERMS_URL)]:
            item=files[name];raw=(registry/'blobs'/item['sha256'][:2]/item['sha256']).read_bytes()
            assert hashlib.sha256(raw).hexdigest()==item['sha256']==REVIEWED_DOCUMENTS[name]
            assert len(raw)==item['size']
            with urllib.request.urlopen(url,timeout=30) as response:current=response.read(1048577)
            assert len(current)<=1048576
            checks.append({'name':name,'source_url':url,'sha256':item['sha256'],'size':len(raw),
                'current_upstream_sha256':hashlib.sha256(current).hexdigest(),'matches_current_upstream':current==raw})
        reports.append({'provider_documents_id':identity,'retrieved_at':artifact['body']['retrieved_at'],'checks':checks})
result={'status':'PASS','checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'documents':reports,
    'qualification':'Exact reviewed provider documentation only; no market values read and no historical vintage or deployment permission established.'}
path=Path(__file__).parent/'provider-documents-result.json'
with path.open('x',encoding='utf-8') as out:out.write(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
