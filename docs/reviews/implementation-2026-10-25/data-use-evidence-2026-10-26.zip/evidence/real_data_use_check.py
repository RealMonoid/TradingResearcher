"""Exercise the new owned check against the already retained development probe."""
import datetime,json,sys
from pathlib import Path
from unittest.mock import patch
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root))
from trading_researcher.coordination import Broker
probe=json.loads((root/'.trf-runtime/nuisance-diagnostics-checks-2026-10-25/real-probe-result.json').read_text())
broker=Broker(probe['registry'])
try:
    with patch.object(broker,'_load_reference_data',side_effect=AssertionError('No market row expansion in this check')):
        assessment=broker.call(broker.admin_token,'assess_data_use',compiled_id=probe['compiled_id'])
        current=broker.call(broker.admin_token,'inspect_data_use',assessment_id=assessment['id'])
    assert assessment['body']['status']=='QUALIFIED_EXPLORATION',assessment['body']
    assert current['status']=='QUALIFIED_EXPLORATION',current
    findings=assessment['body']['findings'];knowledge=findings['prior_knowledge']
    assert findings['rights']['reviewed_bytes_match']
    assert findings['exposure']['target_in_candidate_ancestry']
    assert findings['availability']['delay_seconds']==900
    assert findings['exposure']['evidence_origin'] is None
    previous=broker.call(broker.admin_token,'get_artifact',artifact_id=probe['plan_id'])
    request={**previous['body']['request'],'key':'data-use-integration-2026-10-26-'+assessment['id'],
        'data_use_assessment_id':assessment['id']}
    with patch.object(broker,'_load_reference_data',side_effect=AssertionError('No market row expansion in this check')):
        plan=broker.call(broker.admin_token,'prepare_evaluation_plan',**request)
        plan_view=broker.call(broker.admin_token,'inspect_evaluation_plan',plan_id=plan['id'])
    assert plan['body']['status']=='POLICY_DRAFT'
    assert plan_view['data_use']['qualified_exploration_data_use']=='SATISFIED'
    assert 'scientific_data_and_exposure_acceptance' not in plan_view['current_remaining_gates']
    assert broker.call(broker.admin_token,'get_artifact',artifact_id=probe['plan_id'])==previous
    record={'status':'PASS','checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'assessment_id':assessment['id'],'checker_sha256':assessment['body']['checker_sha256'],
        'compiled_id':probe['compiled_id'],'scope':findings['scope'],'rights':findings['rights'],
        'availability':{k:v for k,v in findings['availability'].items() if k!='provenance'},
        'exposure':findings['exposure'],'prior_knowledge_count':len(knowledge['artifact_ids']),
        'unresolved_exposure_refs':knowledge['unresolved_exposure_refs'],
        'protected_knowledge_ids':knowledge['protected_knowledge_ids'],
        'operations_knowledge_ids':knowledge.get('operations_knowledge_ids',[]),'current':current,
        'plan_id':plan['id'],'prior_plan_unchanged':True,'plan_view':plan_view,
        'provider_calls':0,'scientific_readiness':False,
        'qualification':'Existing engineering-selected development probe with actual retained Binance archives; not a new LLM discovery, protected assessment admission, calibration or profitability result.'}
finally:broker.close()
name='real-data-use-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S')+'.json'
with (Path(__file__).parent/name).open('x',encoding='utf-8') as stream:stream.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
