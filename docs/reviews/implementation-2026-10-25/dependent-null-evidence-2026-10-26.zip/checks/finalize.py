"""Bind independent review and final documentation checks to the scope assessment."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path
root = Path(__file__).resolve().parents[2]
work = Path(__file__).parent
public = root / 'docs/reviews/implementation-2026-10-25'
path = public / 'dependent-null-verification-2026-10-26.json'
value = json.loads(path.read_text())
review = public / 'dependent-null-independent-2026-10-26.json'
assert review.exists()
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
value['checks'] = []
for p in sorted(work.glob('2026*.json')):
    record = json.loads(p.read_text())
    record['record'] = p.name
    record['log_sha256'] = sha(work / record['log'])
    value['checks'].append(record)
value['independent_review'] = {'path': review.name, 'sha256': sha(review)}
archive_path = public / 'dependent-null-evidence-2026-10-26.zip'
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in ('verify_dependent_null_scope.py', 'DEPENDENT_NULL_SCOPE_2026-10-26.md', review.name):
        archive.write(public / name, 'assessment/' + name)
    for p in sorted(work.glob('*')):
        if p.is_file() and p.suffix in ('.py', '.json', '.log'):
            archive.write(p, 'checks/' + p.name)
value['evidence_archive'] = {'path': archive_path.name, 'sha256': sha(archive_path),
                             'bytes': archive_path.stat().st_size}
changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=root, text=True).splitlines()
new = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines()
value['changed_files'] = sorted(set(changed + new))
path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': 'PASS', 'changed_files': len(value['changed_files']),
                  'retained_check_records': len(value['checks']), 'archive_bytes': archive_path.stat().st_size,
                  'verification_sha256': sha(path)}))
