"""Retain exact assessment output and checks without changing production code."""
import hashlib
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[2]
work = Path(__file__).parent
public = root / 'docs/reviews/implementation-2026-10-25'
record = json.loads((work / '20261026T203320-573e2e1c.json').read_text())
result = json.loads((work / record['log']).read_text())
script = public / 'verify_dependent_null_scope.py'
assert record['exit_code'] == 0 and result['status'] == 'PASS'
assert result['source_sha256'] == hashlib.sha256(script.read_bytes()).hexdigest()
assert len(result['cases']) == 6 and len(result['proposed_affine_extension_cases']) == 18
baseline = '58780bd58e92b99bcd3dff39176617b1b3a006e3'
runtime = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', baseline, 'trading_researcher'],
                                  cwd=root, text=True).splitlines()
runtime = [name for name in runtime if name.endswith('.py')]
for name in runtime:
    assert (root / name).read_bytes() == subprocess.check_output(['git', 'show', baseline + ':' + name], cwd=root), name
def write(path, obj):
    path.write_text(json.dumps(obj, indent=2) + '\n', encoding='utf-8')
progress_path = public / 'progress.json'
progress = json.loads(progress_path.read_text())
progress['next_action'] = 'Implement and independently assess the bounded second-order lag-linked stress extension proposed in DEPENDENT_NULL_SCOPE_2026-10-26.md. Preserve assigned effects while varying dependence, with exact joint initialization, explicit feasibility/missingness/capacity limits and retained failures. Then justify actual nuisance/stress scope and substantive information/calibration inventories; no algebra-only or one-world result admits N_min. Continue the existing scientific admission/freeze, mixed-provider research, policy/AmiBroker and reporting sequence.'
audit_addition = ' After verified GitHub publication, an exact dependent-null counterexample established missing long-run score-variance variation; eighteen algebraic cells support a concrete proposed second-order continuation without changing production or scientific authority.'
if audit_addition not in progress['continuation_audit']['basis']:
    progress['continuation_audit']['basis'] += audit_addition
progress['dependent_null_scope_checkpoint'] = {
    'date': '2026-10-26', 'status': 'EXACT_SCOPE_ASSESSMENT_PASS',
    'verification': 'docs/reviews/implementation-2026-10-25/dependent-null-verification-2026-10-26.json',
    'counterexample_cases': 6, 'proposed_extension_cells': 18,
    'production_implemented': False, 'market_data_read': False, 'provider_calls': 0,
    'scientific_readiness': False, 'full_objective_complete': False,
}
write(progress_path, progress)
write(public / 'dependent-null-verification-2026-10-26.json', {
    'schema': 'dependent-null-assessment-verification/1', 'baseline_commit': baseline,
    'status': 'EXACT_SCOPE_ASSESSMENT_PASS', 'check': record, 'result': result,
    'exact_stdout_sha256': hashlib.sha256((work / record['log']).read_bytes()).hexdigest(),
    'production_python_files_unchanged': len(runtime), 'provider_calls': 0,
    'scientific_readiness': False, 'full_objective_complete': False,
    'limits': ['No production extension, market fit or adopted profile',
               'No bootstrap performance or exact finite-sample variance claim',
               'Joint multiple-response initialization and masks remain unimplemented for the proposal',
               'No information target or final calibration'],
})
print(json.dumps({'status': 'PASS', 'exact_cases': 6, 'proposed_cells': 18,
                  'production_python_files_unchanged': len(runtime)}))
