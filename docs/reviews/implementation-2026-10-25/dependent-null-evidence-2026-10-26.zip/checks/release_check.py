"""Validate the exact documentation/assessment publication."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path
root = Path(__file__).resolve().parents[2]
folder = root / 'docs/reviews/implementation-2026-10-25'
path = folder / 'dependent-null-verification-2026-10-26.json'
record = json.loads(path.read_text())
staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=root, text=True).splitlines()
assert sorted(staged) == record['changed_files'] and len(staged) == 7
for name in staged:
    assert not name.startswith(('trading_researcher/', '.trf-runtime/'))
    assert (root / name).read_bytes() == subprocess.check_output(['git', 'show', ':' + name], cwd=root), name
assert record['result']['source_sha256'] == hashlib.sha256((folder / 'verify_dependent_null_scope.py').read_bytes()).hexdigest()
for key in ('independent_review', 'evidence_archive'):
    item = record[key]
    assert hashlib.sha256((folder / item['path']).read_bytes()).hexdigest() == item['sha256']
with zipfile.ZipFile(folder / record['evidence_archive']['path']) as archive:
    assert archive.testzip() is None
for name in ('docs/reviews/verify_system_model.py', 'docs/reviews/verify_retail_contract.py',
             'docs/reviews/implementation-2026-10-25/verify_implementation.py'):
    checks = [item for item in record['checks'] if item['command'][-1] == name]
    assert checks and checks[-1]['exit_code'] == 0, name
assert len(record['result']['cases']) == 6 and len(record['result']['proposed_affine_extension_cases']) == 18
assert record['production_python_files_unchanged'] == 60
assert record['scientific_readiness'] is record['full_objective_complete'] is False
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=root, check=True)
print(json.dumps({'status': 'PASS', 'staged_files_and_exact_byte_checks': len(staged),
                  'exact_counterexamples': 6, 'proposed_extension_cells': 18,
                  'applicable_documentation_checks': 3, 'git_diff_cached_check_exit': 0,
                  'verification_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}))
