"""Alternating retained-source comparisons with complete actual child replay."""
import hashlib
import json
from pathlib import Path
import sys
import time
import zipfile
ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from trading_researcher.study_runs import execute_attempt
from trading_researcher.codec import canonical
assert not (WORK/'comparison.json').exists(), 'Do not overwrite a measured comparison'
with zipfile.ZipFile(WORK/'source-before.zip') as bundle:before={name:bundle.read(name) for name in bundle.namelist()}
after={p.relative_to(ROOT).as_posix():p.read_bytes() for p in (ROOT/'trading_researcher').glob('*.py')}
assert set(before)==set(after)
assert {name for name in before if before[name]!=after[name]}=={
    'trading_researcher/stationary_bootstrap.py','trading_researcher/study_pipeline.py'}
request=json.loads((WORK/'request.json').read_text(encoding='utf-8'))
baseline=json.loads((WORK/'baseline.json').read_text(encoding='utf-8'))['baseline']
cases=('\n'.join(canonical(c) for c in request['cases'])+'\n').encode()
results=[]
for label in ('before','after','after','before','before','after'):
    source=before if label=='before' else after
    outputs=[];meter={'materialized_bytes':0,'accounting_complete':True};started=time.monotonic()
    result,proofs=execute_attempt(source,request['payload'],request['manifest'],request['world'],cases,
        lambda:90-(time.monotonic()-started),meter,outputs)
    elapsed=time.monotonic()-started
    digest=hashlib.sha256(canonical(result).encode()).hexdigest()
    assert digest==baseline['result_sha256']
    assert len(proofs)==2 and all(p['stream_blob']=={'sha256':baseline['stream_sha256'],
        'size':baseline['stream_bytes']} for p in proofs)
    assert all((ROOT/name).read_bytes()==raw for name,raw in after.items())
    observation={'source':label,'seconds':round(elapsed,6),'result_sha256':digest,
        'stream_sha256':baseline['stream_sha256'],'proofs':2,'meter':meter}
    results.append(observation);print(json.dumps(observation),flush=True)
times={label:sorted(r['seconds'] for r in results if r['source']==label) for label in ('before','after')}
record={'status':'PASS_EXACT_ALTERNATING_CHILD_REPLAY','runs':results,'seconds':times,
    'before_median':times['before'][1],'after_median':times['after'][1],
    'after_source_sha256':{name:hashlib.sha256(raw).hexdigest() for name,raw in after.items()},
    'qualification':'Three runs per version of the same 16-time development world, alternating order, actual separate generation/replay. Not representative calibration or large-sample performance.'}
record['median_ratio_after_over_before']=record['after_median']/record['before_median']
with (WORK/'comparison.json').open('x',encoding='utf-8') as stream:json.dump(record,stream,indent=2)
print(json.dumps({key:record[key] for key in ('status','before_median','after_median','median_ratio_after_over_before')}))
