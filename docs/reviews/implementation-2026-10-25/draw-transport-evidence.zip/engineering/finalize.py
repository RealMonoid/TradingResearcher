"""Finalize measured exact transport evidence without executing provider calls."""
from datetime import datetime,timezone
import hashlib,json,re,subprocess,sys,zipfile
from pathlib import Path
from urllib.parse import unquote
ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).resolve().parent
OUT=ROOT/'docs/reviews/implementation-2026-10-25'
target=OUT/'draw-transport-verification.json';archive=OUT/'draw-transport-evidence.zip'
assert not target.exists() and not archive.exists(),'Do not overwrite a checkpoint'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
review_path=OUT/'draw-transport-review.json'
assert sha(review_path)=='182759c2b8063176b1ad667459c6d410bf0561531f10fdbaae45955e69f6b6db'
review=json.loads(review_path.read_text(encoding='utf-8'))
pins={**review['source_sha256'],**review['test_sha256'],**review['protected_artifacts_sha256']}
assert all(sha(ROOT/name)==value for name,value in pins.items())
baseline=json.loads((WORK/'baseline.json').read_text(encoding='utf-8'))
comparison=json.loads((WORK/'comparison.json').read_text(encoding='utf-8'))
changed_source=['trading_researcher/stationary_bootstrap.py','trading_researcher/study_pipeline.py']
assert {name for name,value in baseline['source_sha256'].items() if sha(ROOT/name)!=value}==set(changed_source)
assert all(sha(ROOT/name)==value for name,value in comparison['after_source_sha256'].items())
prior=json.loads((OUT/'calibration-run-verification.json').read_text(encoding='utf-8'))
assert sha(ROOT/'.trf-runtime/openai-integration-budget.sqlite3')==prior['live_ledger_sha256']
contract=ROOT/'docs/architecture/14_RETAIL_RESEARCH_CONTRACT.md'
assert sha(contract)=='e8513ced048dd3c60f30490736e666cadf4d3da0929002b4923a8d70ac31a76d'
changed=changed_source+['tests/test_draw_transport.py','tests/test_draw_transport_adversarial.py',
    'trading_researcher/STATIONARY_BOOTSTRAP.md','trading_researcher/INFORMATION_STUDIES.md',
    'docs/architecture/CURRENT_STATE.md',
    'docs/reviews/integration-research-2026-10-24/IMPLEMENTATION_SEQUENCE_2026-10-25.md',
    'docs/reviews/implementation-2026-10-25/IMPLEMENTATION_SUMMARY_2026-10-25.md',
    'docs/reviews/implementation-2026-10-25/progress.json',
    'docs/reviews/implementation-2026-10-25/draw-transport-review.json']
links=0
for name in changed:
    path=ROOT/name;body=path.read_text(encoding='utf-8')
    assert all(line==line.rstrip() for line in body.splitlines()),name
    if path.suffix=='.json':json.loads(body)
    if path.suffix=='.md':
        for link in re.findall(r'\]\(([^\s)]+)\)',body):
            if link.startswith(('https://','http://','#')):continue
            destination=(path.parent/unquote(link.split('#',1)[0])).resolve()
            assert destination.exists() or destination==target,(name,link)
            links+=1
checks=[('test_draw_transport*.py',13,'16.350','101eaf'),
    ('test_stationary_bootstrap*.py',19,'17.581','3859fd'),
    ('test_exact_bootstrap_acceleration*.py',16,'33.854','fe55b2'),
    ('test_study_runs*.py',13,'245.979','2e0808'),
    ('test_calibration_runs.py',3,'144.816','980a4e')]
record={'schema':'draw-transport-engineering-verification/1','status':'DOCUMENTATION_CHECK_PENDING',
    'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
    'purpose':'Reduce measured duplicate draw serialization/copying while preserving exact calculation and retained replay.',
    'source':'https://docs.python.org/3.14/library/profile.html',
    'source_use':'Primary profiler documentation: profile to locate work; use separate unprofiled timing comparisons.',
    'checks':[{'command':"python -B -m unittest discover -s tests -p '"+pattern+"'",'tests':count,
        'seconds':seconds,'tool_chunk':chunk,'exit_code':0} for pattern,count,seconds,chunk in checks],
    'unique_tests_passed':sum(row[1] for row in checks),
    'independent_review':{'path':'draw-transport-review.json','sha256':sha(review_path),
        'tests':12,'seconds':'14.415','exit_code':0,'included_in_parent_count':True,
        'test_provenance':'Authored after production change; fixed expected values use archived old calculator and old canonical transport.'},
    'benchmark':comparison,'baseline_profile':baseline,
    'changed_files':changed+[str(target.relative_to(ROOT)).replace('\\','/'),str(archive.relative_to(ROOT)).replace('\\','/')],
    'changed_files_sha256':{name:sha(ROOT/name) for name in changed},
    'unchanged_application_files':len(baseline['source_sha256'])-2,
    'unchanged_prior_artifacts':len(review['protected_artifacts_sha256']),
    'contract_unchanged':True,'live_ledger_unchanged':True,'live_ledger_sha256':prior['live_ledger_sha256'],
    'existing_live_usage':prior['existing_live_usage'],'new_provider_calls':0,
    'new_simulation_scope':'Repeat fixed development input for performance and correctness only; no fresh final calibration cohort or new scientific interpretation.',
    'authored_checks':{'whitespace':'PASS','json':'PASS','local_links':links},
    'red_checks':[{'tool_chunk':'d72b8d','exit_code':1,'reason':'Byte callback absent before implementation'},
        {'tool_chunk':'eb8e7f','exit_code':1,'reason':'Profiling helper used nonexistent blob helper name; corrected before collecting data'}],
    'unverified':['Representative larger-sample and full-study budget feasibility','Stationarity, denominator adequacy and justified population/stress law',
        'Complete final calibration and coherent mixed-truth multi-claim worlds','Scientific data/meaning admission and atomic freeze',
        'Genuine mixed-model research, policy/backtest efficacy and full seven-package completion'],
    'next_action':'Continue necessary scientific inputs and full-family calibration capability; do not infer a passing study budget or scientific validity from this small exact workload.'}
assert record['unique_tests_passed']==64
target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
docs=subprocess.run([sys.executable,'-B','docs/reviews/verify_retail_contract.py'],cwd=ROOT,capture_output=True,text=True,timeout=60)
(WORK/'documentation.log').write_text(docs.stdout+docs.stderr,encoding='utf-8')
assert docs.returncode==0,docs.stdout+docs.stderr
record['checks'].append({'command':'python -B docs/reviews/verify_retail_contract.py','exit_code':0,
    'includes':'verify_system_model and git diff --check','result':json.loads(docs.stdout)})
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as bundle:
    for name in changed:bundle.write(ROOT/name,name)
    for name in ('source-before.zip','profile_world.py','profile_attempt.py','compare_attempts.py','finalize.py',
                 'baseline.json','comparison.json','profile.txt','attempt-before.json','attempt-profile.txt','documentation.log'):
        bundle.write(WORK/name,'engineering/'+name)
record['archive_sha256']=sha(archive)
record['archive_scope']='Source baseline, exact changed code/tests/guides and measurements; excludes private cases, registry, credentials and raw retained request.'
record['status']='PASS_EXACT_DRAW_TRANSPORT'
target.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
fresh=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','tests','-p','test_draw_transport.py'],
    cwd=ROOT,capture_output=True,text=True,timeout=60)
(WORK/'final-focused.log').write_text(fresh.stdout+fresh.stderr,encoding='utf-8')
assert fresh.returncode==0,fresh.stdout+fresh.stderr
git=subprocess.run(['git','diff','--check'],cwd=ROOT,capture_output=True,text=True)
(WORK/'git-diff-check.log').write_text(git.stdout+git.stderr,encoding='utf-8')
assert git.returncode==0,git.stdout+git.stderr
assert all(sha(ROOT/name)==value for name,value in pins.items())
print(json.dumps({'status':record['status'],'unique_tests_passed':64,'independent_tests':12,
    'documentation_exit':docs.returncode,'fresh_focused_exit':fresh.returncode,'git_diff_check_exit':git.returncode,
    'unchanged_application_files':record['unchanged_application_files'],
    'unchanged_prior_artifacts':record['unchanged_prior_artifacts'],'new_provider_calls':0}))
