"""Profile parent orchestration with real uninstrumented fresh children."""
import cProfile
import hashlib
import io
import json
from pathlib import Path
import pstats
import sys
import time
import zipfile
ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from trading_researcher.study_runs import execute_attempt
from trading_researcher.codec import canonical
with zipfile.ZipFile(WORK/'source-before.zip') as bundle:source={name:bundle.read(name) for name in bundle.namelist()}
assert all((ROOT/name).read_bytes()==raw for name,raw in source.items())
request=json.loads((WORK/'request.json').read_text(encoding='utf-8'))
cases=('\n'.join(canonical(c) for c in request['cases'])+'\n').encode()
assert hashlib.sha256(cases).hexdigest()==request['payload']['case_blob']['sha256']
outputs=[];meter={'materialized_bytes':0,'accounting_complete':True};started=time.monotonic()
profiler=cProfile.Profile()
result,proofs=profiler.runcall(execute_attempt,source,request['payload'],request['manifest'],request['world'],cases,
    lambda:90-(time.monotonic()-started),meter,outputs)
elapsed=time.monotonic()-started
profiler.dump_stats(str(WORK/'attempt.prof'))
text=io.StringIO();pstats.Stats(profiler,stream=text).strip_dirs().sort_stats('cumulative').print_stats(24)
(WORK/'attempt-profile.txt').write_text(text.getvalue(),encoding='utf-8')
baseline=json.loads((WORK/'baseline.json').read_text(encoding='utf-8'))
assert hashlib.sha256(canonical(result).encode()).hexdigest()==baseline['baseline']['result_sha256']
assert len(proofs)==2 and all(p['stream_blob']['sha256']==baseline['baseline']['stream_sha256'] for p in proofs)
record={'status':'PASS_REAL_CHILD_REPLAY','wall_seconds':round(elapsed,6),'meter':meter,
    'proof_count':len(proofs),'result_sha256':baseline['baseline']['result_sha256'],
    'outputs':{name:{'sha256':hashlib.sha256(raw).hexdigest(),'size':len(raw)} for name,raw in outputs},
    'qualification':'Parent profiling only; child simulation and replay are unprofiled. No registry writes or provider call.'}
with (WORK/'attempt-before.json').open('x',encoding='utf-8') as stream:json.dump(record,stream,indent=2)
print(json.dumps({'status':record['status'],'wall_seconds':record['wall_seconds'],'proof_count':len(proofs)}))
