"""Read-only source-data profiling; saved comparisons are development evidence only."""
import cProfile
import hashlib
import io
import json
from pathlib import Path
import pstats
import sys
import time
import zipfile

ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from trading_researcher.codec import canonical
from trading_researcher.study_pipeline import calculate_world
from trading_researcher.storage import _content_path

def sha(raw):return hashlib.sha256(raw).hexdigest()
sources={p.relative_to(ROOT).as_posix():p.read_bytes() for p in (ROOT/'trading_researcher').glob('*.py')}
pins={name:sha(raw) for name,raw in sources.items()}
assert not (WORK/'baseline.json').exists(), 'Original profile is immutable'
with zipfile.ZipFile(WORK/'source-before.zip','x',zipfile.ZIP_DEFLATED) as archive:
    for name,raw in sorted(sources.items()):archive.writestr(name,raw)
original_path=ROOT/'.trf-runtime/information-study-checks-2026-10-25/real-study-result.json'
original=json.loads(original_path.read_text(encoding='utf-8'))
prior=json.loads((ROOT/'.trf-runtime/nuisance-diagnostics-checks-2026-10-25/real-probe-result.json').read_text(encoding='utf-8'))
body=original['input_capsule']['body'];payload=body['payload'];manifest=body['manifest'];world=manifest['worlds'][0]
raw=_content_path(Path(prior['registry']),payload['case_blob']['sha256']).read_bytes()
assert {'sha256':sha(raw),'size':len(raw)}==payload['case_blob']
cases=[json.loads(line) for line in raw.splitlines()]
with (WORK/'request.json').open('x',encoding='utf-8') as stream:
    json.dump({'payload':payload,'manifest':manifest,'world':world,'cases':cases},stream)

def run(profiled):
    checksum=hashlib.sha256();counts={'case':0,'draw':0};size=0
    with (WORK/('profiled-stream.jsonl' if profiled else 'baseline-stream.jsonl')).open('xb') as sink:
        def retain(record):
            nonlocal size
            line=(canonical(record)+'\n').encode();sink.write(line);checksum.update(line)
            size+=len(line);counts[record['kind']]+=1
        started=time.perf_counter()
        if profiled:
            profiler=cProfile.Profile()
            result=profiler.runcall(calculate_world,payload,manifest,world,cases,retain)
            profiler.dump_stats(str(WORK/'world.prof'))
            stats=io.StringIO();pstats.Stats(profiler,stream=stats).strip_dirs().sort_stats('cumulative').print_stats(28)
            (WORK/'profile.txt').write_text(stats.getvalue(),encoding='utf-8')
        else:result=calculate_world(payload,manifest,world,cases,retain)
        elapsed=time.perf_counter()-started
    assert result==original['attempts'][0]['body']['result'], 'Numerical result differs from retained original'
    assert counts['draw']==3*19999
    return {'wall_seconds':round(elapsed,6),'stream_sha256':checksum.hexdigest(),'stream_bytes':size,
        'counts':counts,'result_sha256':sha(canonical(result).encode()),'state':result['outcome']['state']}

baseline=run(False);print(json.dumps({'baseline':baseline}),flush=True)
profiled=run(True);assert baseline['stream_sha256']==profiled['stream_sha256']
assert pins=={name:sha((ROOT/name).read_bytes()) for name in pins}
record={'status':'PROFILED_IDENTICAL_RETAINED_WORLD','original_observation_sha256':sha(original_path.read_bytes()),
    'source_sha256':pins,'baseline':baseline,'profiled':profiled,
    'qualification':'One retained development world. Profiling timings are instrumented; use unprofiled comparisons for speed. No new study selection, provider call or calibration.'}
with (WORK/'baseline.json').open('x',encoding='utf-8') as stream:json.dump(record,stream,indent=2)
print(json.dumps({'status':record['status'],'profiled':profiled}),flush=True)
