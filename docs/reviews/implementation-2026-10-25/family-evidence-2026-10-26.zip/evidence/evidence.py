"""Publish bounded joint-family implementation evidence, never calibration success."""
import datetime, hashlib, json, re, subprocess, sys, unittest, zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]; work = Path(__file__).parent
out = root/'docs/reviews/implementation-2026-10-25'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
baseline = json.loads((work/'baseline.json').read_text())
checks = [json.loads(path.read_text()) for path in sorted(work.glob('2026*.json'))]
inventory = {'test_family_dispatch.py':1, 'test_family_oracles.py':10, 'test_family_adversarial.py':9,
    'test_family_runs.py':2, 'test_population_models*.py':16, 'test_population_runs.py':4,
    'test_revocation*.py':23, 'test_memory.py':17}
sys.path[:0] = [str(root), str(root/'tests')]
def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite): yield from flatten(item)
        else: yield item.id()
test_ids = {pattern:list(flatten(unittest.TestLoader().discover(str(root/'tests'), pattern=pattern))) for pattern in inventory}
all_ids = [value for values in test_ids.values() for value in values]
assert len(all_ids) == len(set(all_ids)) == sum(inventory.values())
latest = {}
for pattern, count in inventory.items():
    assert len(test_ids[pattern]) == count, pattern
    matches = [check for check in checks if '-p' in check['command'] and check['command'][check['command'].index('-p')+1] == pattern]
    assert matches and matches[-1]['exit_code'] == 0, pattern
    check = matches[-1]; log = (work/check['log']).read_text()
    assert re.search(r'Ran '+str(count)+r' tests? ', log) and re.search(r'\nOK(?:\s|$)', log), pattern
    latest[pattern] = check['log']
changed = set(subprocess.check_output(['git','diff','--name-only'], cwd=root, text=True).splitlines())
changed.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'], cwd=root, text=True).splitlines())
code = sorted(name for name in changed if name.startswith(('trading_researcher/','tests/')) and name.endswith('.py'))
preserved = [name for name in baseline['files'] if (name.startswith('trading_researcher/') and name.endswith('.py') and name not in code)
             or name.startswith('tests/fixtures/')]
preserved += ['docs/architecture/'+name for name in ('02_DECISION_REGISTER.md','03_REJECTED_DECISIONS.md',
    '04_DEFINITIONS.md','14_RETAIL_RESEARCH_CONTRACT.md')]
for name in preserved: assert sha((root/name).read_bytes()) == baseline['files'][name], name
review_path = work/'independent-review.json'
review = json.loads(review_path.read_text())
assert review['status'].startswith('PASS'), review['status']
for name, expected in review['source_sha256'].items(): assert sha((root/name).read_bytes()) == expected, name
published_review = out/'family-independent-2026-10-26.json'
with published_review.open('xb') as handle: handle.write(review_path.read_bytes())
members = {name:(root/name).read_bytes() for name in code}
for path in sorted(work.glob('2026*')): members['checks/'+path.name] = path.read_bytes()
for path in (work/'baseline.json',work/'check.py',work/'evidence.py',review_path): members['evidence/'+path.name] = path.read_bytes()
members['evidence/test-identities.json'] = (json.dumps(test_ids,indent=2)+'\n').encode()
with zipfile.ZipFile(work/'source-before.zip') as before:
    for name in code:
        if name in baseline['files']: members['before/'+name] = before.read(name)
for name, raw in members.items():
    assert not re.search(rb'\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{20,}',raw), 'API-key-like material in '+name
archive = out/'family-evidence-2026-10-26.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as target:
    for name, raw in members.items(): target.writestr(name,raw)
actual_log = (work/latest['test_family_runs.py']).read_text()
actual = next(json.loads(line) for line in actual_log.splitlines() if line.startswith('{"family_status"'))
value = {'schema':'joint-family-verification/1','status':'CODE_CHECKS_PASS_DOCUMENTATION_PENDING',
    'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent_commit':baseline['head'],
    'unique_focused_tests':len(all_ids),'test_inventory':inventory,'latest_pass_log_by_suite':latest,'checks':checks,
    'retained_failed_checks':[check['log'] for check in checks if check['exit_code'] != 0],
    'intermediate_run_note':'Dispatch first failed because the operation was absent. The initial two-response actual run used 20 rows and block lengths 2/4/8. The final fixed integration fixture uses 64 rows and lengths 1/2, with unchanged seeds 101/102; it asserts defined actual intervals and records inconclusive decisions. Neither fixture is final calibration or empirical parameter selection.',
    'actual_joint_world_observation':actual,'independent_review_additional_test_count':0,
    'independent_review_note':'The independently authored 10 oracle and 9 adversarial tests are already included among the unique focused tests. Mocked pipeline event checks are distinguished from the separate actual estimator/process replay test.',
    'source_sha256':{path.relative_to(root).as_posix():sha(path.read_bytes()) for path in sorted((root/'trading_researcher').glob('*.py'))},
    'changed_code_test_sha256':{name:sha((root/name).read_bytes()) for name in code},
    'preserved_sha256':{name:baseline['files'][name] for name in preserved},
    'independent_review_sha256':sha(published_review.read_bytes()),'evidence_archive':archive.name,
    'evidence_archive_sha256':sha(archive.read_bytes()),'archive_members':len(members),
    'archive_scope':'Changed code/tests, prior changed source, exact commands/exits/output, test identities and independent review. No market data, credentials or registry backup.',
    'provider_calls':0,'scientific_readiness':False,'full_objective_complete':False,
    'unverified':['Complete fixed final mixed-truth calibration inventory and 256-world error-rate assessment',
        'Aggregate multi-world resource accounting and final seed reservation for the new family path',
        'Heterogeneous original-claim template/price laws, original AST overlap and empirical population adequacy',
        'Ideal random independence and wider resource/performance envelope',
        'Full repository suite, exhaustive old-package replay and new-family backup/restore',
        'Scientific information target, protected outcome admission, atomic allocation/freeze and fixed release',
        'Complete campaign selection/reservation/exposure chronology',
        'Genuine mixed-provider free research cycle, certified policy/AmiBroker evaluation, domain reporting and economic usefulness']}
with (out/'family-verification-2026-10-26.json').open('x',encoding='utf-8') as handle: handle.write(json.dumps(value,indent=2)+'\n')
path = out/'progress.json'; progress = json.loads(path.read_text())
progress['continuation_audit'] = {'previous_goal_turn':'no_progress_verification_only','current_goal_turn':'progress',
    'basis':'A controller-owned joint family now generates coherent mixed-truth synthetic responses and executes/replays the actual fixed-draw estimator with bound family size. The final multi-world calibration remains unfinished.',
    'blocking_threshold_met':False,'full_objective_complete':False}
progress['joint_family_checkpoint'] = {'date':'2026-10-26','status':'FOCUSED_CHECKS_PASS',
    'unique_focused_tests':len(all_ids),'verification':'docs/reviews/implementation-2026-10-25/family-verification-2026-10-26.json',
    'actual_outer_worlds':1,'actual_draws':actual['draw_count'],'provider_calls':0,'scientific_readiness':False,'full_objective_complete':False}
progress['controls']['evidence-gate'] = {'status':'SATISFIED','evidence':str(len(all_ids))+' unique focused tests pass, including actual owned two-response computation/fresh replay and 19 independent oracle/adversarial cases. Exact outcomes and limits: family-verification-2026-10-26.json.'}
progress['next_action'] = 'Integrate coherent family computations into fixed development/final inventories, distinct final seeds, aggregate budgets and authenticated complete-denominator calibration counts. Assess population/stress adequacy and information targets before scientific freeze. Preserve the full campaign/reservation, protected research, genuine mixed-provider cycle, policy/AmiBroker and reporting objective.'
path.write_text(json.dumps(progress,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':value['status'],'unique_focused_tests':len(all_ids),'code_and_tests':len(code),
    'archive_members':len(members),'retained_failed_checks':len(value['retained_failed_checks'])}))
