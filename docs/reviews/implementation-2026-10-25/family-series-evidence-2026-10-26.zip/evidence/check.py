"""Retain exact check commands, exit status, timestamps and output outside Git."""
import datetime,json,subprocess,sys,uuid
from pathlib import Path
root=Path(__file__).resolve().parents[2]
work=Path(__file__).parent
command=sys.argv[1:]
if not command:raise SystemExit('Command required')
start=datetime.datetime.now(datetime.timezone.utc)
result=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
end=datetime.datetime.now(datetime.timezone.utc)
name=start.strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8]
(work/(name+'.log')).write_bytes(result.stdout)
record={'command':command,'started_at':start.isoformat(),'finished_at':end.isoformat(),
    'seconds':(end-start).total_seconds(),'exit_code':result.returncode,'log':name+'.log'}
(work/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(result.stdout.decode('utf-8',errors='replace')[-7000:])
print(json.dumps(record))
raise SystemExit(result.returncode)
