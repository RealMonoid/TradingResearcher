"""Retain exact joint-family series evidence and the unresolved resource boundary."""
import ast, datetime, hashlib, json, re, subprocess, sys, unittest, zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];work=Path(__file__).parent;out=root/'docs/reviews/implementation-2026-10-25'
sha=lambda value:hashlib.sha256(value).hexdigest()
baseline=json.loads((work/'baseline.json').read_text())
checks=[json.loads(path.read_text()) for path in sorted(work.glob('2026*.json'))]
inventory={'test_family_study*.py':14,'test_family_series_adversarial.py':10,'test_family_series_runs.py':3,
    'test_information_study*.py':19,'test_calibration*.py':42,'test_study_runs*.py':13}
sys.path[:0]=[str(root),str(root/'tests')]
def flatten(suite):
    for item in suite:
        if isinstance(item,unittest.TestSuite):yield from flatten(item)
        else:yield item.id()
ids={pattern:list(flatten(unittest.TestLoader().discover(str(root/'tests'),pattern=pattern))) for pattern in inventory}
all_ids=[value for values in ids.values() for value in values]
assert len(all_ids)==len(set(all_ids))==101
latest={}
for pattern,count in inventory.items():
    assert len(ids[pattern])==count
    matched=[c for c in checks if '-p' in c['command'] and c['command'][c['command'].index('-p')+1]==pattern]
    assert matched and matched[-1]['exit_code']==0,pattern
    check=matched[-1];log=(work/check['log']).read_text()
    assert re.search(r'Ran '+str(count)+r' tests? ',log) and re.search(r'\nOK(?:\s|$)',log),pattern
    latest[pattern]=check['log']
changed=set(subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines())
changed.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines())
code=sorted(name for name in changed if name.startswith(('trading_researcher/','tests/')) and name.endswith('.py'))
preserved=[name for name in baseline['files'] if name.startswith('tests/fixtures/') or
    name.startswith('trading_researcher/') and name.endswith('.py') and name not in code]
preserved+=['docs/architecture/'+name for name in ('02_DECISION_REGISTER.md','03_REJECTED_DECISIONS.md','04_DEFINITIONS.md','14_RETAIL_RESEARCH_CONTRACT.md')]
for name in preserved:assert sha((root/name).read_bytes())==baseline['files'][name],name
unchanged_functions=[]
with zipfile.ZipFile(work/'source-before.zip') as before:
    name='trading_researcher/information_study.py'
    old={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(before.read(name)).body if isinstance(n,ast.FunctionDef)}
    new={n.name:ast.dump(n,include_attributes=False) for n in ast.parse((root/name).read_bytes()).body if isinstance(n,ast.FunctionDef)}
    for key in old:
        if key not in ('_validate_manifest','summarize'):
            assert new[key]==old[key],key
            unchanged_functions.append(key)
review_path=work/'independent-review.json';review=json.loads(review_path.read_text())
assert review['status'].startswith('PASS')
for name,expected in review['source_sha256'].items():assert sha((root/name).read_bytes())==expected,name
published=out/'family-series-independent-2026-10-26.json'
with published.open('xb') as target:target.write(review_path.read_bytes())
members={name:(root/name).read_bytes() for name in code}
for path in sorted(work.glob('2026*')):members['checks/'+path.name]=path.read_bytes()
for path in (work/'baseline.json',work/'check.py',work/'evidence.py',review_path):members['evidence/'+path.name]=path.read_bytes()
members['evidence/test-identities.json']=(json.dumps(ids,indent=2)+'\n').encode()
with zipfile.ZipFile(work/'source-before.zip') as before:
    for name in code:
        if name in baseline['files']:members['before/'+name]=before.read(name)
for name,raw in members.items():assert not re.search(rb'\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{20,}',raw),name
archive=out/'family-series-evidence-2026-10-26.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as target:
    for name,raw in members.items():target.writestr(name,raw)
observed=[json.loads(line) for line in (work/latest['test_family_series_runs.py']).read_text().splitlines()
    if line.startswith(('{"development_series_status"','{"final_planned_worlds"'))]
assert len(observed)==2
value={'schema':'joint-family-series-verification/1','status':'CODE_CHECKS_PASS_DOCUMENTATION_PENDING',
    'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent_commit':baseline['head'],
    'unique_focused_tests':101,'test_inventory':inventory,'latest_pass_log_by_suite':latest,'checks':checks,
    'retained_failed_checks':[c['log'] for c in checks if c['exit_code']!=0],
    'independent_review_note':'The 13 independently authored count/inventory oracles and 10 adversarial cases are included among the 101 unique tests. Mocked boundaries, actual lifecycle runs and complete scientific calibration are distinguished.',
    'intermediate_failures':'Dispatch was absent before implementation. Two initial oracle selectors used id instead of cohort_id; fixed without mathematical expectation changes. Independent red tests exposed missing retained artifact IDs, suppressed known union events and unreplayed partial outcomes. Legacy calibration tests independently exposed the ID bug. All relevant suites pass after corrections.',
    'actual_lifecycle_observations':observed,
    'resource_projection':{'source':'family-verification-2026-10-26.json actual_joint_world_observation',
        'observed_prior_valid_family_stream_bytes':23325061,'projected_worlds':1024,'projected_raw_stream_bytes':23325061*1024,
        'existing_max_logical_storage_bytes':4*1024**3,
        'qualification':'Unchanged-format extrapolation, not an executed complete workload; excludes replay/materialization charges. No capacity or full calibration claim. Budgets and draw requirements unchanged.'},
    'source_sha256':{path.relative_to(root).as_posix():sha(path.read_bytes()) for path in sorted((root/'trading_researcher').glob('*.py'))},
    'changed_code_test_sha256':{name:sha((root/name).read_bytes()) for name in code},
    'preserved_sha256':{name:baseline['files'][name] for name in preserved},
    'unchanged_information_study_functions':unchanged_functions,'independent_review_sha256':sha(published.read_bytes()),
    'evidence_archive':archive.name,'evidence_archive_sha256':sha(archive.read_bytes()),'archive_members':len(members),
    'archive_scope':'Changed code/tests, prior changed source, exact commands/exits/output, identities and independent review. No raw market data, credentials or registry backup.',
    'provider_calls':0,'scientific_readiness':False,'full_objective_complete':False,
    'unverified':['Complete actual final calibration; only one of 1024 final worlds executed in the actual lifecycle fixture',
        'Practical full-series storage/compute feasibility within the unchanged budgets',
        'Population/stress adequacy, heterogeneous original-claim dependence, AST overlap and ideal sampling independence',
        'Actual information target, scientific admission/allocation/freeze and fixed release',
        'Full repository suite, exhaustive old-source replay, new-series backup/restore and all revocation race interleavings',
        'Complete campaign selection/reservation/exposure chronology',
        'Genuine mixed-provider free research cycle, policy/AmiBroker certification, domain reporting and economic usefulness']}
with (out/'family-series-verification-2026-10-26.json').open('x',encoding='utf-8') as target:target.write(json.dumps(value,indent=2)+'\n')
path=out/'progress.json';progress=json.loads(path.read_text())
progress['continuation_audit']={'previous_goal_turn':'no_progress_verification_only','current_goal_turn':'progress',
    'basis':'Shared-template family computations now enter owned fixed development/final inventories, aggregate accounting and authenticated compact complete-denominator counts; actual lifecycle exercised. Full-series resource feasibility and calibration remain unresolved.',
    'blocking_threshold_met':False,'full_objective_complete':False}
progress['family_series_checkpoint']={'date':'2026-10-26','status':'FOCUSED_CHECKS_PASS','unique_focused_tests':101,
    'verification':'docs/reviews/implementation-2026-10-25/family-series-verification-2026-10-26.json',
    'actual_development_worlds':4,'actual_final_worlds':1,'final_planned_worlds':1024,'final_status':'NOT_ASSESSED',
    'provider_calls':0,'scientific_readiness':False,'full_objective_complete':False}
progress['controls']['evidence-gate']={'status':'SATISFIED','evidence':'101 unique tests pass, including actual owned family-series lifecycle, 23 independent cases and legacy study/calibration regressions. Exact evidence and resource limits: family-series-verification-2026-10-26.json.'}
progress['next_action']='Resolve actual full-series storage/compute feasibility with verified lossless retention/calculation improvements or a justified explicit resource configuration; never drop draws, worlds, cohorts or failures. Then assess population/stress adequacy, information targets and full final calibration before scientific freeze, preserving the full campaign/reservation, mixed-provider research, policy/AmiBroker and reporting objective.'
path.write_text(json.dumps(progress,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':value['status'],'unique_focused_tests':101,'changed_code_test_files':len(code),
    'archive_members':len(members),'retained_failed_checks':len(value['retained_failed_checks'])}))
