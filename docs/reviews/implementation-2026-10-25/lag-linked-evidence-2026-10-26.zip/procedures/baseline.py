import hashlib,json,subprocess,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[2]
work=Path(__file__).parent
names=subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
with (work/'baseline.json').open('x',encoding='utf-8') as out:
    json.dump({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
        'files':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in names}},out,indent=2)
with zipfile.ZipFile(work/'source-before.zip','x',zipfile.ZIP_DEFLATED) as archive:
    for name in names:
        if name.startswith(('trading_researcher/','tests/')):archive.write(root/name,name)
print(json.dumps({'retained_files':len(names),'status':'BASELINE_CAPTURED'}))
