"""Read-only verification of completed worlds after a reporting-helper error."""
import gzip,hashlib,json,sqlite3,sys,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];work=Path(__file__).parent;sys.path.insert(0,str(root))
from trading_researcher.evaluation_plans import source_bundle,footprint
from trading_researcher.outcomes import _read_rational
from trading_researcher.population_models import specification
from trading_researcher.population_runs import run_child
profile=json.loads((work/'owned-profile.json').read_text())
prior=json.loads((root/profile['source_result']).read_text());registry=Path(prior['registry'])
saved=json.loads((work/'owned-study-input.json').read_text())
view=json.loads((work/'owned-study-latest.json').read_text())
assert view['study_id']==saved['study_id'] and view['status']=='COMPLETE'
db=sqlite3.connect((registry/'registry.sqlite3').as_uri()+'?mode=ro',uri=True)
def artifact(identity):
    raw=db.execute('SELECT envelope FROM artifacts WHERE id=?',(identity,)).fetchone()[0]
    assert hashlib.sha256(raw.encode()).hexdigest()==identity
    obj=json.loads(raw);assert obj['creator']==obj['origin']=='controller' and obj['data_class']=='development'
    return {'id':identity,**obj}
def blob(descriptor):
    sha=descriptor['sha256'];raw=(registry/'blobs'/sha[:2]/sha).read_bytes()
    assert len(raw)==descriptor['size'] and hashlib.sha256(raw).hexdigest()==sha
    return raw
def check_link(cases):
    lookup={(c['decision_time'],c['instrument']):c for c in cases};count=0
    for case in cases:
        previous=lookup.get((case['decision_time']-1800,case['instrument']))
        if previous is not None and previous['outcome'] is not None and case['condition'] is not None:
            assert int(case['condition'])==_read_rational(previous['outcome']);count+=1
    assert count>0
    return count
try:
    scalar=artifact(saved['scalar_id']);scalar_pairs=check_link([json.loads(line) for line in blob(scalar['body']['world_blob']).splitlines()])
    study=artifact(saved['study_id']);assert study['body']['source_footprint']==saved['source_footprint']==footprint(source_bundle())
    manifest=study['body']['manifest'];assert len(manifest['worlds'])==4
    attempts=[]
    for identity in view['attempt_artifact_ids']:
        body=artifact(identity)['body'];assert body['study_id']==study['id'] and body['failure'] is None
        assert len(body['proofs'])==2 and body['result']['model']['schema']=='lag-linked-binary-model/1'
        descriptor=body['output_blobs']['generate/stream.jsonl.gz'];raw=blob(descriptor)
        replay=blob(body['output_blobs']['replay/expected-stream.jsonl.gz']);assert raw==replay
        assert all(proof['stream_blob']==descriptor and proof['footprint']==saved['source_footprint'] for proof in body['proofs'])
        decoded=gzip.decompress(raw);cases={'a':[],'b':[]};draws=0
        for line in decoded.splitlines():
            if line.startswith(b'{"kind":"case",'):
                item=json.loads(line);cases[item['response_id']].append(item['value'])
            elif line.startswith(b'{"kind":"draw",'):draws+=1
        pairs={name:check_link(rows) for name,rows in cases.items()};assert draws==119994
        attempts.append({'id':identity,'world_id':body['world_id'],'outcome':body['outcome'],
            'proofs':2,'case_counts':{name:len(rows) for name,rows in cases.items()},
            'equal_shift_pairs':pairs,'retained_draws':draws,'stream_blob':descriptor,
            'settlement':body['settlement']})
    assert {a['world_id'] for a in attempts}=={w['id'] for w in manifest['worlds']}
    original=artifact(prior['execution_id'])['body']['result'];diagnostics=artifact(prior['diagnostics_id'])['body']['result']
    payload={'report':original['report'],'case_blob':original['case_blob'],'diagnostics':diagnostics,
        'specification':specification(1,0,0,'Fixed old-path compatibility observation'),
        'effects':scalar['body']['result']['model']['effects'],'scenario':0,'time_rows':96,'seed':2026102601}
    with zipfile.ZipFile(work/'source-before.zip') as archive:
        before={name:archive.read(name) for name in archive.namelist()
            if name.startswith('trading_researcher/') and name.endswith('.py') and name.count('/')==1}
    old,old_bytes=run_child(before,payload,blob(original['case_blob']),120)
    current,current_bytes=run_child(source_bundle(),payload,blob(original['case_blob']),120)
    assert old['result']==current['result'] and old_bytes==current_bytes
    result={'schema':'lag-linked-owned-observation/1','profile':profile,'source_footprint':saved['source_footprint'],
        'source_execution_id':prior['execution_id'],'source_case_blob':original['case_blob'],
        'scalar_id':scalar['id'],'scalar_pairs_equal':scalar_pairs,'scalar_source_model':scalar['body']['result']['model'],
        'legacy_result_and_case_bytes_identical':True,'study_id':study['id'],'study_status':view['status'],
        'attempts':attempts,'summary':view['summary'],'budget':view['budget'],'provider_calls':0,
        'scientific_readiness':False,'n_min':None,'full_objective_complete':False,
        'reporting_recovery':'Initial helper used a nonexistent top-level stream_blob after all four worlds completed. Read-only recovery uses actual output_blobs; no owned scalar or family-study world or attempt was rerun or replaced. The read-only legacy compatibility comparison was repeated during recovery.',
        'qualification':profile['purpose']}
    (work/'owned-observation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'PASS','scalar_equal_pairs':scalar_pairs,'development_worlds':len(attempts),
        'draws':sum(a['retained_draws'] for a in attempts),'all_shift_pairs_equal':[a['equal_shift_pairs'] for a in attempts],
        'charged_compute_ms':view['budget']['charged_compute_ms'],'charged_storage_bytes':view['budget']['charged_storage_bytes'],
        'candidate_time_rows':view['summary']['candidate_time_rows'],'scientific_readiness':False},indent=2))
finally:db.close()
