"""Exercise the new law in genuine owned scalar/family-study retention and replay."""
import gzip,hashlib,json,sys,time,zipfile
from fractions import Fraction as F
from pathlib import Path
root=Path(__file__).resolve().parents[2];work=Path(__file__).parent;sys.path.insert(0,str(root))
from trading_researcher.codec import canonical,digest
from trading_researcher.coordination import Broker
from trading_researcher.evaluation_plans import source_bundle,footprint
from trading_researcher.lag_population import specification
from trading_researcher.outcomes import _read_rational
from trading_researcher.population_models import specification as previous_spec
from trading_researcher.population_runs import run_child

profile=json.loads((work/'owned-profile.json').read_text());prefix=profile['key_prefix']
prior=json.loads((root/profile['source_result']).read_text());expected=footprint(source_bundle())
broker=Broker(prior['registry'])
def op(name,**kwargs):return broker.call(broker.admin_token,name,**kwargs)
def check_link(cases):
    lookup={(c['decision_time'],c['instrument']):c for c in cases};n=0
    for case in cases:
        before=lookup.get((case['decision_time']-1800,case['instrument']))
        if before is not None and before['outcome'] is not None and case['condition'] is not None:
            assert int(case['condition'])==_read_rational(before['outcome']);n+=1
    assert n>0
    return n
try:
    execution=op('get_artifact',artifact_id=prior['execution_id'])
    diagnostic=op('get_artifact',artifact_id=prior['diagnostics_id'])
    prior_plan=op('get_artifact',artifact_id=prior['plan_id'])
    spec=specification(profile['mask_mean_block'],F(profile['common_share']),profile['purpose'])
    scalar_args={'key':prefix+'-scalar','plan_id':prior['plan_id'],'execution_id':prior['execution_id'],
        'diagnostics_id':prior['diagnostics_id'],'specification':spec,'scenario':2,
        'time_rows':profile['scalar_time_rows'],'seed':profile['scalar_seed'],'limits':{'max_seconds':120}}
    scalar=op('run_population_world',**scalar_args)
    assert scalar['body']['status']=='GENERATED_UNCALIBRATED'
    assert op('run_population_world',**scalar_args)==scalar
    scalar_raw=broker._read_blob_bytes(scalar['body']['world_blob']['sha256'])
    scalar_pairs=check_link([json.loads(line) for line in scalar_raw.splitlines()])
    print(json.dumps({'phase':'owned_scalar','pairs_equal':scalar_pairs,'id':scalar['id']}),flush=True)
    # Numerical regression of the OLD specification against the retained complete pre-edit package.
    bound=execution['body']['result'];raw=broker._read_blob_bytes(bound['case_blob']['sha256'])
    payload={'report':bound['report'],'case_blob':bound['case_blob'],'diagnostics':diagnostic['body']['result'],
        'specification':previous_spec(1,0,0,'Fixed old-path compatibility observation'),
        'effects':scalar['body']['result']['model']['effects'],'scenario':0,'time_rows':96,'seed':2026102601}
    with zipfile.ZipFile(work/'source-before.zip') as archive:
        before={name:archive.read(name) for name in archive.namelist()
            if name.startswith('trading_researcher/') and name.endswith('.py') and name.count('/')==1}
    old,old_bytes=run_child(before,payload,raw,120);current,current_bytes=run_child(source_bundle(),payload,raw,120)
    assert old['result']==current['result'] and old_bytes==current_bytes
    plan=op('prepare_evaluation_plan',key=prefix+'-family-plan',compiled_id=prior_plan['body']['request']['compiled_id'],
        primary_count=2,dependence={'base_length':profile['family_base_length'],
            'rationale':'Fixed implementation probe including lag2 sensitivity; not a fitted or scientifically admitted block choice.',
            'development_refs':[prior['execution_id']],
            'randomness':{'algorithm':'unused-plan-input','version':'1','seed':profile['family_seed']}})
    diagnostics=op('prepare_information_diagnostics',key=prefix+'-family-diagnostics',plan_id=plan['id'],
        execution_id=prior['execution_id'],lags=[1,2,4,8],limits={'max_seconds':120})
    # This is an explicit conservative engineering estimate, not an authenticated new benchmark.
    estimate={'world_time_rows':64,'observed_compute_ms':60000,'observed_storage_bytes':64*1024**2,
        'qualification':'Operator engineering allowance for new law; values are conservative estimates, not measured performance or a full-series guarantee.'}
    cost=op('add_source',body={'schema':'development-study-cost-estimate/1',**estimate},data_class='development')
    study_profile={'specifications':[spec],'targets':[profile['family_time_rows']],
        'worlds_per_cell':profile['worlds_per_cell'],'seed':profile['family_seed'],
        'mc_noncoverage':{'numerator':'1','denominator':'100'},'outer_noncoverage':{'numerator':'1','denominator':'20'},
        'responses':['a','b'],'patterns':profile['patterns'],
        'budget':{'max_compute_ms':900000,'attempt_compute_ms':180000,'max_storage_bytes':1024**3,
            'attempt_storage_bytes':256*1024**2,'max_attempts':1},
        'cost_estimate':{'source_ref':cost['id'],**estimate}}
    study=op('prepare_family_study',key=prefix+'-family-study',plan_id=plan['id'],execution_id=prior['execution_id'],
        diagnostics_id=diagnostics['id'],profile=study_profile)
    (work/'owned-study-input.json').write_text(json.dumps({'study_id':study['id'],'profile':study_profile,
        'source_footprint':expected,'scalar_id':scalar['id']},indent=2)+'\n',encoding='utf-8')
    for number in range(4):
        view=op('advance_family_study',study_id=study['id'])
        print(json.dumps({'phase':'owned_family_study','iteration':number+1,'status':view['status'],
            'recorded_worlds':view['summary']['recorded_worlds'],'compute_ms':view['budget']['charged_compute_ms']}),flush=True)
        (work/'owned-study-latest.json').write_text(json.dumps(view,indent=2)+'\n',encoding='utf-8')
    assert view['status']=='COMPLETE',view
    attempts=[]
    for identity in view['attempt_artifact_ids']:
        body=op('get_artifact',artifact_id=identity)['body']
        assert len(body['proofs'])==2,body['failure']
        result=body['result'];assert result['model']['schema']=='lag-linked-binary-model/1'
        encoded=broker._read_blob_bytes(body['stream_blob']['sha256'])
        decoded=gzip.decompress(encoded);cases={'a':[],'b':[]};draws=0
        for line in decoded.splitlines():
            if line.startswith(b'{"kind":"case",'):
                item=json.loads(line);cases[item['response_id']].append(item['value'])
            elif line.startswith(b'{"kind":"draw",'):draws+=1
        pairs={name:check_link(rows) for name,rows in cases.items()}
        assert draws==119994,draws
        attempts.append({'id':identity,'world_id':body['world_id'],'outcome':body['outcome'],
            'proofs':len(body['proofs']),'case_counts':{name:len(rows) for name,rows in cases.items()},
            'equal_shift_pairs':pairs,'retained_draws':draws,'stream_blob':body['stream_blob']})
    assert footprint(source_bundle())==expected
    result={'schema':'lag-linked-owned-observation/1','profile':profile,'profile_hash':digest(profile),
        'source_footprint':expected,'source_execution_id':prior['execution_id'],'source_case_blob':bound['case_blob'],
        'scalar_id':scalar['id'],'scalar_pairs_equal':scalar_pairs,'scalar_source_model':scalar['body']['result']['model'],
        'legacy_result_and_case_bytes_identical':True,'study_id':study['id'],'study_status':view['status'],
        'attempts':attempts,'summary':view['summary'],'budget':view['budget'],'provider_calls':0,
        'scientific_readiness':False,'n_min':None,'full_objective_complete':False,
        'qualification':profile['purpose']}
    (work/'owned-observation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'PASS','owned_scalar_pairs_equal':scalar_pairs,'complete_development_worlds':len(attempts),
        'retained_draws':sum(x['retained_draws'] for x in attempts),'charged_compute_ms':view['budget']['charged_compute_ms'],
        'charged_storage_bytes':view['budget']['charged_storage_bytes'],'scientific_readiness':False}),flush=True)
finally:
    broker.close()
