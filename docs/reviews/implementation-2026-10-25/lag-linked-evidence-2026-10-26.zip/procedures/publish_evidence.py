"""Publish bounded engineering evidence; exclude registries, market rows and keys."""
import hashlib
import json
import re
import subprocess
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
work = Path(__file__).parent
public = root / 'docs/reviews/implementation-2026-10-25'
prefix = 'lag-linked'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

records = []
tests = set()
for path in sorted(work.glob('2026*.json')):
    record = json.loads(path.read_text())
    record['record'] = path.name
    record['log_sha256'] = sha(work / record['log'])
    records.append(record)
    if record['exit_code'] == 0:
        for line in (work / record['log']).read_text(errors='replace').splitlines():
            match = re.fullmatch(r'(test_\S+) \(([^)]+)\) \.\.\. ok', line)
            if match:
                identity = match[2]
                tests.add(identity if identity.endswith('.' + match[1]) else identity + '.' + match[1])
assert len(tests) == 113, len(tests)

observation = json.loads((work / 'owned-observation.json').read_text())
assert observation['study_status'] == 'COMPLETE'
assert observation['legacy_result_and_case_bytes_identical'] is True
assert observation['provider_calls'] == 0
assert observation['scientific_readiness'] is observation['full_objective_complete'] is False
for name, expected in observation['source_footprint'].items():
    assert sha(root / name) == expected, ('owned source drift', name)
write(public / (prefix + '-observation-2026-10-26.json'), observation)

progress_path = public / 'progress.json'
progress = json.loads(progress_path.read_text())
progress['controls']['evidence-gate']['evidence'] = '113 unique focused tests pass, including 19 independent cases. Four original owned lag-linked development worlds completed with 479976 retained draws and independent replay; exact records and retained reporting-helper failures are in lag-linked-verification-2026-10-26.json. No scientific readiness is claimed.'
progress['next_action'] = 'Assess the source-specific nuisance and stress scope beyond the simple lag-linked law before freezing a substantive information/calibration profile. Preserve the original prescribed engineering source and all study inventories; do not equate this one-day template with free discovery or infer power from one world per cell. Continue applicable scientific admission/campaign/freeze, full calibration, mixed-provider research, policy/AmiBroker and reporting.'
progress['continuation_audit']['basis'] = 'A new declared lag-linked stress law preserves the diagnosed C_t=Y_(t-2) relationship, with exact finite joint stationary initialization and missingness-aware group rates. Four owned development worlds completed and replayed without replacing seeds or failures. Existing model bytes remain identical. This is implemented integration progress, not an adequate market law, information target or complete scientific calibration.'
progress['lag_linked_population_checkpoint'] = {
    'date': '2026-10-26', 'status': 'FOCUSED_CHECKS_PASS',
    'verification': 'docs/reviews/implementation-2026-10-25/lag-linked-verification-2026-10-26.json',
    'unique_focused_tests': 113, 'independent_tests': 19,
    'actual_development_worlds': 4, 'actual_draws': 479976,
    'scalar_comparable_pairs': 94, 'unequal_shifted_pairs': 0,
    'charged_compute_ms': 96874, 'charged_logical_bytes': 111632764,
    'legacy_result_and_case_bytes_identical': True, 'provider_calls': 0,
    'original_process_adequacy': 'NOT_ASSESSED', 'n_min': None,
    'scientific_readiness': False, 'full_objective_complete': False,
}
package = next(item for item in progress['packages'] if item['step'] == 4)
for name in ('trading_researcher/LAG_LINKED_POPULATION.md',
             'docs/reviews/implementation-2026-10-25/LAG_LINKED_POPULATION_2026-10-26.md',
             'docs/reviews/implementation-2026-10-25/lag-linked-verification-2026-10-26.json'):
    if name not in package['evidence']:
        package['evidence'].append(name)
write(progress_path, progress)

source_names = ['trading_researcher/lag_population.py', 'trading_researcher/population_models.py',
                'trading_researcher/family_models.py', 'tests/test_lag_population.py',
                'tests/test_lag_population_adversarial.py']
review = public / (prefix + '-independent-2026-10-26.json')
assert review.exists(), 'Independent review must be completed first'
archive_path = public / (prefix + '-evidence-2026-10-26.zip')
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in source_names:
        archive.write(root / name, 'current/' + name)
    for path in sorted(work.glob('2026*')):
        archive.write(path, 'checks/' + path.name)
    for name in ('check.py', 'baseline.py', 'baseline.json', 'source-before.zip',
                 'owned-profile.json', 'owned_probe.initial.py', 'owned_probe.py',
                 'owned-study-input.json', 'owned-study-latest.json', 'inspect_owned.py',
                 'owned-observation.json', 'regressions.py', 'publish_evidence.py', 'release_check.py'):
        archive.write(work / name, 'procedures/' + name)
    archive.write(review, 'review/' + review.name)

baseline = json.loads((work / 'baseline.json').read_text())
changed_old = [name for name, expected in baseline['files'].items()
               if not (root / name).is_file() or sha(root / name) != expected]
allowed = {'README.md', 'docs/architecture/CURRENT_STATE.md',
           'docs/architecture/09_IMPLEMENTATION_BLUEPRINT.md',
           'docs/reviews/integration-research-2026-10-24/IMPLEMENTATION_SEQUENCE_2026-10-25.md',
           'trading_researcher/POPULATION_MODELS.md', 'trading_researcher/population_models.py',
           'trading_researcher/family_models.py', 'docs/reviews/implementation-2026-10-25/progress.json'}
assert set(changed_old) <= allowed, changed_old
dirty = subprocess.check_output(['git', 'diff', '--name-only'], cwd=root, text=True).splitlines()
new = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines()
verification_path = public / (prefix + '-verification-2026-10-26.json')
changed = sorted(set(dirty + new + [verification_path.relative_to(root).as_posix()]))
result = {
    'schema': 'lag-linked-verification/1', 'date': '2026-10-26', 'baseline_commit': baseline['head'],
    'status': 'FOCUSED_CHECKS_PASS', 'unique_focused_tests': len(tests),
    'test_ids': sorted(tests), 'checks': records, 'changed_files': changed,
    'source_and_test_sha256': {name: sha(root / name) for name in source_names},
    'preservation': {'baseline_files': len(baseline['files']),
                     'unchanged_files': len(baseline['files']) - len(changed_old),
                     'changed_baseline_files': changed_old, 'all_other_baseline_hashes_preserved': True},
    'actual_observation': {'path': prefix + '-observation-2026-10-26.json',
                           'sha256': sha(public / (prefix + '-observation-2026-10-26.json'))},
    'independent_review': {'path': review.name, 'sha256': sha(review)},
    'evidence_archive': {'path': archive_path.name, 'sha256': sha(archive_path), 'bytes': archive_path.stat().st_size},
    'retained_expected_failures': ['20261026T200344-de773fd2', '20261026T200648-576b8e9a'],
    'retained_reporting_failures': ['20261026T201115-f05857ba', '20261026T201553-7eda33a9'],
    'read_only_recovery_pass': '20261026T201612-884adcf1',
    'failed_worlds_replaced_or_rerun': False, 'provider_calls': 0,
    'scientific_readiness': False, 'full_objective_complete': False,
    'unverified': ['market nuisance/stress adequacy and heterogeneous raw-process dynamics',
                   'complete scientific calibration and admitted information target',
                   'full repository test suite', 'historical PIT and economic usefulness',
                   'scientific admission/campaign/freeze',
                   'genuine mixed-provider research cycle and policy/AmiBroker/reporting'],
}
write(verification_path, result)
print(json.dumps({'status': result['status'], 'unique_tests': len(tests), 'changed_files': len(changed),
                  'baseline_unchanged': result['preservation']['unchanged_files'],
                  'archive_bytes': archive_path.stat().st_size, 'verification_sha256': sha(verification_path)}))
