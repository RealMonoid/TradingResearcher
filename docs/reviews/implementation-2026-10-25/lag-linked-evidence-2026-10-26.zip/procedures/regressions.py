"""Affected existing source-scope, family and fixed-study contracts."""
import sys,unittest
from pathlib import Path
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tests'))
names=['test_source_process_scope','test_source_process_scope_adversarial',
    'test_family_oracles','test_family_adversarial','test_family_dispatch',
    'test_information_study','test_information_study_adversarial',
    'test_family_study_oracles','test_family_study_dispatch']
suite=unittest.TestLoader().loadTestsFromNames(names)
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
