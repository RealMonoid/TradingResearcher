"""Check exact staged bytes against checks, owned execution and independent review."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
folder = root / 'docs/reviews/implementation-2026-10-25'
record_path = folder / 'lag-linked-verification-2026-10-26.json'
record = json.loads(record_path.read_text())
staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=root, text=True).splitlines()
assert sorted(staged) == record['changed_files'], (staged, record['changed_files'])
for name in staged:
    assert not name.startswith('.trf-runtime/') and not Path(name).name.startswith('.env')
    assert (root / name).read_bytes() == subprocess.check_output(['git', 'show', ':' + name], cwd=root), name
for name, expected in record['source_and_test_sha256'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
for key in ('actual_observation', 'independent_review', 'evidence_archive'):
    item = record[key]
    assert hashlib.sha256((folder / item['path']).read_bytes()).hexdigest() == item['sha256'], key
observation = json.loads((folder / record['actual_observation']['path']).read_text())
for name, expected in observation['source_footprint'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
with zipfile.ZipFile(folder / record['evidence_archive']['path']) as archive:
    assert archive.testzip() is None
for name in ('docs/reviews/verify_system_model.py', 'docs/reviews/verify_retail_contract.py',
             'docs/reviews/implementation-2026-10-25/verify_implementation.py'):
    checks = [item for item in record['checks'] if item['command'][-1] == name]
    assert checks and checks[-1]['exit_code'] == 0, name
assert record['unique_focused_tests'] == len(record['test_ids']) == 113
assert record['scientific_readiness'] is record['full_objective_complete'] is False
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=root, check=True)
print(json.dumps({'status': 'PASS', 'staged_files': len(staged), 'exact_staged_byte_checks': len(staged),
                  'source_test_hashes': len(record['source_and_test_sha256']),
                  'owned_runtime_source_hashes': len(observation['source_footprint']),
                  'applicable_documentation_gates': 3, 'unique_tests': 113,
                  'no_private_runtime_or_credentials_staged': True, 'git_diff_cached_check_exit': 0,
                  'verification_sha256': hashlib.sha256(record_path.read_bytes()).hexdigest()}))
