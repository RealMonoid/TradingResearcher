"""Blind fixed-case review probe. Formalizations are scripted; reviews are live."""
import hashlib
import json
from pathlib import Path
import sys
import threading
import time
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / 'tests')]
from binding_support import BindingFixture, resolve
from trading_researcher.auxiliary import request_for, run_auxiliary_once
from trading_researcher.codec import canonical
from trading_researcher.coordination import Broker
from trading_researcher.meaning_reviews import profile, policy_identity
from trading_researcher.openai_provider import MODEL, configuration, cost_bound
from trading_researcher.provider_usage import read_usage_report
from trading_researcher.researcher import ScriptedProvider
from trading_researcher.server import Client, LocalServer
from trading_researcher.storage import restore_bundle

WORK = Path(__file__).parent
FIXTURE = ROOT / 'tests/fixtures/meaning_review_cases.json'
FIXTURE_SHA = 'be419900653305eb986cccb8c40ff4e1779bef1cf6d478e0b8ea49c166a88d09'
LEDGER = ROOT / '.trf-runtime/openai-integration-budget.sqlite3'
REGISTRY = WORK / 'real-registry'

def save(name, value):
    with (WORK / name).open('x', encoding='utf-8') as out:
        out.write(json.dumps(value, indent=2) + '\n')

def fixed():
    raw = FIXTURE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == FIXTURE_SHA
    return json.loads(raw)

def serve(broker):
    server = LocalServer(broker)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, thread, Client(server.url, broker.admin_token)

def stop(broker, server, thread):
    server.shutdown(); thread.join(5); server.server_close(); broker.close()

def prepare():
    cases = fixed()['cases']
    assert len(cases) == 8
    config = configuration(input_token_limit=10000, output_token_limit=1024)
    before = read_usage_report(LEDGER)
    maximum = 8 * cost_bound(10000, 1024)
    assert not before['money']['halted'] and before['money']['available_nano'] >= maximum
    plan = {'schema':'blind-meaning-review-probe-plan/1', 'created_at_utc':datetime.now(timezone.utc).isoformat(),
        'fixture_sha256':FIXTURE_SHA, 'policy':policy_identity(), 'config':config,
        'actual_model_calls_planned':8, 'actual_call_retries':0, 'maximum_additional_nano_usd':maximum,
        'epoch_groups':[[0,1],[2,3],[4,5],[6,7]],
        'epoch_group_reason':'Four independent technical fixture groups, two distinct targets per original epoch. No target may switch epochs or reset its budget. Scripted byte-count reservations and actual calls all count toward the same 12-call/80,000-token/1,800-second ceiling in each group.',
        'cases':[{'ordinal':i,'case_id':case['id'],'expected':case['expected']} for i,case in enumerate(cases)],
        'qualification':'Prewritten formalizations, not free discovery or live formalizer quality. No raw data outcomes, expected labels, case names, mutation descriptions or earlier model reviews enter the review packet. Every outcome is retained, including refusal, malformed output and disagreement.'}
    save('plan.json', plan)
    print('Frozen eight-case plan; preparing one owned synthetic source fixture.', flush=True)
    fixture = BindingFixture()
    try:
        metadata = {'snapshot':fixture.snapshot, 'feature':fixture.feature, 'reference':fixture.reference}
        fixture.broker.call(fixture.token, 'backup_bundle', destination=str(WORK / 'fixture-backup'))
        restore_bundle(WORK / 'fixture-backup', REGISTRY, fixture.broker.directory / 'operator.key')
        save('fixture-binding.json', metadata)
    finally:
        fixture.close()
    broker = Broker(REGISTRY)
    server, thread, admin = serve(broker)
    try:
        snapshot = metadata['snapshot']['id']; catalog = metadata['snapshot']['body']['catalog_id']
        definition = metadata['feature']['body']['definitions_id']
        assert admin.call('get_artifact', artifact_id=catalog)['body']['features'] == fixed()['catalog']
        for name in ('perspective-a', 'perspective-b'):
            admin.call('register_worker', name=name, role='discovery', capabilities=['research-record/v1'])
        common = {'model':MODEL,'prompt_version':'meaning-quality-probe/1',
            'generation_parameters':{'openai_responses':config},'max_output_tokens':1024,
            'call_timeout_seconds':120,'max_retries':0}
        epochs=[]; reviews=[]; credentials={}
        for group, ordinals in enumerate(plan['epoch_groups']):
            base = admin.call('create_context',role='discovery',epoch=group*3+1,artifact_ids=[catalog,definition])['id']
            epoch_profile = {**common,'mode':'live','currency':'USD','max_calls':12,'max_tokens':80000,
                'max_seconds':1800,'max_cost_units':2*cost_bound(10000,1024),'tools':[],
                'prompts':{'perspective-a':'Unused perspective in fixed technical fixture',
                           'perspective-b':'Unused perspective in fixed technical fixture'}}
            epoch = admin.call('create_research_epoch',key='fixture-group-'+str(group),context_id=base,
                workers=['perspective-a','perspective-b'],profile=epoch_profile)['id']
            epochs.append(epoch)
            for ordinal in ordinals:
                case=cases[ordinal]; label='slot-'+str(ordinal)
                idea=admin.call('add_research',kind='idea',content={'text':case['original_hypothesis_text']},
                    scope={'purpose':'Synthetic fixed semantic comparison; not market research'},source_refs=[])['id']
                aliases={'fixture:idea':idea,'fixture:data_snapshot':snapshot,'fixture:catalog':catalog,
                    'fixture:feature_definitions':definition,'fixture:feature_certificate':metadata['feature']['id'],
                    'fixture:reference_certificate':metadata['reference']['id']}
                candidate=resolve(case['candidate'],aliases)
                formal_context=admin.call('create_context',role='formalizer',epoch=group*3+1,
                    artifact_ids=[idea,catalog,snapshot])['id']
                name=label+'-f'
                token=admin.call('register_worker',name=name,role='formalizer',capabilities=['formalization/v1'])['token']
                scripted={**common,'model':'fixed-formalization-fixture/1','generation_parameters':{},
                    'prompt_version':'fixed-formalization-fixture/1','max_output_tokens':16000,
                    'prompt':'Retain the predeclared synthetic formalization verbatim. No model is called for this step.'}
                spec={'kind':'formalization/v1','context_id':formal_context,'purpose':'Fixed technical comparison input',
                    'allowed_workers':[name],'max_attempts':1,'lease_seconds':60,'deadline':int(time.time())+1800,
                    'dependencies':[],'research_epoch_id':epoch,'research_call_profile':scripted,
                    'research_inputs':{'idea_id':idea,'catalog_id':catalog,'definition_ids':[]}}
                job=admin.call('enqueue',key=label+'-f',spec=spec)['id']
                output={'status':'final','candidate':candidate,'semantic_report':case['semantic_report']}
                result=run_auxiliary_once(Client(server.url,token), ScriptedProvider([output],model=scripted['model'],mode='live'))
                assert result['accepted'], result
                target=admin.call('get_artifact',artifact_id=result['artifact_id'])
                assert target['body']['assessment']['status']==case['expected']['target_structure_status']
                batch=admin.call('inspect',job_id=job)['batch_id']
                admin.call('release_batch',batch_id=batch,target_epoch=group*3+2)
                context=admin.call('create_context',role='formalizer',epoch=group*3+2,
                    artifact_ids=[target['id'],idea,catalog,definition])['id']
                name=label+'-r'
                credentials[label]=admin.call('register_worker',name=name,role='formalizer',capabilities=['semantic-review/v1'])['token']
                spec={**spec,'kind':'semantic-review/v1','context_id':context,'allowed_workers':[name],
                    'dependencies':[job],'research_call_profile':profile(common),
                    'research_inputs':{'formalization_id':target['id'],'definition_ids':[definition]}}
                review_job=admin.call('enqueue',key=label+'-r',spec=spec)['id']
                packet=broker._auxiliary_packet_for_spec(spec)
                rendered=canonical(request_for(spec,packet))
                assert all(other['id'] not in rendered for other in cases)
                assert 'fixture_change' not in rendered and 'expected_judgment_semantics' not in rendered
                assert 'counterexamples' not in rendered and 'review_prerequisite_met_if_authenticated' not in rendered
                save(label+'-request.json',request_for(spec,packet))
                reviews.append({'ordinal':ordinal,'label':label,'job_id':review_job,'target_id':target['id'],
                    'epoch_id':epoch,'input_sha256':hashlib.sha256(rendered.encode()).hexdigest(),
                    'preexisting_scripted_formalization':result})
            usage=admin.call('inspect_research_epoch',epoch_id=epoch)['usage']
            assert usage['tokens']+2*(10000+1024)<=80000, usage
        save('worker-credentials.json', credentials)
        save('prepared.json', {'epochs':epochs,'reviews':reviews,'policy':policy_identity(),
                              'usage_before':before,'registry_verification':admin.call('verify')})
        print(json.dumps({'prepared_cases':len(reviews),'actual_calls':0,'maximum_additional_usd':maximum/1e9}),flush=True)
    finally:
        stop(broker,server,thread)

def run():
    cases=fixed()['cases']; plan=json.loads((WORK/'plan.json').read_text())
    prepared=json.loads((WORK/'prepared.json').read_text()); credentials=json.loads((WORK/'worker-credentials.json').read_text())
    assert prepared['policy']==plan['policy']==policy_identity()
    save('run-started.json',{'started_at_utc':datetime.now(timezone.utc).isoformat(),
        'probe_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'plan_sha256':hashlib.sha256((WORK/'plan.json').read_bytes()).hexdigest()})
    broker=Broker(REGISTRY,provider_routes={MODEL:{'provider':'openai','key_file':str(ROOT/'.env.local'),
        'budget_file':str(LEDGER),'config':plan['config']}})
    server,thread,admin=serve(broker)
    started=time.monotonic(); observations=[]
    try:
        for item in prepared['reviews']:
            if read_usage_report(LEDGER)['money']['halted']:
                observations.append({**item,'status':'NOT_RUN_LEDGER_HALTED'})
                continue
            result=run_auxiliary_once(Client(server.url,credentials[item['label']]))
            assessment=admin.call('assess_meaning_review',key=item['label'],formalization_id=item['target_id'])
            record=admin.call('get_artifact',artifact_id=result['artifact_id']) if result.get('accepted') else None
            judgment=record['body']['review']['judgment'] if record else None
            expected=cases[item['ordinal']]['expected']
            observation={**item,'status':'OBSERVED','outcome':result,'review':record,'assessment':assessment,
                'expected':expected,'observed_judgment':judgment,'judgment_matches':judgment==expected['judgment'],
                'prerequisite_matches':(assessment['body']['independent_semantic_review']=='SATISFIED')==expected['review_prerequisite_met_if_authenticated']}
            observations.append(observation); save(item['label']+'-result.json',observation)
            print(json.dumps({'slot':item['ordinal'],'accepted':result.get('accepted'),'judgment':judgment,
                'judgment_matches':observation['judgment_matches'],'prerequisite_matches':observation['prerequisite_matches']}),flush=True)
    finally:
        after=read_usage_report(LEDGER)
        old={call['dispatch_id'] for call in prepared['usage_before']['calls']}
        calls=[call for call in after['calls'] if call['dispatch_id'] not in old]
        save('live-result.json',{'schema':'blind-meaning-review-observation/1','elapsed_seconds':round(time.monotonic()-started,6),
            'fixture_sha256':FIXTURE_SHA,'observations':observations,'planned_cases':8,
            'epoch_usage':[admin.call('inspect_research_epoch',epoch_id=epoch)['usage'] for epoch in prepared['epochs']],
            'actual_new_provider_calls':calls,'aggregate_usage':after,'registry_verification':admin.call('verify'),
            'qualification':plan['qualification']})
        stop(broker,server,thread)
    assert len(observations)==8 and all(o.get('judgment_matches') and o.get('prerequisite_matches') for o in observations), 'Retained model disagreement or incomplete case; inspect every observation without selective reruns'
    print(json.dumps({'completed_cases':8,'new_provider_calls':len(calls),'elapsed_seconds':round(time.monotonic()-started,6)}))

if __name__=='__main__':
    {'prepare':prepare,'run':run}[sys.argv[1]]()
