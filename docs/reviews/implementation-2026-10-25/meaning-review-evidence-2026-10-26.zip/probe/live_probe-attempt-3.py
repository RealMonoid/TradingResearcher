"""Blind fixed-case review probe. Formalizations are scripted; reviews are live."""
import hashlib
import json
from pathlib import Path
import sys
import threading
import time
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / 'tests')]
from binding_support import BindingFixture, resolve
from trading_researcher.auxiliary import request_for, run_auxiliary_once
from trading_researcher.codec import canonical
from trading_researcher.coordination import Broker
from trading_researcher.meaning_reviews import profile, policy_identity
from trading_researcher.openai_provider import MODEL, configuration, cost_bound
from trading_researcher.provider_usage import read_usage_report
from trading_researcher.researcher import ScriptedProvider
from trading_researcher.server import Client, LocalServer
from trading_researcher.storage import restore_bundle

PRIOR = Path(__file__).parent
WORK = PRIOR / 'attempt-3'
WORK.mkdir(exist_ok=True)
FIXTURE = ROOT / 'tests/fixtures/meaning_review_cases.json'
FIXTURE_SHA = 'be419900653305eb986cccb8c40ff4e1779bef1cf6d478e0b8ea49c166a88d09'
LEDGER = ROOT / '.trf-runtime/openai-integration-budget.sqlite3'
REGISTRY = WORK / 'real-registry'

def save(name, value):
    with (WORK / name).open('x', encoding='utf-8') as out:
        out.write(json.dumps(value, indent=2) + '\n')

def fixed():
    raw = FIXTURE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == FIXTURE_SHA
    return json.loads(raw)

def serve(broker):
    server = LocalServer(broker)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, thread, Client(server.url, broker.admin_token)

def stop(broker, server, thread):
    server.shutdown(); thread.join(5); server.server_close(); broker.close()

def prepare():
    cases = fixed()['cases']
    assert len(cases) == 8
    config = configuration(input_token_limit=14000, output_token_limit=1024)
    before = read_usage_report(LEDGER)
    maximum = 8 * cost_bound(14000, 1024)
    assert not before['money']['halted'] and before['money']['available_nano'] >= maximum
    plan = {'schema':'blind-meaning-review-probe-plan/1', 'created_at_utc':datetime.now(timezone.utc).isoformat(),
        'fixture_sha256':FIXTURE_SHA, 'policy':policy_identity(), 'config':config,
        'actual_model_calls_planned':8, 'actual_call_retries':0, 'maximum_additional_nano_usd':maximum,
        'epoch_groups':[[0,1],[2,3],[4,5],[6,7]],
        'epoch_group_reason':'Four independent technical fixture groups, two distinct targets per original epoch. No target may switch epochs or reset its budget. Scripted byte-count reservations and actual calls all count toward the same 12-call/80,000-token/1,800-second ceiling in each group.',
        'cases':[{'ordinal':i,'case_id':case['id'],'expected':case['expected']} for i,case in enumerate(cases)],
        'qualification':'Prewritten formalizations, not free discovery or live formalizer quality. No raw data outcomes, expected labels, case names, mutation descriptions or earlier model reviews enter the review packet. Every outcome is retained, including refusal, malformed output and disagreement.'}
    save('plan.json', plan)
    save('prior-probe.json', {'status':'INCOMPLETE_PREVIOUS_QUALITY_PROBE',
        'prior_registry':str(PRIOR/'attempt-2/real-registry'),
        'prior_result_sha256':hashlib.sha256((PRIOR/'attempt-2/live-result.json').read_bytes()).hexdigest(),
        'prior_script_sha256':hashlib.sha256((PRIOR/'live_probe-attempt-2.py').read_bytes()).hexdigest(),
        'reason':'Six inputs exceeded the 10,000-token preflight cap; two actual outputs matched fixed expectations. The complete-original fixture snapshot alias lacked an explicit identity binding in the packet; exact future-anchor schema semantics also needed neutral documentation.',
        'correction':'Retain all previous outcomes. Reuse only the pre-job synthetic source fixture. Repeat all eight cases under a new explicitly versioned engineering probe, with 14,000 input-token bound and visible identity/schema interpretation. Original idea text, candidates, golden expectations, comparison prompt and production code stay unchanged. No selective rerun or claim of fresh scientific evidence.'})
    print('Frozen unchanged eight-case plan; restoring retained pre-job synthetic fixture.', flush=True)
    metadata = json.loads((PRIOR/'fixture-binding.json').read_text())
    restore_bundle(PRIOR/'fixture-backup', REGISTRY, PRIOR/'real-registry/operator.key')
    save('fixture-binding.json', metadata)
    broker = Broker(REGISTRY)
    server, thread, admin = serve(broker)
    try:
        snapshot = metadata['snapshot']['id']; catalog = metadata['snapshot']['body']['catalog_id']
        definition = metadata['feature']['body']['definitions_id']
        assert admin.call('get_artifact', artifact_id=catalog)['body']['features'] == fixed()['catalog']
        for name in ('perspective-a', 'perspective-b'):
            admin.call('register_worker', name=name, role='discovery', capabilities=['research-record/v1'])
        common = {'model':MODEL,'prompt_version':'meaning-quality-probe/1',
            'generation_parameters':{'openai_responses':config},'max_output_tokens':1024,
            'call_timeout_seconds':120,'max_retries':0}
        epochs=[]; reviews=[]; credentials={}
        for group, ordinals in enumerate(plan['epoch_groups']):
            base = admin.call('create_context',role='discovery',epoch=group*3+1,artifact_ids=[catalog,definition])['id']
            epoch_profile = {**common,'mode':'live','currency':'USD','max_calls':12,'max_tokens':80000,
                'max_seconds':1800,'max_cost_units':2*cost_bound(14000,1024),'tools':[],
                'prompts':{'perspective-a':'Unused perspective in fixed technical fixture',
                           'perspective-b':'Unused perspective in fixed technical fixture'}}
            epoch = admin.call('create_research_epoch',key='fixture-group-'+str(group),context_id=base,
                workers=['perspective-a','perspective-b'],profile=epoch_profile)['id']
            epochs.append(epoch)
            for ordinal in ordinals:
                case=cases[ordinal]; label='slot-'+str(ordinal)
                idea=admin.call('add_research',kind='idea',content={'text':case['original_hypothesis_text']},
                    scope={'purpose':'Synthetic fixed semantic comparison; not market research',
                        'input_interpretation':{'authority':'Representation and identity definitions only; no added original-hypothesis commitment.',
                            'identity_aliases':{'fixture:data_snapshot':snapshot},
                            'identity_rule':'The original fixture identifier and the owned immutable snapshot ID name the same synthetic input. Original hypothesis text is preserved verbatim.',
                            'schema':'hypothesis-exec/1',
                            'future_anchor_rule':'Under the installed typed language, outcome_bars=h and grid_seconds=900 select exactly t+h*900 seconds, never the next available row. The outcome program runs at that anchor; absent anchors, immature or unavailable outcomes and the exclusive universe boundary remain explicit categories.',
                            'source':'trading_researcher/outcomes.py:_case and trading_researcher/binding.py:normalized_request',
                            'source_sha256':{name:hashlib.sha256((ROOT/'trading_researcher'/name).read_bytes()).hexdigest()
                                             for name in ('outcomes.py','binding.py')}}},source_refs=[])['id']
                aliases={'fixture:idea':idea,'fixture:data_snapshot':snapshot,'fixture:catalog':catalog,
                    'fixture:feature_definitions':definition,'fixture:feature_certificate':metadata['feature']['id'],
                    'fixture:reference_certificate':metadata['reference']['id']}
                candidate=resolve(case['candidate'],aliases)
                formal_context=admin.call('create_context',role='formalizer',epoch=group*3+1,
                    artifact_ids=[idea,catalog,snapshot])['id']
                name=label+'-f'
                token=admin.call('register_worker',name=name,role='formalizer',capabilities=['formalization/v1'])['token']
                scripted={**common,'model':'fixed-formalization-fixture/1','generation_parameters':{},
                    'prompt_version':'fixed-formalization-fixture/1','max_output_tokens':16000,
                    'prompt':'Retain the predeclared synthetic formalization verbatim. No model is called for this step.'}
                spec={'kind':'formalization/v1','context_id':formal_context,'purpose':'Fixed technical comparison input',
                    'allowed_workers':[name],'max_attempts':1,'lease_seconds':60,'deadline':int(time.time())+1800,
                    'dependencies':[],'research_epoch_id':epoch,'research_call_profile':scripted,
                    'research_inputs':{'idea_id':idea,'catalog_id':catalog,'definition_ids':[]}}
                job=admin.call('enqueue',key=label+'-f',spec=spec)['id']
                output={'status':'final','candidate':candidate,'semantic_report':case['semantic_report']}
                result=run_auxiliary_once(Client(server.url,token), ScriptedProvider([output],model=scripted['model'],mode='live'))
                assert result['accepted'], result
                target=admin.call('get_artifact',artifact_id=result['artifact_id'])
                assert target['body']['assessment']['status']==case['expected']['target_structure_status']
                batch=admin.call('inspect',job_id=job)['batch_id']
                admin.call('release_batch',batch_id=batch,target_epoch=group*3+2)
                context=admin.call('create_context',role='formalizer',epoch=group*3+2,
                    artifact_ids=[target['id'],idea,catalog,definition])['id']
                name=label+'-r'
                credentials[label]=admin.call('register_worker',name=name,role='formalizer',capabilities=['semantic-review/v1'])['token']
                (WORK/'worker-credentials.json').write_text(json.dumps(credentials),encoding='utf-8')
                spec={**spec,'kind':'semantic-review/v1','context_id':context,'allowed_workers':[name],
                    'dependencies':[job],'research_call_profile':profile(common),
                    'research_inputs':{'formalization_id':target['id'],'definition_ids':[definition]}}
                packet=broker._auxiliary_packet_for_spec(spec)
                rendered=canonical(request_for(spec,packet))
                assert all(other['id'] not in rendered for other in cases)
                assert 'fixture_change' not in rendered and 'expected_judgment_semantics' not in rendered
                assert 'counterexamples' not in rendered and 'review_prerequisite_met_if_authenticated' not in rendered
                save(label+'-request.json',request_for(spec,packet))
                reviews.append({'ordinal':ordinal,'label':label,'spec':spec,'target_id':target['id'],
                    'epoch_id':epoch,'input_sha256':hashlib.sha256(rendered.encode()).hexdigest(),
                    'preexisting_scripted_formalization':result})
            usage=admin.call('inspect_research_epoch',epoch_id=epoch)['usage']
            assert usage['tokens']+2*(14000+1024)<=80000, usage
        for item in reviews:
            item['job_id']=admin.call('enqueue',key=item['label']+'-r',spec=item.pop('spec'))['id']
        save('prepared.json', {'epochs':epochs,'reviews':reviews,'policy':policy_identity(),
                              'usage_before':before,'registry_verification':admin.call('verify')})
        print(json.dumps({'prepared_cases':len(reviews),'actual_calls':0,'maximum_additional_usd':maximum/1e9}),flush=True)
    finally:
        stop(broker,server,thread)

def run():
    cases=fixed()['cases']; plan=json.loads((WORK/'plan.json').read_text())
    prepared=json.loads((WORK/'prepared.json').read_text()); credentials=json.loads((WORK/'worker-credentials.json').read_text())
    assert prepared['policy']==plan['policy']==policy_identity()
    save('run-started.json',{'started_at_utc':datetime.now(timezone.utc).isoformat(),
        'probe_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'plan_sha256':hashlib.sha256((WORK/'plan.json').read_bytes()).hexdigest()})
    broker=Broker(REGISTRY,provider_routes={MODEL:{'provider':'openai','key_file':str(ROOT/'.env.local'),
        'budget_file':str(LEDGER),'config':plan['config']}})
    server,thread,admin=serve(broker)
    started=time.monotonic(); observations=[]; stop_reason=None
    try:
        for item in prepared['reviews']:
            if stop_reason:
                observations.append({**item,'status':'NOT_RUN_AFTER_HARNESS_FAILURE','reason':stop_reason})
                continue
            if read_usage_report(LEDGER)['money']['halted']:
                observations.append({**item,'status':'NOT_RUN_LEDGER_HALTED'})
                continue
            epoch=admin.call('inspect_research_epoch',epoch_id=item['epoch_id'])
            if epoch['state']!='active' or time.time()+120 >= epoch['created_at']+epoch['request']['profile']['max_seconds']:
                stop_reason='Prepared epoch is not active with a complete call-time allowance'
                observations.append({**item,'status':'NOT_RUN_STALE_EPOCH','reason':stop_reason})
                continue
            try:
                result=run_auxiliary_once(Client(server.url,credentials[item['label']]))
                if result is None:
                    stop_reason='No eligible job; preserve host queue order without redispatch'
                    observation={**item,'status':'NOT_RUN_NO_ELIGIBLE_JOB','reason':stop_reason}
                else:
                    assessment=admin.call('assess_meaning_review',key=item['label'],formalization_id=item['target_id'])
                    record=admin.call('get_artifact',artifact_id=result['artifact_id']) if result.get('accepted') else None
                    judgment=record['body']['review']['judgment'] if record else None
                    expected=cases[item['ordinal']]['expected']
                    observation={**item,'status':'OBSERVED','outcome':result,'review':record,'assessment':assessment,
                        'expected':expected,'observed_judgment':judgment,'judgment_matches':judgment==expected['judgment'],
                        'prerequisite_matches':(assessment['body']['independent_semantic_review']=='SATISFIED')==expected['review_prerequisite_met_if_authenticated']}
            except Exception as exc:
                stop_reason=type(exc).__name__
                observation={**item,'status':'HARNESS_EXCEPTION','error_type':stop_reason}
            observations.append(observation); save(item['label']+'-result.json',observation)
            print(json.dumps({'slot':item['ordinal'],'status':observation['status'],
                'accepted':observation.get('outcome',{}).get('accepted'),'judgment':observation.get('observed_judgment'),
                'judgment_matches':observation.get('judgment_matches'),'prerequisite_matches':observation.get('prerequisite_matches')}),flush=True)
    finally:
        seen={item['ordinal'] for item in observations}
        observations.extend({**item,'status':'NOT_RUN_AFTER_INTERRUPTION'} for item in prepared['reviews'] if item['ordinal'] not in seen)
        after=read_usage_report(LEDGER)
        old={call['dispatch_id'] for call in prepared['usage_before']['calls']}
        calls=[call for call in after['calls'] if call['dispatch_id'] not in old]
        save('live-result.json',{'schema':'blind-meaning-review-observation/1','elapsed_seconds':round(time.monotonic()-started,6),
            'fixture_sha256':FIXTURE_SHA,'observations':observations,'planned_cases':8,
            'epoch_usage':[admin.call('inspect_research_epoch',epoch_id=epoch)['usage'] for epoch in prepared['epochs']],
            'actual_new_provider_calls':calls,'aggregate_usage':after,'registry_verification':admin.call('verify'),
            'qualification':plan['qualification']})
        stop(broker,server,thread)
    assert len(observations)==8 and all(o.get('judgment_matches') and o.get('prerequisite_matches') for o in observations), 'Retained model disagreement or incomplete case; inspect every observation without selective reruns'
    print(json.dumps({'completed_cases':8,'new_provider_calls':len(calls),'elapsed_seconds':round(time.monotonic()-started,6)}))

if __name__=='__main__':
    {'prepare':prepare,'run':run}[sys.argv[1]]()
