"""Record the bounded measurement checkpoint, preserving failed probes and prior evidence."""
import hashlib,json
from pathlib import Path
import subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).resolve().parent
OUT=ROOT/'docs/reviews/implementation-2026-10-25'
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')

checks=read(WORK/'focused-result.json');baseline=read(WORK/'baseline.json')['files']
review=read(OUT/'measurement-review.json');probe=read(WORK/'real-rpc-result.json')
full_loop=read(WORK/'real-http-result.json')
assert checks['tests']==78 and checks['exit_code']==1
assert all(item['exit_code']==0 for item in checks['checks'][:-1])
assert checks['checks'][-1]['exit_code']==1 and checks['checks'][-1]['test_count']==8
assert probe['exit_code']==0 and full_loop['exit_code']==1
assert review['independent_checks']['final']['exit_code']==0
assert all(sha(ROOT/path)==expected for path,expected in checks['source_and_test_hashes'].items())
old_reports={path:value for path,value in baseline.items()
    if path.startswith('docs/reviews/') and path.endswith(('-review.json','-verification.json'))}
assert all(sha(ROOT/path)==value for path,value in old_reports.items())

progress=read(OUT/'progress.json')
package=next(item for item in progress['packages'] if item['step']==2)
package['evidence'] += ['trading_researcher/MEASUREMENTS.md',
    'docs/reviews/implementation-2026-10-25/measurement-review.json',
    'docs/reviews/implementation-2026-10-25/measurement-verification.json']
package['remaining_action']='Implement a genuine provider connection and bounded full-context presentation. Measurement RPC and small scripted loop pass; the large real-data scripted context hit its byte-based budget before dispatch. API key provisioned; USD5 aggregate test budget authorized. Check supported ChatGPT-plan access before requesting any API top-up. Scientific gates remain separate.'
progress['controls']['evidence-gate']['evidence']='Measurement checkpoint:21 focused tests including14 independent cases;78 unique focused/regression tests total.70 passed initially; one of8 runtime tests hit a connection reset, then8 passed unchanged. Direct real-data HTTP measurement passed; full-context scripted loop was blocked before dispatch by its frozen budget. Prior evidence preserved.'
progress['decisions']=[{'id':'API_ACCESS','status':'KEY_PROVISIONED_LIVE_ACCESS_UNVERIFIED',
    'scope':'OpenAI only; ignored local env destination; no plaintext in artifacts',
    'need':'Provisioning approved and verified locally. Supported ChatGPT-plan alternative under review; account/model eligibility and API billing not yet verified.'},
    {'id':'PAID_RUN_CAP','status':'APPROVED','currency':'USD','maximum_total':'5.00',
     'scope':'Aggregate across all initial actual OpenAI integration tests, not per epoch or retry',
     'need':'Retain durable cumulative reservations before paid dispatch; do not silently fall back from subscription access to API billing.'}]
progress['authorization']='User delegated the seven-package implementation; later approved secure OpenAI key provisioning and USD5 aggregate for initial API integration tests. User resumed with pause vorbei. No change to scientific meaning or capital authority.'
progress['next_action']=package['remaining_action']
progress['external_inputs_needed']=['Interactive ChatGPT-plan consent if that supported route is selected; API payment setup only if the API-key route is required and lacks billing.']
progress['continuation_audit']={'previous_goal_turn':'progress','current_goal_turn':'progress',
    'basis':'Retained measurement implementation/review/check/probe evidence and user-approved credential/budget status. Resumed implementation after explicit pause vorbei.',
    'blocking_threshold_met':False,'full_objective_complete':False}
write(OUT/'progress.json',progress)

archive=OUT/'measurement-evidence.zip'
files=set((ROOT/'trading_researcher').glob('*.py'))|set((ROOT/'tests').rglob('*.py'))|set((ROOT/'tests/fixtures').glob('*.json'))
files|=set(WORK.glob('*.py'))|set(WORK.glob('*.json'))|set(WORK.glob('*.log'))
independent=ROOT/'.trf-runtime/measurement-independent-review-2026-10-25'
files|=set(independent.glob('*.py'))|set(independent.glob('*.json'))|set(independent.glob('*.log'))
files|={OUT/'measurement-review.json',ROOT/'trading_researcher/MEASUREMENTS.md',ROOT/'trading_researcher/RESEARCHER.md'}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as stream:
    for path in sorted(files):
        assert path.suffix in ('.py','.json','.log','.md') and path.name!='.env.local'
        stream.write(path,path.relative_to(ROOT).as_posix())
report={'schema':'development-measurement-verification/1','date':'2026-10-25',
    'status':'VERIFIED_BOUNDED_MEASUREMENTS_WITH_RETAINED_INTEGRATION_LIMITS',
    'purpose':'Connect provider-neutral discovery requests to qualified causal measurements within existing authority and exposure rules.',
    'unique_focused_and_regression_tests':78,'focused_initial_run':checks,
    'runtime_unchanged_rerun':{'command':[sys.executable,'-B','-m','unittest','discover','-s','tests','-p','test_local_runtime.py','-q'],
        'test_count':8,'unittest_seconds':14.877,'exit_code':0,
        'evidence_kind':'Structured terminal result observed in the conversation, session31015/chunk074159. No separate raw-log file was captured for this rerun.',
        'remaining_uncertainty':'Initial WinError10054 at the Origin-rejection request remains unexplained; passing rerun does not establish its cause.'},
    'independent_review':{'path':'docs/reviews/implementation-2026-10-25/measurement-review.json','sha256':sha(OUT/'measurement-review.json'),
        'tests':14,'included_in_total_78':True,'exit_code':0},
    'real_data_direct_http_probe':{'status':probe['status'],'exit_code':probe['exit_code'],'wall_seconds':probe['wall_seconds'],
        'measurements':len(probe['measurement_artifacts']),'output_positions_each':8,
        'scope':probe['scope'],'full_source_prompt_loading_exercised':False,
        'source_value_comparison':probe['exact_source_value_comparison'],'peer_read':probe['peer_artifact_read'],
        'result_sha256':sha(WORK/'real-rpc-result.json')},
    'full_real_data_scripted_loop':{'exit_code':1,'model_dispatches':0,
        'finding':'Frozen input budget rejected complete source-context serialization under synthetic byte-based accounting.',
        'result_sha256':sha(WORK/'real-http-result.json'),
        'remaining_work':'Bounded source presentation and genuine provider accounting; the direct-RPC probe does not satisfy this integration requirement.',
        'probe_limit':'The unexecuted final scripted record used observation, which the loop does not accept as a terminal idea/gap. A future full-loop probe must also correct that fixture.'},
    'preserved_prior_reports':old_reports,'evidence_archive':{'path':archive.relative_to(ROOT).as_posix(),
        'sha256':sha(archive),'bytes':archive.stat().st_size,
        'scope':'Source, fixtures, independent review, logs, exact probe requests/results; no credentials or complete underlying Binance registry.'},
    'unverified':['Complete current project suite was not rerun; prior full-suite evidence applies to its prior snapshot.',
        'Live provider/model compatibility, billing reconciliation and genuine invention.',
        'Full large-source researcher-loop integration and underlying cause of the transient HTTP reset.',
        'Historical point-in-time truth, scientific certification/freeze, calibration, N_min, usefulness and capital deployment.'],
    'changed_files':{},'documentation_checks':[]}
report_path=OUT/'measurement-verification.json'
with report_path.open('x',encoding='utf-8') as stream:json.dump(report,stream,indent=2)
for command,name in [([sys.executable,'-B','docs/reviews/verify_retail_contract.py'],'retail-contract.log'),
                     (['git','diff','--check'],'git-diff-check.log')]:
    checked=subprocess.run(command,cwd=ROOT,capture_output=True,text=True)
    (WORK/name).write_text(checked.stdout+checked.stderr,encoding='utf-8')
    report['documentation_checks'].append({'command':command,'exit_code':checked.returncode,'log':name,
        'output':checked.stdout+checked.stderr})
paths=[p for folder in ('trading_researcher','tests','docs') for p in (ROOT/folder).rglob('*') if p.is_file()]+[ROOT/'README.md']
report['changed_files']={p.relative_to(ROOT).as_posix():sha(p) for p in paths
    if p!=report_path and baseline.get(p.relative_to(ROOT).as_posix())!=sha(p)}
report['exit_code']=0 if all(item['exit_code']==0 for item in report['documentation_checks']) else 1
write(report_path,report)
print(json.dumps({'status':report['status'],'exit_code':report['exit_code'],'changed_files':list(report['changed_files']),
    'preserved_prior_reports':len(old_reports),'documentation_checks':report['documentation_checks']},indent=2))
raise SystemExit(report['exit_code'])
