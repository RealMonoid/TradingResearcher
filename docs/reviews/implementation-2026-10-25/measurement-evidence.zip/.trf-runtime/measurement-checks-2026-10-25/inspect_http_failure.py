"""Read only the blocked fixture probe's reason and reservation sizes."""
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from trading_researcher.coordination import Broker
from trading_researcher.codec import decode
broker=Broker(ROOT/'.trf-runtime/binance-normalized-registry-2026-10-25')
try:
    for row in broker._db.execute('SELECT id,envelope FROM job_specs'):
        spec=decode(row['envelope'])
        if any(name.startswith('measurement-probe-') for name in spec['allowed_workers']):
            inspected=broker.call(broker.admin_token,'inspect',job_id=row['id'])
            print(json.dumps({'job_id':row['id'],'attempts':inspected['attempts']}))
finally:broker.close()
