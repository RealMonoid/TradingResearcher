"""Scripted research-tool transport over real retained development data; no LLM."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
import threading
import time

ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from trading_researcher.codec import decode
from trading_researcher.coordination import Broker
from trading_researcher.researcher import DEVELOPMENT_TOOL_DEFINITIONS,ScriptedProvider,run_research_once
from trading_researcher.server import Client,LocalServer

def hashes():
    return {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((ROOT/'trading_researcher').glob('*.py'))}

def main():
    before=hashes();started=time.monotonic()
    registry=ROOT/'.trf-runtime/binance-normalized-registry-2026-10-25'
    snapshot_id='47ba3ea53be2de6ba0ecd63bc0b19ff118ebb55e2bb649a123fd54c8497d2990'
    broker=Broker(registry);server=None;thread=None
    report={'status':'INCOMPLETE','source_hashes':before,'registry':str(registry),
            'qualification':'Scripted provider and real retained Binance development data. No live LLM, market inference or scientific validity.'}
    try:
        server=LocalServer(broker);thread=threading.Thread(target=server.serve_forever);thread.start()
        admin=Client(server.url,broker.admin_token,timeout=120)
        snapshot=admin.call('get_artifact',artifact_id=snapshot_id)
        names=['measurement-probe-first','measurement-probe-second']
        credentials={name:admin.call('register_worker',name=name,role='discovery',capabilities=['research-record/v1']) for name in names}
        context=admin.call('create_context',role='discovery',epoch=1,artifact_ids=[snapshot_id,snapshot['body']['catalog_id']])
        request={'snapshot_id':snapshot_id,'universe':{'start':'2020-01-02T00:00:00Z',
            'end':'2020-01-02T02:00:00Z','instruments':['BTCUSDT']},'warmup_bars':1,
            'program':{'schema':'research-ast/1','catalog_hash':snapshot['body']['catalog_hash'],
                'expression':{'op':'lag','bars':1,'arg':{'op':'feature','ref':'BTCUSDT.close@binance-spot-15m-v1'}}}}
        profile={'model':'fixture/1','prompt_version':'measurement-http-probe/1','max_calls':4,
            'max_tokens':80000,'max_seconds':300,'max_cost_units':0,'currency':'NONE','mode':'fixture',
            'prompts':{name:'Fixed scripted engineering probe; retain data qualifications, no market conclusion.' for name in names},
            'tools':DEVELOPMENT_TOOL_DEFINITIONS,'generation_parameters':{},'max_output_tokens':4096,
            'call_timeout_seconds':15,'max_retries':0}
        with (WORK/'real-http-profile.json').open('x',encoding='utf-8') as out:
            json.dump({'request':request,'profile':profile,'source_hashes':before},out,indent=2)
        epoch=admin.call('create_research_epoch',key='measurement-http-probe/1',context_id=context['id'],workers=names,profile=profile)
        batch=admin.call('create_batch',key='measurement-http-probe/1',epoch=1)
        for name in names:
            admin.call('enqueue',key=name,spec={'kind':'research-record/v1','context_id':context['id'],
                'purpose':'Scripted development measurement transport; no scientific conclusion','allowed_workers':[name],
                'max_attempts':1,'lease_seconds':30,'deadline':int(time.time())+360,'dependencies':[],
                'batch_id':batch['id'],'research_epoch_id':epoch['id']})
        admin.call('seal_batch',batch_id=batch['id']);outcomes=[]
        for name in names:
            provider=ScriptedProvider([
                {'status':'tools','calls':[{'id':'lagged-close','name':'measure_development','arguments':request}]},
                {'status':'final','record':{'kind':'observation','content':{'text':'Scripted tool execution observed; no market conclusion.'},
                    'scope':{'purpose':'technical_integration_probe'},'source_refs':[snapshot_id]}}])
            outcomes.append(run_research_once(Client(server.url,credentials[name]['token'],timeout=120),provider))
        report['outcomes']=outcomes
        assert all(item and item['accepted'] and item['genuine_discovery'] is False for item in outcomes),outcomes
        state=admin.call('inspect_research_epoch',epoch_id=epoch['id']);saved=[]
        for call in state['calls']:
            for message in call['request']['messages']:
                if message['role']=='tool':
                    artifact=decode(message['content'])['result']['value']
                    if artifact['body'].get('schema')=='development-measurement/1':saved.append(artifact)
        assert len(saved)==2
        assert saved[0]['body']['result']==saved[1]['body']['result']
        result=saved[0]['body']['result']
        assert result['status']=='MEASURED_DEVELOPMENT' and result['processed_positions']==8
        assert result['scientific_readiness'] is False and result['classification_permitted'] is False
        # Direct exact source-value oracle; independent of the expression evaluator.
        loaded=broker._load_reference_data(snapshot_id,'2020-01-01T23:45:00Z','2020-01-02T02:00:00Z',['BTCUSDT'])
        rows={row['time']:row for row in loaded['rows']};expected=[]
        for value in result['values']:
            assert value['time'] in rows and value['missing'] is None
            sample=rows[value['time']-900]['features']['BTCUSDT.close@binance-spot-15m-v1']
            assert sample['available_at']<=value['time']
            exact=Fraction(sample['value']);expected.append(exact)
            assert value['value']=={'numerator':str(exact.numerator),'denominator':str(exact.denominator)}
        mean=sum(expected,Fraction(0))/len(expected)
        assert result['summary']['mean']=={'numerator':str(mean.numerator),'denominator':str(mean.denominator)}
        assert saved[0]['id'] not in json.dumps(state['calls'][2]['request'])
        integrity=admin.call('verify');assert integrity['status']=='PASS'
        assert hashes()==before
        report.update(status='PASS_WITH_DEVELOPMENT_ONLY_LIMITS',exit_code=0,
            perspectives=2,calls=len(state['calls']),measurement_artifacts=saved,
            exact_source_value_comparison='PASS',private_perspective_transcripts='PASS',
            epoch_id=epoch['id'],usage=state['usage'],integrity=integrity,
            usage_units='Synthetic fixture byte counts; not provider tokenization or billing')
    except BaseException as exc:
        report.update(status='FAIL',exit_code=1,error={'type':type(exc).__name__,'message':str(exc)[:2000]})
        raise
    finally:
        if server is not None:server.shutdown();server.server_close()
        if thread is not None:thread.join()
        broker.close();report['wall_seconds']=round(time.monotonic()-started,3)
        with (WORK/'real-http-result.json').open('x',encoding='utf-8') as out:json.dump(report,out,indent=2)
        print(json.dumps({key:report.get(key) for key in ('status','exit_code','perspectives','calls','wall_seconds','error')}))

if __name__=='__main__':main()
