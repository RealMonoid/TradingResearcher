"""Bounded direct HTTP measurement probe; does not exercise full prompt loading."""
from fractions import Fraction
import hashlib,json
from pathlib import Path
import sys,threading,time
ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from trading_researcher.coordination import Broker
from trading_researcher.codec import canonical
from trading_researcher.researcher import DEVELOPMENT_TOOL_DEFINITIONS
from trading_researcher.server import Client,LocalServer

def main():
    prior=json.loads((WORK/'real-http-profile.json').read_text())
    request=prior['request'];snapshot_id=request['snapshot_id']
    names=['measurement-rpc-first','measurement-rpc-second'];profile=prior['profile']
    profile['prompts']={name:'Direct fixture RPC check; no full researcher-loop or model claim.' for name in names}
    profile['prompt_version']='measurement-direct-rpc/1'
    before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'trading_researcher').glob('*.py'))}
    registry=ROOT/'.trf-runtime/binance-normalized-registry-2026-10-25'
    broker=Broker(registry);server=None;thread=None;started=time.monotonic()
    report={'status':'INCOMPLETE','scope':'Recorded scripted response -> authenticated measurement RPC -> retained result. Full source prompt loading deliberately not exercised.',
        'prior_full_loop':'real-http-result.json retained the no-dispatch frozen-budget rejection; this separate probe does not resolve it.',
        'source_hashes':before,'genuine_discovery':False,'scientific_readiness':False}
    try:
        server=LocalServer(broker);thread=threading.Thread(target=server.serve_forever);thread.start()
        admin=Client(server.url,broker.admin_token,timeout=120)
        snapshot=admin.call('get_artifact',artifact_id=snapshot_id)
        credentials={name:admin.call('register_worker',name=name,role='discovery',capabilities=['research-record/v1']) for name in names}
        context=admin.call('create_context',role='discovery',epoch=1,artifact_ids=[snapshot_id])
        with (WORK/'real-rpc-profile.json').open('x',encoding='utf-8') as out:json.dump({'request':request,'profile':profile},out,indent=2)
        epoch=admin.call('create_research_epoch',key='measurement-direct-rpc/1',context_id=context['id'],workers=names,profile=profile)
        saved=[]
        for name in names:
            admin.call('enqueue',key=name,spec={'kind':'research-record/v1','context_id':context['id'],
                'purpose':'Direct fixture HTTP measurement; full source prompt loading not exercised',
                'allowed_workers':[name],'max_attempts':1,'lease_seconds':30,'deadline':int(time.time())+120,
                'dependencies':[],'research_epoch_id':epoch['id']})
            client=Client(server.url,credentials[name]['token'],timeout=120);lease=client.call('claim')['lease']
            prompt={'model':profile['model'],'prompt_version':profile['prompt_version'],
                'messages':[{'role':'system','content':profile['prompts'][name]},
                    {'role':'user','content':canonical(request)}],'tools':DEVELOPMENT_TOOL_DEFINITIONS,'generation_parameters':{}}
            intent=client.call('reserve_research_call',lease=lease,key='fixture-request',request=prompt,
                input_token_bound=len(canonical(prompt).encode())+1024,output_token_limit=4096,cost_bound_units=0)
            assert intent['dispatch']
            tool={'id':'lagged-close','name':'measure_development','arguments':request}
            receipt=client.call('finish_research_call',lease=lease,call_id=intent['call_id'],
                response={'status':'completed','provider_id':'direct-scripted-fixture/1','output':{'status':'tools','calls':[tool]}},
                usage={'input_tokens':len(canonical(prompt).encode()),'output_tokens':len(canonical(tool).encode()),'cost_units':0})
            assert not receipt['late'] and receipt['within_reservation']
            artifact=client.call('measure_development',lease=lease,call_id=intent['call_id'],tool_id=tool['id']);saved.append(artifact)
            assert client.call('read_artifact',lease=lease,artifact_id=artifact['id'])==artifact
            if len(saved)==2:
                from trading_researcher.server import RemoteError
                try:client.call('read_artifact',lease=lease,artifact_id=saved[0]['id'])
                except RemoteError as exc:assert exc.status==403
                else:raise AssertionError('Peer measurement was visible')
            client.call('block',lease=lease,reason='Direct engineering probe finished without an invented hypothesis',
                needs=['Actual provider and full researcher-loop integration'],retry_when='Separately authorize and configure a genuine provider test')
        assert saved[0]['body']['result']==saved[1]['body']['result']
        result=saved[0]['body']['result'];assert result['status']=='MEASURED_DEVELOPMENT' and result['processed_positions']==8
        loaded=broker._load_reference_data(snapshot_id,'2020-01-01T23:45:00Z','2020-01-02T02:00:00Z',['BTCUSDT'])
        rows={row['time']:row for row in loaded['rows']};expected=[]
        for value in result['values']:
            assert value['time'] in rows and value['missing'] is None
            sample=rows[value['time']-900]['features']['BTCUSDT.close@binance-spot-15m-v1']
            assert sample['available_at']<=value['time']
            exact=Fraction(sample['value']);expected.append(exact)
            assert value['value']=={'numerator':str(exact.numerator),'denominator':str(exact.denominator)}
        mean=sum(expected,Fraction(0))/len(expected)
        assert result['summary']['mean']=={'numerator':str(mean.numerator),'denominator':str(mean.denominator)}
        assert before=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'trading_researcher').glob('*.py'))}
        integrity=admin.call('verify');assert integrity['status']=='PASS'
        report.update(status='PASS_WITH_EXPLICIT_DIRECT_RPC_LIMITS',exit_code=0,measurement_artifacts=saved,
            exact_source_value_comparison='PASS',peer_artifact_read='DENIED_AS_REQUIRED',
            availability=snapshot['body']['manifest']['availability'],integrity=integrity,
            epoch_id=epoch['id'],usage=admin.call('inspect_research_epoch',epoch_id=epoch['id'])['usage'])
    except BaseException as exc:
        report.update(status='FAIL',exit_code=1,error={'type':type(exc).__name__,'message':str(exc)[:2000]});raise
    finally:
        if server is not None:server.shutdown();server.server_close()
        if thread is not None:thread.join()
        broker.close();report['wall_seconds']=round(time.monotonic()-started,3)
        with (WORK/'real-rpc-result.json').open('x',encoding='utf-8') as out:json.dump(report,out,indent=2)
        print(json.dumps({key:report.get(key) for key in ('status','exit_code','wall_seconds','error')}))

if __name__=='__main__':main()
