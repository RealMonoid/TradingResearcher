"""Retain focused measurement and affected-boundary checks without secret output."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
def hashes():
    files=list((ROOT/'trading_researcher').glob('*.py'))+list((ROOT/'tests').rglob('*.py'))
    return {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}

before=hashes();checks=[]
for pattern in ('test_measurements*.py','test_memory.py','test_storage.py','test_researcher.py',
                'test_research_calls.py','test_local_runtime.py'):
    command=[sys.executable,'-B','-m','unittest','discover','-s','tests','-p',pattern,'-q']
    started=time.monotonic()
    result=subprocess.run(command,cwd=ROOT,capture_output=True,text=True)
    log=WORK/('focused-'+str(len(checks))+'.log')
    log.write_text(result.stdout+result.stderr,encoding='utf-8')
    counts=re.findall(r'Ran (\d+) tests? in ([\d.]+)s',result.stderr)
    item={'command':command,'exit_code':result.returncode,'wall_seconds':round(time.monotonic()-started,3),
          'test_count':int(counts[-1][0]) if counts else None,'log':log.name,
          'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    checks.append(item);print(json.dumps(item),flush=True)
changed=[path for path in set(before)|set(hashes()) if before.get(path)!=hashes().get(path)]
success=not changed and all(item['exit_code']==0 and item['test_count'] is not None for item in checks)
report={'status':'PASS' if success else 'FAIL','exit_code':0 if success else 1,'checks':checks,
        'tests':sum(item['test_count'] or 0 for item in checks),'source_and_test_hashes':before,
        'files_changed_during_checks':changed,'scope':'Focused measurement and affected-boundary regressions; not the complete project suite.'}
with (WORK/'focused-result.json').open('x',encoding='utf-8') as stream:json.dump(report,stream,indent=2)
print(json.dumps({key:report[key] for key in ('status','exit_code','tests','files_changed_during_checks')}))
raise SystemExit(report['exit_code'])
