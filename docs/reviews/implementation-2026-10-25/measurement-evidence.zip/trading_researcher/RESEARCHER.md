# Provider-neutral research loop

This implements bounded controller/adapter mechanics under D077/D079, not evidence of model invention or scientific validity. It extends the existing [runtime](README.md) and [memory](MEMORY.md). Its fixture demo uses no external SDK, model API, credential, paid call, service, or additional software installation.

Run from the repository root with a new or empty target directory:

```powershell
python -B -m trading_researcher research-demo --directory .trf-runtime/research-demo
```

The command uses real authenticated loopback RPC, SQLite, two sequential discovery identities, and isolated child processes for scripted provider output. Both identities receive the same immutable base context and separate prompts. The first fixture performs a memory lookup and stores an idea; the second retains a capability gap without reading the first transcript. The complete operational batch is released into a later epoch. A JSON report is saved in the target directory and the demo closes its server. Fixture token counts are synthetic byte counts, not any provider's tokenizer or pricing model.

## Owned interface and frozen inputs

`create_research_epoch` binds exactly two registered discovery identities, their base context, exact model identifier, prompt version and per-perspective prompts, tool definitions, generation parameters, output limit, call timeout, transport retry count, currency, and total call/token/time/cost limits. Limits cannot exceed the adopted 12 calls, 80,000 input-plus-output tokens and 1,800 seconds. The adapter must supply conservative input-token and cost reservations before dispatch; no real provider estimator is implemented yet. A live profile requires a positive currency cap, but declaring that profile does not install or authorize a live adapter.

The trusted adapter implements `reservation(request, output_limit)` and `complete(request, ordinal, timeout)`. It receives the normalized public request, not the worker RPC client or its credential. Returned public output and provider/request identifiers are retained with reported usage. This interface does not request private reasoning traces. A real adapter still needs provider-specific encoding, token/cost accounting, identifier handling, cancellation limits, and safe credential provisioning. Local child termination cannot prove cancellation of a remotely accepted paid request.

`reserve_research_call` durably commits a unique call intent before dispatch. Retrying the same key cannot dispatch twice; changing its request conflicts. Both perspectives share the durable epoch budget, including across restarts. An unresolved intent blocks further dispatch and successful job completion until its outcome is reconciled. A timeout or absent usage keeps the worst-case reservation charged. A reported overrun, or malformed usage, retains the response and halts the epoch; malformed usage stays unknown rather than becoming zero. A late response from the original owner is retained for accounting but cannot grant authority to a later attempt.

The installed wrapper executes an adapter in a bounded child process and maintains the job heartbeat. It terminates the local child on cancellation, timeout or lost lease. Configured transport retries use distinct counted calls, with at most two retries and no bypass of the total budget. Adapter reservation failures become a durable blocked attempt with a sanitized exception class, excluding potentially secret-bearing exception text.

## Model-visible tools

| Tool | Authority |
|---|---|
| `read_source` | Read an artifact authorized by the frozen context/current private attempt |
| `search_memory` | Permission-first text retrieval; preserve the returned bundle |
| `record_research` | Retain unverified ideas, observations, gaps and research interpretations |
| `capabilities` | Describe implemented tools and remaining evaluation capabilities |
| `measure_development` | Optional explicitly frozen development tool: causal expressions and descriptive values, never a scientific verdict |

Every public tool request and result, including denials, is retained as an immutable artifact. The model cannot name an arbitrary RPC operation or supply a different worker/lease credential. No shell, filesystem, network-fetch or evaluator-storage tool is exposed. Model-supplied text is data. The operator, local OS account and installed adapter code remain trusted; this is not OS sandboxing of hostile Python code.

The [measurement-enabled tool set](MEASUREMENTS.md) is selected explicitly through `DEVELOPMENT_TOOL_DEFINITIONS`; legacy frozen tools are not silently expanded. Measurement arguments come only from a timely retained provider tool call. Its exact request and source precede execution, and a result outside the original lease/epoch authority is retained without worker read access. A full real-data scripted loop currently exceeds the fixture's byte-based input budget when serializing the entire source context; direct HTTP measurement and small synthetic loop checks cover narrower boundaries.

The model may submit unrestricted idea text. Unsupported ideas can end as retained gaps with a reason and reopening condition. Structural acceptance means an operational record was retained; it never issues scientific evidence. A live provider flag alone would not prove genuinely novel or faithful discovery, so that result remains unverified until the real research milestone.

## Verification and remaining boundary

The [auxiliary research handoff](AUXILIARY_RESEARCH.md) now reuses this ledger and isolated adapter invocation for formalization and separate meaning-review tasks. Each role has an explicit immutable model/prompt profile, but shares the original epoch caps and clock. New reservations retain an explicit dispatch deadline; late replies remain accounting records without result authority. Actual independent model judgment remains unverified, including when a fixture is labeled live.

`tests/test_research_calls.py` covers durable intent/idempotency, shared budgets, private transcripts, unknown usage after restart, overruns, late responses, exact profile freezing, pending-dispatch blocking, and malformed-usage retention. `tests/test_researcher.py` covers sequential perspectives, tool execution/denial, gaps, refusal and malformed output, hard timeout, cancellation before/during dispatch, bounded retry, call exhaustion, and sanitized adapter failure. The CLI test exercises the same loop through authenticated RPC. These are software checks with synthetic responses.

The [implementation evidence](../docs/reviews/implementation-2026-10-25/progress.json) records fresh outcomes. Live provider integration and billing reconciliation, real model behavior, full-context integration, semantic formalization/certification, atomic scientific freeze/allocation, calibrated evaluation, scientific terminal-batch release, Market Model publication and market-data validity remain separate work. The registry's general integrity check currently verifies SQLite, content hashes, audit chain and memory projection; it is not a proof of provider billing or scientific conformance.
