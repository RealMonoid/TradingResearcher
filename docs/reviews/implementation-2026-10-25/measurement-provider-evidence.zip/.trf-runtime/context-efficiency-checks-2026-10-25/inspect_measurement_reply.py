"""Read retained measurement replies; no API call or registry mutation."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from trading_researcher.codec import canonical, digest
from trading_researcher.context_views import source_view


def main():
    source = ROOT / '.trf-runtime/measurement-checks-2026-10-25/real-rpc-result.json'
    target = Path(__file__).with_name('measurement-followup-inspection.json')
    if target.exists(): raise RuntimeError('Retained observation must not be overwritten')
    observed = json.loads(source.read_text(encoding='utf-8'))
    rows = []
    for artifact in observed['measurement_artifacts']:
        assert digest({k: v for k, v in artifact.items() if k != 'id'}) == artifact['id']
        view = source_view(artifact)
        assert canonical(view['content']['body']) == canonical(artifact['body'])
        rows.append({'artifact_id': artifact['id'],
            'full_envelope_utf8_bytes': len(canonical(artifact).encode('utf-8')),
            'prospective_view_utf8_bytes': len(canonical(view).encode('utf-8')),
            'measurement_body_utf8_bytes': len(canonical(artifact['body']).encode('utf-8')),
            'exact_measurement_body_preserved': True, 'exposure_count': len(artifact['exposure']),
            'source_refs_count': len(artifact['source_refs'])})
    report = {'schema': 'measurement-context-followup-observation/1',
        'observed_at_utc': datetime.now(timezone.utc).isoformat(),
        'source_report_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'observations': rows,
        'inference_calls': 0, 'qualification': 'Byte sizes, not token estimates. Current view profile applies only to initial sources. '
        'The installed measure_development tool still returns complete envelopes; this read-only comparison does not activate tool-result projection.',
        'next_action': 'Extend only an explicit newly versioned presentation profile to measurement tool replies, '
        'retain both exact full response and exact model-visible view, verify old profiles and authorization/exposure, then exercise actual provider measurement transport.'}
    with target.open('x', encoding='utf-8') as stream:
        json.dump(report, stream, indent=2); stream.write('\n')
    print(json.dumps({'status': 'PASS_READ_ONLY_OBSERVATION', 'observations': rows, 'inference_calls': 0}))


if __name__ == '__main__': main()
