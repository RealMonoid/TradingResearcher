"""Retain the actual measurement transport checkpoint without repeating API calls."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import unquote
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
OUT = ROOT / 'docs/reviews/implementation-2026-10-25'


def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, value): p.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def main():
    target = OUT / 'measurement-provider-verification.json'
    if target.exists(): raise RuntimeError('Frozen verification must not be overwritten')
    protected = {p.relative_to(ROOT).as_posix(): sha(p) for p in OUT.iterdir()
                 if p.suffix in ('.json', '.zip') and p.name != 'progress.json'}
    live = json.loads((WORK / 'live-result.json').read_text(encoding='utf-8'))
    assert live['status'] == 'PASS_ENGINEERING_ONLY' and live['model_identity_and_utc_present']
    assert live['new_dispatches'] == 6 and live['integrity']['status'] == 'PASS'
    usage = live['usage_after']; before = live['usage_before']
    assert usage['totals']['exact_total_tokens'] == 35084
    assert usage['money']['charged_nano'] == 95105000 and not usage['money']['halted']
    assert usage['calls'][:len(before['calls'])] == before['calls']
    baseline = json.loads((WORK / 'baseline.json').read_text(encoding='utf-8-sig'))
    changed_runtime = {'trading_researcher/context_views.py', 'trading_researcher/researcher.py',
                       'trading_researcher/research_calls.py'}
    preserved_runtime = {}
    for row in baseline:
        p = Path(row['path']); name = p.relative_to(ROOT).as_posix()
        if name not in changed_runtime:
            assert sha(p) == row['sha256'], name
            preserved_runtime[name] = row['sha256']
    (OUT / 'measurement-provider-observation.json').write_bytes((WORK / 'live-result.json').read_bytes())
    write(OUT / 'measurement-provider-usage.json', usage)
    first_new = usage['calls'][len(before['calls'])]; last_new = usage['calls'][-1]
    note = OUT / 'OPENAI_MEASUREMENT_INTEGRATION_2026-10-25.md'
    note.write_text(
        '# Actual provider and measurement integration\n\n'
        'Date: October 25, 2026. This is an engineering observation on retained Binance development data, '
        'not free hypothesis invention, scientific validity, research-quality equivalence or profitability.\n\n'
        'Two isolated perspectives each performed three actual OpenAI calls: a prescribed causal measurement, '
        'an exact page of the resulting provenance list, then a retained gap. Each received eight lagged BTCUSDT '
        'close values on January 2, 2020. An independent Fraction-based source-row comparison checked every value '
        'and their mean. Both model responses copied the exact mean and count correctly. No raw or scientific '
        'measurement value was summarized. Availability remains an explicit assumption.\n\n'
        'Version-2 presentation keeps the full raw tool result and separately retains the exact view sent to the model. '
        'The second initial input did not contain the first perspective result. Old profiles remain unchanged. '
        'The full view/error-ordering tests and registry integrity passed; this is not proof of all possible model behavior.\n\n'
        '| Usage | Value |\n|---|---|\n'
        '| New actual calls | 6 |\n| New input tokens | 32,060 |\n| New output tokens | 852 |\n'
        '| New total tokens | 32,912 |\n| Cumulative calls | 10 |\n| Cumulative total tokens | 35,084 |\n'
        '| Cumulative cached-input subset | 19,616 |\n| Unknown-usage calls | 0 |\n'
        '| New conservative rate bound | USD 0.088670 |\n| Cumulative conservative rate bound | USD 0.095105 |\n'
        '| Remaining within original USD 5 cap | USD 4.904895 |\n\n'
        'Cached input is already included in input totals. Cost uses the existing conservative tariff bound; '
        'it is not an invoice or a calculation of realized cache savings. This prescribed workload is not a typical '
        'discovery-cost estimate. The initial raw versus compact count observations are separate from consumed tokens.\n\n'
        f'The new calls record requested/reported model `gpt-6.1-sol`, public catalog `GPT-6.1 Sol` version `6.1`, '
        f'and unknown immutable provider snapshot. First admission: `{first_new["admitted_at_utc"]}`; '
        f'last local settlement: `{last_new["settled_at_utc"]}`. '
        'These are host accounting timestamps, not provider execution start/end. Earlier missing identity/time fields '
        'were not backfilled. [Per-call usage](measurement-provider-usage.json) retains all records.\n\n'
        'The [cheap-worker review](CHEAP_WORKER_REVIEW_2026-10-25.md) recommends deterministic processing first '
        'and qualified helper-role trials rather than automatic model downgrades or unverified source summaries. '
        'No cheaper model, external routing package or new provider was activated.\n\n'
        'Next: continue faithful formalization/scientific admission and the remaining plan, retaining unsupported '
        'semantics and development gaps. Actual free discovery remains a separate milestone after its run inputs are ready. '
        '[Verification and exact source inventory](measurement-provider-verification.json).\n', encoding='utf-8')
    progress = json.loads((OUT / 'progress.json').read_text(encoding='utf-8'))
    next_action = ('The prescribed real-provider measurement/page transport now passes. Continue the step3/4 '
        'faithful formalization, data/semantic acceptance, nuisance-model adequacy, information/calibration '
        'and scientific freeze prerequisites. Free discovery remains step5 after run inputs are ready. '
        'Preserve optional presentation limits and evaluate quality before any equivalent-default claim; '
        'no automatic cheap-worker routing is activated.')
    progress['next_action'] = next_action
    progress['packages'][1]['remaining_action'] = next_action
    progress['packages'][1]['evidence'] += ['docs/reviews/implementation-2026-10-25/measurement-provider-verification.json',
        'docs/reviews/implementation-2026-10-25/CHEAP_WORKER_REVIEW_2026-10-25.md']
    progress['token_usage'].update(reported_tokens=35084, conservative_nano_usd=95105000,
        snapshot='docs/reviews/implementation-2026-10-25/measurement-provider-usage.json')
    progress['continuation_audit']['basis'] = ('Actual provider plus real development measurements and exact source '
        'paging passed on two isolated perspectives. Six new calls, original shared budget, preserved old receipts. '
        'Cheap-worker review completed; full objective remains in progress.')
    progress['controls']['evidence-gate'] = {'status': 'CHECKING', 'evidence': 'Final measurement/provider checks running.'}
    write(OUT / 'progress.json', progress)
    with (OUT / 'IMPLEMENTATION_SUMMARY_2026-10-25.md').open('a', encoding='utf-8') as stream:
        stream.write('\n## Actual model and development measurement transport\n\n'
            'Added explicit source-presentation profile/2 for measurement replies, retaining both the exact original '
            'tool result and the exact model-visible body. Fixed malformed-call guard ordering; prior profiles remain '
            'unchanged. The [six-call live check](OPENAI_MEASUREMENT_INTEGRATION_2026-10-25.md) completed two isolated '
            'measurement/page/gap sequences and independently checked eight exact source values and their mean. '
            'Cumulative usage is 35,084 tokens with USD0.095105 conservative accounting against the original USD5 cap. '
            'Model/version/UTC recording was exercised live. The [cheaper-model review](CHEAP_WORKER_REVIEW_2026-10-25.md) '
            'keeps automatic routing and unverified summaries inactive. Scientific admission, free discovery and '
            'the remaining packages remain pending.\n')
    changed = sorted(changed_runtime) + ['README.md', 'trading_researcher/RESEARCHER.md', 'trading_researcher/OPENAI.md',
        'tests/test_context_views_adversarial.py', 'tests/test_measurement_context_views_adversarial.py',
        'docs/architecture/CURRENT_STATE.md',
        'docs/reviews/integration-research-2026-10-24/IMPLEMENTATION_SEQUENCE_2026-10-25.md']
    changed += ['docs/reviews/implementation-2026-10-25/' + name for name in (
        'CHEAP_WORKER_REVIEW_2026-10-25.md', 'OPENAI_MEASUREMENT_INTEGRATION_2026-10-25.md',
        'measurement-context-views-review.json', 'measurement-provider-observation.json',
        'measurement-provider-usage.json', 'measurement-provider-verification.json',
        'measurement-provider-evidence.zip', 'progress.json', 'IMPLEMENTATION_SUMMARY_2026-10-25.md')]
    report = {'schema': 'measurement-provider-verification/1', 'status': 'CHECKING', 'changed_files': changed,
        'scope': 'Versioned measurement presentation and actual prescribed provider/tool transport; no scientific change.',
        'checks': [], 'preserved_runtime': preserved_runtime, 'protected_prior_artifacts': protected,
        'live_observation_status': live['status'], 'live_command_exit_code': 0,
        'live_command': 'python -B .trf-runtime/measurement-provider-checks-2026-10-25/live_probe.py',
        'live_wall_seconds': live['wall_seconds'], 'actual_inference_calls_added': 6,
        'new_tokens': 32912, 'cumulative_tokens': 35084, 'cumulative_conservative_nano_usd': 95105000,
        'source_measurement_body_preserved': True, 'old_usage_receipts_unchanged': True,
        'new_model_version_utc_records_verified': True,
        'unverified': ['Research-quality equivalence of optional views', 'Autonomous free invention and faithful scientific evaluation',
            'Data availability truth, nuisance-model adequacy, N_min, fresh calibration and scientific freeze',
            'Immutable model snapshot and provider execution timing', 'Invoice or actual cache-cost reconciliation',
            'Representative discovery usage/cost', 'Cheaper-model helper quality or external repository runtime security']}
    write(target, report)
    checks = [(name, [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tests', '-p', pattern])
        for name, pattern in [('context-tests', 'test_context_views*.py'), ('research-tests', 'test_research*.py'),
                              ('measurement-tests', 'test_measurement*.py')]]
    checks += [('retail-contract', [sys.executable, '-B', 'docs/reviews/verify_retail_contract.py']),
        ('system-model', [sys.executable, '-B', 'docs/reviews/verify_system_model.py']),
        ('git-diff-check', ['git', 'diff', '--check']),
        ('usage-cli', [sys.executable, '-B', '-m', 'trading_researcher', 'openai-usage', '--ledger',
                       str(ROOT / '.trf-runtime/openai-integration-budget.sqlite3')])]
    count = 0
    for name, command in checks:
        checked = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, encoding='utf-8', errors='replace')
        log = checked.stdout + checked.stderr; (WORK / (name + '.log')).write_text(log, encoding='utf-8')
        record = {'command': command, 'exit_code': checked.returncode, 'log': (WORK / (name + '.log')).relative_to(ROOT).as_posix()}
        match = re.search(r'Ran (\d+) tests in ([\d.]+)s', log)
        if match: record.update(tests=int(match[1]), seconds=match[2]); count += int(match[1])
        report['checks'].append(record); write(target, report)
        if checked.returncode: raise RuntimeError(name + ' failed; evidence retained')
        if name == 'usage-cli': assert json.loads(checked.stdout) == usage
    assert count == 75, count
    for name in changed:
        p = ROOT / name
        if p.suffix not in ('.py', '.md'): continue
        source = p.read_text(encoding='utf-8')
        assert all(line == line.rstrip() for line in source.splitlines()), name
        if p.suffix == '.md':
            for link in re.findall(r'\]\(([^)]+)\)', source):
                link = link.strip('<>').split('#')[0]
                if not link or re.match(r'^[a-z]+://', link): continue
                assert (p.parent / unquote(link)).exists(), (name, link)
    assert all(sha(ROOT / p) == expected for p, expected in protected.items())
    progress['controls']['evidence-gate'] = {'status': 'SATISFIED', 'evidence':
        '75 unique context/research/measurement tests PASS; current independent review covers31 cases. '
        'Actual six-call provider/measurement/page probe and exact source oracle PASS. Documentation and usage CLI PASS. '
        'Scientific validity and research-quality equivalence remain unverified.'}
    write(OUT / 'progress.json', progress)
    sources = [*ROOT.joinpath('trading_researcher').glob('*.py'), *ROOT.joinpath('tests').glob('*.py'),
        *ROOT.joinpath('tests/fixtures').glob('*.json'), *WORK.glob('*.py'), *WORK.glob('*.json'), *WORK.glob('*.log'),
        *ROOT.joinpath('.trf-runtime/measurement-context-views-independent-review-2026-10-25').glob('*'),
        ROOT / '.trf-runtime/context-efficiency-checks-2026-10-25/measurement-followup-inspection.json',
        ROOT / '.trf-runtime/context-efficiency-checks-2026-10-25/inspect_measurement_reply.py',
        *[ROOT / name for name in changed if (ROOT / name).exists()
          and not name.endswith(('measurement-provider-verification.json', '.zip'))]]
    sources = sorted(set(p for p in sources if p.is_file()))
    archive = OUT / 'measurement-provider-evidence.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as bundle:
        for p in sources: bundle.write(p, p.relative_to(ROOT).as_posix())
    report.update(status='PASS_BOUNDED_PROVIDER_MEASUREMENT', unique_tests=75,
        current_independent_review_subset=31, observed_at_utc=datetime.now(timezone.utc).isoformat(),
        evidence_archive_sha256=sha(archive), source_hashes={p.relative_to(ROOT).as_posix(): sha(p) for p in sources},
        authored_whitespace_and_links='PASS')
    write(target, report)
    final = subprocess.run(['git', 'diff', '--check'], cwd=ROOT, capture_output=True, text=True)
    assert final.returncode == 0
    print(json.dumps({'status': report['status'], 'tests': count, 'documentation_exit': 0,
        'preserved_runtime_files': len(preserved_runtime), 'protected_artifacts': len(protected),
        'cumulative_tokens': 35084, 'conservative_nano_usd': 95105000, 'report': str(target)}))


if __name__ == '__main__': main()
