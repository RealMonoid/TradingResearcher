# Implementation sequence

Date: October 25, 2026. Version: execution-plan/0.1.

The user delegated selection of all next steps after requesting one workstream at a time. This document fixes the engineering sequence for the [integration proposal](INTEGRATION_PROPOSAL.md). The later October 25 user goal authorizes implementation as far as independently possible, necessary software installation, and web research. Execution is in progress; [current evidence and remaining work](../implementation-2026-10-25/progress.json) are retained separately. It does not change scientific contracts, approve spending, or replace the recorded backend decision.

## Outcome and inspected starting point

The first milestone is one bounded, traceable historical research cycle: a real LLM invents an idea, the application preserves its meaning, independent code evaluates a supported formalization under a frozen plan, and the journal retains the entire batch and its outcomes. A negative or inconclusive result can complete the technical milestone. Unsupported ideas remain gaps and do not count as tested negatives.

The inspected repository is at commit `0db94668bb315c23ed824246abf0c0b02cf668f6`. It contains a [local controller](../../../trading_researcher/README.md) and a bounded [AmiBroker utility](../../../tools/amibroker/README.md). The controller handles operational jobs and immutable artifacts; it does not yet implement scientific freeze, the researcher, four complete memory views, or the evaluator. AmiBroker has a recorded import/exploration/export test, not a certified strategy adapter. The [system reconstruction](SYSTEM_MODEL.md) remains the flow and authority basis; its earlier inspection commit describes its historical snapshot.

Use the existing Python application and SQLite registry. Start with direct provider calls behind one owned interface, deterministic reference calculations, and explicit metadata/text retrieval. A new agent platform, graph database, vector database, or dashboard is not a prerequisite. The accepted [research contract](../../architecture/14_RETAIL_RESEARCH_CONTRACT.md), [decision register](../../architecture/02_DECISION_REGISTER.md), and [blueprint](../../architecture/09_IMPLEMENTATION_BLUEPRINT.md) govern meaning and authority.

## Ordered work packages

Work on one numbered package at a time. Each package ends with its named evidence and a short progress update. A failed prerequisite keeps the dependent package pending; unrelated infrastructure is not expanded to avoid the failure.

### 1. Domain records and four memory views

**Status: IN PROGRESS; the bounded [memory foundation](../../../trading_researcher/MEMORY.md) and [external storage/complete backups](../../../trading_researcher/STORAGE.md) are implemented and tested; downstream scientific publication remains open.** Extend the existing registry with versioned ideas, observations, sources, attempts, gaps, lineage, trial/plan references, and evidence/policy records. Implement the Research Journal, Market Model, Research Experience, and Policy Experience as typed views with distinct write authority. Preserve source records and corrections; use immutable hashes for larger content when needed by this slice.

Start retrieval with authorized metadata and text queries. Filter by role, snapshot, time, and exposure before ranking or returning counts. Persist the returned bundle and its later use. Empty policy or evidence views are valid initial states, not populated knowledge.

**Exit evidence:** replay produces the same views; invalid record transitions fail; contradictory and superseded records remain retrievable; denied records cannot leak through search metadata; transaction, backup, and recovery cases pass. Existing controller tests remain passing. Maps to proposal P1, D014/D019/D070/D078 and REQ-007/008/013/016/028-030.

### 2. Researcher adapter and bounded tool loop

**Status: IN PROGRESS; the [provider-neutral loop](../../../trading_researcher/RESEARCHER.md), development measurements and [OpenAI adapter with persistent usage](../../../trading_researcher/OPENAI.md) are implemented. A four-call synthetic-context live check and a later [six-call real-data measurement transport check](../implementation-2026-10-25/OPENAI_MEASUREMENT_INTEGRATION_2026-10-25.md) pass. Genuine research behavior and quality equivalence of optional context presentation remain unverified.** Add one provider interface to the existing worker/controller flow. Record submitted context, returned public output, tool requests, provider identifiers, usage, retries, refusals, partial output, and unknown billing. Configure one provider for the first run; additional vendors use the same contract later and are not separate initial projects.

Implement the two sequential, isolated discovery perspectives with the same permitted base snapshot and separate scratch state. Allow source lookup, development measurements, authorized memory retrieval, idea submission, and gap registration. Enforce the existing call/token/time limits in host code. Do not expose arbitrary shell, filesystem, network, or evaluator storage to the model.

**Exit evidence:** deterministic provider fixtures exercise success, cancellation, timeout, retry, refusal, and tool denial; budgets and inherited exposure survive continuation. These fixtures verify the integration machinery only. Actual paid model use and genuine discovery are exercised at step 5 after run inputs are ready. Maps to proposal P2, D005/D034/D077/D079 and REQ-004/013/018/023.

### 3. Faithful formalization, certification, and freeze

**Status: IN PROGRESS; the [reference expression foundation](../../../trading_researcher/EXPRESSIONS.md), [retained formalization drafts](../../../trading_researcher/FORMALIZATION.md), [reference forward outcomes](../../../trading_researcher/OUTCOMES.md), [implementation certification with retained source replay](../../../trading_researcher/CERTIFICATION.md) and [bound normalized data snapshots](../../../trading_researcher/DATA.md) are tested. Actual acquisition acceptance, per-feature/semantic certification, certified scientific execution, plan/allocation validation and scientific freeze remain pending.** Preserve original `H_idea` separately from `H_exec`. Represent the accepted claim forms without requiring every form to be executable in the first slice. Start executable support with precisely specified primitives needed for an applicable mean/rate contrast; do not turn free invention into a catalog or silently simplify unsupported ideas.

Implement independent primitive checks, explicit semantic mapping, the trial/plan schema, assessment allocation, and atomic freeze. Record every observation actually shown to the researcher. Scientific readiness requires the compatible computation and calibration evidence from step 4; storing or freezing a JSON record alone cannot grant it.

The [Binance acquisition adapter](../../../trading_researcher/BINANCE.md) has retained the complete 144-file pilot source set with matching retrieved checksums. Strict normalization passes for 128 files and retains 16 timestamp-related gaps. Keyed quality handling and owned registry ingestion now preserve invalid versus absent bars, complete original files and qualified receipt times. The [partition normalizer](../../../trading_researcher/BINANCE_NORMALIZATION.md) executes from a fresh retained source snapshot and has generated all three adopted calendar datasets under an explicit assumed delay. Exact year boundaries, prior exposure and all-null invalid bars remain visible. [The original source inventory](../implementation-2026-10-25/binance-source-inventory.json) and [later normalization evidence](../implementation-2026-10-25/binance-normalization-verification.json) retain their separate scopes. Feature/semantic certification, scientific acquisition acceptance, calibrated execution and freeze remain pending.

The [raw measurement certification gate](../../../trading_researcher/FEATURES.md) now implements the existing Binance primitive portion: versioned definitions, exact owned-source replay, independent fixed expectations and host-issued data-bound certificates. Availability remains an explicit assumption. General composition/dependency certification, scientific acceptance, semantic mapping and freeze still require their own gates; this does not complete package 3.

The [bound reference path](../../../trading_researcher/BINDING.md) now connects completed formalizations to exact retained dependencies and exploratory development calculations, with independent fixed fixtures and separate case-consistency verification. It does not grant protected assessment access or complete semantic approval, calibrated inference and atomic scientific freeze.

The [owned evaluation-plan preparation path](../../../trading_researcher/EVALUATION_POLICY.md) now binds pilot policy drafts to exact compiled dependencies and available development diagnostics. It retains missing semantic, calibration/information and freeze gates explicitly. Family count is provisional; preparation grants no protected access or allocation.

Admitted preparation requests now retain their complete calculation inputs and source closure before launch, including interrupted retries and registry recovery. Same-key retries retain the original calculation version. The [retention checkpoint](../implementation-2026-10-25/plan-retention-verification.json) records the evidence; legacy incomplete attempts remain labeled. Actual independent semantic review, scientific data/exposure acceptance, calibration and atomic scientific freeze remain the next unmet gates.

The [auxiliary handoff](../../../trading_researcher/AUXILIARY_RESEARCH.md) now connects formalization and a separate meaning-review worker to the existing epoch ledger and original time/cost limits. Owned inputs, timely response identity and definition provenance are enforced. [Auxiliary verification](../implementation-2026-10-25/auxiliary-research-verification.json) covers the scripted integration and adversarial checks; verified real-provider provenance and substantive independent model assessment remain open, alongside the scientific evaluation/freeze gates.

**Exit evidence:** independently fixed expected cases cover units, missingness, causality, and boundaries; an unsupported or ambiguous meaning becomes a retained gap; altered manifests and conflicting reservations fail; interrupted freezes cannot expose a partially committed trial. No LLM may certify its own implementation. Maps to proposal P1-P3, D002-D004/D074/D078/D082/D084 and REQ-002/003/005/011/026.

### 4. Independent computation and narrow scientific calibration

**Status: IN PROGRESS; policy arithmetic, the [joint stationary-bootstrap computation candidate](../../../trading_researcher/STATIONARY_BOOTSTRAP.md) and an optional [Monte Carlo boundary diagnostic candidate](../../../trading_researcher/MONTE_CARLO.md) exist; calibration/admission and information derivation remain pending.** Implement the approved, applicable estimator and classification rules separately from the model. Use a small reference expression calculator and independently fixed fixtures for this research slice. This is not a new general portfolio simulator. Keep execution inputs and raw outputs behind the owned adapter boundary so a future backend cannot redefine scientific meaning.

Implement the fixed-batch dependence, multiplicity, information, and stopping rules required by the selected profile. Predeclare the calibration worlds and final draws; use the exact adopted criteria in research-contract/1.0 sections 5 and 11. Include applicable null, practical-boundary, planted-effect, overlap, heavy-tail, and common-shock cases. Keep development tuning separate from final assessment.

The [information-planning prerequisite](../implementation-2026-10-25/information-planning-verification.json) now accelerates exact integral sufficient-statistic arithmetic and compares it with the retained Fraction version. The associated planning assessment specifies the next owned development diagnostics/population-model study and its limits. Full-study resource feasibility, actual information targets, faithful return scenarios and calibration remain pending; synthetic kernel speedups do not complete this package or the framework acceleration gate.

The [owned nuisance-diagnostic continuation](../../../trading_researcher/INFORMATION_DIAGNOSTICS.md) supplies plan/execution-bound development rates, full-grid moments and pair coverage with retained source/input and separate replay. [Owned binary population worlds](../../../trading_researcher/POPULATION_MODELS.md) now add exact response/mask generation under explicit stress assumptions, preserving population truth, source-mask provenance and synthetic identity. The next dependency is the complete predeclared finite-grid power study and model-adequacy assessment. Measurements or generated worlds do not establish information sufficiency or calibration.

**Exit evidence:** numerical and manifest checks pass; technical invalidity is separate from market outcomes; the narrowly scoped calibration report meets the applicable adopted gate with uncertainty and every failed world retained. Failure blocks affected scientific classifications and results in a bounded diagnosis. A fixed-calculator pass is not full-process calibration. Maps to proposal P3, D006/D017/D021/D075/D081/D082 and REQ-005/019/020/024/029.

### 5. First genuine historical research cycle

**Status: QUEUED after 1-4.** Before any discovery or assessment use, resolve and record the run inputs: verified data artifacts and rights, actual availability and inherited exposure, exact provider/model/prompt configuration, a finite currency cap if calls are paid, the applicable measurement/estimator profile, and the complete frozen selection/allocation plan. Missing inputs block only the affected operation; they cannot be replaced by invented facts or silent scientific defaults.

Use the adopted BTCUSDT/ETHUSDT spot, 15-minute historical profile and its partition rules. Check whether prior exposure still permits the intended use; a calendar partition is not a claim that the model has never seen it. Register data provenance and unresolved availability limits before interpreting results. Retrieve only the data required by the bounded pilot, not unrelated markets.

Run actual free discovery through both prescribed perspectives, preserve every idea and gap, and carry supported formalizations through freeze, execution, evaluation, batch retention, and allowed later feedback. The first milestone is research, not a portfolio-profit claim. Do not wait for a positive result or replace an unusual idea with a convenient canned strategy.

**Exit evidence:** at least one genuine idea reaches a faithful, reproducible report without manual scientific repair; all attempts, unsupported ideas, negative/inconclusive outcomes, costs, and elapsed processing times remain visible. Deliberate access/leakage/manifest violations are denied. Report technical completion, narrow evaluator evidence, and remaining process validity separately. End at the predeclared cap with STOP, CONTINUE, or RETAIN_GAP. No full-process, economic, or acceleration claim follows automatically. Maps to proposal P4 and research-contract/1.0 sections 6, 9, 11, and 12.

### 6. AmiBroker strategy and portfolio adapter

**Status: QUEUED after the step-5 milestone, or a documented step-5 capability gap that specifically requires policy simulation.** Extend the existing utility only for the needed frozen requests. Translate supported semantics to AFL/APX, pin executable and settings provenance, return raw signals/trades/cash/equity and errors, and independently verify completed exports. Preserve unsupported semantics as gaps.

Check next-eligible-open timing, fees and adverse execution assumptions, position sizing, shared-cash ordering, missing data, and path behavior against hand-checkable reference cases. Include deterministic reruns, timeout cleanup, and isolation from existing user databases. Actual economic conclusions require the applicable cost basis; unknown costs are not zero. Intrabar ordering cannot be inferred from insufficient bars.

Keep AmiBroker's role at execution and policy simulation. CMP-06 retains scientific authority. Vectorbt remains the recorded primary candidate under D042; these tests assess an additional authorized adapter, not a silent replacement. Installing and maintaining two complete production backends is not a prerequisite. Record practical compatibility, runtime, and memory observations before selecting any broader backend change; 32-bit limitations are a reason to measure, not to install a new version automatically.

**Exit evidence:** the frozen-request fixtures agree on timing and accounting, failures are retained, and a separately frozen policy trial produces a reproducible report. Changing fills, exits, or cash interactions requires resimulation. Failure leaves the first research slice usable and the affected policy capability explicitly unavailable. Maps to proposal P5, D022/D042/D076 and REQ-009/012/018.

### 7. Domain monitoring, reporting, and measured expansion

**Status: QUEUED after 6; pending states are retained from step 1 onward.** Connect the existing scheduler to completed-outcome events and bound temporal plans under [D087](../../architecture/16_TEMPORAL_DIAGNOSTIC_INVOCATION.md). Add weekly status generation and a deduplicated delivery outbox under [D088](../../architecture/17_MONITORING_VISIBILITY_AND_REPORTING.md). A report tick is not a scientific look, and an unfinished horizon cannot trigger a completed-outcome check.

Authorized method comparisons run when their predeclared inputs are ready. An absent approved method remains visible as pending; this plan does not choose a quantitative monitoring rule. Keep report creation testable locally before configuring an explicitly authorized delivery destination. This package concerns the future framework, not a Codex chat automation.

**Exit evidence:** due/scope checks, duplicate/corrected deliveries, pending work, report generation, and recovery pass their applicable cases. Real delivery remains unverified until tested on the configured channel. Only then prioritize richer memory retrieval, more providers, other claim/estimator forms, or broader universes in response to observed needs. Economic and acceleration claims require their own predeclared assessment. Maps to proposal P5 and D080/D083/D087/D088.

## Progress, authority, and rollback

Use this file as the single sequence checklist. Record package status, evidence paths, and the next unmet exit condition when execution advances; update verified capability coverage and Current State through the existing maintenance process. Keep status messages short: completed package, check result, next package. Do not create an additional competing roadmap for each tool choice.

The selected sequence is ordinary engineering planning within the existing purpose. It does not alter accepted definitions, adopt the entire research proposal as a new scientific contract, or authorize live capital. Routine implementation choices can follow this sequence within the active task's authorization. Material changes to scientific meaning still follow D008/D026; present a concrete proposal only if that boundary is actually encountered.

Before changing a schema or runtime configuration, retain a compatible backup and versioned manifest. Reverting software restores configuration, never pristine evidence or erased attempts. Apply the existing two-iteration stop rule for changes without meaningful improvement. Do not weaken a failing acceptance condition after observing results.

## Planning verification and limits

The initial planning artifact was additive and left the original integration proposal, canonical contracts, source archive, and runtime files unchanged. Later authorized implementation is recorded in the statuses above and the separate progress/evidence files; the original planning checks do not establish those capabilities. Continue to verify links, package coverage, whitespace, preserved sources/contracts and the authorized implementation inventory. Software checks do not establish provider compatibility, statistical validity, performance or profitability. The original planning checkpoint included no live model call, market experiment or notification; the later bounded provider checks have their own dated evidence and do not establish a completed research cycle.
