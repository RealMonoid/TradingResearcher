"""Fresh read-only final source, evidence, archive and document audit."""
from pathlib import Path
import ast,hashlib,json,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).resolve().parent
AUDIT=ROOT/'docs/reviews/implementation-2026-10-25'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=read(AUDIT/'nuisance-diagnostics-verification.json');t=read(WORK/'tests-result.json')
b=read(AUDIT/'nuisance-diagnostics-baseline.json');peer=read(AUDIT/'nuisance-diagnostics-review.json')
assert r['status']=='PASS_WITH_EXPLICIT_INFORMATION_AND_CALIBRATION_LIMITS'
assert t['exit_code']==0 and t['sources_stable'] and int(t['unittest_summary'][0])==385
assert t['source_hashes_before']==t['source_hashes_after']==r['runtime_tests']['source_hashes']
assert sha(WORK/'tests.log')==t['log_sha256']==r['runtime_tests']['log_sha256']
assert sha(WORK/'tests-result.json')==r['runtime_tests']['report_sha256']
for name,expected in t['source_hashes_after'].items():assert sha(ROOT/name)==expected,name
assert len(r['changed_files_this_checkpoint'])==len(set(r['changed_files_this_checkpoint']))
assert set(r['changed_file_sha256'])==set(r['changed_files_this_checkpoint'])-{
    'docs/reviews/implementation-2026-10-25/nuisance-diagnostics-verification.json'}
for name,expected in r['changed_file_sha256'].items():assert sha(ROOT/name)==expected,name
assert sha(AUDIT/'nuisance-diagnostics-review.json')==r['independent_review']['sha256']=='2c8020b63412e4bf2866269b22b4028ddb25a8fea567a18cd7d836631db86859'
assert peer['source_captures']['before']==peer['source_captures']['after']
for name,expected in peer['source_captures']['after'].items():assert sha(ROOT/name)==expected,name
for name,expected in b['prior_reports_sha256'].items():assert sha(AUDIT/name)==expected,name
assert sha(AUDIT/'nuisance-diagnostics-baseline.json')==r['baseline']['sha256']
for description,members in ((r['baseline'],b['files_sha256']),
    ({'archive':r['evidence_archive']['path'],'archive_sha256':r['evidence_archive']['sha256']},r['evidence_archive']['members_sha256'])):
    path=AUDIT/description['archive'];assert sha(path)==description['archive_sha256']
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None and set(z.namelist())==set(members)
        assert all(hashlib.sha256(z.read(name)).hexdigest()==expected for name,expected in members.items())
for name,expected in b['files_sha256'].items():
    if name not in r['changed_files_this_checkpoint']:assert sha(ROOT/name)==expected,name
for filename,field,script in [('http-result.json','http_smoke','http_smoke.py'),
    ('real-probe-result.json','real_data_probe','real_development_probe.py')]:
    check=read(WORK/filename)
    assert check['exit_code']==0 and check['sources_stable']
    assert check['source_hashes_before']==check['source_hashes_after']==t['source_hashes_after']
    assert {k:v for k,v in check.items() if not k.startswith('source_hashes')}==r[field]
    assert sha(WORK/script)==check['script_sha256']
assert sha(WORK/'real-probe-profile.json')==r['real_data_probe']['profile_sha256']
texts=0
for name in r['changed_files_this_checkpoint']:
    p=ROOT/name;assert p.is_file(),name
    if p.suffix not in ('.py','.md','.json'):continue
    content=p.read_text(encoding='utf-8');texts+=1
    assert all(line.rstrip()==line for line in content.splitlines()),name
    assert not any(ord(c)<32 and c not in '\r\n\t' for c in content),name
    if p.suffix=='.py':ast.parse(content,filename=name)
    if p.suffix=='.json':json.loads(content)
progress=read(AUDIT/'progress.json')
assert progress['status']=='IN_PROGRESS' and next(s for s in progress['packages'] if s['step']==4)['status']=='IN_PROGRESS'
assert '<!-- FINAL_CHECKS -->' not in (AUDIT/'IMPLEMENTATION_SUMMARY_2026-10-25.md').read_text(encoding='utf-8')
checks={}
for name,path in [('retail_contract','docs/reviews/verify_retail_contract.py'),
    ('implementation_preservation','docs/reviews/implementation-2026-10-25/verify_implementation.py')]:
    completed=subprocess.run([sys.executable,'-B',path],cwd=ROOT,capture_output=True,text=True)
    assert completed.returncode==0,completed.stdout+completed.stderr
    value=json.loads(completed.stdout);assert value['status']=='PASS' and not value.get('errors',[])
    checks[name]={'exit_code':0,'status':'PASS','local_document_links':value.get('local_document_links')}
git=subprocess.run(['git','diff','--check'],cwd=ROOT,capture_output=True,text=True)
assert git.returncode==0,git.stdout+git.stderr
for name,check in r['checks'].items():
    assert check['exit_code']==0 and sha(WORK/(name+'.json'))==check['report_sha256']
print(json.dumps({'status':'PASS','exit_code':0,'changed_files':len(r['changed_files_this_checkpoint']),
    'text_files_checked':texts,'runtime_tests':385,'runtime_seconds':t['unittest_summary'][1],
    'runtime_source_fixture_hashes':len(t['source_hashes_after']),'independent_tests':16,
    'http_smoke':'PASS','real_data_probe':'PASS','real_development_rows':96,
    'baseline_members':len(b['files_sha256']),'prior_reports_preserved':len(b['prior_reports_sha256']),
    'checks':checks,'git_diff_check_exit_code':0,'line_ending_warnings':len(git.stderr.splitlines()),
    'goal_status':'IN_PROGRESS'},indent=2))
