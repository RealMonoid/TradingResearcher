"""Real authenticated HTTP transport; explicitly synthetic diagnostic input."""
from pathlib import Path
import hashlib,json,sys,threading,time
ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from test_information_runs import InformationRunTests
from trading_researcher.server import Client,LocalServer

def hashes():
    paths=[*ROOT.glob('trading_researcher/*.py'),*ROOT.glob('tests/*.py'),*ROOT.glob('tests/fixtures/*')]
    return {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths) if p.is_file()}

before=hashes();started=time.monotonic();InformationRunTests.setUpClass()
server=None;thread=None
try:
    fixture=InformationRunTests;broker=fixture.broker
    server=LocalServer(broker);thread=threading.Thread(target=server.serve_forever);thread.start()
    client=Client(server.url,fixture.token,timeout=180)
    request={'key':'http-diagnostics','plan_id':fixture.plan['id'],'execution_id':fixture.execution['id'],
        'lags':[1,2],'limits':{'max_seconds':120}}
    saved=client.call('prepare_information_diagnostics',**request);body=saved['body'];result=body['result']
    assert result['status']=='COMPUTED_DIAGNOSTICS' and result['scientific_readiness'] is False
    assert result['classification_permitted'] is False and result['n_min'] is None
    assert body['verification'] is not None
    assert client.call('prepare_information_diagnostics',**request)==saved
    capsule=client.call('get_artifact',artifact_id=body['input_capsule_id'])
    assert capsule['body']['request']==request
    raw=broker._read_blob_bytes(body['contribution_blob']['sha256'])
    assert len(raw.splitlines())==result['time_rows']
    assert hashlib.sha256(raw).hexdigest()==result['contributions_sha256']
    attempts=client.call('inspect_bound_computations')['attempts']
    assert any(a['kind']=='information_diagnostics' and a['artifact_id']==saved['id'] for a in attempts)
    assert server.scheduler_error is None
    record={'status':'PASS','exit_code':0,'operation':'prepare_information_diagnostics',
        'transport':'authenticated loopback HTTP','synthetic_input':True,'time_rows':result['time_rows'],
        'input_capsule_retrievable':True,'separate_process_replay':True,'same_key_idempotent':True,
        'contribution_bytes_checked':True,'inspection_exposes_attempt':True,
        'scientific_readiness':False,'n_min':None,'source_hashes_before':before}
finally:
    if server is not None:
        server.shutdown();thread.join(timeout=15);assert not thread.is_alive();server.server_close()
    InformationRunTests.tearDownClass()
record['source_hashes_after']=hashes();record['sources_stable']=before==record['source_hashes_after']
assert record['sources_stable']
record['wall_seconds']=round(time.monotonic()-started,3)
record['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
with (WORK/'http-result.json').open('x',encoding='utf-8') as stream:stream.write(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if not k.startswith('source_hashes')},indent=2))
