"""Owned diagnostic transport on an explicitly specified real-data engineering probe."""
from copy import deepcopy
from pathlib import Path
import hashlib,json,sys,threading,time

ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from trading_researcher.coordination import Broker
from trading_researcher.server import Client,LocalServer
from trading_researcher.codec import canonical,digest
from trading_researcher.stationary_bootstrap import randomness


def hashes():
    paths=[*ROOT.glob('trading_researcher/*.py'),*ROOT.glob('tests/*.py'),*ROOT.glob('tests/fixtures/*')]
    return {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths) if p.is_file()}


before=hashes();started=time.monotonic()
registry=ROOT/'.trf-runtime/binance-normalized-registry-2026-10-25'
snapshot_id='47ba3ea53be2de6ba0ecd63bc0b19ff118ebb55e2bb649a123fd54c8497d2990'
feature_id='0a7537664c1548f7c6dcf105371c9b041112a2e8fe60fc1ce54420dd2ad25f8d'
profile={'purpose':'Fixed engineering integration probe, not autonomous LLM invention or scientific evidence.',
    'development_snapshot_id':snapshot_id,'feature_certificate_id':feature_id,
    'start':'2020-01-02T00:00:00Z','end':'2020-01-03T00:00:00Z','instruments':['BTCUSDT'],
    'condition':'previous bar close exceeds previous bar open',
    'outcome':'next bar close exceeds next bar open','horizon_bars':1,
    'lags':[1,2,4,8],'availability':'Retain original 900-second delay scenario; historical PIT remains unverified.',
    'scientific_readiness':False,'source_hashes':before}
with (WORK/'real-probe-profile.json').open('x',encoding='utf-8') as out:out.write(json.dumps(profile,indent=2)+'\n')
broker=Broker(registry);server=None;thread=None
record={'status':'INCOMPLETE','profile_sha256':hashlib.sha256((WORK/'real-probe-profile.json').read_bytes()).hexdigest()}
try:
    op=lambda operation,**args:broker.call(broker.admin_token,operation,**args)
    snapshot=op('get_artifact',artifact_id=snapshot_id)
    assert snapshot['data_class']=='development' and snapshot['body']['manifest']['partition']=='development'
    feature=op('get_artifact',artifact_id=feature_id)
    assert feature['body']['status']=='CERTIFIED'
    reference=op('certify_reference');assert reference['body']['status']=='CERTIFIED'
    idea_text=('Engineering probe only: compare the rate of a next-bar close above its own open, '
        'conditional on the previous bar closing above its own open, with the whole eligible scope '
        'for BTCUSDT on January 2, 2020. Preserve the recorded data-availability scenario. '
        'This is a deliberately specified integration fixture, not LLM invention or a market conclusion.')
    idea=op('add_research',kind='idea',content={'text':idea_text},
        scope={'purpose':'technical_integration_probe'},source_refs=[])
    candidate=deepcopy(json.loads((ROOT/'tests/fixtures/reference_binding_cases.json').read_text())['baseline']['candidate'])
    close={'op':'feature','ref':'BTCUSDT.close@binance-spot-15m-v1'}
    opening={'op':'feature','ref':'BTCUSDT.open@binance-spot-15m-v1'}
    candidate['idea_ref']=idea['id'];candidate['estimand']['unit']='ratio'
    candidate['outcome']['scale']='binary_probability'
    candidate['condition_ast']['expression']={'op':'gt','left':{'op':'lag','arg':close,'bars':1},
        'right':{'op':'lag','arg':opening,'bars':1}}
    candidate['outcome']['program']['expression']={'op':'gt','left':close,'right':opening}
    for program in (candidate['scope_ast'],candidate['condition_ast'],candidate['outcome']['program']):
        program['catalog_hash']=snapshot['body']['catalog_hash']
    candidate['feature_refs']=sorted([close['ref'],opening['ref']])
    candidate['test_universe']={k:profile[k] for k in ('start','end','instruments')}
    candidate['test_universe']['data_snapshot_ref']=snapshot_id
    candidate['parameter_origins']=[{'path':path,'basis':'preexisting_specification','source_refs':[],
        'rationale':'Fixed integration-probe input recorded before calculation; no observed-result selection.'}
        for path in ('/scope_ast/expression/value','/condition_ast/expression/left/bars',
                     '/condition_ast/expression/right/bars','/horizons/outcome_bars')]
    worker=op('register_worker',name='information-real-probe-formalizer',role='formalizer',capabilities=['formalization/v1'])['token']
    context=op('create_context',role='formalizer',epoch=1,
        artifact_ids=[idea['id'],snapshot['body']['catalog_id'],snapshot_id])
    op('enqueue',key='information-real-probe-formalization',spec={'kind':'formalization/v1','context_id':context['id'],
        'purpose':'Fixed real-data diagnostic integration probe; not a model-origin claim',
        'allowed_workers':['information-real-probe-formalizer'],'max_attempts':1,'lease_seconds':300,
        'deadline':int(time.time())+1800,'dependencies':[]})
    lease=broker.call(worker,'claim')['lease']
    mapping={'status':'equivalent','segments':[{'text':idea_text,'path':'/estimand',
        'interpretation':'Specified engineering fixture assertion; independent semantic judgment unverified.'}],'differences':[]}
    formalization=broker.call(worker,'record_formalization',lease=lease,idea_id=idea['id'],
        catalog_id=snapshot['body']['catalog_id'],candidate=candidate,semantic_report=mapping)
    assert broker.call(worker,'submit',lease=lease,artifact_id=formalization['id'])['accepted']
    compiled=op('compile_hypothesis',formalization_id=formalization['id'],feature_certificate_id=feature_id,
        reference_certificate_id=reference['id'],as_of=profile['end'],max_steps=1000000)
    assert compiled['body']['status']=='COMPILED',compiled['body']
    execution=op('execute_development',compiled_id=compiled['id'])
    assert execution['body']['status']=='DESCRIPTIVE_EXECUTION',execution['body']['status']
    plan=op('prepare_evaluation_plan',key='information-real-probe-plan',compiled_id=compiled['id'],primary_count=1,
        dependence={'base_length':4,'rationale':'Fixed engineering input; no stationarity or fitted block-length claim.',
            'development_refs':[execution['id']],'randomness':randomness(2026102502)})
    assert plan['body']['status']=='POLICY_DRAFT'
    server=LocalServer(broker);thread=threading.Thread(target=server.serve_forever);thread.start()
    client=Client(server.url,broker.admin_token,timeout=240)
    request={'key':'information-real-probe-diagnostics','plan_id':plan['id'],'execution_id':execution['id'],
        'lags':profile['lags'],'limits':{'max_seconds':180}}
    saved=client.call('prepare_information_diagnostics',**request);body=saved['body'];result=body['result']
    assert result['status'] in ('COMPUTED_DIAGNOSTICS','INPUT_GAP')
    assert result['n_min'] is None and result['scientific_readiness'] is False
    assert body['verification'] is not None and client.call('prepare_information_diagnostics',**request)==saved
    report=execution['body']['result']['report']
    record.update(status='PASS_WITH_EXPLICIT_DATA_AND_SCIENTIFIC_LIMITS',exit_code=0,registry=str(registry),
        snapshot_id=snapshot_id,reference_certificate_id=reference['id'],feature_certificate_id=feature_id,
        idea_id=idea['id'],formalization_id=formalization['id'],compiled_id=compiled['id'],execution_id=execution['id'],
        plan_id=plan['id'],diagnostics_id=saved['id'],result_state=result['status'],reason=result['reason'],
        state_counts=report['state_counts'],processed_case_count=report['processed_case_count'],
        outcomes_complete=report['outcomes_complete'],contribution_count=result['contribution_count'],
        transport='authenticated loopback HTTP',same_key_idempotent=True,separate_process_replay=True,
        paid_provider_calls=0,market_conclusion=False,scientific_readiness=False,n_min=None,source_hashes_before=before)
finally:
    if server is not None:
        server.shutdown();thread.join(timeout=15);assert not thread.is_alive();server.server_close()
    broker.close()
    record['wall_seconds']=round(time.monotonic()-started,3)
    record['source_hashes_after']=hashes();record['sources_stable']=before==record['source_hashes_after']
    record['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    with (WORK/'real-probe-result.json').open('x',encoding='utf-8') as out:out.write(json.dumps(record,indent=2)+'\n')
assert record['status']=='PASS_WITH_EXPLICIT_DATA_AND_SCIENTIFIC_LIMITS' and record['sources_stable']
print(json.dumps({k:v for k,v in record.items() if not k.startswith('source_hashes')},indent=2))
