"""Close this bounded implementation checkpoint after actual terminal test results."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,zipfile

ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).resolve().parent
AUDIT=ROOT/'docs/reviews/implementation-2026-10-25'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')

tests=read(WORK/'tests-result.json');http=read(WORK/'http-result.json');real=read(WORK/'real-probe-result.json')
assert not (WORK/'real-probe-model-feasibility.json').exists(),'Unexpected output from the blocked optional preflight'
baseline=read(AUDIT/'nuisance-diagnostics-baseline.json');review=read(AUDIT/'nuisance-diagnostics-review.json')
assert tests['exit_code']==0 and tests['sources_stable'] and int(tests['unittest_summary'][0])==385
assert tests['source_hashes_before']==tests['source_hashes_after']
for name,expected in tests['source_hashes_after'].items():assert sha(ROOT/name)==expected,name
for result in (http,real):
    assert result['exit_code']==0 and result['sources_stable']
    assert result['source_hashes_before']==result['source_hashes_after']==tests['source_hashes_after']
assert http['status']=='PASS' and real['status']=='PASS_WITH_EXPLICIT_DATA_AND_SCIENTIFIC_LIMITS'
assert real['result_state']=='COMPUTED_DIAGNOSTICS' and real['processed_case_count']==96
assert real['state_counts']['ELIGIBLE']==94 and real['state_counts']['OUTCOME_MISSING']==1
assert real['state_counts']['PARTITION_BOUNDARY']==1 and real['scientific_readiness'] is False
assert sha(WORK/'http_smoke.py')==http['script_sha256']
assert sha(WORK/'real_development_probe.py')==real['script_sha256']
assert sha(WORK/'real-probe-profile.json')==real['profile_sha256']
assert sha(AUDIT/'nuisance-diagnostics-review.json')=='2c8020b63412e4bf2866269b22b4028ddb25a8fea567a18cd7d836631db86859'
assert review['source_captures']['before']==review['source_captures']['after']
for name,expected in review['source_captures']['after'].items():assert sha(ROOT/name)==expected,name
for name,expected in baseline['prior_reports_sha256'].items():assert sha(AUDIT/name)==expected,name
assert sha(AUDIT/baseline['archive'])==baseline['archive_sha256']
with zipfile.ZipFile(AUDIT/baseline['archive']) as z:
    assert z.testzip() is None and set(z.namelist())==set(baseline['files_sha256'])
    assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in baseline['files_sha256'].items())

changed=['trading_researcher/information_diagnostics.py','trading_researcher/information_runs.py',
    'trading_researcher/bootstrap_runs.py','trading_researcher/coordination.py','trading_researcher/storage.py',
    'trading_researcher/memory.py','tests/test_information_diagnostics.py','tests/test_information_runs.py',
    *review['changed_files_by_reviewer'],'trading_researcher/INFORMATION_DIAGNOSTICS.md',
    'README.md','trading_researcher/README.md','trading_researcher/EVALUATION_POLICY.md',
    'docs/architecture/CURRENT_STATE.md','docs/architecture/09_IMPLEMENTATION_BLUEPRINT.md',
    'docs/reviews/integration-research-2026-10-24/IMPLEMENTATION_SEQUENCE_2026-10-25.md',
    'docs/reviews/implementation-2026-10-25/nuisance-diagnostics-baseline.json',
    'docs/reviews/implementation-2026-10-25/nuisance-diagnostics-source-before.zip',
    'docs/reviews/implementation-2026-10-25/nuisance-diagnostics-verification.json',
    'docs/reviews/implementation-2026-10-25/nuisance-diagnostics-evidence.zip',
    'docs/reviews/implementation-2026-10-25/progress.json',
    'docs/reviews/implementation-2026-10-25/IMPLEMENTATION_SUMMARY_2026-10-25.md']
assert len(changed)==len(set(changed))
for name,expected in baseline['files_sha256'].items():
    if name not in changed:assert sha(ROOT/name)==expected,name

progress=read(AUDIT/'progress.json');step=next(s for s in progress['packages'] if s['step']==4)
step['status']='IN_PROGRESS'
step['evidence']=list(dict.fromkeys([*step['evidence'],
    'docs/reviews/implementation-2026-10-25/nuisance-diagnostics-review.json',
    'docs/reviews/implementation-2026-10-25/nuisance-diagnostics-verification.json']))
step['remaining_action']='Owned development nuisance measurements are implemented and replayed, including a fixed actual Binance-data engineering probe. Fit an explicit population model and retain a finite target/seed/world profile before actual bootstrap/MC power simulation; then perform separate narrow calibration and scientific admission. Return-process and coherent joint-family profiles remain separate gaps.'
progress['next_action']='Implement the predeclared population-model information study using the owned diagnostic inputs and actual fixed-count estimator/MC rule. Measure resource feasibility before launch, retain every world/gap, and keep final calibration fresh. Complete scientific semantic/data acceptance and atomic allocation/freeze before the genuine LLM research cycle; do not substitute an engineering probe for autonomous invention.'
progress['continuation_audit']={'previous_goal_turn':'no_progress','previous_blocker':'Local execution and JavaScript runtimes were unavailable across three turns; the goal was marked blocked.',
    'current_goal_turn':'progress','basis':'User resumed; local access recovered. Closed the previously pending source-bound arithmetic report, implemented owned diagnostics and their independent corrections, ran actual HTTP and Binance development probes, and completed current full regression.',
    'blocking_threshold_met':False,'full_objective_complete':False}
progress['controls']['evidence-gate']={'status':'SATISFIED','evidence':
    f"{tests['unittest_summary'][0]} runtime tests PASS with unchanged before/after source hashes. Independent fixtures/review, owned retention/replay, actual HTTP and 96-row Binance development engineering probe verified. Model fitting, power, N_min, calibration and scientific freeze remain incomplete; see nuisance-diagnostics-verification.json."}
progress['external_inputs_needed']=['Secure LLM API access for the intended provider(s).','Explicit finite currency cap before any paid run.']
save(AUDIT/'progress.json',progress)

summary_path=AUDIT/'IMPLEMENTATION_SUMMARY_2026-10-25.md'
summary=summary_path.read_text(encoding='utf-8')
checks_text=(f"The complete post-change regression passed **{tests['unittest_summary'][0]} tests in {tests['unittest_summary'][1]} seconds, exit 0**. "
    f"All {len(tests['source_hashes_after'])} captured runtime/test/fixture hashes were unchanged. The independent reviewer ran 12 pure and four owned-boundary tests; both passed. "
    "The synthetic HTTP and actual Binance-development probes passed their transport, retention and replay checks. "
    "Contract, preservation/link and whitespace outcomes are recorded in [checkpoint verification](nuisance-diagnostics-verification.json); the final read-only audit runs after all reports are saved.")
summary,count=re.subn(r'<!-- FINAL_CHECKS -->.*?<!-- /FINAL_CHECKS -->',checks_text,summary,flags=re.S)
assert count==1
summary_path.write_text(summary,encoding='utf-8')

evidence={'tests.log':WORK/'tests.log','tests-result.json':WORK/'tests-result.json','run_checks.py':WORK/'run_checks.py',
    'http_smoke.py':WORK/'http_smoke.py','http-result.json':WORK/'http-result.json',
    'real_development_probe.py':WORK/'real_development_probe.py','real-probe-profile.json':WORK/'real-probe-profile.json',
    'real-probe-result.json':WORK/'real-probe-result.json','record_results.py':Path(__file__),
    'final_gate.py':WORK/'final_gate.py'}
for field in ('log','report'):
    p=ROOT/review['checks']['owned_adversarial'][field]
    assert sha(p)==review['checks']['owned_adversarial'][field+'_sha256']
    evidence['independent-'+p.name]=p
evidence_path=AUDIT/'nuisance-diagnostics-evidence.zip';assert not evidence_path.exists()
with zipfile.ZipFile(evidence_path,'x',zipfile.ZIP_DEFLATED) as z:
    for name,path in evidence.items():z.writestr(name,path.read_bytes())

report={'schema':'nuisance-diagnostics-verification/1','status':'PENDING_FINAL_DOCUMENT_CHECKS',
    'purpose':'Bind exact development nuisance/dependence measurements to their owned plan, data and source as the next actual-information-study prerequisite.',
    'finding':'The new operation retains inputs/source before computation, preserves the full grid and unknown/missing distinctions, and separately replays results/contribution bytes. Fixed independent oracles exposed two repaired issues; actual stored Binance data exercised the connected path.',
    'warranted_conclusion':'The exercised diagnostic boundary works as described. It is not a fitted world, actual power calculation, N_min, calibration or completed research framework.',
    'changed_files_this_checkpoint':changed,'baseline':{'path':'nuisance-diagnostics-baseline.json','sha256':sha(AUDIT/'nuisance-diagnostics-baseline.json'),
        'archive':baseline['archive'],'archive_sha256':baseline['archive_sha256'],'retained_files':len(baseline['files_sha256'])},
    'runtime_tests':{'command':tests['command'],'exit_code':0,'tests':int(tests['unittest_summary'][0]),
        'seconds':tests['unittest_summary'][1],'wall_seconds':tests['wall_seconds'],'source_hashes':tests['source_hashes_after'],
        'sources_stable':True,'log_sha256':tests['log_sha256'],'report_sha256':sha(WORK/'tests-result.json')},
    'independent_review':{'path':'nuisance-diagnostics-review.json','sha256':sha(AUDIT/'nuisance-diagnostics-review.json'),
        'checks':review['checks'],'conclusion':review['review_conclusion']},
    'focused_history':[
        {'check':'New pure module admission','exit_code':1,'reason':'Module did not exist before implementation.'},
        {'check':'Owned operation admission','tests':1,'seconds':'65.601','exit_code':1,'reason':'Operation unavailable before implementation.'},
        {'check':'Initial pure behavior','tests':7,'seconds':'0.013','exit_code':0},
        {'check':'Owned operation integration','tests':4,'seconds':'83.194','exit_code':0,'qualification':'Before the two subsequent pure fixes; final regression covers the current source.'},
        {'check':'Pure calculations after independent fixes','tests':18,'seconds':'0.036','exit_code':0,'qualification':'Before the reviewer added the empty-scope test, which is in final regression.'}],
    'http_smoke':{k:v for k,v in http.items() if not k.startswith('source_hashes')},
    'real_data_probe':{k:v for k,v in real.items() if not k.startswith('source_hashes')},
    'evidence_archive':{'path':evidence_path.name,'sha256':sha(evidence_path),'members_sha256':{n:sha(p) for n,p in evidence.items()}},
    'preserved_prior_reports_sha256':baseline['prior_reports_sha256'],
    'prior_checkpoint_closed_on_resumption':{'path':'information-planning-verification.json','sha256':sha(AUDIT/'information-planning-verification.json'),
        'qualification':'Its 358-test run was retained and current-source-verified before this new diagnostic implementation began; it is not represented as a newly repeated run.'},
    'optional_check_not_executed':{'purpose':'Additional SQLite-based population-rate feasibility preflight',
        'outcome':'Process creation denied; the user supplied the matching Bitdefender malicious-command-line notification for pwsh.exe.',
        'disposition':'Optional command omitted, not reissued through another launcher. No feasibility result is claimed.',
        'protection_rules_changed':False,'malware_or_false_positive_verdict':'not_determined',
        'subsequent_required_check':'The ordinary git diff --check command succeeded with exit 0; final project gates are recorded separately.'},
    'remaining_boundaries':review['remaining_boundaries'][:-1]+[
        'The actual-data probe is a predefined engineering case, not genuine LLM invention, a power study or market evidence.',
        'Historical PIT availability and account costs remain qualified; the 900-second scenario was preserved.',
        'No live provider call, new software installation, order, capital permission, commit or push occurred in this continuation.'],
    'next_action':progress['next_action'],'goal_status':'IN_PROGRESS'}
destination=AUDIT/'nuisance-diagnostics-verification.json';assert not destination.exists()
save(destination,report);checks={}
for name,command in [('retail_contract',[sys.executable,'-B','docs/reviews/verify_retail_contract.py']),
    ('implementation_preservation',[sys.executable,'-B','docs/reviews/implementation-2026-10-25/verify_implementation.py']),
    ('git_diff_check',['git','diff','--check'])]:
    result=subprocess.run(command,cwd=ROOT,capture_output=True,text=True)
    assert result.returncode==0,result.stdout+result.stderr
    save(WORK/(name+'.json'),{'command':command,'exit_code':0,'stdout':result.stdout,'stderr':result.stderr})
    checks[name]={'command':command,'exit_code':0,'report_sha256':sha(WORK/(name+'.json'))}
    if name!='git_diff_check':
        value=json.loads(result.stdout);assert value['status']=='PASS'
        checks[name]['status']='PASS'
        if 'local_document_links' in value:checks[name]['local_document_links']=value['local_document_links']
report['checks']=checks;report['status']='PASS_WITH_EXPLICIT_INFORMATION_AND_CALIBRATION_LIMITS'
report['changed_file_sha256']={name:sha(ROOT/name) for name in changed if ROOT/name!=destination}
save(destination,report)
print(json.dumps({'status':report['status'],'exit_code':0,'changed_files':len(changed),
    'runtime_tests':report['runtime_tests']['tests'],'source_files':len(tests['source_hashes_after']),
    'http':'PASS','real_data_probe':real['result_state'],'checks':checks},indent=2))
