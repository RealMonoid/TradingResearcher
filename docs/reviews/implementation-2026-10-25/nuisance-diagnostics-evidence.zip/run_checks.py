import hashlib,json,re,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
def hashes():
    paths=[*ROOT.glob('trading_researcher/*.py'),*ROOT.glob('tests/*.py'),*ROOT.glob('tests/fixtures/*')]
    return {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(paths) if p.is_file()}
command=[sys.executable,'-B','-m','unittest','discover','-s','tests','-v']
before=hashes();started=time.monotonic()
with (WORK/'tests.log').open('xb') as stream:
    process=subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
elapsed=time.monotonic()-started;after=hashes()
log=(WORK/'tests.log').read_text(encoding='utf-8')
summary=re.findall(r'Ran (\d+) tests? in ([\d.]+)s',log)
report={'command':command,'exit_code':process.returncode,'wall_seconds':round(elapsed,3),
        'unittest_summary':summary[-1] if summary else None,'source_hashes_before':before,
        'source_hashes_after':after,'sources_stable':before==after,
        'log_sha256':hashlib.sha256((WORK/'tests.log').read_bytes()).hexdigest()}
(WORK/'tests-result.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if not k.startswith('source_hashes')}),flush=True)
print('\n'.join(log.splitlines()[-12:]),flush=True)
raise SystemExit(0 if process.returncode==0 and before==after else 1)
