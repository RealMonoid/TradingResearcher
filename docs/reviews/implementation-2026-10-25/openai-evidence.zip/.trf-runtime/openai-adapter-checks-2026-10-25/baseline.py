import hashlib,json
from pathlib import Path
root=Path.cwd();work=Path(__file__).resolve().parent
files=[p for folder in ('trading_researcher','tests','docs') for p in (root/folder).rglob('*') if p.is_file()]+[root/'README.md']
result={'files':{p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}}
with (work/'baseline.json').open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2)
print(json.dumps({'status':'PASS','files':len(result['files'])}))
