"""Retain the bounded OpenAI/usage checkpoint without repeating model calls."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from trading_researcher.provider_usage import read_usage_report


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write_json(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')


def main():
    work=Path(__file__).resolve().parent
    out=ROOT/'docs/reviews/implementation-2026-10-25'
    target=out/'openai-verification.json'
    if target.exists():raise RuntimeError('Frozen checkpoint already exists')
    protected={str(path.relative_to(ROOT)):sha(path) for path in out.iterdir()
        if path.suffix in ('.json','.zip') and path.name!='progress.json'}
    baseline=json.loads((work/'baseline.json').read_text())['files']
    live=json.loads((work/'live-result.json').read_text())
    assert live['status']=='PASS' and live['integrity']['status']=='PASS'
    ledger=ROOT/'.trf-runtime/openai-integration-budget.sqlite3'
    ledger_before=sha(ledger)
    usage=read_usage_report(ledger)
    assert usage==live['usage'] and sha(ledger)==ledger_before
    totals=usage['totals']
    assert (totals['known_input_tokens'],totals['known_output_tokens'],totals['exact_total_tokens'])==(2038,134,2172)
    assert usage['money']['charged_nano']==6435000
    assert sum(call['receipt']['usage']['input_tokens']+call['receipt']['usage']['output_tokens']
        for call in usage['calls'])==2172
    assert sum(call['receipt']['usage']['input_tokens']*2500+call['receipt']['usage']['output_tokens']*10000
        for call in usage['calls'])==6435000
    write_json(out/'openai-initial-usage.json',usage)
    text='''# First live OpenAI usage observation

Date: October 25, 2026. This is a frozen observation, not a live counter.

The actual API-key integration passed four model calls, two isolated perspectives,
authenticated tool round trips and registry integrity checks. Both perspectives
retained an explicit gap because this test supplied synthetic context only.
It is not a representative research workload or evidence of scientific discovery.

| Perspective | Calls | Input tokens | Output tokens | Total tokens |
|---|---:|---:|---:|---:|
| First | 2 | 1,019 | 67 | 1,086 |
| Second | 2 | 1,019 | 67 | 1,086 |
| Total | 4 | 2,038 | 134 | 2,172 |

All four calls have reported usage. Cached input and reasoning output were reported
as zero. Preflight counts are retained separately and are not added to these totals.
The conservative published-rate charge is USD 0.006435; USD 4.993565 remains in the
user-authorized USD 5 aggregate test allowance. This is not a provider invoice or
account balance. The API accepted these calls without any top-up performed by us.

Each subsequent admitted OpenAI inference automatically records its run, perspective,
model, prompt version, timestamp, request hash and usage in the same durable ledger.
Unknown usage remains visible; token subsets are never double-counted. See the
[exact snapshot](openai-initial-usage.json), [implementation verification](openai-verification.json)
and [adapter/report documentation](../../../trading_researcher/OPENAI.md).

Read current totals without sending a model request:

```powershell
python -B -m trading_researcher openai-usage --ledger .trf-runtime/openai-integration-budget.sqlite3
```

This covers framework inference, not this Codex development chat. Additional vendors
and automatic weekly report delivery remain future integrations. Actual invoices,
account balance, typical research cost, the large real-data context and scientific
validity remain unverified.
'''
    (out/'OPENAI_USAGE_2026-10-25.md').write_text(text,encoding='utf-8')
    progress=json.loads((out/'progress.json').read_text())
    next_action=('Resolve bounded full-context research integration using the genuine provider and existing '
        'development measurement tool; preserve source visibility/exposure and scientific admission boundaries. '
        'Use the existing aggregate OpenAI ledger and retain token reports. Complete scientific gates and later '
        'AmiBroker/reporting packages without treating this synthetic API test as discovery.')
    progress['next_action']=next_action
    progress['packages'][1]['remaining_action']=next_action
    progress['packages'][1]['evidence']+=['trading_researcher/OPENAI.md',
        'docs/reviews/implementation-2026-10-25/openai-verification.json',
        'docs/reviews/implementation-2026-10-25/provider-usage-review.json',
        'docs/reviews/implementation-2026-10-25/openai-initial-usage.json']
    progress['decisions'][0].update(status='LIVE_API_ACCESS_VERIFIED_BOUNDED',
        need='Four actual API calls completed. No new top-up needed for this probe; account balance and invoice remain unchecked. ChatGPT-plan preview is incompatible with the current remote output cap.')
    progress['external_inputs_needed']=[]
    progress['controls']['evidence-gate']={'status':'SATISFIED',
        'evidence':'OpenAI:36 unique offline adapter/usage tests, including26 independent cases;20 existing researcher/accounting regressions. Four-call actual provider/RPC probe PASS,2172 reported tokens. No scientific claim.'}
    progress['continuation_audit']['basis']='Completed bounded live API and persistent token-usage checkpoint; full seven-package objective remains incomplete.'
    progress['token_usage']={'ledger':'.trf-runtime/openai-integration-budget.sqlite3',
        'snapshot':'docs/reviews/implementation-2026-10-25/openai-initial-usage.json',
        'reported_tokens':2172,'conservative_nano_usd':6435000,'aggregate_authorization_nano_usd':5000000000,
        'future_recording':'Automatic per admitted OpenAI call; read-only CLI per run and aggregate. No Codex chat or synthetic fixture counts.'}
    write_json(out/'progress.json',progress)
    summary_path=out/'IMPLEMENTATION_SUMMARY_2026-10-25.md'
    summary=summary_path.read_text()
    summary=summary.replace('A genuine provider adapter, compact full-context integration and verified live invocation remain outstanding.',
        'A genuine OpenAI adapter and persistent token reporting now pass a four-call synthetic-context live check. Full-context research integration remains outstanding.')
    summary=summary.replace('no credential bytes enter project artifacts, and no paid call has run.',
        'no credential bytes enter project artifacts. The later OpenAI checkpoint below records the first actual API calls.')
    summary=summary.replace('No new software, Docker service or paid provider call was needed.',
        'No new software or Docker service was needed. The later bounded OpenAI checkpoint used four actual provider calls.')
    summary=summary.replace('1. Set a finite currency budget before the first paid integration/research run. OpenAI key provisioning is complete; live account/model access remains untested.',
        '1. No immediate access/budget decision is pending: the user approved USD 5 total for initial API tests and four actual calls succeeded. Account balance, actual invoices and any later budget increase require separate treatment.')
    summary+='''\n## OpenAI and token documentation checkpoint\n\nThe [actual provider check and usage report](OPENAI_USAGE_2026-10-25.md) completed four model calls through two isolated researcher perspectives and authenticated tools. It used 2,172 reported tokens and a conservative USD 0.006435 rate bound. Persistent per-call, per-run and aggregate usage records now preserve unknown receipts and cache/reasoning subsets without double-counting. [Verification](openai-verification.json) lists all changed files and exact check outcomes. This synthetic-context integration does not resolve the large real-data context, establish typical research consumption or confer scientific authority. The original seven-package goal remains in progress.\n'''
    summary_path.write_text(summary,encoding='utf-8')
    sequence=ROOT/'docs/reviews/integration-research-2026-10-24/IMPLEMENTATION_SEQUENCE_2026-10-25.md'
    content=sequence.read_text()
    content=content.replace('the [provider-neutral loop and fixture adapter](../../../trading_researcher/RESEARCHER.md) are implemented, while the live connector and development measurement tools remain pending.',
        'the [provider-neutral loop](../../../trading_researcher/RESEARCHER.md), development measurements and [OpenAI adapter with persistent usage](../../../trading_researcher/OPENAI.md) are implemented. A four-call synthetic-context live check passes; full-context research integration remains pending.')
    sequence.write_text(content,encoding='utf-8')
    assert all(sha(ROOT/path)==expected for path,expected in protected.items())
    changed=[name for name,old in baseline.items() if (ROOT/name).is_file() and sha(ROOT/name)!=old]
    candidates=[*ROOT.joinpath('trading_researcher').glob('*.py'),*ROOT.joinpath('trading_researcher').glob('*.md'),
        *ROOT.joinpath('tests').glob('*.py'),*out.iterdir()]
    changed+= [str(path.relative_to(ROOT)).replace('\\','/') for path in candidates
        if path.is_file() and str(path.relative_to(ROOT)).replace('\\','/') not in baseline]
    checks=[
        {'command':"python -B -m unittest discover -s tests -p 'test_openai_provider*.py' -q",'tests':25,'exit_code':0,'seconds':1.798,'evidence':'Observed structured exec chunk0592cb; includes19 independently authored cases.'},
        {'command':"python -B -m unittest discover -s tests -p 'test_provider_usage.py' -q",'tests':4,'exit_code':0,'seconds':0.159,'evidence':'Observed structured exec chunke751e6.'},
        {'tests':26,'exit_code':0,'seconds':1.819,'evidence':'provider-usage-review.json; includes19 adapter cases plus7 additional usage cases, overlapping the25 above.'},
        {'command':"python -B -m unittest discover -s tests -p 'test_research*.py' -q",'tests':20,'exit_code':0,'seconds':13.644,'evidence':'Observed structured exec session78482/chunk21a612.'},
        {'command':'python -B .trf-runtime/openai-adapter-checks-2026-10-25/live_probe.py','exit_code':0,'evidence':'live-result.json; structured exec session97076/chunkd56195.'},
        {'command':'python -B -m trading_researcher openai-usage --ledger .trf-runtime/openai-integration-budget.sqlite3','exit_code':0,'evidence':'Observed structured exec chunkaae61b; same report as retained live snapshot.'},
        {'check':'Independent report arithmetic and byte-preserving read-only report','exit_code':0}]
    report={'schema':'openai-implementation-verification/1','status':'CHECKING',
        'scope':'Bounded API transport, actual synthetic-context tool loop and persistent operational usage.',
        'unique_offline_tests':56,'offline_inventory':'36 adapter/usage cases plus20 researcher/accounting regression cases; overlapping independent runs are not added twice.',
        'checks':checks,'changed_files':sorted(set(changed)),
        'protected_prior_artifacts':protected,'prior_artifacts_unchanged':True,
        'token_usage':usage['totals'],'money':usage['money'],
        'unverified':['Representative full-context market research workload','Full real-data context integration',
            'Actual provider invoice and account balance','Other provider adapters and aggregate reports',
            'Weekly delivery','Scientific validity, novelty, calibration, atomic scientific freeze and profitability'],
        'authorization':'USD5 aggregate initial OpenAI tests, user-approved; no top-up or other purchase performed.'}
    write_json(target,report)
    for name,args in [('retail-contract',[sys.executable,'-B','docs/reviews/verify_retail_contract.py']),
                      ('git-diff-check',['git','diff','--check'])]:
        run=subprocess.run(args,cwd=ROOT,capture_output=True,text=True,encoding='utf-8',errors='replace')
        (work/(name+'.log')).write_text(run.stdout+run.stderr,encoding='utf-8')
        checks.append({'command':args,'exit_code':run.returncode,'log':name+'.log'})
        if run.returncode:raise RuntimeError(name+' failed; retained report remains incomplete')
    archive=out/'openai-evidence.zip'
    sources=[*ROOT.joinpath('trading_researcher').glob('*.py'),*ROOT.joinpath('tests').glob('*.py'),
        *ROOT.joinpath('tests/fixtures').glob('*.json'),*work.glob('*.py'),*work.glob('*.json'),*work.glob('*.log')]
    sources+=[*ROOT.joinpath('.trf-runtime/openai-independent-review-2026-10-25').glob('*.json'),
        *ROOT.joinpath('.trf-runtime/openai-independent-review-2026-10-25').glob('*.log')]
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted(set(sources)):
            bundle.write(path,str(path.relative_to(ROOT)))
    report.update(status='PASS_BOUNDED_PROVIDER_AND_USAGE',evidence_archive_sha256=sha(archive),
        source_hashes={str(path.relative_to(ROOT)):sha(path) for path in sources},
        changed_files=sorted(set(changed+[str(target.relative_to(ROOT)),str(archive.relative_to(ROOT))])))
    write_json(target,report)
    assert all(sha(ROOT/path)==expected for path,expected in protected.items())
    final_check=subprocess.run(['git','diff','--check'],cwd=ROOT,capture_output=True,text=True)
    if final_check.returncode:raise RuntimeError('Final whitespace check failed')
    print(json.dumps({'status':report['status'],'offline_unique_tests':56,'live_calls':4,
        'tokens':2172,'conservative_usd':'0.006435','prior_artifacts_preserved':len(protected),
        'documentation_exit_codes':[item['exit_code'] for item in checks[-2:]],
        'final_git_diff_check_exit':final_check.returncode,'report':str(target)},indent=2))


if __name__=='__main__':main()
