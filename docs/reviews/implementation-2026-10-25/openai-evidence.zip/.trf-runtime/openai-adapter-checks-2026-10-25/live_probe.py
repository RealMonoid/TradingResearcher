"""One bounded, retained integration probe. Uses the already approved local key.

Never print credentials; no automatic retries, top-ups, or alternative providers.
The global ledger is shared with all later initial integration tests.
"""
import json
import hashlib
from pathlib import Path
import sys
import threading
import time

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from trading_researcher.coordination import Broker
from trading_researcher.openai_provider import OpenAIResponsesProvider,SpendLedger,configuration,cost_bound
from trading_researcher.researcher import TOOL_DEFINITIONS,run_research_once
from trading_researcher.server import Client,LocalServer


def save(path,value):
    with path.open('x',encoding='utf-8') as stream:json.dump(value,stream,indent=2);stream.write('\n')


def main():
    work=Path(__file__).resolve().parent
    for relative,expected in {
        'trading_researcher/openai_provider.py':'2b62017bd32775f8167d577b4988ca9679144fc389d44eb19a89a0b9376000ad',
        'trading_researcher/provider_usage.py':'34059ae2defd4b4a13059cc9bae1b495e7e16d320b9a169cfc2f8df4fb6a8daf',
    }.items():
        if hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()!=expected:
            raise RuntimeError('Provider changed after the independent offline check')
    registry=work/'live-registry'
    if registry.exists():raise RuntimeError('Existing live attempt must be inspected, never silently repeated')
    config=configuration(input_token_limit=8000,output_token_limit=1024)
    ledger_path=ROOT/'.trf-runtime/openai-integration-budget.sqlite3'
    ledger=SpendLedger(ledger_path,5000000000)
    before=ledger.report()
    if before['calls']:raise RuntimeError('This first probe requires explicit reconciliation of existing calls')
    broker=Broker(registry);server=LocalServer(broker)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    try:
        admin=Client(server.url,broker.admin_token)
        credentials={name:admin.call('register_worker',name=name,role='discovery',
            capabilities=['research-record/v1']) for name in ('first','second')}
        source=admin.call('add_research',kind='source',content={
            'text':'Synthetic API integration context. No market observations or empirical result.',
            'uri':'fixture:openai-integration'},scope={},source_refs=[])
        context=admin.call('create_context',role='discovery',epoch=1,artifact_ids=[source['id']])
        common=('This is a transport/tool integration test, not market research. First call capabilities exactly once. '
            'After its result, return a JSON object with status="final" and record={"kind":"gap",'
            '"content":{"text":"Integration context has no market observations",'
            '"reason":"Synthetic input only","reopen_condition":"Authorized real research inputs"},'
            '"scope":{},"source_refs":[]}. Do not claim discovery or scientific evidence. ')
        profile={'model':config['model'],'prompt_version':'openai-integration/1','max_calls':4,
            'max_tokens':80000,'max_seconds':180,'max_cost_units':4*cost_bound(8000,1024),
            'currency':'USD','mode':'live','prompts':{
                'first':common+'You are the first isolated perspective.',
                'second':common+'You are the second isolated perspective.'},
            'tools':TOOL_DEFINITIONS,'generation_parameters':{'openai_responses':config},
            'max_output_tokens':1024,'call_timeout_seconds':60,'max_retries':0}
        save(work/'live-profile.json',profile)
        epoch=admin.call('create_research_epoch',key='openai-integration',context_id=context['id'],
            workers=['first','second'],profile=profile)
        batch=admin.call('create_batch',key='openai-integration',epoch=1)
        for name in credentials:
            admin.call('enqueue',key='openai-'+name,spec={'kind':'research-record/v1',
                'context_id':context['id'],'purpose':'Verify API transport and usage; no scientific result',
                'allowed_workers':[name],'max_attempts':1,'lease_seconds':30,
                'deadline':int(time.time())+240,'dependencies':[],'batch_id':batch['id'],
                'research_epoch_id':epoch['id']})
        admin.call('seal_batch',batch_id=batch['id'])
        outcomes=[]
        for name in credentials:
            provider=OpenAIResponsesProvider(ROOT/'.env.local',ledger_path,config,
                epoch_id=epoch['id'],worker=name)
            outcome=run_research_once(Client(server.url,credentials[name]['token']),provider)
            outcomes.append(outcome)
            if not outcome.get('accepted'):break
        snapshot=admin.call('inspect_research_epoch',epoch_id=epoch['id'])
        report=ledger.report()
        tool_calls=sum(call['reply'] is not None and
            (call['reply']['response'].get('output') or {}).get('status')=='tools' for call in snapshot['calls'])
        passed=len(outcomes)==2 and all(item.get('accepted') for item in outcomes) and tool_calls==2
        result={'schema':'openai-live-integration-observation/1',
            'status':'PASS' if passed else 'BLOCKED','genuine_discovery':False,
            'scope':'Actual provider and isolated RPC tool loop on synthetic input only.',
            'outcomes':outcomes,'epoch':snapshot,'usage':report,'integrity':admin.call('verify'),
            'qualifications':['Not a representative scientific research workload.',
                'Conservative currency bound, not a billing statement.',
                'Full real-data context and scientific gates remain separate.']}
        save(work/'live-result.json',result)
        save(work/'live-usage.json',report)
        print(json.dumps({'status':result['status'],'totals':report['totals'],'money':report['money'],
            'provider_statuses':[{name:call['reply']['response'].get(name) for name in (
                'status','error_type','error_kind','http_status','transport_request_id')}
                for call in snapshot['calls'] if call['reply']],
            'integrity':result['integrity']['status']},indent=2))
        return 0 if passed else 2
    finally:
        server.shutdown();server.server_close();thread.join(5);broker.close()


if __name__=='__main__':raise SystemExit(main())
