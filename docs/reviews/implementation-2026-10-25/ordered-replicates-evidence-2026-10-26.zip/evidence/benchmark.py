"""Paired cold retained-source pipelines; complete fixed draws and replay each time."""
import datetime,hashlib,json,statistics,sys,time,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];work=Path(__file__).parent
sys.path[:0]=[str(root),str(root/'tests')]
from study_stream_support import inputs
from trading_researcher import study_runs
from trading_researcher.codec import digest
from trading_researcher.evaluation_plans import source_bundle,footprint
archive=root/'tests/fixtures/study-source-dc3e6fc.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='7b6ae8230d46af0e072736be9f905310d9b8936d2cdff3fde2becc3fd92cc014'
with zipfile.ZipFile(archive) as retained:
    before={name:retained.read(name) for name in retained.namelist()}
after=source_bundle();payload,manifest,world,cases=inputs()
assert set(before)==set(after)
assert {name for name in before if before[name]!=after[name]}=={
    'trading_researcher/evaluation_policy.py','trading_researcher/monte_carlo.py'}
observed=[];reference=None;reference_stream=None
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
for index,label in enumerate(('before','after','after','before','before','after')):
    meter={'materialized_bytes':0};outputs=[];begin=time.monotonic()
    result,proofs=study_runs.execute_attempt(before if label=='before' else after,payload,manifest,world,cases,
        lambda:180,meter,outputs)
    seconds=time.monotonic()-begin
    assert len(proofs)==2 and result['outcome']['state']=='VERIFIED'
    streams=dict(outputs)
    encoded=streams['generate/stream.jsonl.gz']
    assert encoded==streams['replay/expected-stream.jsonl.gz']
    if reference is None:reference=result;reference_stream=encoded
    assert result==reference and encoded==reference_stream
    assert proofs[0]['stream_encoding']==proofs[1]['stream_encoding']
    record={'index':index,'label':label,'seconds':seconds,'proof_count':len(proofs),
        'complete_result_and_stream_equal':True,'result_hash':digest(result),
        'stream_blob':proofs[0]['stream_blob'],'stream_encoding':proofs[0]['stream_encoding'],
        'charged_bytes':meter['materialized_bytes']+sum(len(value) for _,value in outputs)+study_runs.METADATA_BYTES}
    (work/('benchmark-run-'+str(index)+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    observed.append(record);print(json.dumps(record),flush=True)
timings={label:[r['seconds'] for r in observed if r['label']==label] for label in ('before','after')}
medians={key:statistics.median(values) for key,values in timings.items()}
gain=1-medians['after']/medians['before']
value={'schema':'paired-ordered-replicates-benchmark/1','started_at':started,
    'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sequence':'AB BA AB',
    'runs':observed,'medians_seconds':medians,'median_reduction_percent':100*gain,
    'after_max_below_before_min':max(timings['after'])<min(timings['before']),
    'source_before':footprint(before),'source_after':footprint(after),
    'qualification':'Three cold process pairs for one fixed synthetic family, each with complete generation/replay. No full calibration or broad hardware/workload guarantee.',
    'scientific_readiness':False,'provider_calls':0}
(work/'benchmark.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({k:v for k,v in value.items() if k not in ('runs','source_before','source_after')}))
assert gain>0.05 and value['after_max_below_before_min'],'Observed performance gain does not clear the predeclared 5% and disjoint-range engineering gate'
