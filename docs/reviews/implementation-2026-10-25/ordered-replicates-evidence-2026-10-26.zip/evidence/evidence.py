"""Retain exact arithmetic reuse, repeated pipeline timing and unresolved scope."""
import ast,datetime,hashlib,json,re,subprocess,sys,unittest,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];work=Path(__file__).parent;out=root/'docs/reviews/implementation-2026-10-25'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
baseline=json.loads((work/'baseline.json').read_text())
checks=[json.loads(p.read_text()) for p in sorted(work.glob('2026*.json'))]
inventory={'test_ordered_replicates_independent.py':16,'test_evaluation_policy*.py':14,
    'test_monte_carlo*.py':27,'test_exact_bootstrap_acceleration*.py':16,'test_stationary_bootstrap*.py':19}
sys.path[:0]=[str(root),str(root/'tests')]
def flatten(suite):
    for item in suite:
        if isinstance(item,unittest.TestSuite):yield from flatten(item)
        else:yield item.id()
ids={p:list(flatten(unittest.TestLoader().discover(str(root/'tests'),pattern=p))) for p in inventory}
all_ids=[item for values in ids.values() for item in values]
assert len(all_ids)==len(set(all_ids))==sum(inventory.values())==92
latest={}
for pattern,count in inventory.items():
    assert len(ids[pattern])==count
    matched=[c for c in checks if '-p' in c['command'] and c['command'][c['command'].index('-p')+1]==pattern]
    assert matched and matched[-1]['exit_code']==0,pattern
    check=matched[-1];log=(work/check['log']).read_text()
    assert re.search(r'Ran '+str(count)+r' tests? ',log) and re.search(r'\nOK(?:\s|$)',log)
    latest[pattern]=check['log']
changed=set(subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines())
changed.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines())
code=sorted(n for n in changed if n.startswith(('trading_researcher/','tests/')) and n.endswith(('.py','.zip')))
assert sorted(n for n in code if n.startswith('trading_researcher/'))==[
    'trading_researcher/evaluation_policy.py','trading_researcher/monte_carlo.py']
preserved=[n for n in baseline['files'] if n.startswith(('trading_researcher/','tests/')) and n not in changed]
preserved+=['docs/architecture/'+n for n in ('02_DECISION_REGISTER.md','03_REJECTED_DECISIONS.md','04_DEFINITIONS.md',
    '14_RETAIL_RESEARCH_CONTRACT.md','05_REQUIREMENTS.md','06_MASTER_ARCHITECTURE.md','07_SCIENTIFIC_EVALUATION.md')]
for name in preserved:assert sha((root/name).read_bytes())==baseline['files'][name],name
unchanged_functions={}
with zipfile.ZipFile(work/'source-before.zip') as before:
    for name,exempt in {'trading_researcher/evaluation_policy.py':{'quantile','basic_interval'},
                        'trading_researcher/monte_carlo.py':{'quantile_band','diagnose'}}.items():
        old={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(before.read(name)).body if isinstance(n,ast.FunctionDef)}
        new={n.name:ast.dump(n,include_attributes=False) for n in ast.parse((root/name).read_bytes()).body if isinstance(n,ast.FunctionDef)}
        unchanged_functions[name]=sorted(set(old)-exempt)
        for key in unchanged_functions[name]:assert old[key]==new[key],(name,key)
review_path=work/'independent-review.json';review=json.loads(review_path.read_text())
assert review['status'].startswith('PASS')
for field in ('source_sha256','canonical_authority_sha256'):
    for name,expected in review[field].items():assert sha((root/name).read_bytes())==expected,name
benchmark=json.loads((work/'benchmark.json').read_text())
assert benchmark['median_reduction_percent']>5 and benchmark['after_max_below_before_min']
assert len(benchmark['runs'])==6 and all(r['proof_count']==2 and r['complete_result_and_stream_equal'] for r in benchmark['runs'])
assert len({r['result_hash'] for r in benchmark['runs']})==1
assert len({r['stream_blob']['sha256'] for r in benchmark['runs']})==1
for name,expected in benchmark['source_after'].items():assert sha((root/name).read_bytes())==expected,name
for source,target in ((review_path,out/'ordered-replicates-independent-2026-10-26.json'),
                     (work/'benchmark.json',out/'ordered-replicates-benchmark-2026-10-26.json')):
    with target.open('xb') as destination:destination.write(source.read_bytes())
members={name:(root/name).read_bytes() for name in code}
for p in sorted(work.glob('2026*')):members['checks/'+p.name]=p.read_bytes()
for name in ('baseline.json','check.py','evidence.py','profile_world.py','profile-summary.txt',
             'profile-observation.json','world.pstats','benchmark.py','benchmark.json','independent-review.json'):
    members['evidence/'+name]=(work/name).read_bytes()
members['evidence/test-identities.json']=(json.dumps(ids,indent=2)+'\n').encode()
with zipfile.ZipFile(work/'source-before.zip') as before:
    for name in code:
        if name in baseline['files']:members['before/'+name]=before.read(name)
for name,raw in members.items():
    if not name.endswith(('.zip','.pstats')):assert not re.search(rb'\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{20,}',raw),name
with zipfile.ZipFile(root/'tests/fixtures/study-source-dc3e6fc.zip') as archive:
    for name in archive.namelist():
        raw=archive.read(name);assert sha(raw)==baseline['files'][name]
        assert not re.search(rb'\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{20,}',raw),name
archive=out/'ordered-replicates-evidence-2026-10-26.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as target:
    for name,raw in members.items():target.writestr(name,raw)
value={'schema':'ordered-replicates-verification/1','status':'CODE_CHECKS_PASS_DOCUMENTATION_PENDING',
    'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent_commit':baseline['head'],
    'unique_focused_tests':92,'test_inventory':inventory,'latest_pass_log_by_suite':latest,'checks':checks,
    'retained_failed_checks':[c['log'] for c in checks if c['exit_code']!=0],
    'initial_failures':'Four expected missing-helper errors before implementation; then combined invalid-input priority counterexamples exposed changed tail numeric-error precedence. Original preflight restored; all 16 independent cases now pass.',
    'profile':json.loads((work/'profile-observation.json').read_text()),
    'benchmark_record':'ordered-replicates-benchmark-2026-10-26.json',
    'benchmark_sha256':sha((work/'benchmark.json').read_bytes()),'benchmark_median_seconds':benchmark['medians_seconds'],
    'median_runtime_reduction_percent':benchmark['median_reduction_percent'],
    'benchmark_scope':'Six cold executions of the same fixed synthetic world, each with actual generation/replay; not six independent scientific observations. No concurrent regression batches during timing.',
    'source_sha256':{p.relative_to(root).as_posix():sha(p.read_bytes()) for p in sorted((root/'trading_researcher').glob('*.py'))},
    'changed_code_test_sha256':{n:sha((root/n).read_bytes()) for n in code},
    'preserved_sha256':{n:baseline['files'][n] for n in preserved},'unchanged_function_ast':unchanged_functions,
    'independent_review_sha256':sha(review_path.read_bytes()),'evidence_archive':archive.name,
    'evidence_archive_sha256':sha(archive.read_bytes()),'archive_members':len(members),
    'archive_scope':'Changed code/new tests, pinned prior application source, exact checks, profile, six-run benchmark and independent review. No market observations, credentials or private registries.',
    'provider_calls':0,'scientific_readiness':False,'full_objective_complete':False,
    'unverified':['Full repository suite, all possible numerical inputs, broad hardware/workload speed and peak memory',
        'Contract-level discovery-to-freeze and freeze-to-report comparative acceleration',
        'Actual complete final calibration and resource feasibility, bounded recorded continuation runtime',
        'Nuisance/stress adequacy, justified information targets, scientific admission/freeze and campaign/reservation',
        'Genuine mixed-provider free research cycle, policy/AmiBroker, domain reporting and economic usefulness']}
with (out/'ordered-replicates-verification-2026-10-26.json').open('x',encoding='utf-8') as target:
    target.write(json.dumps(value,indent=2)+'\n')
p=out/'progress.json';progress=json.loads(p.read_text())
progress['continuation_audit']={'previous_goal_turn':'no_progress_verification_only','current_goal_turn':'progress',
    'basis':'Profile-selected redundant exact ordering removed; 92 targeted tests and six cold actual pipeline executions retain all outputs with a 20.74% median workload gain. Contract section9 supports inspecting a recorded bounded continuation path next.',
    'blocking_threshold_met':False,'full_objective_complete':False}
progress['ordered_replicates_checkpoint']={'date':'2026-10-26','status':'FOCUSED_CHECKS_PASS','unique_focused_tests':92,
    'verification':'docs/reviews/implementation-2026-10-25/ordered-replicates-verification-2026-10-26.json',
    'cold_pipeline_executions':6,'paired_result_and_encoded_stream_identical':True,
    'median_runtime_reduction_percent':benchmark['median_reduction_percent'],
    'provider_calls':0,'scientific_readiness':False,'full_objective_complete':False}
progress['next_action']='Implement the contract section9 recorded bounded resource-continuation path after reviewing exact ownership, immutable world/source identity, cumulative budget/failure accounting and D030 stopping rules; no alias resets or replacement draws. The 60-minute initial cap and 4GiB installed envelope are unchanged here. Then complete actual nuisance/stress/information/final-calibration work and the full campaign, scientific freeze, mixed-provider research, policy/AmiBroker and reporting objective.'
p.write_text(json.dumps(progress,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':value['status'],'unique_tests':92,'code_test_files':len(code),
    'preserved':len(preserved),'archive_bytes':archive.stat().st_size,
    'median_reduction_percent':benchmark['median_reduction_percent']}))
