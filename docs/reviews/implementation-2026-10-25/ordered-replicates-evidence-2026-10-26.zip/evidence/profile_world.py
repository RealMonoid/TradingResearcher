"""One fixed preselected actual computation; profiling overhead is not timing evidence."""
import cProfile,hashlib,json,pstats,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[2];work=Path(__file__).parent
sys.path[:0]=[str(root),str(root/'tests')]
from study_stream_support import inputs
from trading_researcher.codec import canonical,decode,digest
from trading_researcher.study_pipeline import calculate_world
from trading_researcher.study_stream import EncodedStream
payload,manifest,world,cases=inputs()
counts={};sizes={};raw_hash=hashlib.sha256()
with (work/'profile-stream.gz').open('xb') as target:
    encoded=EncodedStream(target,encoded_limit=256*1024**2)
    def retain_line(raw):
        raw_hash.update(raw);encoded.write(raw)
    def retain(record):
        raw=(canonical(record)+'\n').encode();retain_line(raw)
    def draw(raw):retain_line(b'{"kind":"draw","value":'+raw+b'}\n')
    profiler=cProfile.Profile();start=time.monotonic();profiler.enable()
    result=calculate_world(payload,manifest,world,[decode(line) for line in cases.splitlines()],retain,
        retain_draw_bytes=draw,retain_family_draw_bytes=retain_line)
    encoding=encoded.finish();profiler.disable();seconds=time.monotonic()-start
profiler.dump_stats(work/'world.pstats')
with (work/'profile-summary.txt').open('w',encoding='utf-8') as output:
    pstats.Stats(profiler,stream=output).strip_dirs().sort_stats('cumulative').print_stats(35)
for raw in __import__('gzip').decompress((work/'profile-stream.gz').read_bytes()).splitlines():
    value=decode(raw);kind=value['kind'];counts[kind]=counts.get(kind,0)+1;sizes[kind]=sizes.get(kind,0)+len(raw)+1
value={'status':result['outcome']['state'],'result_hash':digest(result),'decoded_sha256':raw_hash.hexdigest(),
    'encoding':encoding,'profiled_seconds_not_benchmark':seconds,'records':counts,'raw_bytes_by_kind':sizes,
    'encoded_bytes':(work/'profile-stream.gz').stat().st_size}
(work/'profile-observation.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value));print((work/'profile-summary.txt').read_text())
