# Implementation Blueprint

Status: binding semantic specification with scoped implementation choices adopted in D071-D085 and the later D087 temporal invocation and D088 reporting extensions; no application code is implemented. Source-backed behavior, research-contract/1.0, temporal-diagnostic-invocation/1.0 and monitoring-visibility/1.0 govern their stated scopes. Complete the remaining run inputs and conformance prerequisites before affected operations. Do not interpret this blueprint as user authorization for live trading or material framework self-modification.

## Minimal coherent implementation shape

Use a modular application with explicit ownership of context, discovery, formalization, registry/freeze, backend execution and evidence. Keep immutable artifact bodies in content-addressed storage and an indexed transaction-capable registry for identities, events and dependency edges. D078 selects one local SQLite writer plus content-addressed external blobs for v1. The bounded runtime below implements small envelopes, immutable external files, corruption quarantine and complete backup/restore; full scientific conformance remains incomplete. A separate graph database, message broker, vector store and service mesh are not initially justified.

Use one orchestrator that routes artifacts and enforces permissions, not one that selects scientific conclusions. Roles can be sequential in an engineering smoke test. Target independent discovery perspectives must later be demonstrated with separate state and identical allowed context; a one-agent smoke test is not proof of that requirement.

## Interface contracts

Names below identify owned contracts; they are not promises about third-party APIs.

| ID | Interface / caller → owner | Request | Response and failure behavior |
|---|---|---|---|
| IF-01 | BuildContext: orchestrator → CMP-01 | Research time, data/knowledge/experience versions, scope and permission profile | Immutable snapshot and exposure closure; deny unresolved availability or unauthorized ancestry |
| IF-02 | DiscoveryTools: CMP-02 → CMP-01/CMP-07 | Bounded query or source/retrieval request with snapshot and purpose | Referenced response plus exposure event, availability, trust label and cost; no evaluator/holdout access |
| IF-03 | SubmitIdea / Formalize: CMP-02 → CMP-03 | H_idea, parent/source references and snapshot | H_exec draft with semantic-difference report, or typed gap retaining original idea |
| IF-04 | CertifyFeature / Compile: CMP-03 → CMP-04 | Feature spec or H_exec, definition/compiler versions, certified dependencies | Certificate or typed validation error; deterministic compiled representation with hash |
| IF-05 | FreezeTrial: orchestrator → CMP-04 | Complete executable artifact, assigned policy, selected allocation and exposure assessment | Durable FrozenManifest and TrialRecord atomically; same idempotency key returns same result, conflicting payload rejected |
| IF-06 | Execute: CMP-04 → CMP-05 | FrozenManifest, authorized evaluation partition, cost/fill/execution versions and seed if needed | ExecutionResult with raw case/path references, accounting checks and environment; typed unsupported/invalid/transient failure |
| IF-07 | Evaluate: CMP-05 → CMP-06 | Verified result hash and frozen EvaluationPlan | Immutable EvidenceRecord with effect/uncertainty and policy-determined outcome; invalid run cannot become empirical negative |
| IF-08 | RecordResearch / PublishKnowledge / Experience: producing roles → CMP-07; CMP-06 → CMP-08 | Search trajectories, abandonment, gaps, queue decisions, errors, policy results or qualified evidence, with event type and full ancestry | Append journal events regardless of evaluation completion; derive labeled heuristics separately; only valid qualified evidence updates market evidence; new context snapshots only for future epochs |
| IF-09 | RevokeDependency: validator → CMP-08 | Version, defect evidence and authority | Append invalidation event and affected-object set; no deletion; preserve distinction from scientific contradiction |
| IF-10 | SubmitPolicy: CMP-09 → CMP-04 | PolicySpec, rule basis/scope/parameters/conflicts, own EvaluationPlan | Separate registered policy trial or explicit gap; no inherited whole-policy support |
| IF-11 | Authorize / Observe: CMP-10 ↔ CMP-11 | Evidence/applicability/risk authority, intended-use request or eligible completed-outcome batch event | Bound-plan due/scope check, bounded decision or registered surveillance observation; D088 actionable notice with source record; missing assessment is visible; no direct generator/evidence mutation |
| IF-12 | Propose / Approve / Rollback: CMP-12 | Current/new versions, reason, impact, probes, independent validation and rollback plan | Proposal state and explicitly authorized activation event; retain failed changes and all exposure |
| IF-13 | ReadDiagnostics: reviewer → CMP-11 | Cohort, artifact, version and metric definition, or D088 weekly reporting tick | Counts, costs, gaps and evidence/operations views with denominators; timestamped pending-work/freshness projection and report; read-only projection |

## Required record fields before the first real evaluation

| Record | Minimum semantic fields | Constraint |
|---|---|---|
| Artifact envelope | artifact_id, artifact_type, schema_version, definition_refs, created_at, creator_version, content_hash, source_refs, dependency_refs | Immutable payload; unknown version is an error |
| ContextSnapshot | research_time, data_snapshot_refs, knowledge_snapshot, experience_snapshot, feature_catalog_version, permissions, exposure_refs | Snapshot closure determines permitted tools and data |
| H_idea | claim_text, question_ref, generator_version, context_ref, parents, source_refs, causal_assertions, gaps | No requirement that a new idea already fits the language |
| H_exec | idea_ref, claim_kind, estimand, scope, test_universe, condition_ast, outcome, comparator, horizons, parameter_origins, feature_refs | Each semantic choice is explicit; missing meaning prevents freeze |
| FeatureDefinition | input_refs, units, output_type, algorithm/composition, parameters, availability_rule, missingness_rule, specification_version, golden_case_refs | New primitive needs independent certification |
| EvaluationPlan | claim_ref, effect_criterion, family_policy, eligibility, dependence_design, sample/precision_plan, stopping_rule, null/control_contract, uncertainty_method, status_rules, replication_plan, code_version | Values assigned before confirmation; no universal hardcoded alpha or N_min |
| FrozenManifest | h_exec_hash, compiler_version, policy_hash, dependency_closure_hash, data_access_manifest, trial_id, frozen_at, allocation_ref, definition_refs | Atomic durable commitment before outcome access |
| ExecutionResult | request_hash, data_snapshot, case_ids, raw_output_refs, data/feature/cost/fill/execution_versions, seed/environment, checks, errors | Backend does not assign evidence status |
| EvidenceRecord | trial_ref, result_hash, evaluation_version, effect/interval/statistics, primary_outcome, origin, validity, replication_ref, limitations | D071 / research-contract/1.0 supplies separate axes; do not flatten them |
| PolicySpec | rules, basis_refs, assumptions, scope_relations, parameter_origins, conflicts, update_rules, operational_constraints, own_plan | Assumptions can create research candidates, not silent facts |

These field lists are contract requirements, not complete JSON Schemas. Concrete scalar types, enumerations, timestamp/decimal encodings and migration rules must be specified together with executable validation fixtures in Phase P1. A cosmetic schema that accepts arbitrary prose in the estimand field is not sufficient.

## Selection and assessment through existing interfaces

Apply D014/D031/D045-D049/D070 through the records above. The following mapping explains existing semantic fields; it does not add a separate ledger service, prescribe physical schemas or replace document 13 version 1.0.

| Existing boundary | Information that must remain reconstructable | Failure or qualification |
|---|---|---|
| IF-02/03/08: query, idea and Journal lineage | Candidates/alternatives, selector/version, queried data/results, chosen columns/thresholds/horizons, revisions and abandonment, linked through existing artifact IDs | A winning rule without its selection ancestry cannot support a claim of independently assessed selection. Retain the idea and the gap. |
| IF-04: feature certification and compilation | Input availability, fitted transformation state/version, fitting sample and parameters through FeatureDefinition and dependency references | A valid formula with fitting state learned from prohibited outcomes still fails the applicable availability/exposure boundary. Certification is not evidence of predictive value. |
| IF-05/07: plan, freeze and evaluation | Whether the target is a frozen candidate or a selection/adaptation procedure; permitted training/fitting and assessment inputs, family/dependence/stopping rules, and the inference supported | Reject incomplete confirmation contracts. Do not describe globally selected features followed by outer refits as a wholly independent procedure evaluation. |
| IF-08/12/13: feedback use and assessment release | Released artifact/result, recipient context/version, access timing and any subsequent selection/use, including aggregate ranks or pass/fail feedback | Used assessment feedback becomes descendant exposure even without raw-data access. Preserve the original frozen result; deny unsupported freshness claims for later work. |
| IF-06/10: execution and policy selection | Eligible population, exclusions, original execution constraints, changed rules and whether saved paths still represent the requested policy | If removing a trade frees a position slot or cash for an absent opportunity, filtering the old rows is only a subset diagnostic. Resimulate affected interactions or return an explicit capability gap. |

For example, discovery selects a distance column and cutoff on permitted historical outcomes. The selected claim retains the alternatives and fitting provenance. It can be frozen for a separate admissible candidate assessment once its open contracts are resolved. If instead the experiment assesses that selection procedure, fitting and choosing the cutoff must occur inside each permitted development portion; outer outcomes cannot influence those choices. In either case, released assessment feedback used to propose the next cutoff creates an exposed descendant. This is information provenance, not a prohibition on learning.

The [worked cases](12_TRACEABILITY_MATRIX.md#selection-and-exposure-acceptance-cases) specify both invalid and permitted uses. D070 already requires final-assessment release/access rules; D075/D081/D082 now supply the scoped policy; bind all required run-specific inputs. The examples supply no reusable-holdout guarantee; adopted batch allocation is specified in document 14 section 12.

## Expression-language requirements

The language needs typed scalar/time-series/event expressions, comparisons, AND/OR/NOT, scope and outcome definitions, lag/window semantics, units and temporal availability. It must express the five accepted relationship forms and both binary and continuous outcomes. Mechanisms are represented through measurable implications rather than a special truth-granting mechanism label.

The compiler validates syntax, types, referenced definitions, temporal eligibility, supported estimators and dependency certification. It must not reject ideas merely because they are unfamiliar. Return DATA_GAP, FEATURE_GAP, LANGUAGE_GAP, SEMANTIC_AMBIGUITY or EVALUATION_GAP as appropriate; preserve the idea, required capability and retry trigger. These exact error-code spellings are proposed API choices.

Language extensions use a versioned proposal, semantics, conformance cases, migration impact and approval where material. Never translate a new claim into a convenient old rule while retaining the same idea ID as if meaning had not changed.

## Transaction, recovery and concurrency design

Persist artifact content and verify its hash before committing the manifest reference. The registry transaction commits freeze, trial identity and data-access authorization together. If external storage cannot participate atomically, use an explicit staged/committed lifecycle and recovery procedure; an uncommitted object grants no evaluation authority.

Use compare-and-set on expected artifact/version state for transitions. A retry key identifies the same execution, not another scientific trial. Backend retries may produce multiple attempts attached to one trial; contradictory successful outputs require investigation, not selection of the better result. Crash recovery must replay safely without duplicate support records.

Exposure edges are monotonic audit facts. Revocation or rollback appends a state change; it does not erase lineage. Dependency cycles in execution closure are invalid. Genealogical relations and shared-evidence links have separate semantics from executable dependency edges.

## Worked lifecycle and failure paths

A discovery agent receives a 15-minute-or-higher snapshot and notices an expectation violation. It asks a deterministic measurement question; the query and answer become discovery exposure. It submits a free H_idea. The formalizer preserves the claim and maps its outcome/conditions to certified features. If a required measurement is unavailable, the original idea is retained as NOT_TESTABLE_YET with a capability request.

A concrete pre-freeze attack may instead lead to revision or abandonment. IF-08 records that trajectory, a retained gap or an unselected candidate without requiring an EvidenceRecord. Research Experience can derive a labeled heuristic for later retrieval; the record does not become a primary negative or supported claim. A gap's retry condition depends on a relevant capability change. Any stage's technical failure is recorded through error tracking and the journal, with the affected execution quarantined.

For an executable candidate, code checks semantics, assigns the frozen evaluation family/plan and checks evidence eligibility. The selected confirmation request is committed atomically. The backend executes the authorized partition and returns raw cases plus versions. The evidence engine verifies the manifest, applies the frozen rule and records a result. Interpretation may explain the result but cannot alter it. A future knowledge snapshot includes the qualified result and its exposure ancestry.

The valid result may be negative, inconclusive or supported; each is retained with its evidence origin and limits. Primary research uses historical data, while genuinely fresh/forward confirmation has distinct eligibility and allocation rules. The [Master Architecture](06_MASTER_ARCHITECTURE.md#freeze-and-state-transitions) explains the current intent versus the preserved prospective lifecycle. D071/D075/D082 now resolve the scoped transitions, evaluation/stopping and allocation contracts. Their required run fields and conformance must be complete before affected operations; no universal early-stop rule is inferred.

If a feature is later revoked, dependent results become unusable according to the canonical invalidation rule. Recalculation creates a new execution/evidence record using certified dependencies and the appropriate retained or new scientific contract; it must not erase the old failure. If a result inspires a narrower claim, that claim is a new descendant and inherits all relevant exposure.

## Capability probes before dependency adoption

For vectorbt, specify synthetic paths with known entries, exits, fees, slippage, no trades, multiple instruments, same-bar ambiguities and evolving state. Compare outputs with independently calculated expected results. Verify whether required path dependence, cash/leverage/contract accounting and edition capabilities are supported. Do not infer support from fast array sweeps.

For Hermes, verify permitted-tool-only operation, immutable session context, profile isolation, provenance-preserving retrieval and suppression/routing of material automatic skill or memory changes. For Harness2 patterns, demonstrate that proposer/composer cannot reach final validation data or scores through files, tools or network. All probes remain unexecuted in this task.

## Build boundaries

### Binding generator feedback and assessment extension

D069-D070 adopt [document 13](13_GENERATOR_FEEDBACK_AND_EVALUATION.md) as the semantic contract for the existing modules and interfaces. Extend IF-08's Journal/Experience records with separate feedback observations, interpretations, use records and review outcomes; IF-01/02 must include the retrieval policy/version and inherited exposure. Use the existing artifact envelope and registry, not another memory database or new service.

IF-12 carries the purpose-specific assessment plan for a candidate improvement, including the reference only when the claim is comparative, tuning/assessment separation, budget and planned result interpretation. IF-13 exposes versioned diagnostic cohorts with pending cases, formalization gaps, costs and uncertainty. Discovery diagnostics distinguish unsearched analogues from unsuccessful retrieval and do not assign scientific support. The field contracts and future TEST-28/29/30 fixtures in document 13 are required for affected implementations; concrete executable schemas remain implementation work, while D071-D085 now supply the scoped numerical and semantic policies.

An absolute-economic investigation must not fail readiness merely because no competitor generator or prior profitable result exists. It still needs the applicable claim, data, execution and evaluation contracts before a real confirmatory run. This extension is implemented in the specification only.

No application code, packages, dependencies, agent runtime, database, live API connection or deployment is created by this deliverable. The next authorized implementation task should select one phase and its explicit acceptance criteria, resolve its blocking decisions, and retain the same source-backed invariants.

## Research-contract/1.0 interface bindings

The [adopted contract](14_RETAIL_RESEARCH_CONTRACT.md) supplies normative meaning. This binding assigns its fields to existing owners; these tables are not executable schemas or a claim that the runtime exists.

| Interface / records | Required extension and invariant |
|---|---|
| IF-01 / ContextSnapshot | Exact source checksums, retrieval/availability times and uncertainty, timestamp units, development/assessment roles, model exposure and transitive ancestry; same allowed snapshot for both perspectives |
| IF-02/03 / HypothesisProposal | Prompt/model versions, bounded tool capability, calls/tokens/time/cost, retained original idea, selection reason and semantic-difference report; no evaluator or peer scratch access |
| IF-04/09 / ExecutableHypothesis, CertificationRecord | Typed AST, five relationship forms, explicit estimand, units/time/missingness, exact primitive specs, independent validator/fixtures and approved-envelope classification; unknown membership is a gap |
| IF-05 / EvaluationPlan | Contract/profile versions; theta/direction/delta; frozen m and 0.05/m marginal noncoverage; dependence/overlap and exact block lengths; 19,999 draws, quantile/PRNG/version/seed; N_min justification and fixed cutoff; origin/limits; selection/reservation/release and separate resource stops |
| IF-05/06 / FrozenManifest, TrialRecord, ExecutionResult | Atomic immutable closure and allocation, canonical-json/1 bytes/hash, idempotency identity, same-trial retries; actual data/cost/fill versions and next-bar/shared-cash conventions; failed or contradictory results retained/quarantined |
| IF-07 / EvidenceRecord | Separate stage, validity, primary outcome, origin/null reason, historical qualification, replication trial, usability, timestamped applicability and action authority; raw references and enclosing interval with assumptions; no scientific verdict on invalid attempts |
| IF-08 / KnowledgeEntry, ExperienceEntry | Whole-batch release provenance, descendants' inherited exposure, original outcome retained on dependency invalidation, explicit descriptive cohort denominators and pending follow-up |
| IF-10 / PolicySpec | Direct target evidence or UNTESTED_ASSUMPTION per rule; no automatic subset transport; independent policy plan, frozen net-value hurdle/risk scenarios, actual cost basis or explicit break-even scenarios |
| IF-11 / operational view | Research-only and zero authorized capital; D087 plan reference, eligible-batch event, frozen checkpoint, data cutoff/version, attempt identity, due/freshness result and visible gap; cost/fill incidents trigger review, never rewrite scientific outcomes |
| IF-12/13 / ImprovementProposal, diagnostics | Purpose-specific gate, development/final separation, exact calibration bounds, paired acceleration plan when claimed, complete costs/failures, two-no-improvement stopping and D084 change classification |

Target research persistence uses one SQLite writer with checked foreign keys and FULL synchronization. Small envelopes/events/edges/freezes commit together; external blobs are staged/flushed/hash-verified before reference commitment. Recovery quarantines missing/corrupt committed blobs. Backups include a verified blob manifest and restored projections. Migration keeps old bytes/hashes and versioned mappings. The runtime now implements those storage primitives for owned source files and reference code packages, with backed-up migrations and process-exit tests. Complete scientific records, scientific migration semantics and automatic orphan reclamation remain separate work.

Implementation should proceed through typed schema/fixtures and registry, controlled adapter slice, candidate evaluator conformance/calibration, and then an authorized evidence run with actual inputs. Future schemas must make every field above machine-checkable; free text may explain a gap but cannot substitute for frozen executable meaning.

## Agent inquiry integration

D086 / [agent-inquiry/1.0](15_AGENT_INQUIRY_DISCIPLINE.md) elaborates REQ-014 through existing interfaces. IF-02's purpose identifies the investigation object and uncertainty, with possible implications of targeted findings or an honest open-exploration purpose. IF-03's semantic-difference report preserves the original question through formalization. IF-08 retains concise purpose, sourced finding, warranted conclusion, remaining uncertainty and next action with reason at completed investigations, handoffs and continuation decisions. Reference existing context/exposure and budget records; reuse an adequate existing artifact rather than duplicate it.

The challenger can report no substantiated objection; discovery need not invent a hypothesis to justify exploration. Existing access, allocation, freeze and evidence controls remain authoritative. These are semantic requirements for future implementations, not new fixed JSON field names, lifecycle states or a per-call approval gate. The [TEST-14 examples](15_AGENT_INQUIRY_DISCIPLINE.md#acceptance-examples-for-test-14) remain unexecuted behavioral specifications. Material prompt configurations remain versioned under D026.

## Temporal diagnostic invocation integration

D087 / [temporal-diagnostic-invocation/1.0](16_TEMPORAL_DIAGNOSTIC_INVOCATION.md) uses existing CMP-01, CMP-06/07/08 and CMP-10/11 with IF-11. The existing orchestrator routes CMP-01's committed-batch event to the IF-11 due check; no additional service is implied. CMP-01 commits a versioned batch only after the declared outcome horizon and required availability conditions are satisfied. Its event checks the bound plan's next frozen checkpoint; a quantitative run occurs only when its approved method and information requirement are ready. Intended use independently invokes a scope/freshness check. Duplicate delivery is idempotent, while corrected data append a linked reassessment rather than independent evidence. Missing plan, data or capability is visible as NOT_ASSESSED/REVIEW_REQUIRED. These are future TEST-17/25 cases, not an implemented scheduler or a new scientific estimator.

## Monitoring visibility and reporting integration

D088 / [monitoring-visibility/1.0](17_MONITORING_VISIBILITY_AND_REPORTING.md) adds a wall-clock reporting tick to the same orchestrator and persistent work records. The tick reads IF-13's versioned diagnostic/pending-work projection, checks plan-defined data freshness and delivery state, and emits one weekly report; it does not call CMP-06 for an extra quantitative look. Newly actionable records from IF-11 or a bounded CMP-12 method-comparison job produce one prompt notice, keyed by object, plan and event revision. Failed delivery is retained and retried under that identity. The report renderer may be an LLM but receives only allowed record references and cannot write evidence, approve a method or authorize action. These remain future full TEST-17/22/25 cases. Generic time/event triggers now exist; the reporting workflow, channel and LLM renderer remain unimplemented.

## Implemented local coordination slice

The October 25 [research memory extension](../../trading_researcher/MEMORY.md) implements bounded IF-01/02/08 behavior on the same controller: typed inquiry records, four query surfaces, role-scoped writes, immutable base contexts with private attempt ancestry, permission-first retrieval, observed host terminal events, and recoverable projections. Market Model scientific publication is unavailable until the independent evaluator exists. This is an additive storage/interface implementation, not a new scientific schema or evidence rule. The current [execution plan](../reviews/integration-research-2026-10-24/IMPLEMENTATION_SEQUENCE_2026-10-25.md) retains the remaining integration requirements.

The [provider-neutral loop](../../trading_researcher/RESEARCHER.md) implements a bounded CMP-02 continuation: two sequential private perspectives, immutable public call/tool transcripts, frozen provider configuration, durable shared reservations, and host-controlled stop/retry behavior. Deterministic fixtures and real RPC exercise the interface. A live provider adapter, measurement tools, semantic certification and scientific completion remain separate requirements; operational record acceptance grants no empirical authority.

The [reference expression slice](../../trading_researcher/EXPRESSIONS.md) implements a bounded subset of the D074 type/time/missingness rules, with independent fixed arithmetic and temporal fixtures. It retains explicit gaps for unsupported semantics and grants no scientific certification or data-access authority. Complete H_exec/plan validation, feature certification, forward-outcome materialization, atomic scientific freeze/allocation and calibrated estimator integration remain required.

The [formalization draft implementation](../../trading_researcher/FORMALIZATION.md) adds IF-03 retention and bounded IF-04 structural checks: separate original idea/candidate, exact-text mapping provenance, explicit unit/time/parameter closure, gaps, role-scoped writes and completion recalculation. Creation/ancestry availability is enforced at context admission. An accepted `formalization/v1` job confirms retention and structure only; neither semantic equivalence nor scientific readiness follows. Oversized retained envelopes return an explicit resource gap without partial commitment.

The [reference outcome implementation](../../trading_researcher/OUTCOMES.md) adds a pure calculation slice for IF-06: exact future anchors, original decision cutoffs, expected-grid exclusions, maturity metadata and an exact descriptive canonical contrast. Independently fixed cases cover temporal and missingness boundaries. Ambiguous dependency membership remains a review gap; the interface neither grants data access nor publishes an EligibleOutcomeBatchCommitted event or scientific evidence. Bound input manifests, certification, uncertainty and scientific evaluation remain separate pending work.

The [implementation certification gate](../../trading_researcher/CERTIFICATION.md) adds the reference-computation portion of IF-04: fixed specification/expectation pins, fresh isolated-child checks, complete executed local dependency fingerprints, parent-side snapshot checks, host-issued immutable records and stale-version detection. It retains exact source packages in [external storage](../../trading_researcher/STORAGE.md), supports replay without workspace reads, and records interrupted attempts durably. Child validation runs outside the write transaction; package publication and final hashing/record commitment hold the lock. Complete backups preserve these packages, but Python distributions are only fingerprinted. This does not certify Broker authentication or old imported code. Per-feature availability/dependency certification, faithful semantic mapping, bound scientific execution and freeze/allocation remain pending.

The [data snapshot boundary](../../trading_researcher/DATA.md) adds the binding portion of IF-01: exact retained row/catalog/raw-source identities, immutable acquisition assertions, ordered grid and scalar checks, explicit missingness coverage and inherited source restrictions. The trusted host loader verifies the complete snapshot before returning an exact bounded window. Only structural acceptance is implemented here; provider-checksum authenticity, normalization fidelity, historical availability evidence, feature certification and scientific execution/allocation permissions require their own checks. A manifest or a supplied integer availability time cannot satisfy those gates by declaration.

The [public archive adapter](../../trading_researcher/BINANCE.md) adds acquisition-time byte/checksum verification and independently exercised complete-bar normalization for the adopted Binance profile. It retains failed files and qualified receipts, handles the declared 2025 timestamp-unit transition and keeps symbol-specific quantity units. Availability delays are explicit simulation scenarios. A separate keyed quality audit now preserves invalid present bars as unavailable values and distinguishes them from absent observations. Owned retention binds original files, failure receipts and complete row audits; a verified real registry backup/restore preserves them. Legacy failed receipts do not gain a file/time binding from present inspection. Partition-bound normalization, scientific missingness policy, data/feature certification and scientific freeze remain separate requirements; these source records do not grant those capabilities.

The later [partition normalizer](../../trading_researcher/BINANCE_NORMALIZATION.md) now supplies that data-organization step in a fresh bound Python source snapshot. It chooses exactly the required source months, preserves decision-time boundaries and invalid/absent distinctions, and reuses the full acquisition/document receipt validators before registering structural data snapshots. It retains explicit availability assumptions and inherited exposure. This execution binding does not certify feature meaning, historical PIT truth, scientific missingness, label-boundary eligibility or scientific freeze.

`SESSION-2026-10-24-LOCAL-COORDINATION` records the user's explicit implementation approval. [The runtime guide](../../trading_researcher/README.md) specifies the runnable commands, public API, operational schema and trust boundary. One local controller owns the queue, authenticated identities, immutable contexts/artifacts, leases with attempt fencing, bounded retries, blocked reasons, trusted completion checks and atomic operational batch release. Reference workers execute synthetic arithmetic or exact source copying. Small artifacts are content-addressed SQLite envelopes; generic triggers persist occurrence identities and bounded schedules.

These capabilities support parts of CMP-01/02/07 and IF-01/02/08 but do not replace their complete scientific contracts. A `completed` job means its declared operational check passed; it does not mean a hypothesis succeeded or an EvidenceRecord was issued. Identity authentication, ownership of the current attempt and scientific authority remain separate. Worker reads and writes require the frozen capability; direct messages cannot confer additional data or write authority. No unrestricted model filesystem tool is exposed by this slice.

The [raw measurement certification gate](../../trading_researcher/FEATURES.md) adds the existing Binance primitive portion of IF-04: versioned symbol-specific definitions, explicit scenario and missingness semantics, pinned independent expectations, exact source replay, protected host issuance and snapshot-bound currency checks. Historical PIT, arbitrary composition/dependency certification, semantic equivalence, calibrated scientific execution and freeze remain separate.

The original [verification record](../reviews/LOCAL_COORDINATION_VERIFICATION_2026-10-24.json) covers local tests, real HTTP execution, abrupt-process recovery and restored backups; [implementation progress](../reviews/implementation-2026-10-25/progress.json) records later memory, calculator, certificate and external-storage checks. Scientific freeze/allocation, semantic certification, scientific memory publication, live provider adapters, temporal diagnostics and user delivery remain future work. D087's event must still be produced from an eligible completed-outcome batch, never inferred from a generic timer or a new price bar.

The [bound reference computation gate](../../trading_researcher/BINDING.md) binds exact completed formalizations and data/feature/calculator identities, retains the separate driver, and executes only development data through owned processes. Case consistency is checked before result commitment. Protected assessment, semantic approval, scientific allocation/freeze and calibrated inference remain separate pending gates.

The [historical evaluation policy and owned preparation path](../../trading_researcher/EVALUATION_POLICY.md) implement exact approved classification/interval arithmetic and retained policy drafts. The host binds completed compiled hypotheses, intact development diagnostics and captured calculation sources; fresh processes calculate and verify the draft before atomic retention. Family count remains provisional, N_min remains pending, and no scientific allocation, assessment permission or freeze is granted. The independent allocation-state fixtures remain future behavioral tests.
