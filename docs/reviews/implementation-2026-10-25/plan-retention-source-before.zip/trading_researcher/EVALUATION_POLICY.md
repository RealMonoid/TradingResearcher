# Historical evaluation policy and owned plan preparation

This continuation implements exact arithmetic for the approved `historical-batch-v1` rules and an operator-owned plan-preparation path. It is a prerequisite for scientific evaluation and freeze, not their completion. The [retail contract](../docs/architecture/14_RETAIL_RESEARCH_CONTRACT.md) sections 5 and 12 remain the authority.

## Executable policy arithmetic

The pure [policy module](evaluation_policy.py) implements:

- One through eight primary claims, family noncoverage 0.05, marginal noncoverage `0.05 / m` and two-sided intervals. The policy needs valid marginal coverage; it assumes no independence between claims and establishes no coverage by itself.
- Directional support when the oriented lower bound exceeds the assigned positive delta, negative when the upper bound is below delta, and inconclusive at equality or other overlap. Negative-direction claims reverse and negate both interval bounds.
- Nondirectional support when the interval is strictly outside `[-delta, delta]`, negative when it is contained in that explicitly closed region, and otherwise inconclusive. Endpoint inclusion follows that separate closed-set rule; it does not replace the directional equality rule.
- The five-percentage-point probability target and the ten-basis-point simple 24-hour return target. The latter requires the actual `(close / lag(close, 96)) - 1` expression on the 900-second grid, the same certified symbol-specific raw close and its price unit. A volume ratio, price level, different horizon or generator-supplied delta does not acquire this profile. Other meanings remain gaps without rewriting the original idea.
- Deduplicated half/base/double block lengths, upward rounding and the outcome-overlap lower bound. Every required sensitivity needs 19,999 attempted and defined draws. Undefined draws, discarded-and-replaced draws and missing sensitivities cannot be hidden.
- Exact linear quantiles at `(B - 1) * p`, basic-interval reflection and the enclosing interval across the prespecified sensitivities. Arithmetic growth beyond the 8,192-bit rational envelope raises a typed resource failure. No floating-point approximation silently changes a boundary decision.
- Fixed whole-batch release prerequisites, a technical-status-only termination path, and inconclusive classification for an already established Monte Carlo instability diagnostic. These functions do not implement the diagnostic or grant registry release permissions.

The caller of a pure function must supply an admitted, appropriately calibrated interval or authenticated feature/compiler description where required. A calculated status label is not an EvidenceRecord. Actual joint stationary-block sampling, dependence diagnostics, numerical calibration and N_min derivation are still absent. The small replicate arrays in arithmetic fixtures do not replace the mandatory assessment resample count.

## Owned preparation operation

The operator RPC is:

```text
prepare_evaluation_plan(key, compiled_id, primary_count, dependence)
```

Use the existing `rpc` CLI request-file interface against the owned server. `dependence` requires an integer `base_length`, a rationale, one through sixteen `development_refs`, and `randomness` with explicit `algorithm`, `version` and integer `seed`. No default seed, dependence justification or nuisance estimate is invented. The generator cannot override delta through this operation.

The host accepts an owned compiled development hypothesis and its compatible retained calculation/data/feature dependencies. Development references must be genuine owned descriptive executions on the same snapshot. Their committed case blobs must exist and match both hash and size. Supplied sources, protected data and worker requests are denied before the affected dependent reads. The request is canonically copied before admission; later caller mutation cannot change the calculated plan or its idempotency identity.

The calculation runs in fresh isolated Python against a retained application source capsule. A separate fresh process repeats the same calculation and verifies its complete result hash. The parent verifies request/source/runtime identities and rechecks dependencies, diagnostic bytes and source version before commitment. This avoids treating import-time disk hashes as proof of which previously loaded dependency function ran. The source capsule is bounded to 128 application files and 16 MiB. Python and loaded standard-library files are fingerprinted rather than archived. This is source binding and transport verification, not independent semantic or statistical certification.

Preparation retains the exact request, source blobs, runtime evidence, policy draft or typed evaluation gap, and inherited exposure. The same key and request returns the same immutable artifact; conflicting reuse is rejected. Source staging alone grants no artifact reference. A failed commit leaves no visible plan or key reservation; interrupted attempts remain in the existing bound-computation history. Each owned child uses the existing time, output, cancellation and reaping limits. Parent admission, copying and final integrity checks are outside the child timeout.

Exact request and source-capsule retention currently applies to completed drafts and typed gaps. Interrupted attempts retain their kind, compiled identity, timestamps and status, but not the complete failed request or its source capsule. Complete failed-request replay remains unfinished.

`evaluation-plan/1` is a protected namespace. A successful preparation record has `POLICY_DRAFT`, `frozen: false`, `allocation_reserved: false` and `scientific_readiness: false`. Its family count is provisional and must be recomputed from actual frozen batch membership. Its N_min remains null with a calibrated-information-target requirement; planned power and the zero/delta/2*delta sensitivities follow the adopted contract. Merely supplying a PRNG name or development rationale does not validate that method or its assumptions.

No assessment access, budget reservation, scientific result release, semantic approval or empirical claim follows from this draft. Genuine independent review must assess the exact original idea, executable candidate and mappings; replaying a formalizer's self-declared equivalence in another process cannot supply that judgment.

## Evidence and unfinished requirements

The independent [91-case fixture](../tests/fixtures/reference_evaluation_policy_cases.json) and [authorship note](../tests/fixtures/reference_evaluation_policy_expectations.md) were fixed before the implementation was inspected. The policy suite exercises 81 cases. The ten allocation-state cases remain explicitly pending for the future campaign/freeze state machine; they are not counted as verified behavior. Additional adversarial tests cover arithmetic growth, units, false Boolean/count coercion, undefined draws, input mutation, unavailable diagnostic blobs, stale imports and transaction failures.

The [source baseline archive](../docs/reviews/implementation-2026-10-25/evaluation-policy-source-baseline.zip) preserves the three exact source documents pinned by the fixture, including the blueprint before its descriptive implementation update. Archive member hashes must match the fixture's source hashes; later documentation does not replace those source versions.

[Current verification](../docs/reviews/implementation-2026-10-25/evaluation-policy-verification.json) records exact commands, source hashes, independent review and remaining limits. Owned-registry tests use synthetic hypotheses and data. They do not establish historical PIT, scientific acquisition/rights acceptance, actual independent model review, full composition certification, calibrated inference, atomic scientific allocation/freeze, real LLM discovery or market usefulness. The trusted host account and installed controller remain outside the isolation boundary.
