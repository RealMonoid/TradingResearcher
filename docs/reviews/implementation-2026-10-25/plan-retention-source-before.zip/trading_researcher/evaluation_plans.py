"""Owned pre-assessment plan drafts; scientific admission and freeze remain separate."""
import hashlib
from pathlib import Path
import sys
import tempfile

from .codec import Invalid, canonical, decode, digest, integer, strings, text
from .errors import Conflict, Denied
from .evaluation_policy import draft_plan
from .binding import environment, write_file, require
from .certification import _environment_current
from .binance_normalize import _run_child
from .storage import _hash_file


ROOT=Path(__file__).resolve().parents[1]
SCHEMA='evaluation-plan/1'


def source_bundle():
    bundle={path.relative_to(ROOT).as_posix():path.read_bytes() for path in sorted((ROOT/'trading_researcher').glob('*.py'))}
    if len(bundle)>128 or sum(map(len,bundle.values()))>16*1024*1024:
        raise Invalid('Plan source capsule exceeds the resource envelope')
    return bundle


def footprint(bundle):
    return {name:hashlib.sha256(raw).hexdigest() for name,raw in bundle.items()}


LOADED_SOURCE=footprint(source_bundle())


BOOTSTRAP=('import sys;sys.path.insert(0,sys.argv[1]);'
    'from trading_researcher.evaluation_plans import child_entry;child_entry(sys.argv[2])')


def child_entry(request_path):
    request=decode(Path(request_path).read_bytes())
    expected=request['footprint']
    require(footprint(source_bundle())==expected,'Retained plan source differs')
    environment(expected)
    try:
        result={'plan':draft_plan(**request['payload']),'gap':None}
    except Invalid as exc:
        result={'plan':None,'gap':{'code':'EVALUATION_GAP','reason':str(exc),
            'reopen_condition':'Supply compatible approved meaning and required development design without changing the original claim'}}
    if request['verify_hash'] is not None:
        require(digest(result)==request['verify_hash'],'Plan response differs from exact retained replay')
        result={'verified_result_hash':digest(result)}
    require(footprint(source_bundle())==expected,'Plan source changed during computation')
    print(canonical({'result':result,'request_hash':digest(request),'footprint':expected,
        'environment':environment(expected)}),flush=True)


def run_plan_child(bundle,payload,verify_hash=None):
    expected=footprint(bundle)
    request={'payload':payload,'footprint':expected,'verify_hash':verify_hash}
    with tempfile.TemporaryDirectory(prefix='trf-plan-') as temporary:
        directory=Path(temporary)
        for name,raw in bundle.items():
            path=directory/name
            path.parent.mkdir(parents=True,exist_ok=True)
            write_file(path,raw)
        write_file(directory/'request.json',canonical(request).encode())
        report=_run_child([sys.executable,'-I','-S','-B','-c',BOOTSTRAP,str(directory),str(directory/'request.json')],directory)
        require(type(report) is dict and set(report)=={'result','request_hash','footprint','environment'},'Malformed plan response')
        require(report['request_hash']==digest(request) and report['footprint']==expected
            and _environment_current(report['environment']),'Plan response identity/environment mismatch')
        require(footprint({name:(directory/name).read_bytes() for name in bundle})==expected,'Plan package changed')
        return report


class EvaluationPlans:
    def _existing_evaluation_plan(self,request):
        for row in self._db.execute('SELECT id,envelope FROM artifacts'):
            envelope=decode(row['envelope'])
            body=envelope.get('body')
            if (envelope['creator']==envelope['origin']=='controller' and type(body) is dict
                    and body.get('schema')==SCHEMA and body['request']['key']==request['key']):
                if digest(body['request'])!=digest(request):raise Conflict('Plan key already binds a different request')
                return self._artifact(row['id'])
        return None

    def _plan_inputs(self,actor,request):
        compiled=self._artifact(request['compiled_id'])
        body=compiled['body']
        if (compiled['creator']!=compiled['origin'] or compiled['creator']!='controller'
                or type(body) is not dict or body.get('schema')!='compiled-hypothesis/1'
                or body.get('status')!='COMPILED'):
            raise Denied('Plan preparation requires an owned compiled hypothesis')
        snapshot=self._data_snapshot(body['data_snapshot_id'])
        if snapshot['data_class']!='development' or snapshot['body']['manifest']['partition']!='development':
            raise Denied('This preparation route accepts development bindings only')
        references=strings(request['dependence'].get('development_refs'),'development diagnostic references')
        if not 1<=len(references)<=16:raise Invalid('One through sixteen retained development diagnostics required')
        diagnostics=[]
        for identity in references:
            artifact=self._artifact(identity)
            value=artifact['body']
            if (artifact['creator']!=artifact['origin'] or artifact['creator']!='controller'
                    or artifact['data_class']!='development' or type(value) is not dict
                    or value.get('schema')!='reference-execution/1' or value.get('status')!='DESCRIPTIVE_EXECUTION'
                    or value.get('data_snapshot_id')!=snapshot['id']):
                raise Denied('Dependence references must be owned computations on this development snapshot')
            descriptor=value['result']['case_blob']
            require(artifact['blob_refs']==[descriptor['sha256']],'Diagnostic blob binding differs')
            try:
                actual,size,_=_hash_file(self._blob_path(descriptor['sha256']))
            except (OSError,Invalid) as exc:
                raise Conflict('Retained diagnostic cases unavailable') from exc
            require(actual==descriptor['sha256'] and type(descriptor['size']) is int and size==descriptor['size'],
                'Retained diagnostic cases differ from the committed result')
            diagnostics.append(artifact)
        args=body['dependency_arguments']
        dependencies=self._bound_dependencies(actor,*(args[name] for name in ('formalization_id','feature_certificate_id','reference_certificate_id')))
        definitions=self._artifact(dependencies['feature_certificate']['body']['definitions_id'])['body']['definitions']
        payload={'candidate':dependencies['formalization']['body']['candidate'],'definitions':definitions,
            'outcome_description':body['compilation']['programs']['outcome_program'],
            'primary_count':request['primary_count'],'dependence':request['dependence']}
        refs=sorted(set([compiled['id'],*references,*dependencies['refs']]))
        exposure=set(refs)|set(compiled['exposure'])|set(dependencies['exposure'])
        for artifact in diagnostics:exposure.update(artifact['exposure'])
        return payload,refs,sorted(exposure)

    def _prepare_evaluation_plan_external(self,token,args):
        with self._mutex:
            actor=self._binding_owner(token)
            require(set(args)=={'key','compiled_id','primary_count','dependence'},'Missing or unexpected plan request fields')
            request=decode(canonical(args))
            text(request['key'],'plan request key')
            text(request['compiled_id'],'compiled identity')
            integer(request['primary_count'],'primary count',1)
            require(request['primary_count']<=8 and type(request['dependence']) is dict,
                'A bounded family and explicit dependence design are required')
            existing=self._existing_evaluation_plan(request)
            if existing is not None:return existing
            payload,refs,exposure=self._plan_inputs(actor,request)
            source=source_bundle()
            if footprint(source)!=LOADED_SOURCE:
                raise Conflict('Plan source changed since process import; restart with the intended source version')
        attempt=self._bound_start('evaluation_plan',request['compiled_id'])
        try:
            calculated=run_plan_child(source,payload)
            result=calculated['result']
            require(type(result) is dict and set(result)=={'plan','gap'},'Malformed plan calculation')
            verified=run_plan_child(source,payload,verify_hash=digest(result))
            require(verified['result']=={'verified_result_hash':digest(result)},'Malformed plan verification')
            if result['plan'] is not None:
                require(result['gap'] is None and result['plan']['scientific_readiness'] is False,
                    'Plan preparation cannot issue scientific readiness')
            else:
                require(type(result['gap']) is dict and result['gap']['code']=='EVALUATION_GAP','Missing plan gap')
            source_files={name:self._stage_blob_bytes(raw) for name,raw in source.items()}
            with self._transaction():
                actor=self._binding_owner(token)
                existing=self._existing_evaluation_plan(request)
                if existing is not None:
                    self._event('controller','bound_computation_checked',attempt_id=attempt,artifact_id=existing['id'],status='REUSED')
                    return existing
                current=self._plan_inputs(actor,request)
                require(digest(list(current))==digest([payload,refs,exposure]),'Plan dependencies changed before commitment')
                if footprint(source_bundle())!=LOADED_SOURCE:
                    raise Conflict('Plan source changed before commitment')
                require(_environment_current(calculated['environment']) and _environment_current(verified['environment']),
                    'Plan runtime changed before commitment')
                for descriptor in source_files.values():self._register_blob(descriptor)
                saved=self._save_artifact({'version':'local-artifact/1','creator':'controller','origin':'controller',
                    'data_class':'development','source_refs':refs,'exposure':exposure,
                    'blob_refs':sorted({descriptor['sha256'] for descriptor in source_files.values()}),
                    'authority':'plan_preparation_not_scientific_admission',
                    'body':{'schema':SCHEMA,'created_at':self._now(),'request':request,
                        'status':'POLICY_DRAFT' if result['gap'] is None else 'EVALUATION_GAP',
                        'plan':result['plan'],'gap':result['gap'],'attempt_id':attempt,
                        'source_files':source_files,'source_footprint':footprint(source),
                        'calculation_environment':calculated['environment'],'verification':verified,
                        'family_count_authority':'declared_preparation_only_recompute_from_frozen_batch',
                        'scientific_readiness':False,'allocation_reserved':False,'frozen':False,
                        'qualification':'Preparation retains assigned pilot policy and pending gates; no protected execution or result publication permission.'}})
                self._event('controller','evaluation_plan_prepared',artifact_id=saved['id'],request_key=request['key'],status=saved['body']['status'])
                self._event('controller','bound_computation_checked',attempt_id=attempt,artifact_id=saved['id'],status=saved['body']['status'])
                canonical(saved)
                return saved
        except BaseException:
            with self._transaction():
                self._event('controller','bound_computation_interrupted',attempt_id=attempt,reason='plan_preparation_failed_or_cancelled')
            raise
