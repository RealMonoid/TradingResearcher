"""Owned HTTP generation and actual estimator integration; not a power study."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
import threading
import time

ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from trading_researcher.codec import canonical,decode,digest
from trading_researcher.coordination import Broker
from trading_researcher.population_models import specification
from trading_researcher.server import Client,LocalServer
from trading_researcher.stationary_bootstrap import calculate,randomness

def hashes():
    return {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(ROOT.glob('trading_researcher/*.py'))}

prior=json.loads((ROOT/'.trf-runtime/nuisance-diagnostics-checks-2026-10-25/real-probe-result.json').read_text())
request={'key':'population-http-probe-20261025-02',
    **{key:prior[key] for key in ('plan_id','execution_id','diagnostics_id')},
    'specification':specification(4,Fraction(1,2),Fraction(1,2),
        'Fixed engineering stress: exact stationary joint masks and persistent homogeneous binary responses. Not fitted or validated against market dynamics.'),
    'scenario':2,'time_rows':128,'seed':2026102501,'limits':{'max_seconds':120}}
profile={'request':request,'bootstrap_seed':2026102502,'bootstrap_limits':{'max_seconds':120,'max_segments':100000000},
    'mc_noncoverage':{'numerator':'1','denominator':'100'},'source_hashes':hashes(),
    'purpose':'One fixed HTTP/estimator integration and cost probe. No target search, power estimate or calibration.'}
with (WORK/'current-world-profile.json').open('x',encoding='utf-8') as stream:json.dump(profile,stream,indent=2)
broker=Broker(prior['registry']);server=None;thread=None;start=time.monotonic()
record={'status':'INCOMPLETE','profile_sha256':hashlib.sha256((WORK/'current-world-profile.json').read_bytes()).hexdigest()}
try:
    server=LocalServer(broker);thread=threading.Thread(target=server.serve_forever);thread.start()
    client=Client(server.url,broker.admin_token,timeout=180)
    saved=client.call('run_population_world',**request)
    assert saved['body']['status']=='GENERATED_UNCALIBRATED'
    assert client.call('run_population_world',**request)==saved
    body=saved['body'];capsule=client.call('get_artifact',artifact_id=body['input_capsule_id'])
    assert capsule['body']['request']==request
    raw=broker._read_blob_bytes(body['world_blob']['sha256'])
    report={**body['result']['world']['report'],'cases':[decode(line) for line in raw.splitlines()]}
    assert len(report['cases'])==128 and report['simulation']['raw_AST_executed'] is False
    generation_seconds=time.monotonic()-start
    plan=client.call('get_artifact',artifact_id=request['plan_id'])['body']
    criterion=plan['plan']['effect_criterion']
    design={'base_length':plan['request']['dependence']['base_length'],
        'primary_count':plan['request']['primary_count'],'randomness':randomness(profile['bootstrap_seed']),
        'mc_policy':{'schema':'mc-boundary-policy/1','noncoverage':profile['mc_noncoverage'],
            'delta':criterion['delta'],'direction':criterion['direction']}}
    checksum=hashlib.sha256();draws=0;started=time.monotonic()
    with (WORK/'current-draws.jsonl').open('xb') as stream:
        def retain(draw):
            global draws
            data=(canonical(draw)+'\n').encode();stream.write(data);checksum.update(data);draws+=1
        bootstrap=calculate(report,design,profile['bootstrap_limits'],on_draw=retain)
    elapsed=time.monotonic()-started
    assert draws==19999*len(bootstrap['required_lengths'])
    assert bootstrap['status'] in ('COMPUTED_UNCALIBRATED','INFORMATION_GAP')
    assert not bootstrap['scientific_readiness'] and not bootstrap['classification_permitted']
    with (WORK/'current-bootstrap.json').open('x',encoding='utf-8') as stream:json.dump(bootstrap,stream,indent=2)
    assert hashes()==profile['source_hashes']
    record.update(status='PASS_WITH_EXPLICIT_MODEL_AND_CALIBRATION_LIMITS',exit_code=0,
        world_artifact_id=saved['id'],input_capsule_id=capsule['id'],world_blob=body['world_blob'],
        generation_and_replay_seconds=round(generation_seconds,3),bootstrap_seconds=round(elapsed,3),
        bootstrap_status=bootstrap['status'],bootstrap_draws=draws,bootstrap_draw_sha256=checksum.hexdigest(),
        monte_carlo_status=bootstrap['monte_carlo']['status'],source_hashes=hashes(),
        model_status=body['result']['model']['status'],time_rows=128,
        population=body['result']['model']['population'],truth=body['result']['world']['truth'],
        n_min=None,scientific_readiness=False,qualification=profile['purpose'])
finally:
    if server:server.shutdown();server.server_close()
    if thread:thread.join(5)
    broker.close()
    with (WORK/'current-world-result.json').open('x',encoding='utf-8') as stream:json.dump(record,stream,indent=2)
print(json.dumps({k:v for k,v in record.items() if k!='source_hashes'},indent=2))
