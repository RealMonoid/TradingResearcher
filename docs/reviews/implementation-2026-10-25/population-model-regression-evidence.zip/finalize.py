"""Close population-world verification only after the existing suite finishes."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).resolve().parent
AUDIT=ROOT/'docs/reviews/implementation-2026-10-25'
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')

tests=read(WORK/'tests-result.json')
assert tests['exit_code']==0 and tests['sources_stable']
assert tests['source_hashes_before']==tests['source_hashes_after']
assert sha(WORK/'tests.log')==tests['log_sha256']
for name,value in tests['source_hashes_after'].items():assert sha(ROOT/name)==value,name
count,seconds=tests['unittest_summary'];count=int(count)
assert count>=405,(count,seconds)
probe=read(WORK/'current-world-result.json')
assert probe['exit_code']==0 and probe['bootstrap_draws']==59997
assert all(sha(ROOT/name)==value for name,value in probe['source_hashes'].items())
assert sha(AUDIT/'population-model-review.json')=='f1aa7677a1fb2513cf9d9afe67a5b1627811761a2669d4a27d71f29defde6333'
baseline=read(WORK/'baseline.json')
output=AUDIT/'population-model-verification.json'
assert not output.exists(),'Final report already exists; use its read-only audit instead'

progress=read(AUDIT/'progress.json')
progress['controls']['evidence-gate']={'status':'SATISFIED','evidence':
    f'{count} current-source tests PASS in {seconds}s, exit0; before/after source hashes unchanged. '
    'Independent fixed fixtures/review and current authenticated HTTP plus 59997-draw bootstrap/MC probe passed. '
    'Population model adequacy, complete power/N_min, calibration and scientific admission remain incomplete.'}
step=next(item for item in progress['packages'] if item['step']==4)
step['remaining_action']=('Owned binary population stress worlds are implemented and verified. Build the complete '
    'immutable finite target/scenario/world/seed study with actual fixed-count bootstrap/MC, resumable aggregate '
    'compute/storage accounting and every failure retained. Assess model adequacy and keep final calibration fresh. '
    'Return-process, coherent joint-family worlds and scientific admission remain separate gaps.')
step['evidence'].append('docs/reviews/implementation-2026-10-25/population-model-verification.json')
step['evidence'].append('docs/reviews/implementation-2026-10-25/INFORMATION_STUDY_IMPLEMENTATION.md')
progress['next_action']=step['remaining_action']+' Preserve all seven packages, including genuine LLM invention and the later AmiBroker/reporting integrations.'
progress['continuation_audit']={'previous_goal_turn':'verified_wait','current_goal_turn':'progress',
    'basis':'Polled the original live regression session without restart; inspected its terminal result and source hashes, '
        'then closed the population-world checkpoint. Complete information-study design is the next dependency.',
    'blocking_threshold_met':False,'full_objective_complete':False}
dump(AUDIT/'progress.json',progress)
summary=AUDIT/'IMPLEMENTATION_SUMMARY_2026-10-25.md'
content=summary.read_text(encoding='utf-8')
old='The complete current-source regression is running; no completion claim is made for it yet.'
assert old in content
content=content.replace(old,f'The complete current-source regression passed **{count} tests in {seconds} seconds, exit 0**, '
    'with unchanged before/after source hashes. [Final verification](population-model-verification.json) records the exact checks and boundaries.')
content=content.replace('After current verification, the next dependency','The next dependency')
content+='\nThe [information-study implementation boundary](INFORMATION_STUDY_IMPLEMENTATION.md) records the next manifest, resource-accounting, recovery and complete-grid acceptance work. It is an engineering design, not an implemented study or a new scientific contract.\n'
summary.write_text(content,encoding='utf-8')
dump(output,{'status':'FINAL_CHECKS_IN_PROGRESS'})
checks={}
for name,script in [('retail_contract','docs/reviews/verify_retail_contract.py'),
                    ('implementation_preservation','docs/reviews/implementation-2026-10-25/verify_implementation.py')]:
    command=[sys.executable,'-B',script]
    process=subprocess.run(command,cwd=ROOT,capture_output=True,text=True)
    assert process.returncode==0,process.stdout+process.stderr
    result=json.loads(process.stdout);assert result['status']=='PASS' and not result.get('errors')
    dump(WORK/(name+'-final.json'),{'command':command,'exit_code':0,'result':result})
    checks[name]={'command':command,'exit_code':0,'status':'PASS',
        'local_document_links':result.get('local_document_links'),'report_sha256':sha(WORK/(name+'-final.json'))}
git=subprocess.run(['git','diff','--check'],cwd=ROOT,capture_output=True,text=True)
assert git.returncode==0,git.stdout+git.stderr
checks['git_diff_check']={'command':['git','diff','--check'],'exit_code':0,'line_ending_warnings':len(git.stderr.splitlines())}
archive=AUDIT/'population-model-regression-evidence.zip';members={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as stream:
    for name in ('tests.log','tests-result.json','run_checks.py','retail_contract-final.json',
                 'implementation_preservation-final.json','finalize.py'):
        stream.write(WORK/name,name);members[name]=sha(WORK/name)
current={p.relative_to(ROOT).as_posix():sha(p) for folder in ('trading_researcher','tests','docs')
    for p in (ROOT/folder).rglob('*') if p.is_file()}
current['README.md']=sha(ROOT/'README.md')
changed=sorted(name for name,value in current.items() if baseline['files'].get(name)!=value)
preserved={name:value for name,value in baseline['files'].items()
    if name.startswith('docs/reviews/') and name.endswith('.json') and name not in changed}
assert all(sha(ROOT/name)==value for name,value in preserved.items())
record={'schema':'population-model-verification/1','status':'PASS_WITH_EXPLICIT_MODEL_AND_CALIBRATION_LIMITS',
    'goal_status':'IN_PROGRESS','changed_files_this_checkpoint':changed,
    'changed_file_sha256':{name:current[name] for name in changed if name!=output.relative_to(ROOT).as_posix()},
    'runtime_tests':tests,'independent_review':{'path':'population-model-review.json',
        'sha256':sha(AUDIT/'population-model-review.json'),'tests':11,'seconds':'0.121','exit_code':0},
    'current_source_probe':probe,'checks':checks,'prior_reports_preserved':len(preserved),
    'baseline_sha256':sha(AUDIT/'population-model-baseline.json'),
    'probe_evidence_sha256':sha(AUDIT/'population-model-probe-evidence.zip'),
    'regression_archive':{'path':archive.name,'sha256':sha(archive),'members_sha256':members},
    'unverified':read(AUDIT/'population-model-progress.json')['unverified'][1:]}
dump(output,record)
for name,value in record['changed_file_sha256'].items():assert sha(ROOT/name)==value,name
with zipfile.ZipFile(archive) as stream:
    assert stream.testzip() is None
    assert all(hashlib.sha256(stream.read(name)).hexdigest()==value for name,value in members.items())
print(json.dumps({'status':record['status'],'exit_code':0,'tests':count,'seconds':seconds,
    'source_hashes':len(tests['source_hashes_after']),'changed_files':len(changed),'checks':checks,
    'prior_reports_preserved':len(preserved),'goal_status':'IN_PROGRESS'},indent=2))
