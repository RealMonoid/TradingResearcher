"""Record verified private preparation without claiming scientific admission."""
import ast,datetime,hashlib,json,re,subprocess,sys,unittest,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];work=Path(__file__).parent
out=root/'docs/reviews/implementation-2026-10-25';sha=lambda raw:hashlib.sha256(raw).hexdigest()
baseline=json.loads((work/'baseline.json').read_text())
checks=[json.loads(path.read_text()) for path in sorted(work.glob('2026*.json'))]
inventory={'test_protected*.py':19,'test_data_use*.py':24,'test_plan_retention*.py':11,
    'test_plan_review*.py':16,'test_evaluation_plans.py':5}
sys.path[:0]=[str(root),str(root/'tests')]
def flatten(suite):
    for item in suite:
        if isinstance(item,unittest.TestSuite):yield from flatten(item)
        else:yield item.id()
test_ids={pattern:list(flatten(unittest.TestLoader().discover(str(root/'tests'),pattern=pattern))) for pattern in inventory}
all_ids=[identity for values in test_ids.values() for identity in values]
assert len(all_ids)==len(set(all_ids))==75
selected={}
for pattern,count in inventory.items():
    assert len(test_ids[pattern])==count,pattern
    matches=[c for c in checks if '-p' in c['command'] and c['command'][c['command'].index('-p')+1]==pattern]
    assert matches and matches[-1]['exit_code']==0,pattern
    check=matches[-1];log=(work/check['log']).read_text()
    assert re.search(r'Ran '+str(count)+r' tests? ',log) and re.search(r'\nOK\s*$',log),pattern
    selected[pattern]=check['log']
preserved=[name for name in baseline['files'] if (name.startswith('trading_researcher/') and name.endswith('.py')
    and name not in ('trading_researcher/coordination.py','trading_researcher/data_use.py','trading_researcher/evaluation_plans.py'))
    or name.startswith('tests/fixtures/')]
preserved += ['docs/architecture/'+name for name in ('02_DECISION_REGISTER.md','03_REJECTED_DECISIONS.md',
    '04_DEFINITIONS.md','14_RETAIL_RESEARCH_CONTRACT.md')]
for name in preserved:assert sha((root/name).read_bytes())==baseline['files'][name],name
unchanged_functions={}
with zipfile.ZipFile(work/'source-before.zip') as before:
    for name in ('trading_researcher/evaluation_plans.py','trading_researcher/data_use.py'):
        functions=lambda raw:{node.name:ast.dump(node,include_attributes=False) for node in ast.parse(raw).body if isinstance(node,ast.FunctionDef)}
        old,new=functions(before.read(name)),functions((root/name).read_bytes())
        assert all(new.get(key)==value for key,value in old.items()),name
        unchanged_functions[name]=sorted(old)
review=out/'protected-plan-independent-2026-10-26.json';review_value=json.loads(review.read_text())
assert review_value['status'].startswith('PASS')
for name,expected in review_value['source_sha256'].items():assert sha((root/name).read_bytes())==expected,name
names=set(subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines())
names.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines())
code=sorted(name for name in names if name.startswith(('trading_researcher/','tests/')) and name.endswith('.py'))
members={name:(root/name).read_bytes() for name in code}
for path in sorted(work.glob('2026*')):members['checks/'+path.name]=path.read_bytes()
for path in (work/'baseline.json',work/'check.py',work/'evidence.py',
        work.parent/'protected-plan-independent-2026-10-26.py',review):members['evidence/'+path.name]=path.read_bytes()
members['evidence/test-identities.json']=(json.dumps(test_ids,indent=2)+'\n').encode()
with zipfile.ZipFile(work/'source-before.zip') as before:
    for name in code:
        if name in baseline['files']:members['before/'+name]=before.read(name)
for name,raw in members.items():
    assert not re.search(rb'\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{20,}',raw),'API-key-like material in '+name
archive=out/'protected-plan-evidence-2026-10-26.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as target:
    for name,raw in members.items():target.writestr(name,raw)
value={'schema':'protected-plan-verification/1','status':'CODE_CHECKS_PASS_DOCUMENTATION_PENDING',
    'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent_commit':baseline['head'],
    'unique_focused_tests':75,'test_inventory':inventory,'latest_pass_log_by_suite':selected,'checks':checks,
    'independent_review_unique_additional_tests':0,
    'independent_review_note':'Reviewer-written three guard tests and independently rerun knowledge/development cases are included in the 75 identities, not additional tests.',
    'retained_failed_checks':[c['log'] for c in checks if c['exit_code']!=0],
    'intermediate_run_note':'The first 14-case protected run passed before adding genuine composition/review consumption, final calibration ancestry checks and three independent guard tests. The final fixture needs only one protected version; the legacy fixture default remains three.',
    'clock_note':'Structured timestamps/durations are wall-clock observations; unittest durations are independently printed by the runner. Both are retained verbatim, including any wall-clock adjustment.',
    'source_sha256':{path.relative_to(root).as_posix():sha(path.read_bytes()) for path in sorted((root/'trading_researcher').glob('*.py'))},
    'changed_code_test_sha256':{name:sha((root/name).read_bytes()) for name in code},
    'preserved_sha256':{name:baseline['files'][name] for name in preserved},'unchanged_existing_top_level_functions':unchanged_functions,
    'independent_review_sha256':sha(review.read_bytes()),'evidence_archive':archive.name,
    'evidence_archive_sha256':sha(archive.read_bytes()),'archive_members':len(members),
    'archive_scope':'Changed sources/tests, prior changed sources, exact check output and exits, unique test identities and independent review. No raw market download, credentials or registry backup.',
    'provider_calls':0,'scientific_readiness':False,'full_objective_complete':False,
    'unverified':['Real protected-market application/evaluation','Full repository suite and exhaustive historical package replay',
        'Complete campaign selection/prior-use/reservation chronology','Historical publication vintage and model training contents',
        'Fully qualified actual independent meaning review combined with a protected plan',
        'Protected scientific admission and pre-outcome eligibility','Population/stress adequacy and calibrated information/inference',
        'Atomic scientific allocation/freeze and fixed release','Genuine mixed-provider research cycle',
        'Certified AmiBroker policy evaluation, domain reporting and economic usefulness']}
with (out/'protected-plan-verification-2026-10-26.json').open('x',encoding='utf-8') as target:target.write(json.dumps(value,indent=2)+'\n')
path=out/'progress.json';progress=json.loads(path.read_text())
progress['continuation_audit']={'previous_goal_turn':'no_progress_verification_only','current_goal_turn':'progress',
    'basis':'An exact private data qualification is now consumed by actual protected plan preparation, using declared development diagnostics and private replayable capsules. Scientific data/exposure admission remains open.',
    'blocking_threshold_met':False,'full_objective_complete':False}
progress['protected_plan_checkpoint']={'date':'2026-10-26','status':'FOCUSED_CHECKS_PASS','unique_focused_tests':75,
    'verification':'docs/reviews/implementation-2026-10-25/protected-plan-verification-2026-10-26.json',
    'scope':'Qualified private plan preparation only; complete campaign/selection review, protected scientific admission and execution remain unavailable.',
    'provider_calls':0,'scientific_readiness':False,'full_objective_complete':False}
progress['next_action']='Resolve campaign selection/reservation and pre-outcome eligibility under the existing contracts, and complete justified nuisance/stress-model and information/calibration work before atomic scientific freeze. Preserve private draft inputs, qualified history and the full genuine mixed-provider cycle, policy/AmiBroker and reporting objective.'
progress['controls']['evidence-gate']={'status':'SATISFIED','evidence':
    '75 unique tests pass: 19 protected preparation/ancestry cases, 24 existing data-use, 11 retention, 16 plan-review and 5 direct plan cases. See protected-plan-verification-2026-10-26.json for exact evidence and limits. No paid call.'}
path.write_text(json.dumps(progress,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':value['status'],'unique_focused_tests':75,'changed_code_and_tests':len(code),
    'archive_members':len(members),'retained_failed_checks':len(value['retained_failed_checks'])}))
