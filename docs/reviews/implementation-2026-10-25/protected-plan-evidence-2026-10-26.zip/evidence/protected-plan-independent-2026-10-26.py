"""Freeze the independent bounded review once; never overwrite its evidence."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
WORK = ROOT / '.trf-runtime/protected-plan-checks-2026-10-26'
DEST = ROOT / 'docs/reviews/implementation-2026-10-25/protected-plan-independent-2026-10-26.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def checked(stem, expected_count, expected_exit=0):
    path = WORK / (stem + '.json')
    value = json.loads(path.read_text(encoding='utf-8'))
    log = WORK / value['log']
    text = log.read_text(encoding='utf-8')
    found = re.search(r'Ran (\d+) tests? in ([0-9.]+)s', text)
    assert value['exit_code'] == expected_exit and found
    assert int(found[1]) == expected_count
    if expected_exit == 0:
        assert '\nOK\n' in text
    return {**value, 'record': path.relative_to(ROOT).as_posix(),
            'record_sha256': sha(path), 'log_sha256': sha(log),
            'test_count': expected_count, 'unittest_seconds': float(found[2])}


def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item.id()


baseline = json.loads((WORK / 'baseline.json').read_text(encoding='utf-8'))
selected = {
    'test_protected*.py': ('20261026T164634-9b7e4144', 19),
    'test_data_use*.py': ('20261026T163746-afd27ff6', 24),
    'test_plan_retention*.py': ('20261026T163746-fe575a0c', 11),
    'test_plan_review*.py': ('20261026T164148-1d58914e', 16),
    'test_evaluation_plans.py': ('20261026T164148-2afac4cc', 5),
}
test_ids = {}
for pattern, (_, count) in selected.items():
    suite = unittest.TestLoader().discover(str(ROOT / 'tests'), pattern=pattern)
    identities = sorted(flatten(suite))
    assert len(identities) == count and len(set(identities)) == count
    test_ids[pattern] = identities
assert len(set(identity for values in test_ids.values() for identity in values)) == 75

canonical = ['AGENTS.md', 'REVIEWING.md',
    'docs/architecture/02_DECISION_REGISTER.md', 'docs/architecture/03_REJECTED_DECISIONS.md',
    'docs/architecture/04_DEFINITIONS.md', 'docs/architecture/05_REQUIREMENTS.md',
    'docs/architecture/06_MASTER_ARCHITECTURE.md', 'docs/architecture/07_SCIENTIFIC_EVALUATION.md',
    'docs/architecture/11_OPEN_DECISIONS.md', 'docs/architecture/12_TRACEABILITY_MATRIX.md',
    'docs/architecture/14_RETAIL_RESEARCH_CONTRACT.md', 'docs/architecture/15_AGENT_INQUIRY_DISCIPLINE.md']
for name in canonical:
    assert sha(ROOT / name) == baseline['files'][name], name
assert sha(ROOT / 'trading_researcher/evaluation_policy.py') == baseline['files']['trading_researcher/evaluation_policy.py']

docs = ['README.md', 'docs/architecture/CURRENT_STATE.md', 'trading_researcher/DATA_USE.md',
    'trading_researcher/DATA_TARGETS.md', 'trading_researcher/EVALUATION_POLICY.md',
    'docs/reviews/implementation-2026-10-25/PROTECTED_PLAN_INTEGRATION_2026-10-26.md']
paths = set(canonical + docs + ['tests/data_target_support.py', 'tests/binding_support.py',
    'tests/plan_review_support.py', 'tests/meaning_review_support.py'])
paths.update(path.relative_to(ROOT).as_posix() for path in (ROOT / 'trading_researcher').glob('*.py'))
for pattern in selected:
    paths.update(path.relative_to(ROOT).as_posix() for path in (ROOT / 'tests').glob(pattern))
paths.update(path.relative_to(ROOT).as_posix() for path in (ROOT / 'tests/fixtures').glob('reference_evaluation_policy*'))
assert all((ROOT / name).is_file() for name in paths)

report = {
    'schema': 'independent-protected-plan-review/1',
    'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer': '/root/publication_review',
    'status': 'PASS_BOUNDED_PRIVATE_PLAN_DATA_PREREQUISITE',
    'baseline_commit': baseline['head'],
    'purpose': 'Review actual consumption of exact protected-target data qualifications by host-private policy preparation, without granting protected outcome execution, unused reservations or independent confirmation.',
    'authority': {
        'contract': 'research-contract/1.0', 'sections': ['1', '6', '8', '12', '14'],
        'decisions': ['D014', 'D071', 'D076', 'D082', 'D084'],
        'classification': 'Implementation of existing qualified historical-use, exposure, provenance and access constraints. The profile is a private preparation prerequisite, not a new scientific admission or exposure policy.',
        'canonical_basis_unchanged': True, 'numerical_policy_implementation_unchanged': True},
    'reviewed_invariants': [
        'assess_data_use retains the same operator API and data-use-assessment/1 envelope, with a separately versioned protected profile and private_plan_data_prerequisite_only authority for explicit private-target compilations.',
        'Positive private qualification is bound to the exact compiled identity, original formalization, public target, explicit private binding, protected snapshot and feature certificate. Full definitions/parameters/specification versions, normalization delay, source integrity and pinned reviewed rights bytes remain required.',
        'Candidate knowledge starts at original formalization ancestry before compiler-added private dependencies. A protected target already present in prior ancestry is never subtracted. Known protected/operations knowledge and unresolved concrete exposure references produce a private gap.',
        'Unknown model training alone is not converted to known exposure or a gap. Origin remains null with a reason, vintage remains unverified, delay remains an assumed scenario, independent_confirmation and reserved_role_verified remain false, and campaign selection/prior use remains NOT_ASSESSED.',
        'Private preparation requires a current exact matching private qualification. Its development diagnostics must be owned descriptive executions on the development snapshot explicitly named by the public declaration certificate, with valid case-blob hash/size, acceptable concrete ancestry and current dependencies.',
        'The unchanged numerical draft_plan calculation consumes the original candidate and policy inputs. It does not compute protected outcomes or validate empirical dependence-model adequacy.',
        'Private assessment, input capsule and plan retain assessment class and private binding ancestry. Research-role contexts and development wrappers remain denied. The new exception applies only to host consumption of private data-use/composition evidence and never permits final calibration ancestry.',
        'Private current inspection keeps scientific_data_and_exposure_acceptance open and reports protected_selection_and_reservation_review NOT_ASSESSED. Scientific readiness, protected admission, allocation reservation and freeze remain false.',
        'Completed request keys return historical bytes before new admission. Interrupted requests retain exact input/source capsules; retries cannot silently replace prerequisites. Commitment rechecks qualification, diagnostic bytes, other evidence and revocation after child work.',
        'Existing direct development behavior and numerical policy semantics are preserved. No generic-source or worker API can issue owned data qualification or private policy plans.'
    ],
    'independent_findings': {
        'production_blockers': [],
        'conclusion': 'No substantiated production bypass was found within the inspected code paths and exercised synthetic boundaries. This is not proof of absence of bugs or a whole-framework scientific verdict.',
        'review_driven_coverage': [
            'Added independent isolated tests for both private host-consumer routes, their continued denial for development-class targets, and final calibration ancestry through development wrappers.',
            'Requested actual private plan integration with composition and owned meaning-review evidence; the final suite exercises both.',
            'The single scripted review deliberately remains NOT_SATISFIED. An initial suggestion to require SATISFIED was withdrawn because this fixture has no complete independent reviewer-quality qualification. No fabricated qualification was introduced.'
        ]},
    'checks': {
        'independently_executed': [
            checked('20261026T163940-f5902b3f', 3),
            checked('20261026T163944-f9bbf151', 10),
            checked('20261026T164046-12bc8fa1', 3)],
        'parent_executed_final_suites_inspected': {
            pattern: checked(stem, count) for pattern, (stem, count) in selected.items()},
        'unique_tests_in_selected_final_suites': 75,
        'new_target_tests': 19,
        'counting_note': 'The reviewer three knowledge and three guard cases are included in the final nineteen; the reviewer ten data-use cases are included in the final twenty-four. Preliminary runs and repeated executions are not additional test identities. This is not a full-repository test claim.',
        'test_identities': test_ids,
        'final_target_coverage': [
            'Actual synthetic normalization, feature certification, public declaration, formalization, explicit private compilation and exact private qualification without _load_reference_data protected outcome expansion.',
            'Private policy draft consuming the declared development diagnostic; exact candidate retention, private capsule class, same-key replay, interrupted retry and complete backup/restore.',
            'No protected execution through execute_development; no worker issuance or research-context/wrapper access to private qualifications/plans.',
            'Absent or wrong-compilation qualification, unreviewed rights, unresolved actual candidate ancestry, protected/unresolved diagnostic ancestry and wrong/protected diagnostic snapshot are denied.',
            'Revocation after child calculation prevents plan commitment and preserves a private interrupted capsule.',
            'Genuine CONFORMANT composition certificate satisfies only its composition gate; an owned scripted semantic review maps to the exact public definition but retains NOT_SATISFIED and the semantic gate.',
            'Final calibration ancestry stays prohibited both through the real preparation path and isolated data-use/composition host consumers.'
        ],
        'static_downstream_boundary_review': {
            'basis': 'Source inspection only; no additional downstream run is claimed here.',
            'findings': [
                'bootstrap_runs._development_plan_execution still requires owned development-class plan and execution plus a development snapshot before computation.',
                'information_runs._information_inputs uses that shared boundary.',
                'population_runs and study_runs require development diagnostics and use the same development plan/execution boundary.',
                'An assessment-class plan with the existing evaluation-plan/1 schema therefore does not grant the existing downstream development computation APIs protected execution authority.'
            ]},
        'documentation_consistency': {'files': docs, 'result': 'No material discrepancy found against the reviewed code.'}
    },
    'retained_preliminary_evidence': {
        'expected_preimplementation_failure': {
            **checked('20261026T163138-cb51ba87', 1, 1),
            'reason': 'ImportError for protected_knowledge_gaps before the implementation existed; not counted as a passing behavioral test.'},
        'first_knowledge_pass': checked('20261026T163319-037dcc7e', 3),
        'earlier_fourteen_case_pass': checked('20261026T163652-d5857386', 14),
        'fixture_change': 'Final target fixture requests private_versions=1 instead of certifying two unused alternatives; existing target-fixture default remains three. Expected production behavior and scientific limits were not relaxed.'
    },
    'limitations': [
        'Protected observations in the integration are synthetic. Synthetic provider-document pins are explicitly substituted; this step does not repeat the prior real provider-document verification or establish new provider rights.',
        'Scripted model transport exercises owned records and provenance only; there are no paid calls, actual model-quality results or a completed genuine multi-provider research cycle.',
        'A fully qualified semantic-review SATISFIED result combined with a protected plan was not established by the new synthetic integration. Existing direct plan-review regressions cover qualified/stale inventories separately.',
        'Isolated guard tests use host-owned synthetic envelopes and mock downstream evidence consumers. They demonstrate ancestry routing, not genuine certificate validity or attacks that can forge controller-owned storage.',
        'Registered candidate ancestry does not account for every prior campaign, sibling query, external observation or selection decision. Unused reservation, full selection chronology and independent confirmation remain unverified.',
        'Host and local filesystem are trusted; no OS isolation or protection from a malicious operator is proved.',
        'Outcome eligibility, justified nuisance/stress assumptions, calibrated inference and information targets, atomic scientific allocation/freeze, fixed release, realistic policy evaluation and economic usefulness remain unfinished.',
        'No exhaustive replay of all old retained source packages or full repository test suite was run for this review.'
    ],
    'next_action': 'Use the private draft as retained preparation only. Resolve campaign selection/reservation and pre-outcome eligibility under the existing contract, and finish justified nuisance/information/calibration prerequisites before atomic scientific freeze or protected execution.',
    'changed_by_reviewer': ['tests/test_protected_plan_adversarial.py', DEST.relative_to(ROOT).as_posix()],
    'source_sha256': {name: sha(ROOT / name) for name in sorted(paths)},
    'procedure_sha256': sha(Path(__file__)),
}
with DEST.open('x', encoding='utf-8', newline='\n') as handle:
    json.dump(report, handle, indent=2)
    handle.write('\n')
print(json.dumps({'report': DEST.relative_to(ROOT).as_posix(), 'sha256': sha(DEST),
    'source_count': len(paths), 'unique_tests': 75, 'status': report['status']}))
