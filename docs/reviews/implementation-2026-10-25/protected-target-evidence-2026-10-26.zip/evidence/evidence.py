"""Retain the exact public-target checkpoint and all observed test phases."""
import ast,datetime,hashlib,json,re,subprocess,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];work=Path(__file__).parent
out=root/'docs/reviews/implementation-2026-10-25'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
baseline=json.loads((work/'baseline.json').read_text())
checks=[json.loads(p.read_text()) for p in sorted(work.glob('2026*.json'))]
identities=json.loads((work/'test-inventory.json').read_text())
inventory={pattern:len(ids) for pattern,ids in identities.items()}
all_ids=[identity for ids in identities.values() for identity in ids]
assert len(all_ids)==len(set(all_ids))==142
selected={}
for pattern,count in inventory.items():
    matches=[c for c in checks if '-p' in c['command'] and c['command'][c['command'].index('-p')+1]==pattern]
    assert matches and matches[-1]['exit_code']==0,pattern
    last=matches[-1];log=(work/last['log']).read_text()
    assert re.search(r'Ran '+str(count)+r' tests? ',log) and re.search(r'\nOK\s*$',log),pattern
    selected[pattern]=last['log']
preserved=['trading_researcher/'+name+'.py' for name in ('expressions','outcomes','evaluation_policy',
    'stationary_bootstrap','calibration','formalization','features','certification','data','binance_normalize','data_use')]
preserved += ['docs/architecture/'+name for name in ('02_DECISION_REGISTER.md','03_REJECTED_DECISIONS.md',
    '04_DEFINITIONS.md','14_RETAIL_RESEARCH_CONTRACT.md')]
preserved += [name for name in baseline['files'] if name.startswith('tests/fixtures/')]
for name in preserved:assert sha((root/name).read_bytes())==baseline['files'][name],name
pure_functions={}
with zipfile.ZipFile(work/'source-before.zip') as before:
    for name in ('trading_researcher/binding.py','trading_researcher/composition.py','trading_researcher/evaluation_plans.py'):
        old=ast.parse(before.read(name));new=ast.parse((root/name).read_bytes())
        functions=lambda tree:{node.name:ast.dump(node,include_attributes=False) for node in tree.body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))}
        assert functions(old)==functions(new),name
        pure_functions[name]=sorted(functions(new))
review=out/'protected-target-independent-2026-10-26.json'
independent=json.loads(review.read_text());assert independent['status'].startswith('PASS')
review_hash_differences=[]
for name,expected in independent['source_sha256'].items():
    if sha((root/name).read_bytes())!=expected:review_hash_differences.append(name)
assert review_hash_differences==['trading_researcher/BINDING.md'],review_hash_differences
names=set(subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines())
names.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines())
code=sorted(n for n in names if n.startswith(('trading_researcher/','tests/')) and n.endswith('.py'))
members={name:(root/name).read_bytes() for name in code}
for path in sorted(work.glob('2026*')):members['checks/'+path.name]=path.read_bytes()
for path in [work/'check.py',work/'baseline.json',work/'test-inventory.json',work/'inventory.py',work/'evidence.py',review]:
    members['evidence/'+path.name]=path.read_bytes()
with zipfile.ZipFile(work/'source-before.zip') as before:
    for name in code:
        if name in baseline['files']:members['before/'+name]=before.read(name)
for name,raw in members.items():
    assert not re.search(rb'\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{20,}',raw),'API-key-like material in '+name
archive=out/'protected-target-evidence-2026-10-26.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as target:
    for name,raw in members.items():target.writestr(name,raw)
value={'schema':'protected-target-verification/1','status':'CODE_CHECKS_PASS_DOCUMENTATION_PENDING',
    'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent_commit':baseline['head'],
    'unique_focused_tests':len(all_ids),'test_inventory':inventory,'latest_pass_log_by_suite':selected,
    'checks':checks,'independent_review_unique_additional_tests':0,
    'independent_review_note':'The reviewer independently reran two tests already included in the fifteen target tests.',
    'independent_review_sha256':sha(review.read_bytes()),
    'later_reviewed_document_change':'BINDING.md wording now states unchanged warmup, outcome and numerical semantics instead of implying the RPC request has no optional addition. All reviewed production/test hashes match.',
    'retained_failed_checks':[c['log'] for c in checks if c['exit_code']!=0],
    'source_sha256':{p.relative_to(root).as_posix():sha(p.read_bytes()) for p in sorted((root/'trading_researcher').glob('*.py'))},
    'changed_code_test_sha256':{name:sha((root/name).read_bytes()) for name in code},
    'preserved_sha256':{name:baseline['files'][name] for name in preserved},
    'unchanged_top_level_functions':pure_functions,
    'evidence_archive':archive.name,'evidence_archive_sha256':sha(archive.read_bytes()),'archive_members':len(members),
    'archive_scope':'Changed production/tests, prior changed sources, exact test/check outputs including failures, test identities and independent review. No credentials, raw market downloads or registry backups.',
    'provider_calls':0,'scientific_readiness':False,'full_objective_complete':False,
    'unverified':['Full repository test suite and exhaustive old-package replay',
        'Real protected-market application or evaluation','Operating-system isolation and trusted-host compromise',
        'Historical publication vintage and model training exposure','Scientific protected-target data/exposure admission',
        'Outcome eligibility and population/stress adequacy','Calibrated information/inference including mixed-truth families',
        'Atomic scientific allocation/freeze and fixed result release','Genuine mixed-provider research cycle',
        'Certified AmiBroker policy evaluation and domain reporting','Profitability']}
with (out/'protected-target-verification-2026-10-26.json').open('x',encoding='utf-8') as target:
    target.write(json.dumps(value,indent=2)+'\n')
path=out/'progress.json';progress=json.loads(path.read_text())
progress['continuation_audit']={'previous_goal_turn':'no_progress_verification_only','current_goal_turn':'progress',
    'basis':'Public predeclared targets now bind explicitly to private exact data without changing formalization/review packets or granting scientific admission. Synthetic owned-path tests, legacy regressions and independent review pass.',
    'blocking_threshold_met':False,'full_objective_complete':False}
progress['protected_target_checkpoint']={'date':'2026-10-26','status':'FOCUSED_CHECKS_PASS',
    'verification':'docs/reviews/implementation-2026-10-25/protected-target-verification-2026-10-26.json',
    'scope':'Public declaration and private exact reference resolution only; protected scientific admission and execution remain unavailable.',
    'unique_focused_tests':len(all_ids),'provider_calls':0,'scientific_readiness':False,'full_objective_complete':False}
progress['next_action']='Integrate protected-target data/exposure qualification with the approved scientific admission requirements without transporting development approval or exposing private coverage/binding failures to research roles. Continue justified nuisance/stress-model and information/calibration work, atomic family allocation/freeze, fixed release and the genuine mixed-provider research cycle.'
progress['controls']['evidence-gate']={'status':'SATISFIED','evidence':
    '142 unique focused tests pass: 15 target, 16 plan-review, 19 binding, 24 auxiliary, 23 revocation, 21 composition and 24 data-use cases. Independent review and original failed checks retained. See protected-target-verification-2026-10-26.json. Synthetic protected data only; no paid call.'}
path.write_text(json.dumps(progress,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':value['status'],'unique_focused_tests':len(all_ids),'changed_code_and_tests':len(code),
    'archive_members':len(members),'retained_failed_checks':len(value['retained_failed_checks'])}))
