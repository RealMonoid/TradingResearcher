"""Collect test identities without executing fixtures or making provider calls."""
import collections,json,sys,unittest
from pathlib import Path
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'tests'))
sys.path.insert(0,str(root))
patterns=['test_data_targets*.py','test_plan_review*.py','test_binding*.py',
    'test_auxiliary*.py','test_revocation*.py','test_composition*.py','test_data_use*.py']
def flatten(suite):
    for item in suite:
        if isinstance(item,unittest.TestSuite):yield from flatten(item)
        else:yield item.id()
inventory={pattern:list(flatten(unittest.TestLoader().discover(str(root/'tests'),pattern=pattern))) for pattern in patterns}
counts=collections.Counter(identity for identities in inventory.values() for identity in identities)
assert all(count==1 for count in counts.values()),[identity for identity,count in counts.items() if count!=1]
with (Path(__file__).parent/'test-inventory.json').open('x',encoding='utf-8') as target:
    target.write(json.dumps(inventory,indent=2)+'\n')
print(json.dumps({'status':'PASS','tests_per_suite':{p:len(ids) for p,ids in inventory.items()},
    'unique_test_identities':len(counts),'fixtures_executed':False}))
