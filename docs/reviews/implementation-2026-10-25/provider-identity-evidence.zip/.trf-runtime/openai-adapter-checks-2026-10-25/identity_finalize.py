"""Freeze the usage identity/time extension; no provider access or receipt backfill."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
OUT=ROOT/'docs/reviews/implementation-2026-10-25'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')


def main():
    target=OUT/'provider-identity-verification.json'
    if target.exists():raise RuntimeError('Existing frozen identity checkpoint must not be overwritten')
    protected={str(path.relative_to(ROOT)):sha(path) for path in OUT.iterdir()
        if path.suffix in ('.json','.zip') and path.name!='progress.json'}
    observation=json.loads((OUT/'provider-identity-observation.json').read_text())
    ledger=ROOT/'.trf-runtime/openai-integration-budget.sqlite3'
    assert sha(ledger)==observation['ledger_sha256_before']==observation['ledger_sha256_after']
    command=[sys.executable,'-B','-m','trading_researcher','openai-usage','--ledger',str(ledger)]
    cli=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
    if cli.returncode:raise RuntimeError('Read-only usage CLI failed')
    assert json.loads(cli.stdout)==observation['report'] and sha(ledger)==observation['ledger_sha256_after']
    (WORK/'identity-cli-result.json').write_text(cli.stdout,encoding='utf-8')
    progress=json.loads((OUT/'progress.json').read_text())
    progress['token_usage'].update(identity_and_time_observation='docs/reviews/implementation-2026-10-25/provider-identity-observation.json',
        future_recording='Automatic per admitted OpenAI call: requested/reported model, public catalog name/version/source, explicit unknown immutable snapshot, UTC admission/local settlement times, input/output and optional token subsets. Historical gaps remain unknown.')
    progress['packages'][1]['evidence']+=['docs/reviews/implementation-2026-10-25/provider-identity-verification.json']
    progress['controls']['evidence-gate']={'status':'SATISFIED',
        'evidence':'44 unique focused provider/usage/identity/time tests pass, including32 independent cases. Read-only historical supplement and CLI preserve ledger bytes and2172-token total. Original four actual requests serialize identically under current wire code; no new API calls.'}
    progress['continuation_audit']['basis']='Implemented user-required model/version/date/time usage records and preserved historical evidence. Full-context investigation resumes next; complete seven-package goal remains active.'
    write(OUT/'progress.json',progress)
    summary=OUT/'IMPLEMENTATION_SUMMARY_2026-10-25.md'
    with summary.open('a',encoding='utf-8') as stream:
        stream.write('\n## Model identity and timestamp documentation\n\nThe user additionally required model name/version and date/time alongside consumption. New usage records retain requested and reported identifiers, the public catalog name/version/source, explicit unknown immutable snapshot, and ISO8601 UTC admission/local settlement timestamps. Summaries separate different identities. The [historical supplement](OPENAI_USAGE_IDENTITY_2026-10-25.md) annotates the original four responses without changing ledger bytes or inventing missing receipt fields. The [verification](provider-identity-verification.json) records44 focused tests, including32 independent cases, and a read-only CLI check. No further API calls or charges were made.\n')
    changed=['trading_researcher/openai_provider.py','trading_researcher/provider_usage.py',
        'trading_researcher/OPENAI.md','docs/architecture/CURRENT_STATE.md',
        'tests/test_provider_identity.py','tests/test_provider_identity_adversarial.py',
        'docs/reviews/implementation-2026-10-25/progress.json',
        'docs/reviews/implementation-2026-10-25/IMPLEMENTATION_SUMMARY_2026-10-25.md',
        'docs/reviews/implementation-2026-10-25/OPENAI_USAGE_IDENTITY_2026-10-25.md',
        'docs/reviews/implementation-2026-10-25/provider-identity-observation.json',
        'docs/reviews/implementation-2026-10-25/provider-identity-review.json',
        'docs/reviews/implementation-2026-10-25/provider-identity-verification.json',
        'docs/reviews/implementation-2026-10-25/provider-identity-evidence.zip']
    report={'schema':'provider-identity-time-verification/1','status':'CHECKING','changed_files':changed,
        'scope':'Operational model/version/UTC usage attribution; no scientific contract or pricing change.',
        'checks':[{'command':"python -B -m unittest discover -s tests -p 'test_*provider*.py' -q",'tests':44,
            'seconds':2.366,'exit_code':0,'evidence':'Observed structured exec chunk7f8efa; includes the32 independent cases, not added twice.'},
            {'check':'Independent identity/time review','tests':32,'seconds':2.039,'exit_code':0,'evidence':'provider-identity-review.json'},
            {'command':command,'exit_code':cli.returncode,'exact_report_match':True,'ledger_bytes_preserved':True},
            {'check':'Historical observation script','initial_exit_code':1,'initial_cause':'Profile was read from wrong retained object; KeyError before output writes.',
                'corrected_exit_code':0,'evidence':'Structured exec chunk5cf8a3; retained profile file used; four original wire hashes match.'}],
        'new_api_calls':0,'tokens_unchanged':2172,'conservative_nano_usd_unchanged':6435000,
        'protected_prior_artifacts':protected,'unverified':['Immutable served model snapshot',
            'Provider execution start/end timestamps','Missing original settlement times/catalog fields',
            'Live transmission of new accounting fields; existing API wire payloads are unchanged',
            'Representative full-context research workload and scientific validity']}
    write(target,report)
    for name,args in [('identity-retail-contract',[sys.executable,'-B','docs/reviews/verify_retail_contract.py']),
                      ('identity-git-diff-check',['git','diff','--check'])]:
        result=subprocess.run(args,cwd=ROOT,capture_output=True,text=True,encoding='utf-8',errors='replace')
        (WORK/(name+'.log')).write_text(result.stdout+result.stderr,encoding='utf-8')
        report['checks'].append({'command':args,'exit_code':result.returncode})
        if result.returncode:raise RuntimeError(name+' failed')
    sources=[*ROOT.joinpath('trading_researcher').glob('*.py'),*ROOT.joinpath('tests').glob('*.py'),
        *ROOT.joinpath('tests/fixtures').glob('*.json'),*WORK.glob('identity*.py'),*WORK.glob('identity*.json'),*WORK.glob('identity*.log')]
    archive=OUT/'provider-identity-evidence.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted(set(sources)):bundle.write(path,str(path.relative_to(ROOT)))
    report.update(status='PASS_BOUNDED_IDENTITY_AND_TIME',evidence_archive_sha256=sha(archive),
        source_hashes={str(path.relative_to(ROOT)):sha(path) for path in sources})
    write(target,report)
    assert all(sha(ROOT/path)==expected for path,expected in protected.items())
    assert sha(ledger)==observation['ledger_sha256_after']
    final=subprocess.run(['git','diff','--check'],cwd=ROOT,capture_output=True,text=True)
    if final.returncode:raise RuntimeError('Final documentation whitespace check failed')
    print(json.dumps({'status':report['status'],'tests':44,'independent_subset':32,
        'read_only_cli_exit':cli.returncode,'documentation_exit':0,'preserved_artifacts':len(protected),
        'new_api_calls':0,'report':str(target)}))


if __name__=='__main__':main()
