"""Read-only historical metadata supplement; no credentials or provider calls."""
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from trading_researcher.codec import digest
from trading_researcher.openai_provider import wire_request
from trading_researcher.provider_usage import read_usage_report


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):
    with path.open('x',encoding='utf-8') as stream:json.dump(value,stream,indent=2);stream.write('\n')


def main():
    work=Path(__file__).resolve().parent;out=ROOT/'docs/reviews/implementation-2026-10-25'
    ledger=ROOT/'.trf-runtime/openai-integration-budget.sqlite3'
    before=sha(ledger)
    report=read_usage_report(ledger)
    assert sha(ledger)==before
    original=json.loads((work/'live-result.json').read_text())
    originals={call['reply']['response']['aggregate_dispatch_id']:call for call in original['epoch']['calls']}
    config=json.loads((work/'live-profile.json').read_text())['generation_parameters']['openai_responses']
    annotations=[]
    for call in report['calls']:
        captured=originals[call['dispatch_id']];response=captured['reply']['response']
        assert digest(wire_request(captured['request'],config))==response['wire_request_sha256']
        assert call['receipt']['usage']==captured['reply']['usage']
        assert call['settled_at_utc'] is None
        assert call['model_identity']['reported_model'] is None
        annotations.append({'dispatch_id':call['dispatch_id'],'admitted_at_utc':call['admitted_at_utc'],
            'requested_model':captured['request']['model'],'reported_model':response['resolved_model'],
            'catalog_name':'GPT-6.1 Sol','catalog_version':'6.1',
            'catalog_source':'https://developers.openai.com/api/docs/models/gpt-6.1-sol',
            'immutable_snapshot_id':None,'immutable_snapshot_status':'UNKNOWN',
            'annotation_basis':'Separate October 25 catalog annotation and original retained API response; not a historical receipt rewrite.',
            'response_source':'.trf-runtime/openai-adapter-checks-2026-10-25/live-result.json',
            'worker':call['metadata']['worker'],'usage':call['receipt']['usage']})
    result={'schema':'provider-identity-time-observation/1','status':'PASS_READ_ONLY',
        'source_sha256':sha(work/'live-result.json'),'ledger_sha256_before':before,
        'ledger_sha256_after':sha(ledger),'report':report,'historical_response_annotations':annotations,
        'current_wire_payloads_match_original_four_requests':True,
        'new_api_calls':0,'new_accounting_rows':0,
        'limitations':['No immutable model snapshot is established.','No missing historical settlement timestamp was invented.',
            'New identity/time fields are locally tested; no new live request was made for this metadata change.']}
    save(out/'provider-identity-observation.json',result)
    lines=['# Model identity and call timestamps','',
        'Date: October 25, 2026. This supplement preserves the original usage observation and ledger bytes.',
        'The table joins already retained API response metadata to original admission timestamps.',
        'Catalog name/version is a separately sourced public label, not an immutable model revision.','',
        '| Admission time (UTC) | Perspective | Requested model | Reported model | Input | Output |',
        '|---|---|---|---|---:|---:|']
    for row in annotations:
        lines.append('| '+ ' | '.join([row['admitted_at_utc'],row['worker'],row['requested_model'],
            row['reported_model'],str(row['usage']['input_tokens']),str(row['usage']['output_tokens'])])+' |')
    lines+=['','Public model: **GPT-6.1 Sol**, catalog version **6.1**. '
        '[Official catalog](https://developers.openai.com/api/docs/models/gpt-6.1-sol). '
        'The retained responses report `gpt-6.1-sol`; an immutable snapshot is **UNKNOWN**.',
        '', 'The old records have no retained settlement time or catalog fields. Their original rows remain unchanged. '
        'This supplement does not silently populate missing historical receipt fields.',
        '', 'New calls automatically store catalog identity, requested/reported model identifiers, prompt version, '
        'admission time and local settlement time. Times are ISO8601 with the explicit UTC marker `Z`; '
        'they are host accounting times, not provider execution timestamps.',
        '', '**Consumption remains 2,172 tokens; conservative currency bound remains USD 0.006435.** '
        'No new model call or charge was created for this supplement.',
        '', '[Exact observation](provider-identity-observation.json) · '
        '[Report interface](../../../trading_researcher/OPENAI.md)', '']
    with (out/'OPENAI_USAGE_IDENTITY_2026-10-25.md').open('x',encoding='utf-8') as stream:stream.write('\n'.join(lines))
    print(json.dumps({'status':result['status'],'tokens':report['totals']['exact_total_tokens'],
        'rows':len(annotations),'ledger_byte_preservation':before==sha(ledger),
        'wire_requests_unchanged':True,'new_api_calls':0}))


if __name__=='__main__':main()
