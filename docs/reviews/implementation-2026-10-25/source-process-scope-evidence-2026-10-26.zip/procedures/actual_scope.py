"""Read exact owned development inputs, compare retained old/new source and replay."""
import hashlib,json,sqlite3,sys,zipfile
from copy import deepcopy
from fractions import Fraction
from pathlib import Path

root=Path(__file__).resolve().parents[2];work=Path(__file__).parent
sys.path.insert(0,str(root))
from trading_researcher.codec import canonical,digest
from trading_researcher.evaluation_plans import source_bundle,footprint
from trading_researcher.outcomes import _rational,_read_rational
from trading_researcher.population_models import specification
from trading_researcher.population_runs import run_child

profile=json.loads((work/'actual-scope-profile.json').read_text())
prior=json.loads((root/profile['source_result']).read_text())
registry=Path(prior['registry'])
objects={}
with sqlite3.connect((registry/'registry.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    for key in ('diagnostics_id','execution_id','plan_id'):
        raw=db.execute('SELECT envelope FROM artifacts WHERE id=?',(prior[key],)).fetchone()[0]
        assert hashlib.sha256(raw.encode()).hexdigest()==prior[key]
        obj=json.loads(raw);assert obj['creator']==obj['origin']=='controller' and obj['data_class']=='development'
        objects[key]=obj
execution=objects['execution_id']['body']['result']
descriptor=execution['case_blob'];sha=descriptor['sha256']
raw=(registry/'blobs'/sha[:2]/sha).read_bytes()
assert hashlib.sha256(raw).hexdigest()==sha and len(raw)==descriptor['size']
criterion=objects['plan_id']['body']['plan']['effect_criterion']
assert criterion['direction']=='positive' and _read_rational(criterion['delta'])==Fraction(1,20)
payload={'report':execution['report'],'case_blob':descriptor,
    'diagnostics':objects['diagnostics_id']['body']['result'],
    'specification':specification(profile['mask_mean_block'],profile['persistence'],profile['common_share'],profile['purpose']),
    'effects':[_rational(Fraction(x)) for x in profile['effects']],
    'scenario':profile['scenario'],'time_rows':profile['time_rows'],'seed':profile['seed']}
with zipfile.ZipFile(work/'source-before.zip') as archive:
    before={name:archive.read(name) for name in archive.namelist()
            if name.startswith('trading_researcher/') and name.endswith('.py') and name.count('/')==1}
after=source_bundle()
old,old_cases=run_child(before,payload,raw,120)
new,new_cases=run_child(after,payload,raw,120)
verified,replayed=run_child(after,payload,raw,120,verify=digest(new['result']),world_cases=new_cases)
assert new_cases==old_cases==replayed
current=new['result'];old_model=old['result']['model'];model=current['model']
without_diagnostic={k:v for k,v in model.items() if k not in ('source_process_scope','source_identity_preservation')}
assert without_diagnostic==old_model
old_world=deepcopy(old['result']['world']);new_world=deepcopy(current['world'])
for obj in (old_world,new_world):
    obj.pop('model_hash')
    obj['report']['request'].pop('candidate_ref')
    obj['report']['request'].pop('data_snapshot_ref')
assert old_world==new_world
audit=model['source_process_scope'];observed=audit['observations']
assert audit['identity']['condition_equals_outcome_at_offset_bars']==-2
assert observed=={'target_rows':96,'partner_absent':2,'both_unobserved':0,'condition_unobserved':0,
    'outcome_unobserved':0,'compared':94,'equal':94,'unequal':0,'both_eligible_compared':92}
# Independent timestamp join, applying the ORIGINAL source identity to the new
# synthetic responses. Their own synthetic AST deliberately makes no such claim.
cases=[json.loads(line) for line in new_cases.splitlines()]
lookup={(case['decision_time'],case['instrument']):case for case in cases}
equal=unequal=compared=0
for case in cases:
    partner=lookup.get((case['decision_time']-1800,case['instrument']))
    if partner is None or type(case['condition']) is not bool or partner['outcome'] is None:continue
    compared+=1
    match=int(case['condition'])==_read_rational(partner['outcome'])
    equal+=int(match);unequal+=int(not match)
assert unequal>0
result={'schema':'development-source-scope-observation/1','profile':profile,'profile_hash':digest(profile),
    'source_ids':{key:prior[key] for key in objects},'source_case_blob':descriptor,
    'diagnostic':audit,'synthetic_identity_comparison':{'compared':compared,'equal':equal,'unequal':unequal},
    'model_status':model['status'],'source_identity_preservation':model['source_identity_preservation'],
    'source_before':footprint(before),'source_after':footprint(after),'world_blob':new['world_blob'],
    'result_hash':digest(current),'replay_result_hash':verified['result']['verified_result_hash'],
    'legacy_source_case_bytes_equal':True,'legacy_source_probabilities_equal':True,
    'legacy_source_world_equal_except_model_derived_identity':True,
    'provider_calls':0,'scientific_readiness':False,'n_min':None,
    'qualification':'One prescribed one-day engineering probe. Exact source identity and one fixed synthetic counterexample; not a scientific market hypothesis, fitted law, power study or population adequacy certificate.'}
with (work/'actual-scope-observation.json').open('x',encoding='utf-8') as out:out.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('source_before','source_after','profile')},indent=2))
