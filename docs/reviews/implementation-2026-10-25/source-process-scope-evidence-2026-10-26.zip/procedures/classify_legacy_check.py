"""Check whether the historical proposal-only inventory already fails at HEAD."""
import hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[2];work=Path(__file__).parent
prefix='docs/reviews/integration-research-2026-10-24/'
baseline=json.loads((root/prefix/'baseline.json').read_text())['files_sha256']
head=json.loads((work/'baseline.json').read_text())['head']
paths=sorted(baseline)
proc=subprocess.run(['git','cat-file','--batch'],cwd=root,input=''.join(head+':'+p+'\n' for p in paths).encode(),capture_output=True,check=True)
offset=0;changed=[]
for name in paths:
    end=proc.stdout.index(b'\n',offset);header=proc.stdout[offset:end].split();offset=end+1
    if header[-1]==b'missing':changed.append(name);continue
    size=int(header[-1]);raw=proc.stdout[offset:offset+size];offset+=size+1
    if hashlib.sha256(raw).hexdigest()!=baseline[name]:changed.append(name)
inventory=subprocess.check_output(['git','ls-tree','-r','--name-only',head],cwd=root,text=True).splitlines()
unexpected=sorted(p for p in inventory if p not in baseline and not p.startswith(prefix) and '__pycache__' not in p)
observed=json.loads((work/'20261026T194754-ba59a9e6.log').read_text())
assert observed['status']=='FAIL' and len(observed['errors'])==2
assert observed['errors'][0].startswith('Preexisting files changed:')
assert observed['errors'][1].startswith('Unexpected new files:')
assert changed and unexpected
result={'schema':'historical-proposal-check-scope/1','baseline_commit':head,
    'checker':prefix+'verify_review.py','actual_exit_code':1,'actual_log':'20261026T194754-ba59a9e6.log',
    'prior_commit_changed_historical_files':changed,'prior_commit_unexpected_file_count':len(unexpected),
    'current_changed_historical_files':observed['checks']['changed_preexisting_files'],
    'current_unexpected_file_count':len(observed['checks']['unexpected_new_files']),
    'inventory_requirements_already_false_before_change':True,
    'disposition':'Not an applicable implementation release gate: its frozen proposal scope forbids all later implementation files. Failure retained, historical checker unchanged. Current system/retail/implementation checks are the applicable documentation gates.'}
(work/'historical-check-scope.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
