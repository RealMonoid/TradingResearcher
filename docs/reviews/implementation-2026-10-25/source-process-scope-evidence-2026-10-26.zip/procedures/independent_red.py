"""Run the unchanged independent tests against the retained pre-change package."""
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

root = Path(__file__).resolve().parents[2]
work = Path(__file__).parent
name = 'test_source_process_scope_adversarial.py'
with tempfile.TemporaryDirectory(prefix='trf-scope-before-') as temporary:
    base = Path(temporary)
    with zipfile.ZipFile(work / 'source-before.zip') as archive:
        selected = [item for item in archive.namelist() if item.startswith('trading_researcher/') and item.endswith('.py')]
        assert selected and 'trading_researcher/source_process_scope.py' not in selected
        for item in selected:
            assert len(Path(item).parts) == 2 and '..' not in Path(item).parts
            target = base / item
            target.parent.mkdir(exist_ok=True)
            target.write_bytes(archive.read(item))
    (base / 'tests').mkdir()
    (base / 'tests' / name).write_bytes((root / 'tests' / name).read_bytes())
    result = subprocess.run([sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tests', '-p', name, '-v'], cwd=base)
raise SystemExit(result.returncode)
