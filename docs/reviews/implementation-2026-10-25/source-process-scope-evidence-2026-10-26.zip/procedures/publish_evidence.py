"""Assemble bounded public evidence without market rows, registries or secrets."""
import hashlib,json,re,subprocess,zipfile
from pathlib import Path

root=Path(__file__).resolve().parents[2];work=Path(__file__).parent
public=root/'docs/reviews/implementation-2026-10-25'
prefix='source-process-scope'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
records=[];tests=set()
for path in sorted(work.glob('2026*.json')):
    record=json.loads(path.read_text());record['record']=path.name
    record['log_sha256']=sha(work/record['log']);records.append(record)
    if record['exit_code']==0:
        for line in (work/record['log']).read_text(errors='replace').splitlines():
            match=re.fullmatch(r'(test_\S+) \(([^)]+)\) \.\.\. ok',line)
            if match:tests.add(match[2] if match[2].endswith('.'+match[1]) else match[2]+'.'+match[1])
assert len(tests)==91, len(tests)
progress_path=public/'progress.json';progress=json.loads(progress_path.read_text())
progress['controls']['evidence-gate']['evidence']='91 unique focused tests pass, including 14 independent cases and owned generation/replay. A fixed actual-source counterexample retains unchanged numerical outputs and prior-source case bytes; source-process-scope-verification-2026-10-26.json records exact checks and limits.'
progress['next_action']='Formulate and assess a source-specific population/profile rationale that respects the diagnosed temporal dependencies before admitting an actual information target. Keep existing estimator-only stress studies explicitly scoped, preserve original source-bound inventories and justify resource continuation. Do not turn the prescribed one-day engineering case into a fixed discovery catalog. Continue full calibration/campaign/admission/freeze, mixed-provider research, policy/AmiBroker and reporting.'
progress['continuation_audit']['basis']='The actual source identity C_t=Y_(t-2) is retained in new model reports; independent tests and a fixed counterexample expose the original-process scope gap without changing the estimator-only stress law. This is an implemented descriptive diagnostic, not calibrated scientific readiness.'
progress['source_process_scope_checkpoint']={'date':'2026-10-26','status':'FOCUSED_CHECKS_PASS',
    'verification':'docs/reviews/implementation-2026-10-25/source-process-scope-verification-2026-10-26.json',
    'unique_focused_tests':91,'independent_tests':14,'observed_pairs':94,'observed_equal':94,
    'synthetic_pairs':91,'synthetic_unequal':42,'legacy_case_bytes_unchanged':True,
    'provider_calls':0,'original_process_adequacy':'NOT_ASSESSED','scientific_readiness':False,'full_objective_complete':False}
write(progress_path,progress)
observation=json.loads((work/'actual-scope-observation.json').read_text())
write(public/(prefix+'-observation-2026-10-26.json'),observation)
source_names=['trading_researcher/source_process_scope.py','trading_researcher/population_models.py',
    'tests/test_source_process_scope.py','tests/test_source_process_scope_adversarial.py','tests/test_population_runs.py']
review=public/(prefix+'-independent-2026-10-26.json')
assert review.exists(),'Independent review must be completed first'
archive_path=public/(prefix+'-evidence-2026-10-26.zip')
with zipfile.ZipFile(archive_path,'w',zipfile.ZIP_DEFLATED) as archive:
    for name in source_names:archive.write(root/name,'current/'+name)
    for path in sorted(work.glob('2026*')):archive.write(path,'checks/'+path.name)
    for name in ('check.py','baseline.json','source-before.zip','actual_scope.py','actual-scope-profile.json',
                 'actual-scope-observation.json','regressions.py','independent_red.py','publish_evidence.py',
                 'classify_legacy_check.py','historical-check-scope.json'):
        archive.write(work/name,'procedures/'+name)
    archive.write(review,'review/'+review.name)
baseline=json.loads((work/'baseline.json').read_text())
changed_old=[name for name,expected in baseline['files'].items() if not (root/name).is_file() or sha(root/name)!=expected]
allowed={'README.md','docs/architecture/CURRENT_STATE.md','docs/architecture/09_IMPLEMENTATION_BLUEPRINT.md',
    'trading_researcher/POPULATION_MODELS.md','trading_researcher/population_models.py','tests/test_population_runs.py',
    'docs/reviews/implementation-2026-10-25/progress.json'}
assert set(changed_old)<=allowed,changed_old
dirty=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
verification_path=public/(prefix+'-verification-2026-10-26.json')
changed=sorted(set(dirty+new+[verification_path.relative_to(root).as_posix()]))
result={'schema':'source-process-scope-verification/1','date':'2026-10-26',
    'baseline_commit':baseline['head'],'status':'FOCUSED_CHECKS_PASS','unique_focused_tests':len(tests),
    'test_ids':sorted(tests),'checks':records,'changed_files':changed,
    'source_and_test_sha256':{name:sha(root/name) for name in source_names},
    'historical_proposal_check':json.loads((work/'historical-check-scope.json').read_text()),
    'assembly_note':'The first evidence assembly stopped with exit 1 while the independent report was still pending; no release occurred. Assembly then succeeded after the report was present.',
    'preservation':{'baseline_files':len(baseline['files']),'unchanged_files':len(baseline['files'])-len(changed_old),
        'changed_baseline_files':changed_old,'all_other_baseline_hashes_preserved':True},
    'actual_observation':{'path':prefix+'-observation-2026-10-26.json','sha256':sha(public/(prefix+'-observation-2026-10-26.json'))},
    'independent_review':{'path':review.name,'sha256':sha(review)},
    'evidence_archive':{'path':archive_path.name,'sha256':sha(archive_path),'bytes':archive_path.stat().st_size},
    'provider_calls':0,'scientific_readiness':False,'full_objective_complete':False,
    'unverified':['original-process adequacy and fitted nuisance law','complete scientific calibration and information target',
        'general AST equivalence or independent program/feature certification','historical PIT and actual economic usefulness',
        'full repository test suite','scientific admission/campaign/freeze','genuine mixed-provider research and policy/reporting']}
write(verification_path,result)
print(json.dumps({'status':result['status'],'unique_tests':len(tests),'changed_files':len(changed),
    'baseline_unchanged':result['preservation']['unchanged_files'],'archive_bytes':archive_path.stat().st_size,
    'verification_sha256':sha(verification_path)}))
