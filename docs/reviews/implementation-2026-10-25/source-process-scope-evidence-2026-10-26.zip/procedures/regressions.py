"""Run the existing affected pure-family and reference execution suites."""
import sys,unittest
from pathlib import Path
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tests'))
names=['test_family_oracles','test_family_adversarial','test_outcomes','test_expressions']
suite=unittest.TestLoader().loadTestsFromNames(names)
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
