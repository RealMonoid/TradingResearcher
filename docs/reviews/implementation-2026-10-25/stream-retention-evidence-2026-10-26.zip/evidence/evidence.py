"""Bind this measured transport checkpoint to exact tests and preserved sources."""
import datetime,hashlib,json,re,subprocess,sys,unittest,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];work=Path(__file__).parent;out=root/'docs/reviews/implementation-2026-10-25'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
baseline=json.loads((work/'baseline.json').read_text())
checks=[json.loads(p.read_text()) for p in sorted(work.glob('2026*.json'))]
inventory={'test_study_stream_independent.py':17,'test_study_stream_transport.py':2,
    'test_study_runs*.py':13,'test_family_series_runs.py':3,'test_calibration*.py':42,
    'test_family_adversarial.py':9,'test_family_series_adversarial.py':10}
sys.path[:0]=[str(root),str(root/'tests')]
def flatten(suite):
    for item in suite:
        if isinstance(item,unittest.TestSuite):yield from flatten(item)
        else:yield item.id()
ids={p:list(flatten(unittest.TestLoader().discover(str(root/'tests'),pattern=p))) for p in inventory}
all_ids=[item for values in ids.values() for item in values]
assert len(all_ids)==len(set(all_ids))==sum(inventory.values())==96
latest={}
for pattern,count in inventory.items():
    assert len(ids[pattern])==count
    matched=[c for c in checks if '-p' in c['command'] and c['command'][c['command'].index('-p')+1]==pattern]
    assert matched and matched[-1]['exit_code']==0,pattern
    check=matched[-1];log=(work/check['log']).read_text()
    assert re.search(r'Ran '+str(count)+r' tests? ',log) and re.search(r'\nOK(?:\s|$)',log)
    latest[pattern]=check['log']
changed=set(subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines())
changed.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines())
code=sorted(n for n in changed if n.startswith(('trading_researcher/','tests/')) and n.endswith(('.py','.zip')))
preserved=[n for n in baseline['files'] if n.startswith(('trading_researcher/','tests/fixtures/')) and n not in changed]
preserved+=['docs/architecture/'+n for n in ('02_DECISION_REGISTER.md','03_REJECTED_DECISIONS.md','04_DEFINITIONS.md',
    '14_RETAIL_RESEARCH_CONTRACT.md','05_REQUIREMENTS.md','06_MASTER_ARCHITECTURE.md','07_SCIENTIFIC_EVALUATION.md')]
for name in preserved:assert sha((root/name).read_bytes())==baseline['files'][name],name
review_path=work/'independent-review.json';review=json.loads(review_path.read_text())
assert review['status'].startswith('PASS')
for name,expected in review['source_sha256'].items():assert sha((root/name).read_bytes())==expected,name
published=out/'stream-retention-independent-2026-10-26.json'
with published.open('xb') as target:target.write(review_path.read_bytes())
observations=[json.loads(line) for line in (work/latest['test_study_stream_transport.py']).read_text().splitlines()
    if line.startswith('{"benchmark"')]
assert len(observations)==1 and observations[0]['complete_result_and_stream_equal']
benchmark=observations[0];old,new=benchmark['observations']
assert old['charged_bytes']==93962634 and new['charged_bytes']==19148378
lifecycle=[json.loads(line) for line in (work/latest['test_family_series_runs.py']).read_text().splitlines()
    if line.startswith(('{"development_series_status"','{"final_planned_worlds"'))]
members={name:(root/name).read_bytes() for name in code}
for p in sorted(work.glob('2026*')):members['checks/'+p.name]=p.read_bytes()
for p in (work/'baseline.json',work/'check.py',work/'evidence.py',review_path):members['evidence/'+p.name]=p.read_bytes()
members['evidence/test-identities.json']=(json.dumps(ids,indent=2)+'\n').encode()
with zipfile.ZipFile(work/'source-before.zip') as before:
    for name in code:
        if name in baseline['files']:members['before/'+name]=before.read(name)
for name,raw in members.items():
    if not name.endswith('.zip'):assert not re.search(rb'\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{20,}',raw),name
with zipfile.ZipFile(root/'tests/fixtures/study-source-0f1bf36.zip') as archive:
    for name in archive.namelist():
        raw=archive.read(name)
        assert sha(raw)==baseline['files'][name]
        assert not re.search(rb'\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{20,}',raw),name
archive=out/'stream-retention-evidence-2026-10-26.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as target:
    for name,raw in members.items():target.writestr(name,raw)
value={'schema':'lossless-study-retention-verification/1','status':'CODE_CHECKS_PASS_DOCUMENTATION_PENDING',
    'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent_commit':baseline['head'],
    'unique_focused_tests':96,'test_inventory':inventory,'latest_pass_log_by_suite':latest,'checks':checks,
    'retained_failed_checks':[c['log'] for c in checks if c['exit_code']!=0],
    'initial_failures':'Baseline import failure proves absence only. Independent tests exposed fragmentation-dependent encoding; fixed chunk buffering resolves it. Existing deadline mock lacked new optional callback; interface updated without changing assertions.',
    'paired_actual_pipeline':benchmark,'actual_lifecycle_observations':lifecycle,
    'storage_reduction_percent':100*(1-new['charged_bytes']/old['charged_bytes']),
    'stream_reduction_percent':100*(1-new['stream_bytes']/old['stream_bytes']),
    'projection':{'worlds':1024,'logical_bytes_excluding_setup':new['charged_bytes']*1024,
        'seconds':new['seconds']*1024,'logical_storage_cap_bytes':4*1024**3,'compute_cap_seconds':3600,
        'qualification':'One synthetic paired workload extrapolated; not a full-series measurement. Both caps still exceeded. No speed gain demonstrated.'},
    'source_sha256':{p.relative_to(root).as_posix():sha(p.read_bytes()) for p in sorted((root/'trading_researcher').glob('*.py'))},
    'changed_code_test_sha256':{n:sha((root/n).read_bytes()) for n in code},
    'preserved_sha256':{n:baseline['files'][n] for n in preserved},
    'independent_review_sha256':sha(published.read_bytes()),'evidence_archive':archive.name,
    'evidence_archive_sha256':sha(archive.read_bytes()),'archive_members':len(members),
    'archive_scope':'Changed code/tests, pinned legacy application source, prior changed source, exact commands/exits/logs, test identities and independent review. No market observations, credentials or private registries.',
    'provider_calls':0,'scientific_readiness':False,'full_objective_complete':False,
    'unverified':['Full repository suite and all historical source/runtime versions',
        'Practical complete-series resource feasibility; observed projection exceeds unchanged limits',
        'Complete actual final calibration, nuisance/stress adequacy and justified information target',
        'Scientific admission/freeze, complete campaign/reservation, genuine mixed-provider research, policy/AmiBroker and domain reporting']}
with (out/'stream-retention-verification-2026-10-26.json').open('x',encoding='utf-8') as target:
    target.write(json.dumps(value,indent=2)+'\n')
p=out/'progress.json';progress=json.loads(p.read_text())
progress['continuation_audit']={'previous_goal_turn':'no_progress_verification_only','current_goal_turn':'progress',
    'basis':'Lossless bounded study transport and family byte callback now preserve all actual old/new results and streams with lower measured storage; full-series feasibility remains unresolved.',
    'blocking_threshold_met':False,'full_objective_complete':False}
progress['stream_retention_checkpoint']={'date':'2026-10-26','status':'FOCUSED_CHECKS_PASS','unique_focused_tests':96,
    'verification':'docs/reviews/implementation-2026-10-25/stream-retention-verification-2026-10-26.json',
    'raw_charged_bytes':old['charged_bytes'],'encoded_charged_bytes':new['charged_bytes'],
    'paired_results_and_decoded_stream_identical':True,'speed_gain_demonstrated':False,
    'provider_calls':0,'scientific_readiness':False,'full_objective_complete':False}
progress['next_action']='Continue resolving full-series storage and computation costs: lossless gzip reduced observed charged bytes by 79.62% but the 1024-world projection still exceeds 4GiB/60min. Preserve every draw/world/failure. Then complete nuisance/stress adequacy, information targets, actual final calibration, campaign/reservation and scientific freeze, mixed-provider research, policy/AmiBroker and reporting.'
p.write_text(json.dumps(progress,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':value['status'],'unique_tests':96,'code_test_files':len(code),'preserved':len(preserved),
    'archive_bytes':archive.stat().st_size,'logical_bytes_reduction_percent':value['storage_reduction_percent']}))
