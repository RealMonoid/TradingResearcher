"""Retain bounded continuation evidence, exact checks and unchanged authority."""
import datetime,hashlib,json,re,subprocess,sys,unittest,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];work=Path(__file__).parent;out=root/'docs/reviews/implementation-2026-10-25'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
baseline=json.loads((work/'baseline.json').read_text())
checks=[json.loads(p.read_text()) for p in sorted(work.glob('2026*.json'))]
inventory={'test_study_continuation.py':1,'test_study_continuation_independent.py':23,
    'test_information_study*.py':19,'test_study_runs*.py':13,'test_family_series*.py':13,
    'test_calibration*.py':42,'test_revocations*.py':18}
sys.path[:0]=[str(root),str(root/'tests')]
def flatten(suite):
    for item in suite:
        if isinstance(item,unittest.TestSuite):yield from flatten(item)
        else:yield item.id()
ids={p:list(flatten(unittest.TestLoader().discover(str(root/'tests'),pattern=p))) for p in inventory}
all_ids=[i for values in ids.values() for i in values]
assert len(all_ids)==len(set(all_ids))==sum(inventory.values())==129
latest={}
for pattern,count in inventory.items():
    assert len(ids[pattern])==count
    matched=[c for c in checks if '-p' in c['command'] and '-k' not in c['command']
        and c['command'][c['command'].index('-p')+1]==pattern]
    assert matched and matched[-1]['exit_code']==0,pattern
    check=matched[-1];log=(work/check['log']).read_text()
    assert re.search(r'Ran '+str(count)+r' tests? ',log) and re.search(r'\nOK(?:\s|$)',log)
    latest[pattern]=check['log']
changed=set(subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines())
changed.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines())
code=sorted(n for n in changed if n.startswith(('trading_researcher/','tests/')) and n.endswith('.py'))
assert len([n for n in code if n.startswith('trading_researcher/')])==8
assert len([n for n in code if n.startswith('tests/')])==3
preserved=[n for n in baseline['files'] if n.startswith(('trading_researcher/','tests/')) and n not in changed]
preserved+=['docs/architecture/'+n for n in ('02_DECISION_REGISTER.md','03_REJECTED_DECISIONS.md','04_DEFINITIONS.md',
    '14_RETAIL_RESEARCH_CONTRACT.md','05_REQUIREMENTS.md','06_MASTER_ARCHITECTURE.md','07_SCIENTIFIC_EVALUATION.md',
    '12_TRACEABILITY_MATRIX.md')]
for name in preserved:assert sha((root/name).read_bytes())==baseline['files'][name],name
review_path=work/'independent-review.json';review=json.loads(review_path.read_text())
assert review['status']=='PASS_BOUNDED_LOCAL_RESOURCE_CONTINUATION'
assert not review['remaining_substantiated_production_blockers']
for field in ('source_sha256','canonical_authority_sha256'):
    for name,expected in review[field].items():assert sha((root/name).read_bytes())==expected,name
actual_log=(work/latest['test_study_continuation.py']).read_text()
actual=next(json.loads(line) for line in actual_log.splitlines() if line.startswith('{"actual_development_worlds"'))
assert actual['actual_development_worlds']==4 and actual['actual_final_worlds']==2
assert actual['final_planned_worlds']==1024 and actual['final_count_status']=='NOT_ASSESSED'
for label in ('development_budget','final_budget'):
    assert actual[label]['continuation_storage_bytes']==1048576 and not actual[label]['overrun']
    assert actual[label]['original_max_compute_ms']==90000 and actual[label]['max_compute_ms']==180000
with (out/'study-continuation-independent-2026-10-26.json').open('xb') as target:target.write(review_path.read_bytes())
members={name:(root/name).read_bytes() for name in code}
for p in sorted(work.glob('2026*')):members['checks/'+p.name]=p.read_bytes()
for name in ('baseline.json','check.py','evidence.py','independent-review.json','write_independent_review.py'):
    if (work/name).exists():members['evidence/'+name]=(work/name).read_bytes()
members['evidence/test-identities.json']=(json.dumps(ids,indent=2)+'\n').encode()
with zipfile.ZipFile(work/'source-before.zip') as before:
    for name in code:
        if name in baseline['files']:members['before/'+name]=before.read(name)
for name,raw in members.items():assert not re.search(rb'\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{20,}',raw),name
archive=out/'study-continuation-evidence-2026-10-26.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as target:
    for name,raw in members.items():target.writestr(name,raw)
value={'schema':'study-resource-continuation-verification/1','status':'CODE_CHECKS_PASS_DOCUMENTATION_PENDING',
    'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent_commit':baseline['head'],
    'unique_focused_tests':129,'test_inventory':inventory,'latest_pass_log_by_suite':latest,'checks':checks,
    'retained_failed_checks':[c for c in checks if c['exit_code']!=0],
    'failure_interpretation':'Expected preimplementation API/checkpoint failures; corrected synthetic resolver and minimal source-footprint fixtures; reproduced and fixed missing empty blob_refs, incomplete inherited grant exposure, and revoked development-grant reuse at final setup. The initially proposed blanket denial for all development grants was withdrawn after checking actual release/access semantics; final ancestry remains denied.',
    'actual_lifecycle':actual,
    'actual_scope':'One genuine owned synthetic family lifecycle with six separately replayed worlds, explicit development/final tranches, immutable inputs/seeds, stale-final-source denial and typed development-grant revocation propagated into the final input. A separate legacy family suite and scalar suites also ran; no complete final cohort or scientific campaign is claimed.',
    'source_sha256':{p.relative_to(root).as_posix():sha(p.read_bytes()) for p in sorted((root/'trading_researcher').glob('*.py'))},
    'changed_code_test_sha256':{n:sha((root/n).read_bytes()) for n in code},
    'preserved_sha256':{n:baseline['files'][n] for n in preserved},
    'independent_review_sha256':sha(review_path.read_bytes()),'evidence_archive':archive.name,
    'evidence_archive_sha256':sha(archive.read_bytes()),'archive_members':len(members),
    'archive_scope':'Changed code/tests, their prior bytes, exact check logs/commands, independent review and reproduction procedures. Synthetic fixture results only; no credentials, private registries or market rows.',
    'provider_calls':0,'scientific_readiness':False,'full_objective_complete':False,
    'unverified':['Full repository suite and all possible crash/interleaving states',
        'Global anti-rollback authority across cloned registries and hard OS resource containment',
        'Actual complete final calibration, full-series resource feasibility and market-model/stress adequacy',
        'Justified information target, scientific admission/freeze, complete campaign/selection accounting',
        'Genuine mixed-provider research, policy/AmiBroker, domain reporting and economic usefulness']}
with (out/'study-continuation-verification-2026-10-26.json').open('x',encoding='utf-8') as target:
    target.write(json.dumps(value,indent=2)+'\n')
p=out/'progress.json';progress=json.loads(p.read_text())
progress['continuation_audit']={'previous_goal_turn':'no_progress_verification_only','current_goal_turn':'progress',
    'basis':'Explicit bounded continuation is now consumed by the owned study runner. Chronological costs, authenticated decisions, source/exposure/revocation and actual development/final continuation are tested; complete scientific calibration is not claimed.',
    'blocking_threshold_met':False,'full_objective_complete':False}
progress['study_resource_continuation_checkpoint']={'date':'2026-10-26','status':'FOCUSED_CHECKS_PASS',
    'unique_focused_tests':129,'verification':'docs/reviews/implementation-2026-10-25/study-continuation-verification-2026-10-26.json',
    'actual_development_worlds':4,'actual_final_worlds':2,'final_planned_worlds':1024,'final_count_status':'NOT_ASSESSED',
    'provider_calls':0,'scientific_readiness':False,'full_objective_complete':False}
progress['controls']['evidence-gate']={'status':'SATISFIED',
    'evidence':'129 focused tests pass, including 23 independent cases and actual continued development/final execution; study-continuation-verification-2026-10-26.json retains exact outputs and limits.'}
progress['next_action']='Resolve and retain the actual nuisance/stress/information profile against the observed diagnostic limitations, then execute the complete original development and protected final inventories with explicit justified resource tranches where needed. Do not reclassify the synthetic continuation fixture as calibration or migrate stale final sources. Continue the full scientific admission/campaign/freeze, mixed-provider research, policy/AmiBroker and reporting objective.'
p.write_text(json.dumps(progress,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':value['status'],'unique_tests':129,'code_test_files':len(code),
    'preserved_files':len(preserved),'archive_bytes':archive.stat().st_size,'actual_worlds':6}))
