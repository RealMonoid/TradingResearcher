"""Finalize documentation gates and include the independent review procedure."""
import datetime,hashlib,json,subprocess,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];work=Path(__file__).parent
path=root/'docs/reviews/implementation-2026-10-25/study-continuation-verification-2026-10-26.json'
value=json.loads(path.read_text());assert value['status']=='CODE_CHECKS_PASS_DOCUMENTATION_PENDING'
checks=[json.loads(p.read_text()) for p in sorted(work.glob('2026*.json'))]
commands=[['git','diff','--check']]+[['C:/Users/monoi/AppData/Local/Programs/Python/Python314/python.exe','-B',p] for p in (
    'docs/reviews/verify_retail_contract.py','docs/reviews/verify_system_model.py',
    'docs/reviews/implementation-2026-10-25/verify_implementation.py')]
docs=[]
for command in commands:
    matches=[c for c in checks if c['command']==command]
    assert matches and matches[-1]['exit_code']==0,command
    assert matches[-1]['started_at']>value['created_at'],command
    docs.append(matches[-1])
for key in ('source_sha256','changed_code_test_sha256','preserved_sha256'):
    for name,expected in value[key].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
archive=path.parent/value['evidence_archive']
with zipfile.ZipFile(archive,'a',zipfile.ZIP_DEFLATED) as target:
    for name in ('write-independent-review.py','finalize.py'):
        member='evidence/'+name
        assert member not in target.namelist();target.writestr(member,(work/name).read_bytes())
    for check in docs:
        for name in (check['log'],check['log'].replace('.log','.json')):
            member='checks/'+name
            assert member not in target.namelist();target.writestr(member,(work/name).read_bytes())
    value['archive_members']=len(target.namelist())
value['evidence_archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest()
tracked=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
added=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
value.update(status='PASS',finalized_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    changed_files=sorted(set(tracked+added)),documentation_checks=[{**c,'output':(work/c['log']).read_text()} for c in docs])
path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
result=subprocess.run(['git','diff','--check'],cwd=root,capture_output=True,text=True)
print(json.dumps({'status':value['status'],'changed_files':len(value['changed_files']),
    'unique_focused_tests':value['unique_focused_tests'],'documentation_checks':len(docs),
    'post_write_diff_check_exit':result.returncode,'verification_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}))
raise SystemExit(result.returncode)
