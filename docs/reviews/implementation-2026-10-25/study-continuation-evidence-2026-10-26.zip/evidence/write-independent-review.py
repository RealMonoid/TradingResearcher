"""Freeze the bounded independent continuation review without editing prior evidence."""
import datetime
import hashlib
import json
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(name):
    record_path = WORK / (name + '.json')
    record = json.loads(record_path.read_text(encoding='utf-8'))
    log = WORK / record['log']
    text = log.read_text(encoding='utf-8')
    found = re.search(r'Ran (\d+) tests? in ([0-9.]+)s', text)
    return {**record, 'record_sha256':sha(record_path), 'log_sha256':sha(log),
        'test_count':int(found[1]) if found else None,
        'unittest_seconds':float(found[2]) if found else None}


final = check('20261026T191513-787f84b0')
assert final['exit_code'] == 0 and final['test_count'] == 23
source_names = [
    'trading_researcher/study_resources.py', 'trading_researcher/study_runs.py',
    'trading_researcher/information_study.py', 'trading_researcher/calibration_runs.py',
    'trading_researcher/family_study_runs.py', 'trading_researcher/coordination.py',
    'trading_researcher/storage.py', 'trading_researcher/memory.py', 'trading_researcher/revocations.py',
    'tests/test_study_continuation_independent.py', 'tests/test_information_study.py']
start = datetime.datetime.fromisoformat(final['started_at']).timestamp()
assert all((ROOT / name).stat().st_mtime <= start for name in source_names)
baseline = json.loads((WORK / 'baseline.json').read_text(encoding='utf-8'))
report = {
    'schema':'independent-study-resource-continuation-review/1',
    'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer':'/root/publication_review',
    'status':'PASS_BOUNDED_LOCAL_RESOURCE_CONTINUATION',
    'baseline_commit':baseline['head'],
    'purpose':'Verify explicit bounded resource continuation without changing scientific inventory, arithmetic, prior charges, failure history or protected final-calibration isolation.',
    'authority':{
        'contract':'research-contract/1.0 section 9, adopted by D079; D030 bounded iteration; section 13 technical dependency invalidation',
        'interpretation':'Additional computation requires a recorded decision. The added no-progress counter is an inventory-only conservative operational fence, not a definition or proof of scientific meaningful improvement.',
        'unchanged':'No change to required worlds, seeds, scenario vectors, draws, retry caps, fixed-denominator calibration criteria, source version, protected outcomes or scientific admission.'},
    'findings':[
        {'id':'missing-empty-blob-list', 'status':'FIXED',
         'observation':'All positive grants reached transactional replay, which indexed an absent blob_refs field and raised KeyError. The transaction rolled back.',
         'correction':'New host-issued grants explicitly carry blob_refs: []; successful replay and backup/restore now pass.',
         'red_check':'20261026T190745-0e8f1db7'},
        {'id':'incomplete-inherited-grant-exposure', 'status':'FIXED',
         'observation':'An attempt after two grants referenced the latest grant, but its explicitly retained exposure omitted the earlier grant inherited by that latest grant.',
         'correction':'The new attempt unions the current resource dependency exposure with the original study exposure and direct references.',
         'red_check':'20261026T191231-56fae306'},
        {'id':'revoked-completed-development-grant-at-final-use', 'status':'FIXED',
         'observation':'A completed development attempt became INVALIDATED_BY_DEPENDENCY when its used grant was technically revoked, but the original final-development resolver still accepted the COMPLETE input series.',
         'correction':'Final setup authenticates the latest completed attempt for every world, checks the used grant dependencies and binds those grant IDs into the final input, references, inherited exposure and typed revocation graph. Historical failed attempts are not indiscriminately required.',
         'red_check':'20261026T191358-95d90df8'}],
    'withdrawn_or_corrected_test_assumptions':[
        'The first synthetic fixture patched numerical input resolution only at preparation. Continuation correctly revalidates the exact frozen inputs, so the fixture was corrected to return its unchanged request-specific tuple throughout the test. No production validation was removed.',
        'An initial test assumed all operations-only development grants must cause blanket research-ancestry denial. Current context/release policy does not define that rule. The test was narrowed to protected final ancestry through both source_refs and exposure, while preserving existing development behavior. This was a test-scope correction, not a relaxed final-calibration boundary.'
    ],
    'remaining_substantiated_production_blockers':[],
    'reviewed_invariants':[
        'Only authenticated operator requests dispatch the continuation operation; source/worker-supplied continuation namespaces are reserved.',
        'Each explicit request supplies an exact checkpoint and nonempty bounded tranche of at most 3600000 compute milliseconds and 4 GiB logical storage, including room for 1 MiB decision metadata and the next entire fixed attempt.',
        'The manifest and retained numerical package are immutable. Historical aliases cannot stack a grant at the same consumed checkpoint; the same key and identical request return only their original decision without adding a charge.',
        'Relevant events are replayed chronologically. Temporary reservation overflow remains latched after a smaller known settlement, and a later forged grant cannot hide that prefix. Unknown settlements, outstanding attempts, orphan uncertainty, terminal states and exhausted retries cannot receive a compensating grant.',
        'Complete VERIFIED or INFORMATION_GAP world inventory is the only mechanical progress counter. A third consecutive no-progress grant is refused even when two technical attempts leave a third frozen retry available.',
        'Grant artifact and authoritative event commit atomically. A fault after both inserts rolls back both; the original request can subsequently commit once.',
        'Grants retain the prior grant, original study and inherited exposure. New attempts bind their current grant and recheck that resource dependency before use and settlement.',
        'Final calibration inputs consume usable completed-development grant dependencies and retain those dependencies for future typed invalidation. A budget decision cannot silently update an old final assessment source.',
        'Full backup/restore preserves the checkpoint, grant identity and accumulated charges. Exact retry after restore does not add another tranche.'
    ],
    'checks':{
        'initial_api_red':check('20261026T190420-61ba2de8'),
        'no_progress_preimplementation_red':check('20261026T190546-fb7022b7'),
        'fixture_resolution_error_retained':check('20261026T190607-15544a85'),
        'empty_blob_field_red':check('20261026T190745-0e8f1db7'),
        'inherited_exposure_red':check('20261026T191231-56fae306'),
        'completed_development_dependency_red':check('20261026T191358-95d90df8'),
        'independent_final_green':final,
        'unique_independent_tests':23,
        'other_runs':'The parent owns separate genuine child/replay lifecycle and affected regression runs. Their latest final runs were not yet inspected by this reviewer at report creation; no result is inferred here.'},
    'test_evidence_scope':{
        'real':'Temporary owned SQLite registry; authenticated public operations; actual source/blob retention; event replay; typed revocation; backup/restore; injected transactional failure.',
        'synthetic':'Only _study_inputs numeric-data resolution is replaced with an exact request-specific fixed tuple. Host observation events establish selected arithmetic histories. Two orchestration cases replace execute_attempt with an explicit synthetic INFORMATION_GAP result and two placeholder proofs.',
        'not_claimed':'These synthetic observations are not numerical scientific worlds or independent child replay. The separate parent integration must establish the actual continued-calculator lifecycle.'},
    'limitations':[
        'This bounded local review is not the full repository suite or a completed final calibration.',
        'A grant is permission to use another bounded tranche for unchanged work, not scientific acceptance, an information target, market-model adequacy or profitability.',
        'Logical storage and parent elapsed-work accounting are retained; this does not create an operating-system disk, memory or CPU quota.',
        'The no-progress counter does not certify that D030 meaningful improvement occurred; explicit operator rationale and the existing scientific decision boundaries remain necessary.',
        'Source-stale final studies remain blocked. No automatic migration, seed reset or selective replacement is provided.',
        'A complete backup preserves the known ledger. Protection against separately running or deliberately rolling back older registry copies is not established without an external shared authority.',
        'No paid model call, protected market-data read, full 256-world-per-cohort run or actual expanded scientific campaign is performed by this review.'
    ],
    'next_action':'Confirm the separately executed genuine continuation lifecycle and affected regressions, preserve all failed observations, then record a concrete bounded campaign continuation only when its unchanged inventory and remaining resource requirements are reviewable.',
    'source_sha256':{name:sha(ROOT / name) for name in source_names},
    'canonical_authority_sha256':{name:sha(ROOT / name) for name in (
        'docs/architecture/14_RETAIL_RESEARCH_CONTRACT.md', 'docs/architecture/02_DECISION_REGISTER.md')},
    'baseline_evidence_sha256':{'baseline.json':sha(WORK / 'baseline.json'), 'source-before.zip':sha(WORK / 'source-before.zip')},
    'reviewer_changed_files':['tests/test_study_continuation_independent.py',
        '.trf-runtime/study-continuation-checks-2026-10-26/independent-review.json'],
    'procedure_sha256':sha(Path(__file__))}
path = WORK / 'independent-review.json'
with path.open('x', encoding='utf-8', newline='\n') as handle:
    handle.write(json.dumps(report, indent=2) + '\n')
assert json.loads(path.read_text(encoding='utf-8')) == report
print(json.dumps({'path':str(path.relative_to(ROOT)), 'status':report['status'], 'sha256':sha(path),
    'unique_independent_tests':23, 'source_hashes':len(report['source_sha256'])}))
