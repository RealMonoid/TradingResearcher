import hashlib,json
from pathlib import Path
root=Path.cwd();work=Path(__file__).resolve().parent
files=sorted(p for folder in ('trading_researcher','tests','docs') for p in (root/folder).rglob('*') if p.is_file())+[root/'README.md']
value={'files':{p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
with (work/'baseline.json').open('x',encoding='utf-8') as stream:json.dump(value,stream,indent=2)
print(json.dumps({'status':'PASS','files':len(value['files'])}))
