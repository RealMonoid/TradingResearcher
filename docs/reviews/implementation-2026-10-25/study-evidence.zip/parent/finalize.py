"""Retain this bounded implementation checkpoint without rewriting prior evidence."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).resolve().parent
OUT=ROOT/'docs/reviews/implementation-2026-10-25';sys.path.insert(0,str(ROOT))
from trading_researcher.coordination import Broker

def read(path):return json.loads(path.read_text(encoding='utf-8'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')

checks=read(WORK/'verified-tests-result.json');probe=read(WORK/'real-study-result.json')
review=read(OUT/'study-review.json')
assert checks['status']=='PASS' and checks['exit_code']==0 and checks['source_hashes_unchanged']
assert all(sha(ROOT/name)==value for name,value in checks['source_hashes'].items())
assert probe['status']=='PASS_WITH_EXPLICIT_DEVELOPMENT_ONLY_LIMITS' and probe['exit_code']==0
assert probe['settled_world_restart']==probe['complete_backup_restore']=='PASS'
independent=ROOT/'.trf-runtime/information-study-independent-review-2026-10-25'
owner=read(independent/'owner-tests-result.json')
assert owner['exit_code']==0
baseline=read(WORK/'baseline.json')['files']
preserved={name:value for name,value in baseline.items() if name.startswith('docs/reviews/implementation-2026-10-25/')
    and name not in ('docs/reviews/implementation-2026-10-25/progress.json',
                    'docs/reviews/implementation-2026-10-25/IMPLEMENTATION_SUMMARY_2026-10-25.md')}
assert all(sha(ROOT/name)==value for name,value in preserved.items())

archive=OUT/'study-evidence.zip'
assert not archive.exists()
prior=read(ROOT/'.trf-runtime/nuisance-diagnostics-checks-2026-10-25/real-probe-result.json')
broker=Broker(prior['registry'])
try:
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as bundle:
        for name in checks['source_hashes']:bundle.write(ROOT/name,'source/'+name)
        for path in sorted(WORK.glob('*')):
            if path.is_file() and path.suffix in ('.py','.json','.log'):
                bundle.write(path,'parent/'+path.name)
        for path in sorted(independent.glob('*')):
            if path.is_file() and path.suffix in ('.json','.log'):bundle.write(path,'independent/'+path.name)
        bundle.write(OUT/'study-review.json','independent/study-review.json')
        seen=set()
        for attempt in probe['attempts']:
            for descriptor in attempt['body']['output_blobs'].values():
                identity=descriptor['sha256']
                if identity in seen:continue
                raw=broker._read_blob_bytes(identity)
                assert len(raw)==descriptor['size'] and hashlib.sha256(raw).hexdigest()==identity
                bundle.writestr('blobs/'+identity,raw);seen.add(identity)
finally:broker.close()

progress=read(OUT/'progress.json')
progress['controls']['evidence-gate']={'status':'SATISFIED','evidence':
    '60 focused/regression tests and9 additional independent owner tests PASS, exits0, stable hashes. '
    'Authenticated HTTP three-world study generated and replayed179991 prescribed draws; settled-world restart '
    'and complete backup/restore PASS. These are engineering checks, not model adequacy, power, calibration or N_min.'}
next_action=('Owned finite development studies are implemented and verified. Assess adequate development nuisance/stress '
    'models and meaningful information targets, then fresh calibration and scientific admission. Genuine provider/measurement '
    'integration, atomic scientific freeze and later AmiBroker/reporting packages remain in the seven-package objective.')
for step in progress['packages']:
    if step['step']==4:
        step['remaining_action']=next_action
        step['evidence']+=['trading_researcher/INFORMATION_STUDIES.md',
            'docs/reviews/implementation-2026-10-25/study-review.json',
            'docs/reviews/implementation-2026-10-25/study-verification.json']
progress['next_action']=next_action
progress['continuation_audit']={'previous_goal_turn':'progress','current_goal_turn':'progress',
    'basis':'Implemented owned finite studies, corrected independently observed defects, completed current-source checks '
        'and actual HTTP generation/estimation/replay/restart/restore probe. Full goal remains incomplete.',
    'blocking_threshold_met':False,'full_objective_complete':False}
write(OUT/'progress.json',progress)

report={'schema':'information-study-verification/1','status':'DOCUMENTATION_CHECKS_PENDING',
    'scope':'Owned uncalibrated development studies; not the complete framework',
    'tests':checks,'independent_owner_check':owner,
    'unique_current_source_tests':69,
    'probe':{key:probe[key] for key in ('status','exit_code','study_id','wall_seconds','settled_world_restart',
        'complete_backup_restore','prescribed_draws_generated','prescribed_draws_replayed','qualification')},
    'review_sha256':sha(OUT/'study-review.json'),'evidence_archive':{'path':archive.name,'sha256':sha(archive)},
    'baseline_qualification':'Preimplementation source/red-test baseline; parent test_information_study.py already existed '
        'at capture and is explicitly included in changed files.',
    'preserved_prior_evidence_files':len(preserved),'preserved_prior_evidence_sha256':preserved,
    'unverified':['No fitted/adequate market nuisance law or reliable power estimate.',
        'No scientific N_min, fresh256-world calibration, semantic/data acceptance or atomic scientific freeze.',
        'No full regression rerun for this source snapshot; preceding405-test run is historical.',
        'No abrupt-process-death containment/reclamation; outstanding recovered work is terminal orphan-uncertain.',
        'Logical byte/work accounting is not a hard OS quota or whole-system wall-clock guarantee.',
        'Cost-estimate source is retained operator input, not an authenticated benchmark.',
        'No genuine LLM provider call, autonomous research result, new AmiBroker adapter, monitoring delivery or profitability.',
        'No commit or GitHub publication of this continuation.']}
path=OUT/'study-verification.json';assert not path.exists();write(path,report)
gates=[]
for label,command in [('retail-contract',[sys.executable,'-B','docs/reviews/verify_retail_contract.py']),
                      ('git-diff-check',['git','diff','--check'])]:
    completed=subprocess.run(command,cwd=ROOT,capture_output=True)
    log=WORK/(label+'.log');log.write_bytes(completed.stdout+completed.stderr)
    gates.append({'check':label,'command':command,'exit_code':completed.returncode,'log_sha256':sha(log)})
    assert completed.returncode==0,log.read_text(errors='replace')[-3000:]
files=sorted(p for folder in ('trading_researcher','tests','docs') for p in (ROOT/folder).rglob('*') if p.is_file())+[ROOT/'README.md']
changed={p.relative_to(ROOT).as_posix() for p in files if baseline.get(p.relative_to(ROOT).as_posix())!=sha(p)}
changed.add('tests/test_information_study.py')
for name in changed:
    item=ROOT/name
    if item.suffix not in ('.py','.json','.md'):continue
    raw=item.read_text(encoding='utf-8')
    assert not any(line.rstrip()!=line for line in raw.splitlines()),name
    if item.suffix=='.py':ast.parse(raw,filename=name)
    if item.suffix=='.json':json.loads(raw)
assert all(sha(ROOT/name)==value for name,value in checks['source_hashes'].items())
report.update(status='PASS_WITH_EXPLICIT_DEVELOPMENT_AND_SCIENTIFIC_LIMITS',exit_code=0,
    documentation_checks=gates,changed_files=sorted(changed),
    changed_file_sha256={name:sha(ROOT/name) for name in sorted(changed) if ROOT/name!=path},
    source_hashes_rechecked_after_documentation=True)
write(path,report)
print(json.dumps({'status':report['status'],'exit_code':0,'unique_tests':69,'changed_files':len(changed),
    'preserved_prior_evidence_files':len(preserved),'documentation_checks':gates}),flush=True)
