"""Fixed engineering HTTP study on retained development inputs; no calibration."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
import threading
import time

ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from trading_researcher.coordination import Broker
from trading_researcher.server import Client,LocalServer
from trading_researcher.population_models import specification
from trading_researcher.storage import restore_bundle

def hashes():
    return {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted((ROOT/'trading_researcher').glob('*.py'))}

prior=json.loads((ROOT/'.trf-runtime/nuisance-diagnostics-checks-2026-10-25/real-probe-result.json').read_text())
cost_path=ROOT/'.trf-runtime/population-model-checks-2026-10-25/current-world-result.json'
measurement=json.loads(cost_path.read_text());before=hashes();broker=Broker(prior['registry'])
server=None;thread=None;started=time.monotonic();retained={'status':'INCOMPLETE','source_hashes':before}
try:
    server=LocalServer(broker);thread=threading.Thread(target=server.serve_forever);thread.start()
    client=Client(server.url,broker.admin_token,timeout=180)
    estimate={'world_time_rows':128,'observed_compute_ms':19756,
        'observed_storage_bytes':measurement['world_blob']['size']+(cost_path.parent/'current-draws.jsonl').stat().st_size,
        'qualification':'Prior single-world engineering measurement: generation/replay8.573s plus one bootstrap11.183s. '
            'Not a measured complete study attempt or budget guarantee; study adds bootstrap replay and bookkeeping. '
            'Retained measurement SHA256 '+hashlib.sha256(cost_path.read_bytes()).hexdigest()}
    cost=client.call('add_source',body={'schema':'development-study-cost-estimate/1',**estimate},data_class='development')
    profile={'specifications':[specification(4,Fraction(1,2),Fraction(1,2),
        'Predeclared homogeneous binary and persistent joint-mask stress; not a fitted or adequate market model.')],
        'targets':[16],'worlds_per_cell':1,'seed':2026102503,
        'mc_noncoverage':{'numerator':'1','denominator':'100'},'outer_noncoverage':{'numerator':'1','denominator':'20'},
        'budget':{'max_compute_ms':300000,'attempt_compute_ms':90000,'max_storage_bytes':1024**3,
            'attempt_storage_bytes':256*1024**2,'max_attempts':1},'cost_estimate':{'source_ref':cost['id'],**estimate}}
    request={'key':'information-study-http-20261025-01',
        **{key:prior[key] for key in ('plan_id','execution_id','diagnostics_id')},'profile':profile}
    with (WORK/'real-study-profile.json').open('x',encoding='utf-8') as stream:json.dump(request,stream,indent=2)
    study=client.call('prepare_information_study',**request)
    retained['study_id']=study['id'];retained['input_capsule']=study
    assert client.call('prepare_information_study',**{**request,'key':request['key']+'-alias'})==study
    view=client.call('inspect_information_study',study_id=study['id']);views=[view]
    while view['status']=='READY':
        view=client.call('advance_information_study',study_id=study['id']);views.append(view)
        print(json.dumps({'status':view['status'],'worlds':view['summary']['recorded_worlds'],
            'charged_compute_ms':view['budget']['charged_compute_ms']}),flush=True)
        if len(views)==2 and view['status']=='READY':
            server.shutdown();server.server_close();thread.join();broker.close()
            server=None;thread=None;broker=Broker(prior['registry'])
            server=LocalServer(broker);thread=threading.Thread(target=server.serve_forever);thread.start()
            client=Client(server.url,broker.admin_token,timeout=180)
            assert client.call('inspect_information_study',study_id=study['id'])==view
            retained['settled_world_restart']='PASS'
    retained['views']=views
    retained['attempts']=[client.call('get_artifact',artifact_id=identity) for identity in view['attempt_artifact_ids']]
    assert view['status']=='COMPLETE',view['status']
    assert view['summary']['recorded_worlds']==3 and view['n_min'] is None and not view['scientific_readiness']
    for attempt in retained['attempts']:
        body=attempt['body'];assert len(body['proofs'])==2
        computation=body['result']['bootstrap']
        assert computation['status'] in ('COMPUTED_UNCALIBRATED','INFORMATION_GAP')
        assert [x['attempted'] for x in computation['cases']]==[19999]*3
    backup=client.call('backup_bundle',destination=str(WORK/'real-study-backup'))
    assert backup['status']=='PASS'
    restored=WORK/'real-study-restored'
    restore_bundle(WORK/'real-study-backup',restored,Path(prior['registry'])/'operator.key')
    other=Broker(restored)
    try:
        assert other.call(other.admin_token,'inspect_information_study',study_id=study['id'])==view
        assert other.call(other.admin_token,'get_artifact',artifact_id=study['id'])==study
        retained['complete_backup_restore']='PASS'
    finally:other.close()
    assert hashes()==before,'Source changed during probe'
    retained.update(status='PASS_WITH_EXPLICIT_DEVELOPMENT_ONLY_LIMITS',exit_code=0,
        prescribed_draws_generated=3*59997,prescribed_draws_replayed=3*59997,
        qualification='Three fixed engineering worlds, one per effect scenario at16 timestamps. No reliable power estimate, '
            'model adequacy, N_min, calibration, scientific admission or market result.')
except BaseException as exc:
    retained.update(status='FAILED',exit_code=1,error={'type':type(exc).__name__,'message':str(exc)[:3000]})
    raise
finally:
    retained['wall_seconds']=round(time.monotonic()-started,3)
    if server is not None:server.shutdown();server.server_close()
    if thread is not None:thread.join()
    broker.close()
    with (WORK/'real-study-result.json').open('x',encoding='utf-8') as stream:json.dump(retained,stream,indent=2)
    print(json.dumps({key:retained.get(key) for key in ('status','exit_code','study_id','wall_seconds')}),flush=True)
