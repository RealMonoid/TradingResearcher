"""Retain bounded focused regression commands and exact current-source hashes."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[2];WORK=Path(__file__).resolve().parent
def hashes():
    files=[p for directory in ('trading_researcher','tests') for p in (ROOT/directory).rglob('*')
        if p.is_file() and p.suffix in ('.py','.json')]
    return {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}

before=hashes();checks=[];total=0
patterns=['test_information_study*.py','test_study_runs.py',
          'test_local_runtime.py','test_memory.py','test_storage.py']
for index,pattern in enumerate(patterns):
    command=[sys.executable,'-B','-m','unittest','discover','-s','tests','-p',pattern,'-v']
    log=WORK/('verified-tests-'+str(index)+'.log');started=time.monotonic()
    with log.open('xb') as out:result=subprocess.run(command,cwd=ROOT,stdout=out,stderr=subprocess.STDOUT)
    raw=log.read_bytes();match=re.search(rb'Ran (\d+) tests? in ([\d.]+)s',raw)
    check={'command':command,'exit_code':result.returncode,'wall_seconds':round(time.monotonic()-started,3),
        'tests':int(match[1]) if match else None,'test_seconds':match[2].decode() if match else None,
        'log':log.name,'log_sha256':hashlib.sha256(raw).hexdigest()}
    checks.append(check);total+=check['tests'] or 0
    print(json.dumps(check),flush=True)
    if result.returncode:break
stable=before==hashes();passed=len(checks)==len(patterns) and all(x['exit_code']==0 for x in checks) and stable
report={'status':'PASS' if passed else 'FAILED','checks':checks,'total_tests':total,
    'source_hashes':before,'source_hashes_unchanged':stable,'exit_code':0 if passed else 1}
with (WORK/'verified-tests-result.json').open('x',encoding='utf-8') as stream:json.dump(report,stream,indent=2)
sys.exit(report['exit_code'])
