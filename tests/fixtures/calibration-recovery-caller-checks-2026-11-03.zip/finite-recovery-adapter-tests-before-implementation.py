"""Independent thin recovery-consumer guards, not live/scientific authority.

The genuine owned tiny kernel fixture is reused by composition, never TestCase
inheritance. Old failure timing and kernel transport spies remain explicitly
synthetic. Existing source/certification/input owners are not replaced. No live
Registry, original2048-world series, provider call or protected data is used.
"""
from contextlib import contextmanager
from copy import deepcopy
from fractions import Fraction
import hashlib
import importlib
import importlib.util
import inspect
import json
from pathlib import Path
import shutil
import unittest
from unittest.mock import patch

import test_calibration_recovery_independent as kernel_support
from trading_researcher.codec import Invalid
from trading_researcher.coordination import Broker
from trading_researcher.errors import Conflict, Denied
from trading_researcher.storage import restore_bundle


MODULE = 'tools.calibration.finite_family_recovery'
GIB = 1073741824
MIB = 1048576
PER_WORLD = 7525747
ERRORS = (Invalid, Denied, Conflict, OSError)
BOUND_FIELDS = {'schema', 'authority_binding', 'recovery_id', 'artifact_hash',
    'recovery_artifact_hash', 'request_hash', 'manifest_hash', 'assessment_footprint',
    'calculation_footprint', 'controller_footprint', 'runtime_identity',
    'recovery_path', 'recovery_sha256', 'driver_files'}
PROOF_FIELDS = {'schema', 'status', 'study_id', 'recovery_id', 'input_id',
    'artifact_hash', 'recovery_artifact_hash', 'original_checkpoint', 'prepared_checkpoint',
    'initial_attempt_ids', 'initial_continuation_ids', 'charged_compute_ms',
    'charged_storage_bytes', 'backup_manifest', 'restored_database'}


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')


def identity(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class RecoveryConsumerEntrypointIndependentTests(unittest.TestCase):
    def test_entrypoint_accepts_only_broker_and_sealed_binding(self):
        self.assertIsNotNone(importlib.util.find_spec(MODULE),
            'Recovery consumer absent; this check supplies0 adapter-domain coverage')
        owner = importlib.import_module(MODULE)
        self.assertTrue(callable(getattr(owner, 'consume_next', None)))
        self.assertEqual(['broker', 'bound_run'], list(inspect.signature(owner.consume_next).parameters))

