"""Independent one-off recovery kernel cases; no real-series authorization.

Genuine owned FamilyFixture inputs/certificates and input recomputation are kept.
Historical failure observations, clock faults and substituted final transports
are explicitly synthetic transaction fixtures. The live2048-world study and its
Registry are never opened. New module absence is0 recovery-flow coverage; the
preimplementation check separately demonstrates the correct old300s/max1 fence.
"""
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import importlib
import importlib.util
import inspect
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

import family_run_support as family_support
import test_information_study as scalar_support
from trading_researcher import family_study, study_runs
from trading_researcher.codec import Invalid
from trading_researcher.coordination import Broker
from trading_researcher.errors import Conflict, Denied
from trading_researcher.evaluation_plans import source_bundle
from trading_researcher.family_study_runs import FamilyCalibrationStudies
from trading_researcher.information_study import budget_state
from trading_researcher.storage import restore_bundle


MIB = 1048576
GIB = 1073741824
MODULE = 'trading_researcher.calibration_recovery'
PROFILE = 'scalar-calibration-recovery/1'
INPUT = 'calibration-recovery-input/1'
SOURCE = 'calibration-recovery-source/1'
AMENDMENT = 'calibration-recovery-amendment/1'
RESULT = 'calibration-recovery-attempt/1'
GRANT = 'calibration-recovery-continuation/1'
ERRORS = (Invalid, Denied, Conflict, OSError)
BINDING_FIELDS = {'schema', 'calibration_id', 'registry_path', 'assessment_host',
    'approval_path', 'approval_sha256', 'original_approval_path', 'original_approval_sha256'}
TERMS = {'additional_attempts_for_named_failed_world': 1,
    'attempt_compute_ms_for_retry_and_remaining_original_worlds': 600000,
    'other_worlds_max_attempts': 1, 'attempt_storage_bytes': 268435456,
    'aggregate_compute_ms': 648000000, 'aggregate_logical_bytes': 107374182400,
    'additional_grants_max': 179}


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')


def identity(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class RecoveryPreimplementationIndependentTests(unittest.TestCase):
    def test_original300_fence_and_required_recovery_entrypoint(self):
        config = scalar_support.profile()
        config.update(targets=[16], worlds_per_cell=256,
            responses=['a', 'b'], patterns=[[0, 0], [0, 1], [1, 1], [2, 2]])
        config['budget'].update(max_compute_ms=3600000, attempt_compute_ms=300000,
            max_storage_bytes=4 * GIB, attempt_storage_bytes=256 * MIB, max_attempts=1)
        manifest = family_study.make_final_manifest(
            {**scalar_support.assigned(), 'primary_count': 2}, config)
        original = deepcopy(manifest)
        reservation = {'attempt_id': 'synthetic-old-failed', 'world_id': manifest['worlds'][0]['id'],
                       'compute_ms': 300000, 'storage_bytes': 256 * MIB}
        settlement = {'attempt_id': reservation['attempt_id'], 'compute_ms': 300226,
                      'storage_bytes': MIB, 'usage_known': True}
        historical = budget_state(manifest, [reservation], [settlement])
        self.assertEqual(300226, historical['charged_compute_ms'])
        self.assertIs(historical['overrun'], True)
        self.assertIs(historical['next_reservation_fits'], False)
        for compute in (300000, 600000):
            with self.subTest(new_reserved_compute_ms=compute), self.assertRaises(Invalid):
                budget_state(manifest, [reservation, {**reservation,
                    'attempt_id': 'synthetic-approved-retry', 'compute_ms': compute}], [settlement])
        self.assertEqual(original, manifest)
        self.assertIsNotNone(importlib.util.find_spec(MODULE),
            'Approved recovery owner absent; old fence verified,0 new recovery-flow coverage')
        owner = importlib.import_module(MODULE)
        self.assertEqual(['broker', 'authority_binding'], list(inspect.signature(owner.CalibrationRecovery).parameters))

