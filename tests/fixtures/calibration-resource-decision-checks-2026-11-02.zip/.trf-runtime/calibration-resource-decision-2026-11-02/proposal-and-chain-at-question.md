## Finite calibration resource decision (November 2, 2026)

**Immediate user instruction:** the approved completion task from
SESSION-2026-11-02-CORE-CLOSEOUT requests this decision now, preserving the full
specification, existing method/criteria and original-A hold. Fix concrete
obstacles through actual callers and required independent controls; a retained
gap alone is not a remedy. Additional resources and the run itself remain
unapproved until the user's answer. D099 option A is already approved separately.

**Recommended supported route:** use the existing retained-scalar final owner,
keeping completed development study `37208f834cf223fc3a94a4aa55ddf620d40c6b5f42bbd956d0936e69d507c9ab`
and calculation source `4251242fe7a807ffe7d3568d7df56efdd91c35359375901e5f32c3c5b9b89558`
unchanged. This route already loads the retained calculator and binds a new
assessment/controller source separately; it needs no native final selector or
source transfer. Pin that controller in an isolated exact-source checkout using
the same Python/runtime, so unrelated construction cannot stale a week-long run.
Native timing remains useful engineering evidence, not a reason to delay this
finite option for another optimization branch.

| Item | Concrete proposed inventory or limit |
|---|---|
| Selected conditional calibration | 2 second-order signed-dependence stresses (beta -1/2,+1/2; mask block8, common share1/2) x4 vectors (00,02,11,22) x256 fresh joint worlds =2,048 worlds,20 criterion cohorts; each denominator256 |
| Per world | 4,096 time positions,one instrument,two responses; lengths4/8/16;19,999draws/response/length =119,994generation draws, repeated completely in a fresh separate replay;491,495,424draw calculations over a fully completed inventory |
| Method/criteria | Existing exact arithmetic, PRNG/order, full stream/result checks and MC policy unchanged. Exact95% error upper bound<=0.10; detection lower bound>=0.70; existing80% design target reported separately |
| Observed time | 16 relevant retained-scalar4,096 worlds:238.246..263.655seconds,mean248.14625 including replay. Linear scaling135.54..149.99hours is descriptive,not a forecast. Plan roughly140..180compute-hours plus unmetered setup/check/commit/wait overhead; no promised wall-clock bound |
| Compute proposal | <=180hours aggregate metered compute. Initial<=1hour; <=179additional real-checkpoint grants,each<=1hour. No grant beyond the total/count limits |
| Logical storage proposal | <=100GiB aggregate including initial retention and continuation metadata (<=179MiB). Historical linear projection81.10GiB;100GiB is not the512GiB all-attempt-cap worst case or a completion guarantee |
| Per attempt | Unchanged300seconds,256MiB logical reservation,max1attempt per world; reserve the full next envelope before work |
| Physical results | Measured16world output/JSON sizes imply13.85..14.35GiB additional retained files,conditional on those sizes. This is not81GiB physical and not an NTFS allocated-extent guarantee |
| Physical target | Recommend >=60GiB initially free on a selected local NTFS target: complete primary retention,before/after full backups,one preserved full restore copy,2GiBsetup/temp and4GiBfree floor plus margin. Normal operation without the extra restore copy has a40GiB planning alternative |

Fresh C observation:19,272,409,088bytes (17.95GiB) free at
2026-11-02T18:40:11Z; no other mounted writable volume was observed. C therefore
does not meet either complete capacity plan. The60GiB target derives from a
57,857,471,704byte peak model including the planned full restore,leaving6.12GiB
additional margin. It is capacity planning,not a new scientific gate. Existing
backups on the same disk do not constitute independent hardware-loss protection.
No deletion,move,cleanup,purchase or new storage destination is authorized here.

The finite operator must enforce aggregate/storage/grant-count authority before
every existing API call; the generic tranche API has no such global authorization
field. Grants require actual RESOURCE_STOP,exact checkpoint,full next reservation
plus metadata,no pending/orphan/unknown/overrun/model gap,and progress under D030.
Storage-only grants count toward179. A required failed/unavailable world can
prevent passing complete cohorts under unchanged max1. Stop,retain full charges
and diagnose/fix the concrete cause; no discarded world,reseed,replacement series,
criterion relaxation or automatic optimization campaign follows. Additional
recovery attempts or changed meaning/resources need their actual reviewed authority.

Before preparation/run, verify original complete development/continuation,
retained source/blob/runtime and revocation,exact request/fresh seed separation,
applicability/count plan,finite operator,isolated host and physical/backup readiness.
Recheck free capacity at intended use. No final input,seed/world preparation,
resource grant or numerical run has occurred for this proposal. Setup evidence
includes earlier separate158.883second preparation and approximately106MiB tracked
checkout; neither measures full future setup. Compression,host load,Registry/history
growth,unmetered overhead and failure-space growth remain uncertain.

The read-only time/source and physical inventories are recorded in the existing
progress register. This2,048world recipe is the complete selected shared-template
conditional evaluator inventory,not complete framework/full-process calibration.
Population/nuisance adequacy,applicable N_min and full discovery/selection-process
assessment retain their own existing requirements and pre-outcome inputs. No
unknown full-process repetition count or extra LLM budget is fabricated.

**Decision:** explicitly approve or decline this one finite retained-scalar run
envelope under the prerequisites,and provide/choose physical capacity. Existing
180hour/100GiB/60GiB figures are proposals only; USD0.574585,53settled calls,seven
revoked grants,no protected2024/no retarget and original-A hold remain unchanged.

## Remaining admissible idea-to-report chain (November 2, 2026)

1. **M2 / IF-05 / REQ-005/007/013/019:** implement D099 owned outcome reservation,
   complete development-only campaign/selection chronology and actual scientific
   data/exposure admission. Reuse registry/certification/revocation; independently
   exercise genuine valid and denied evidence through the production resolver,
   atomic conflicts and recovery. Private-admission substitution proves only its
   existing transaction scope. Fix concrete defects rather than merely logging them.
2. **M2 / REQ-005/019/020/024/029:** finalize the bounded supported calibration
   request,source/seed/count/applicability and resource/physical conditions above.
   Once explicitly authorized,run the full fixed inventory with full replay and
   retained failures. Before market admission,qualify applicability/nuisance and
   the justified information target separately; count calibration alone cannot
   supply adequacy. A failed gate requires sourced diagnosis and prompt decision
   for genuinely changed meaning/resources,not another automatic optimization series.
3. **M2 / IF-03/04/05 / REQ-001/002/003/011/026:** use an eligible retained freely
   generated idea outside the original-A hold,or a newly admitted discovery only
   under existing actual packet/funding authority. Preserve original H_idea,
   faithful formalization,independent meaning/feature/composition checks and all
   exposure. Reuse M1's qualified technical witness at its exact source,without
   treating it as scientific evidence or restarting its old paid run.
4. **M2 / IF-05/06/07 / REQ-005/012/019/029:** with every actual prerequisite met,
   atomically freeze the full selected family/allocation/input closure,execute
   the permitted evidence,independently verify full results and apply the frozen
   policy. Retain same-trial attempts; quarantine contradictory/invalid outputs;
   release no partial scientific ranking. Protected2024 is not accessed early.
5. **M2 / IF-08 / REQ-007/013/022/023/028/030:** independently check the faithful
   report,all outcomes/gaps/failures,costs and complete elapsed-time accounting.
   A valid negative or inconclusive outcome is acceptable; low information or
   budget exhaustion is not empirical falsification. Later feedback inherits
   exposure. This closes only that actual cycle,not economic usefulness,
   full-process calibration,policy evaluation or all package6/7 acceptance.

While an answer or authorized compute is pending,only already authorized
independent work directly fulfilling these criteria may proceed. Stop when none
remains; no duplicate audits,unchanged checks or new optimization branches.

