"""Read-only acceptance of an existing, exactly identified development path.

Reuse the independently authored retained-case reconciliation without changing
its source; redirect only its final evidence file into this work directory.
This is construction evidence glue, not a new runtime or scientific evaluator.
"""
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import runpy
import sqlite3
import time
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).parent
AUDIT = ROOT / 'docs/reviews/implementation-2026-10-25'
REGISTRY = ROOT / '.trf-runtime/binance-normalized-registry-2026-10-25'
PREVIOUS = ROOT / '.trf-runtime/paired-breakout-continuation-2026-10-30'


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def file_hash(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def instant(value):
    if isinstance(value, int):
        return datetime.fromtimestamp(value, timezone.utc)
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    assert result.utcoffset().total_seconds() == 0
    return result


def main():
    began = time.monotonic()
    started = datetime.now(timezone.utc).isoformat()
    protected_files = [REGISTRY / 'registry.sqlite3',
                       ROOT / '.trf-runtime/openai-integration-budget.sqlite3']
    protected_files += [path for path in (REGISTRY / 'registry.sqlite3-wal',
        ROOT / '.trf-runtime/openai-integration-budget.sqlite3-wal') if path.exists()]
    before = {str(path.relative_to(ROOT)): file_hash(path) for path in protected_files}
    report_file = AUDIT / 'paired-breakout-result-2026-10-30.json'
    independent_file = AUDIT / 'paired-breakout-independent-audit-2026-10-30.json'
    publication_file = AUDIT / 'paired-breakout-feedback-publication-2026-10-30.json'
    report, independent, publication = map(load, (report_file, independent_file, publication_file))
    assert report['manual_candidate_repair'] is False
    assert report['scientific_readiness'] is False
    assert report['protected_outcomes_accessed'] is False
    artifacts, checks = {}, {}

    with closing(sqlite3.connect((REGISTRY / 'registry.sqlite3').as_uri() + '?mode=ro', uri=True)) as db:
        db.execute('PRAGMA query_only=ON')
        db.execute('BEGIN')

        def artifact(identity):
            if identity not in artifacts:
                row = db.execute('SELECT envelope FROM artifacts WHERE id=?', (identity,)).fetchone()
                assert row is not None, identity
                envelope = json.loads(row[0])
                assert digest(envelope) == identity, identity
                artifacts[identity] = {'id': identity, **envelope}
            return artifacts[identity]

        def owned_call(target, job_id=None):
            if job_id is None:
                rows = db.execute('SELECT id FROM jobs WHERE result_id=? AND state=?',
                                  (target, 'completed')).fetchall()
                assert len(rows) == 1
                job_id = rows[0][0]
            rows = db.execute('SELECT id,epoch_id,owner,request_id,response_id,receipt,state '
                              'FROM research_calls WHERE job_id=?', (job_id,)).fetchall()
            assert len(rows) == 1
            call_id, epoch_id, owner, request_id, response_id, raw_receipt, state = rows[0]
            receipt = json.loads(raw_receipt)
            assert state == 'recorded'
            assert receipt['within_reservation'] and not receipt['late']
            assert not receipt['usage_unknown'] and receipt['accounting_valid']
            request = artifact(request_id)['body']['request']
            response = artifact(response_id)['body']['response']
            assert response['status'] == 'completed'
            assert response['model_identity']['immutable_snapshot_id'] is None
            return {'call_id': call_id, 'epoch_id': epoch_id, 'job_id': job_id,
                    'owner': owner, 'request_id': request_id, 'response_id': response_id,
                    'request_sha256': digest(request), 'output': response['output']}

        idea = artifact(report['original_idea_id'])
        formal = artifact(report['formalization_id'])
        meaning = artifact(report['meaning_review_id'])
        compiled = artifact(report['compiled_id'])
        composition = artifact(report['composition_id'])
        execution = artifact(report['execution_id'])
        discovery = owned_call(idea['id'])
        output_record = discovery['output']['record']
        assert output_record['kind'] == idea['body']['kind'] == 'idea'
        assert output_record['content'] == idea['body']['content']
        assert output_record['scope'] == idea['body']['scope']
        assert discovery['response_id'] in idea['source_refs']
        assert idea['creator'] == discovery['owner'] and idea['origin'] == 'worker'
        epoch = db.execute('SELECT request,created_at FROM research_epochs WHERE id=?',
                           (discovery['epoch_id'],)).fetchone()
        epoch_request = json.loads(epoch[0])
        assert epoch_request['profile']['mode'] == 'live'
        assert len(set(epoch_request['workers'])) == 2
        rows = db.execute('SELECT s.envelope,j.state FROM job_specs s JOIN jobs j ON j.id=s.id '
                          'WHERE json_extract(s.envelope,\'$.research_epoch_id\')=?',
                          (discovery['epoch_id'],)).fetchall()
        discovery_specs = [json.loads(row[0]) for row in rows
                           if json.loads(row[0])['kind'] == 'research-record/v1']
        assert len(discovery_specs) == 2
        assert {spec['context_id'] for spec in discovery_specs} == {epoch_request['context_id']}
        assert {spec['allowed_workers'][0] for spec in discovery_specs} == set(epoch_request['workers'])
        checks['genuine_discovery_and_two_perspective_context_binding'] = True

        formal_call = owned_call(formal['id'])
        assert formal['body']['original_idea'] == idea['body']
        assert formal['body']['idea_id'] == idea['id']
        for name in ('candidate', 'semantic_report'):
            assert formal_call['output'][name] == formal['body'][name]
        assert digest(formal['body']['candidate']) == report['candidate_sha256']
        assert formal['body']['assessment']['status'] == 'STRUCTURE_CHECKED'
        assert formal_call['response_id'] in formal['source_refs']
        checks['original_and_provider_authored_candidate_without_manual_repair'] = True

        assert meaning['body']['formalization_id'] == formal['id']
        assert meaning['body']['independent_semantic_review'] == 'SATISFIED'
        assert not meaning['body']['gaps']
        observation = meaning['body']['review_observations'][0]
        review_call = owned_call(None, observation['job_id'])
        assert observation['call_id'] == review_call['call_id']
        assert review_call['output']['review']['judgment'] == observation['judgment'] == 'faithful'
        assert review_call['owner'] != formal_call['owner']
        assert review_call['epoch_id'] == formal_call['epoch_id'] == report['epoch_id']
        checks['separate_host_observed_meaning_review'] = True

        assert compiled['body']['formalization_id'] == formal['id']
        assert compiled['body']['compilation']['candidate_hash'] == report['candidate_sha256']
        assert composition['body']['compiled_id'] == compiled['id']
        assert composition['body']['status'] == 'CERTIFIED'
        certificates = {name: artifact(compiled['body'][name]) for name in
                        ('feature_certificate_id', 'reference_certificate_id')}
        assert execution['body']['compiled_id'] == compiled['id']
        assert execution['body']['composition_id'] == composition['id']
        assert execution['body']['meaning_assessment_id'] == meaning['id']
        actual_report = execution['body']['result']['report']
        assert set(actual_report) == set(report['execution_report']) | {'request'}
        assert {key: value for key, value in actual_report.items() if key != 'request'} == report['execution_report']
        assert actual_report['request'] == compiled['body']['compilation']['request']
        assert execution['body']['result']['contrast'] == report['contrast']
        for value in (formal, meaning, compiled, composition, execution):
            assert value['body']['scientific_readiness'] is False
        checks['immutable_certificates_execution_and_report_binding'] = True

        manifest = artifact(publication['publication']['manifest_id'])
        cohort = manifest['body']['cohort']
        assert cohort['root_epoch_id'] == discovery['epoch_id']
        assert len(cohort['epoch_ids']) == 4 and len(cohort['jobs']) == len(cohort['calls']) == 8
        assert len(cohort['idea_ids']) == 2 and idea['id'] in cohort['idea_ids']
        for identity in cohort['artifact_ids']:
            artifact(identity)
        retained_gaps = [identity for identity in cohort['artifact_ids'] if
            isinstance(artifacts[identity]['body'], dict) and
            artifacts[identity]['body'].get('assessment', {}).get('status') == 'RETAINED_GAP']
        assert retained_gaps
        for call in cohort['calls']:
            actual = db.execute('SELECT state,request_id,response_id,receipt FROM research_calls WHERE id=?',
                                (call['id'],)).fetchone()
            assert actual[:3] == (call['state'], call['request_id'], call['response_id'])
            assert digest(json.loads(actual[3])) == call['receipt_sha256']
        for value in manifest['body']['retained_research_records']:
            actual = artifact(value['id'])
            assert all(actual[key] == item for key, item in value.items())
        grant = artifact(publication['publication']['grant_id'])
        assert grant['creator'] == grant['origin'] == 'controller'
        assert grant['body']['schema'] == 'paired-breakout-development-feedback-release/1'
        assert grant['body']['scientific_readiness'] is False
        target_epoch = publication['request']['target_epoch']
        assert grant['not_before_epoch'] == grant['body']['target_epoch'] == target_epoch
        for name, kind in (('observation_id', 'observation'),
                           ('experience_id', 'research_experience')):
            identity = publication['publication'][name]
            value = artifact(identity)
            assert value['body']['kind'] == kind
            assert value['source_refs'] == [manifest['id']]
            assert value['body']['scope']['manifest_id'] == manifest['id']
            assert grant['body'][name] == identity
        assert grant['body']['manifest_id'] == manifest['id']
        assert grant['source_refs'] == sorted({manifest['id'],
            publication['publication']['observation_id'], publication['publication']['experience_id']})
        context = json.loads(db.execute('SELECT envelope FROM contexts WHERE id=?',
                                       (publication['context_id'],)).fetchone()[0])
        assert digest(context) == publication['context_id']
        assert context['epoch'] == target_epoch and manifest['id'] in context['artifact_ids']
        assert context['research_time'] >= grant['body']['created_at']
        event = json.loads(db.execute("SELECT envelope FROM events WHERE "
            "json_extract(envelope,'$.details.manifest_id')=? AND "
            "json_extract(envelope,'$.action')='development_feedback_published'",
            (manifest['id'],)).fetchone()[0])
        assert event['details']['grant_id'] == grant['id']
        checks['complete_registered_cohort_gaps_and_later_feedback_retained'] = True

        start = instant(epoch[1])
        idea_at = instant(idea['body']['created_at'])
        end = instant(independent['at_utc'])
        assert start <= idea_at <= instant(formal['body']['created_at'])
        assert instant(execution['body']['created_at']) <= instant(report['recorded_at_utc']) <= end
        timing = {'start_basis': 'Original discovery epoch creation; not last successful continuation',
            'discovery_epoch_created_at_utc': start.isoformat(),
            'original_idea_created_at_utc': idea_at.isoformat(),
            'descriptive_report_recorded_at_utc': report['recorded_at_utc'],
            'independently_checked_report_at_utc': independent['at_utc'],
            'epoch_to_checked_report_elapsed_seconds': (end - start).total_seconds(),
            'idea_to_checked_report_elapsed_seconds': (end - idea_at).total_seconds(),
            'successful_formalization_review_wall_seconds': report['model_pipeline_seconds'],
            'execution_replay_original_audit_ms': report['execution_replay_audit_ms'],
            'all_cohort_epoch_times': [{'id': value['id'], 'created_at_utc':
                instant(value['created_at']).isoformat()} for value in cohort['epochs']],
            'qualification': 'Wall-clock differences from retained timestamps. Stage timers are '
                'not a disjoint full-duration allocation; discovery, repairs, preparation, waits '
                'and operator-active time are not completely classified. Unknown intervals remain '
                'unknown. This is a historical path, not a newly executed or accelerated cycle.'}
        checks['original_start_and_unknown_phase_intervals_retained'] = True

    script = PREVIOUS / 'independent-actual-reconciliation.py'
    assert file_hash(script) == independent['script_sha256']
    historical_output = PREVIOUS / 'independent-actual-accounting-and-execution.json'
    fresh_output = WORK / ('retained-case-reconciliation-' +
                           datetime.now(timezone.utc).strftime('%H%M%S%f') + '.json')
    original_open = Path.open

    def redirect_output(path, mode='r', *args, **kwargs):
        if any(flag in mode for flag in 'wax+'):
            assert path == historical_output, str(path)
            return original_open(fresh_output, mode, *args, **kwargs)
        return original_open(path, mode, *args, **kwargs)

    with patch.object(Path, 'open', redirect_output):
        runpy.run_path(str(script), run_name='__main__')
    fresh = load(fresh_output)
    assert fresh['status'] == 'PASS' and fresh['case_blob'] == independent['case_blob']
    assert fresh['source_files_sha256'] == independent['source_files_sha256']
    checks['fresh_unchanged_independent_case_and_accounting_reconciliation'] = True
    after = {str(path.relative_to(ROOT)): file_hash(path) for path in protected_files}
    assert after == before
    checks['registry_and_spend_ledger_bytes_unchanged'] = True
    inputs = {str(path.relative_to(ROOT)): file_hash(path) for path in
              (report_file, independent_file, publication_file, script)}
    result = {'schema': 'manufacturing-m1-retained-path-acceptance/1',
        'status': 'PASS_RETAINED_PATH_RECONCILIATION', 'started_at_utc': started,
        'completed_at_utc': datetime.now(timezone.utc).isoformat(),
        'elapsed_seconds': time.monotonic() - began, 'checks': checks,
        'inputs_sha256': inputs, 'artifact_ids_checked': sorted(artifacts),
        'root_idea_id': idea['id'], 'execution_id': execution['id'],
        'discovery_call': {key: value for key, value in discovery.items() if key != 'output'},
        'formalization_call': {key: value for key, value in formal_call.items() if key != 'output'},
        'meaning_review_call': {key: value for key, value in review_call.items() if key != 'output'},
        'certificate_ids': {key: value['id'] for key, value in certificates.items()},
        'cohort': {'epochs': 4, 'jobs': 8, 'calls': 8, 'ideas': 2,
                   'artifacts': len(cohort['artifact_ids']), 'retained_gap_ids': retained_gaps,
                   'retained_research_records': len(manifest['body']['retained_research_records'])},
        'timing': timing, 'protected_files_before': before, 'protected_files_after': after,
        'independent_case_check': {'path': str(fresh_output.relative_to(ROOT)),
                                  'sha256': file_hash(fresh_output)},
        'unverified': ['Current installed-source production admission or future eligibility',
            'General model invention/formalization reliability and global originality',
            'Complete active-time attribution or measured research acceleration',
            'Scientific information/calibration, protected assessment, economic value, policy '
            'qualification, monitoring delivery and whole-process improvement benefit'],
        'new_provider_calls': 0, 'scientific_readiness': False}
    with (WORK / 'retained-path-acceptance.json').open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ('status', 'checks', 'cohort', 'timing')}, indent=2))


if __name__ == '__main__':
    main()
