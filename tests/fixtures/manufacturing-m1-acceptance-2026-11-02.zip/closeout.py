"""Preserve M1 evidence and merge one scoped entry into the existing register."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).parent
PROGRESS = ROOT / 'docs/reviews/implementation-2026-10-25/progress.json'
ARCHIVE = ROOT / 'tests/fixtures/manufacturing-m1-acceptance-2026-11-02.zip'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


acceptance = load(WORK / 'retained-path-acceptance.json')
controls = load(WORK / 'control-checks.json')
assert acceptance['status'] == 'PASS_RETAINED_PATH_RECONCILIATION'
assert controls['status'] == 'PASS' and controls['total_tests'] == 34
assert all(acceptance['checks'].values())
failures = [
    {'attempt': 1, 'exit_code': 1,
     'source': 'initial-helper-failed-report-assumption.py',
     'finding': 'Published report is the exact execution report projection excluding request.',
     'correction': 'Check the exact projection plus request equality to the immutable compilation.'},
    {'attempt': 2, 'exit_code': 1,
     'source': 'second-helper-failed-release-column.py',
     'finding': 'Exploratory helper used nonexistent releases.target_epoch; actual column is epoch.',
     'correction': 'Inspect the actual owner rather than infer its storage from a generic name.'},
    {'attempt': 3, 'exit_code': 1,
     'source': 'third-helper-failed-release-epoch.py',
     'finding': 'Owned development feedback uses its immutable release grant, not generic batch releases.',
     'correction': 'Verify the owned grant, typed records, original epoch-126 context and publication event.'},
]
for failure in failures:
    failure['source_sha256'] = sha(WORK / failure['source'])
failure_record = {'status': 'RETAINED_AND_CORRECTED_EVIDENCE_HELPER_FAILURES',
    'failures': failures,
    'qualification': 'Inspection helper defects, not observed runtime/candidate defects; no '
        'original artifact, report, numerical result or research registry was repaired. An earlier '
        'read-only schema probe also selected a nonexistent job_specs.spec column before using envelope.'}
with (WORK / 'failure-history.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(failure_record, indent=2) + '\n')

files = {path.name: path for path in WORK.iterdir() if path.is_file()
         and path.suffix in ('.py', '.json', '.log')}
files['retained-independent-reconciliation.py'] = ROOT / (
    '.trf-runtime/paired-breakout-continuation-2026-10-30/independent-actual-reconciliation.py')
manifest = {name: {'sha256': sha(path), 'size': path.stat().st_size}
            for name, path in sorted(files.items())}
assert not ARCHIVE.exists()
with zipfile.ZipFile(ARCHIVE, 'x', zipfile.ZIP_DEFLATED) as archive:
    for name, path in sorted(files.items()):
        archive.writestr(name, path.read_bytes())
    archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(ARCHIVE) as archive:
    assert archive.testzip() is None
    for name, value in manifest.items():
        raw = archive.read(name)
        assert len(raw) == value['size'] and hashlib.sha256(raw).hexdigest() == value['sha256']

requirements = {
    'REQ-001/002': 'Exact genuine discovery response and untouched original/candidate/semantic mapping; '
        'separate host-observed meaning review. This witness does not establish general invention coverage.',
    'REQ-003/012/018': 'Exact retained certificates, immutable compilation/request, cases and '
        'historical separate replay/original audit; fresh unchanged independent case reconciliation.',
    'REQ-004/006/013/023': 'Two-perspective base binding plus 34 existing current-source synthetic '
        'host/budget/researcher checks: denied access/forgery/protected ancestry, replay/source failure, '
        'revocation, finite usage, refusal/timeout/cancellation and retained public replies.',
    'REQ-028/029': 'Full four-epoch/eight-job/eight-call/two-idea cohort with seven retained gaps, '
        'typed later feedback and original known/unknown timing. No scientific or economic upgrade.',
}
record = {'schema': 'manufacturing-milestones-construction/1',
    'authority': 'SESSION-2026-11-02-MANUFACTURING-MILESTONES: user explicitly requested '
        'implementation of the complete proposed plan.',
    'execution_plan_version': 'execution-plan/0.6',
    'updated_at_utc': datetime.now(timezone.utc).isoformat(),
    'purpose': 'Accept existing genuine technical research evidence before expanding the manufacturing path.',
    'status': 'M1_ACCEPTED_BOUNDED_TECHNICAL_WITNESS_M2_IN_PROGRESS',
    'milestones': {'M1': 'ACCEPTED_BOUNDED_TECHNICAL_WITNESS',
                   'M2': 'IN_PROGRESS_EXISTING_SCIENTIFIC_CORE',
                   'M3': 'OPEN_SEPARATE_POLICY_EVALUATION',
                   'M4': 'OPEN_D087_D088_MONITORING_REPORTING',
                   'M5': 'OPEN_GOVERNED_WHOLE_PROCESS_IMPROVEMENT'},
    'stations': 'CMP-01 through CMP-09 via existing IF-01 through IF-13; '
        'CMP-10/11/12 retain applicability, visibility and governed improvement authority.',
    'completed_acceptance': requirements,
    'root_idea_id': acceptance['root_idea_id'], 'execution_id': acceptance['execution_id'],
    'acceptance_checks': acceptance['checks'], 'cohort': acceptance['cohort'],
    'timing': acceptance['timing'],
    'fresh_checks': {'unchanged_independent_retained_case_reconciliation': 'PASS; 8640 cases; '
        'no numerical evaluator/original-formula rerun',
        'synthetic_control_methods': controls['total_tests'], 'receipts': controls['receipts']},
    'evidence_archive': {'path': ARCHIVE.relative_to(ROOT).as_posix(), 'sha256': sha(ARCHIVE),
        'members': len(manifest), 'scope': 'Exact inspection/evidence sources and receipts; excludes '
            'private registry, market rows/case blob, credentials and any new scientific certificate.'},
    'source_base': 'a0258fef7e3a52af7776906c189a5e101a14c847',
    'historical_input_sha256': acceptance['inputs_sha256'],
    'new_provider_calls': 0, 'scientific_readiness': False,
    'failure_history': failure_record,
    'reuse': 'Existing independent retained-case checker, original model/meaning/execution/report '
        'artifacts and existing independently authored tests. Python sqlite3/json/hashlib/zipfile '
        'only inspect/package project-owned evidence; no new dependency, runtime or audit platform.',
    'construction_effort': {'control_seconds': sum(item['elapsed_seconds'] for item in controls['receipts']),
        'acceptance_seconds': acceptance['elapsed_seconds'],
        'coordination': 'Read-only confirmation of active existing M2 construction chat '
            '01a19b95-777d-7cb2-9d67-8d2cd82ea782; its D099/runtime/resource work is not duplicated.',
        'total_wall_seconds': None,
        'unmeasured': 'Initial exploration, documentation, helper repairs and coordination; '
            'these costs are retained as unknown rather than omitted or attributed to research calls.'},
    'unverified': acceptance['unverified'],
    'preserved_boundaries': ['No production runtime source changes by this slice',
        'Registry and spend-ledger bytes unchanged at retained-path check',
        'Original A hold, all grants/charges, protected assessment and zero capital retained',
        'D099 option A approval is separate from actual admission and resource decisions'],
    'next_action': 'M1 is accepted only for the exact historical technical witness. Continue M2 '
        'in its existing active construction chat: D099 outcome reservation and complete '
        'selection/data/exposure/information/calibration/admission under actual resource authority. '
        'Do not duplicate its writes or label M2-M5 complete. Future complete-cycle timing remains '
        'pending; this historical reconstruction is not an earliest-cycle or acceleration claim.'}
before = PROGRESS.read_bytes()
progress = json.loads(before)
assert 'manufacturing_milestones_2026_11_02' not in progress
progress['manufacturing_milestones_2026_11_02'] = record
assert PROGRESS.read_bytes() == before, 'Concurrent register update; reload before merging'
PROGRESS.write_text(json.dumps(progress, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'status': record['status'], 'evidence_archive': record['evidence_archive'],
                  'changed_register': str(PROGRESS.relative_to(ROOT))}, indent=2))
