"""Retain document gate failures and final passes without replacing old evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).parent
PROGRESS = ROOT / 'docs/reviews/implementation-2026-10-25/progress.json'
ARCHIVE = ROOT / 'tests/fixtures/manufacturing-m1-acceptance-2026-11-02.zip'
KEY = 'manufacturing_milestones_2026_11_02'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


gates = []
for source, command in (
    ('system-model-verification-settled.json', 'python -B docs/reviews/verify_system_model.py'),
    ('retail-contract-verification-settled.json', 'python -B docs/reviews/verify_retail_contract.py')):
    value = load(WORK / source)
    assert value['status'] == 'PASS' and not value['errors']
    gates.append({'command': command, 'status': 'PASS', 'exit_code': 0,
                  'evidence': source, 'sha256': sha(WORK / source)})
command = [sys.executable, '-B', 'docs/reviews/implementation-2026-10-25/verify_implementation.py']
run = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=60)
implementation = json.loads(run.stdout)
assert run.returncode == 0 and implementation['status'] == 'PASS' and not implementation['errors']
path = WORK / 'implementation-verification-settled.json'
with path.open('x', encoding='utf-8') as stream:
    stream.write(run.stdout)
gates.append({'command': command, 'status': 'PASS', 'exit_code': run.returncode,
              'evidence': path.name, 'sha256': sha(path)})
diff = subprocess.run(['git', 'diff', '--check'], cwd=ROOT, capture_output=True, text=True)
assert diff.returncode == 0
documentation = {'status': 'PASS', 'at_utc': datetime.now(timezone.utc).isoformat(), 'gates': gates,
    'git_diff_check_exit': diff.returncode,
    'retained_failures': [
        {'system-model-verification.json': ['Decision forward trace missing', 'Decision reverse trace missing']},
        {'retail-contract-verification.json': ['Inherited D099 trace failures',
            'Adopted scientific policy differs from approved proposal']},
        {'implementation_initial_exit_code': 1,
         'error': 'Unplanned baseline change: docs/architecture/14_RETAIL_RESEARCH_CONTRACT.md'},
        {'retail-contract-verification-final.json': ['Adopted scientific policy differs from approved proposal']}],
    'correction': 'Complete D099 forward/reverse mapping; explicitly allow the independently '
        'approved D099 contract extension in implementation preservation. Move its exact note '
        'to the version-resolution preamble, preserving the original 15 policy sections unchanged. '
        'No comparison was disabled or scientific expectation changed.',
    'unverified': 'Document checks do not establish scientific validity, delivery, economic '
        'usefulness, general model behavior or full M2-M5 completion.'}
with (WORK / 'documentation-checks.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(documentation, indent=2) + '\n')

old_archive_sha = sha(ARCHIVE)
files = [WORK / name for name in (
    'system-model-verification.json', 'system-model-verification-final.json',
    'system-model-verification-settled.json', 'retail-contract-verification.json',
    'retail-contract-verification-final.json', 'retail-contract-verification-settled.json',
    'implementation-verification-settled.json', 'documentation-checks.json', 'finalize_evidence.py')]
extra = {path.name: {'sha256': sha(path), 'size': path.stat().st_size} for path in files}
with zipfile.ZipFile(ARCHIVE, 'a', zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        assert path.name not in archive.namelist()
        archive.writestr(path.name, path.read_bytes())
    archive.writestr('documentation-manifest.json', json.dumps(extra, indent=2) + '\n')
with zipfile.ZipFile(ARCHIVE) as archive:
    assert archive.testzip() is None
    for manifest_name in ('manifest.json', 'documentation-manifest.json'):
        for name, item in json.loads(archive.read(manifest_name)).items():
            raw = archive.read(name)
            assert len(raw) == item['size'] and hashlib.sha256(raw).hexdigest() == item['sha256']

before = PROGRESS.read_bytes()
progress = json.loads(before)
record = progress[KEY]
record['documentation_checks'] = documentation
record['evidence_archive']['prior_local_pre_documentation_sha256'] = old_archive_sha
record['evidence_archive']['sha256'] = sha(ARCHIVE)
record['evidence_archive']['members'] += len(extra)
record['changed_files'] = ['README.md', 'docs/architecture/CURRENT_STATE.md',
    'docs/architecture/12_TRACEABILITY_MATRIX.md', 'docs/architecture/14_RETAIL_RESEARCH_CONTRACT.md',
    'docs/reviews/implementation-2026-10-25/verify_implementation.py',
    'docs/reviews/implementation-2026-10-25/progress.json',
    'docs/reviews/integration-research-2026-10-24/IMPLEMENTATION_SEQUENCE_2026-10-25.md',
    'tests/fixtures/manufacturing-m1-acceptance-2026-11-02.zip']
record['concurrent_scope_preserved'] = 'Active construction chat owns D099 specification/runtime '
    'and resource continuation. Shared documentation consistency fixes are included here; '
    'its decision/register/proposal files remain separate from M1 work.'
record['unverified'].append('Documentation preexisting-file inventory uses the existing dated '
    'adoption checks, not the historical optional system-model CHANGED inventory for this slice.')
text = before.decode('utf-8')
marker = '  "' + KEY + '": '
start = text.index(marker)
value_start = start + len(marker)
_, end = json.JSONDecoder().raw_decode(text, value_start)
replacement = json.dumps({KEY: record}, ensure_ascii=False, indent=2)[2:-2]
result = (text[:start] + replacement + text[end:]).encode('utf-8')
assert json.loads(result) == progress
assert PROGRESS.read_bytes() == before, 'Concurrent register edit; reload before merging'
PROGRESS.write_bytes(result)
assert subprocess.run(['git', 'diff', '--check'], cwd=ROOT, capture_output=True).returncode == 0
print(json.dumps({'status': documentation['status'], 'gates': gates,
    'archive_sha256': sha(ARCHIVE), 'milestone_status': record['status']}, indent=2))
