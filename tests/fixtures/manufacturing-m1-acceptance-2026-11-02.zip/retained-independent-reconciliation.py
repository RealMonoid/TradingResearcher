"""Read-only reconciliation of the authorized retained development result.

No Broker, provider, ledger connection, raw market-row loader, or numerical
research evaluator is used. Only the exact authorized case blob is opened.
The aggregate interval arithmetic below uses independently expressed Fraction
operations; it does not call paired_contrast or Enclosure.
"""
from collections import Counter
from contextlib import closing
from datetime import datetime, timezone
from decimal import Decimal, localcontext
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import time

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).parent
REGISTRY = ROOT / '.trf-runtime/binance-normalized-registry-2026-10-25'
EXECUTION = '8456955e281d7e4f9c50c33ba7763597d87a06ee24c66bd6f1a09bed82003980'
CASE_SHA = '8132450f0ca3a49ea2cd6a60df16e1bda7093e92bd6ad6c2e10ccba69e51b592'
CASE_SIZE = 108043230
SCALE = 2 ** 128
START, END, STEP = 1672531200, 1680307200, 900


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def load(name):
    return json.loads((WORK / (name + '.json')).read_bytes())


def utc(value):
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    assert result.utcoffset().total_seconds() == 0
    return result


def rational(value):
    assert type(value) is dict and set(value) == {'numerator', 'denominator'}
    assert type(value['numerator']) is str and type(value['denominator']) is str
    assert re.fullmatch(r'-?(0|[1-9][0-9]*)', value['numerator'])
    assert re.fullmatch(r'[1-9][0-9]*', value['denominator'])
    result = Fraction(int(value['numerator']), int(value['denominator']))
    assert str(result.numerator) == value['numerator']
    assert str(result.denominator) == value['denominator']
    return result


def interval(value):
    assert type(value) is dict and set(value) == {'schema', 'lower', 'upper'}
    assert value['schema'] == 'bounded-real/1'
    lower, upper = rational(value['lower']), rational(value['upper'])
    assert lower <= upper and upper - lower <= Fraction(1, 10 ** 12)
    return lower, upper


def pair(value):
    return {'numerator': str(value.numerator), 'denominator': str(value.denominator)}


def encoded(bounds):
    return {'schema': 'bounded-real/1', 'lower': pair(bounds[0]), 'upper': pair(bounds[1])}


def outward(bounds):
    low, high = (value * SCALE for value in bounds)
    floor = low.numerator // low.denominator
    ceil = -((-high.numerator) // high.denominator)
    return Fraction(floor, SCALE), Fraction(ceil, SCALE)


def specified_mean(total, count):
    inverse = outward((Fraction(1, count), Fraction(1, count)))
    products = [value * factor for value in total for factor in inverse]
    return outward((min(products), max(products)))


def displayed(bounds):
    with localcontext() as ctx:
        ctx.prec = 55
        return {'lower': str(Decimal(bounds[0].numerator) / Decimal(bounds[0].denominator)),
                'upper': str(Decimal(bounds[1].numerator) / Decimal(bounds[1].denominator)),
                'width': str(Decimal((bounds[1] - bounds[0]).numerator) /
                             Decimal((bounds[1] - bounds[0]).denominator))}


began = time.monotonic()
names = ['prepared-v2', 'run-result', 'grant-closure', 'formalization', 'review',
         'compiled', 'composition', 'execution', 'independent-actual-candidate']
source_hashes = {name + '.json': hashlib.sha256((WORK / (name + '.json')).read_bytes()).hexdigest()
                 for name in names}
prepared, run, closure = (load(name) for name in names[:3])
formal, review, compiled, composition, execution, independent = (load(name) for name in names[3:])
candidate = formal['artifact']['body']['candidate']
candidate_hash = digest(candidate)
assert candidate_hash == independent['candidate_sha256']
assert independent['status'] == 'PASS_SYNTHETIC_AND_SOURCE_MAPPING'
before, after = prepared['usage_before'], run['usage_after']
calls = run['new_calls']
assert len(calls) == 2 and len({call['dispatch_id'] for call in calls}) == 2
assert len({call['metadata']['worker'] for call in calls}) == 2
assert {call['metadata']['epoch_id'] for call in calls} == {closure['revocation']['epoch_id']}
call_summaries = []
for index, call in enumerate(calls):
    receipt = call['receipt']
    usage, details, identity = receipt['usage'], receipt['token_details'], receipt['model_identity']
    assert call['state'] == 'settled' and receipt['response_status'] == 'completed'
    assert call['provider'] == 'openai' and identity == call['model_identity']
    assert identity['requested_model'] == identity['reported_model'] == 'gpt-6.1-sol'
    assert identity['catalog_version'] == '6.1' and identity['immutable_snapshot_id'] is None
    assert identity['immutable_snapshot_status'] == 'UNKNOWN'
    assert usage['input_tokens'] == call['metadata']['counted_input_tokens']
    assert details['cached_input_tokens'] == 0
    assert 0 <= details['reasoning_output_tokens'] <= usage['output_tokens']
    assert usage['cost_units'] == call['charged_nano'] == usage['input_tokens'] * 2500 + usage['output_tokens'] * 10000
    input_cap, output_cap = ((48000, 32000), (76000, 4000))[index]
    assert usage['input_tokens'] + 128 <= input_cap and usage['output_tokens'] <= output_cap
    assert call['reserved_nano'] == input_cap * 2500 + output_cap * 10000
    admitted, settled = utc(call['admitted_at_utc']), utc(call['settled_at_utc'])
    assert admitted.timestamp() == call['created_at'] and admitted <= settled
    if index:
        assert utc(calls[index - 1]['settled_at_utc']) <= admitted
    call_summaries.append({'role': 'formalizer' if index == 0 else 'independent_reviewer',
        'worker': call['metadata']['worker'], 'admitted_at_utc': call['admitted_at_utc'],
        'settled_at_utc': call['settled_at_utc'], 'elapsed_receipt_seconds': int((settled - admitted).total_seconds()),
        'input_tokens': usage['input_tokens'], 'output_tokens': usage['output_tokens'],
        'reasoning_output_tokens': details['reasoning_output_tokens'],
        'charged_nano_usd': call['charged_nano'], 'reserved_nano_usd': call['reserved_nano'],
        'model_identity': identity, 'request_sha256': call['request_sha256']})
tokens_in = sum(call['receipt']['usage']['input_tokens'] for call in calls)
tokens_out = sum(call['receipt']['usage']['output_tokens'] for call in calls)
cost = sum(call['charged_nano'] for call in calls)
assert (tokens_in, tokens_out, tokens_in + tokens_out, cost) == (72173, 23152, 95325, 411952500)
for key, increment in [('calls', 2), ('known_usage_calls', 2), ('known_input_tokens', tokens_in),
                       ('known_output_tokens', tokens_out), ('known_total_tokens', tokens_in + tokens_out),
                       ('exact_total_tokens', tokens_in + tokens_out),
                       ('known_reasoning_output_tokens', 6565)]:
    assert after['totals'][key] == before['totals'][key] + increment
assert after['totals']['unknown_usage_calls'] == before['totals']['unknown_usage_calls'] == 0
assert after['money']['charged_nano'] == before['money']['charged_nano'] + cost == 3956722500
assert after['money']['cap_nano'] == before['money']['cap_nano'] == 5000000000
assert after['money']['available_nano'] == 5000000000 - after['money']['charged_nano'] == 1043277500
assert after['totals']['exact_total_tokens'] == 1064316
assert closure['revocation']['status'] == 'REVOKED'
assert utc(closure['at_utc']) >= utc(calls[-1]['settled_at_utc'])
prior = {}
for name, record in prepared['prior_grants'].items():
    assert record['revoked'] == 1
    retained_calls = json.loads(record['calls'])
    assert retained_calls
    prior[name] = {'revoked': True, 'retained_call_count': len(retained_calls)}

assert execution['id'] == EXECUTION
body = execution['body']
result = body['result']
report, contrast = result['report'], result['contrast']
assert body['status'] == 'DESCRIPTIVE_EXECUTION' and body['error'] is None
assert body['profile'] == 'paired-breakout-development/1' and body['scientific_readiness'] is False
assert body['compiled_id'] == compiled['id'] and body['composition_id'] == composition['id']
assert body['meaning_assessment_id'] == review['assessment']['id']
assert compiled['body']['formalization_id'] == formal['artifact']['id']
assert compiled['body']['compilation']['candidate_hash'] == candidate_hash
assert result['compilation_hash'] == digest(compiled['body']['compilation'])
assert report['request'] == compiled['body']['compilation']['request']
assert body['verification']['result']['result_hash'] == digest(result)
assert body['verification']['result']['case_blob'] == result['case_blob'] == {'sha256': CASE_SHA, 'size': CASE_SIZE}
assert CASE_SHA in execution['blob_refs']
assert body['verification']['request_hash'] == body['independent_original_audit']['request_hash']
assert body['verification']['result']['checked_cases'] == 8640
actual_audit = body['independent_original_audit']['result']
qualification = composition['body']['report']['result']
assert composition['body']['status'] == 'CERTIFIED' and composition['body']['error'] is None
assert qualification['scenario_count'] == 299 and qualification['checked_cases'] == 8970
assert qualification['candidate_hash'] == actual_audit['candidate_hash'] == candidate_hash
assert qualification['oracle_sha256'] == actual_audit['oracle_sha256'] == independent['qualifier']['result']['oracle_sha256']
assert actual_audit['checked_cases'] == 8640 and actual_audit['observed_outcomes'] == 8625
assert actual_audit['scientific_readiness'] is False and qualification['scientific_readiness'] is False

# Only the explicitly authorized execution/capsule metadata and its exact case
# blob are accessed; sqlite mode=ro plus query_only prohibit registry mutation.
with closing(sqlite3.connect((REGISTRY / 'registry.sqlite3').as_uri() + '?mode=ro', uri=True)) as database:
    database.execute('PRAGMA query_only=ON')
    actual = json.loads(database.execute('SELECT envelope FROM artifacts WHERE id=?', (EXECUTION,)).fetchone()[0])
    assert digest(actual) == EXECUTION and {'id': EXECUTION, **actual} == execution
    assert database.execute('SELECT size FROM blobs WHERE sha256=?', (CASE_SHA,)).fetchone()[0] == CASE_SIZE
    assert database.execute('SELECT 1 FROM artifact_blobs WHERE artifact_id=? AND sha256=?', (EXECUTION, CASE_SHA)).fetchone() == (1,)
    capsules = []
    for identity in execution['source_refs']:
        item = json.loads(database.execute('SELECT envelope FROM artifacts WHERE id=?', (identity,)).fetchone()[0])
        assert digest(item) == identity
        if item['body']['schema'] == 'paired-execution-input/1':
            capsules.append({'id': identity, **item})
    assert len(capsules) == 1
    capsule = capsules[0]
    assert capsule['body']['compiled_id'] == compiled['id']
    execution_input = capsule['body']['input']
    assert execution_input['compilation_hash'] == result['compilation_hash']
    assert execution_input['rows'] == result['rows']
    assert execution_input['compilation_input']['candidate'] == candidate
    assert digest({'execution_input': execution_input, 'result': result}) == body['verification']['request_hash']

blob = REGISTRY / 'blobs' / CASE_SHA[:2] / CASE_SHA
assert blob.resolve().is_relative_to(REGISTRY.resolve())
assert not blob.is_symlink() and not any(part.is_symlink() or part.is_junction() for part in (blob, blob.parent, blob.parent.parent))
states, reasons, conditions = Counter(), Counter(), Counter()
cross = {name: {'observed': 0, 'missing': 0} for name in ('true', 'false', 'unknown')}
total = [Fraction(0), Fraction(0)]
conditioned = [Fraction(0), Fraction(0)]
observed = conditioned_n = 0
largest_width = Fraction(0)
single_true = []
checksum, size, case_count = hashlib.sha256(), 0, 0
with blob.open('rb') as stream:
    for raw in stream:
        checksum.update(raw)
        size += len(raw)
        case = json.loads(raw)
        assert (canonical(case) + '\n').encode() == raw
        when = START + case_count * STEP
        assert case['decision_time'] == when < END and case['outcome_anchor'] == when + 5 * STEP
        assert case['pair'] == ['BTCUSDT', 'ETHUSDT'] and case['scope'] is True
        condition = case['condition']
        assert condition is None or type(condition) is bool
        label = 'unknown' if condition is None else 'true' if condition else 'false'
        conditions[label] += 1
        states[case['status']] += 1
        categories = case['diagnostics']['reason_categories']
        assert categories == sorted(set(categories))
        reasons.update(categories)
        assert ('condition_unknown' in categories) is (condition is None)
        assert ('boundary_censoring' in categories) is (when + 5 * STEP >= END)
        has_outcome = case['status'] == 'ELIGIBLE'
        cross[label]['observed' if has_outcome else 'missing'] += 1
        if has_outcome:
            low, high = interval(case['outcome'])
            assert SCALE % low.denominator == SCALE % high.denominator == 0
            total[0] += low
            total[1] += high
            largest_width = max(largest_width, high - low)
            observed += 1
            if condition is True:
                conditioned[0] += low
                conditioned[1] += high
                conditioned_n += 1
                single_true.append({'decision_time': when, 'decision_at_utc': datetime.fromtimestamp(when, timezone.utc).isoformat(),
                    'outcome_anchor': case['outcome_anchor'], 'outcome': case['outcome']})
        else:
            assert case['outcome'] is None
        case_count += 1
assert checksum.hexdigest() == CASE_SHA and size == CASE_SIZE
assert case_count == report['processed_case_count'] == report['expected_case_count'] == 8640
assert all(type(value) is int and value >= 0 for value in report['state_counts'].values())
assert dict(states) == {key: value for key, value in report['state_counts'].items() if value}
assert dict(reasons) == report['diagnostics']['reason_counts']
assert cross == report['diagnostics']['condition_outcome_counts']
assert dict(conditions) == {'unknown': 43, 'false': 8596, 'true': 1}
assert (observed, conditioned_n) == (8625, 1)
assert report['processing_complete'] is report['outcomes_complete'] is True
assert contrast['scope_count'] == observed and contrast['condition_count'] == conditioned_n
assert contrast['status'] == 'DESCRIPTIVE_ONLY' and contrast['scientific_readiness'] is False

# First compute the exact linear averages of all stored lower/upper endpoints.
# Separately reconstruct the specified outward 2^-128 reciprocal and product,
# requiring byte-value equality with the published aggregate enclosures.
exact_scope = tuple(value / observed for value in total)
exact_condition = tuple(value / conditioned_n for value in conditioned)
expected_scope = specified_mean(total, observed)
expected_condition = specified_mean(conditioned, conditioned_n)
expected_effect = outward((expected_condition[0] - expected_scope[1], expected_condition[1] - expected_scope[0]))
aggregate = {}
for name, expected, exact in [('scope_mean', expected_scope, exact_scope),
                              ('condition_mean', expected_condition, exact_condition),
                              ('effect', expected_effect, (exact_condition[0] - exact_scope[1], exact_condition[1] - exact_scope[0]))]:
    assert encoded(expected) == contrast[name]
    assert expected[0] <= exact[0] <= exact[1] <= expected[1]
    aggregate[name] = {'published_exact_rationals': encoded(expected),
        'direct_exact_endpoint_average': encoded(exact), 'decimal_display_only': displayed(expected)}

for name, expected in source_hashes.items():
    assert hashlib.sha256((WORK / name).read_bytes()).hexdigest() == expected
report_out = {'schema': 'independent-paired-breakout-actual-reconciliation/1', 'status': 'PASS',
    'at_utc': datetime.now(timezone.utc).isoformat(), 'elapsed_seconds': time.monotonic() - began,
    'execution_id': EXECUTION, 'candidate_sha256': candidate_hash, 'source_files_sha256': source_hashes,
    'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'purpose': 'Reconcile exact retained call accounting and authorized case bytes, counts and descriptive interval aggregates.',
    'calls': call_summaries, 'new_input_tokens': tokens_in, 'new_output_tokens': tokens_out,
    'new_total_tokens': tokens_in + tokens_out, 'new_charged_nano_usd': cost,
    'aggregate_total_tokens': after['totals']['exact_total_tokens'], 'aggregate_money': after['money'],
    'prior_grants_at_preparation': prior, 'current_grant_closure': closure,
    'composition': {key: qualification[key] for key in ('profile', 'scenario_count', 'checked_cases', 'oracle_sha256')},
    'case_blob': {'sha256': checksum.hexdigest(), 'size': size, 'physically_read_only_hashed': True},
    'case_count': case_count, 'state_counts': dict(states), 'condition_counts': dict(conditions),
    'condition_outcome_counts': cross, 'overlapping_reason_counts': dict(reasons),
    'scope_count': observed, 'condition_count': conditioned_n, 'single_true_case': single_true,
    'maximum_case_interval_width': pair(largest_width), 'aggregate_intervals': aggregate,
    'retained_verification_and_original_audit_consistent': True, 'capsule_id': capsule['id'],
    'candidate_check': {'result_file': 'independent-actual-candidate.json', 'exit_code': 0,
        'elapsed_seconds': independent['elapsed_seconds'], 'scenarios': 299, 'case_checks': 8970,
        'initial_helper_issue': 'The first helper expectation omitted the two valid pair-member parameter-origin paths; exit1 was corrected only in the helper. No candidate/runtime defect or repair.'},
    'reconciliation_helper_correction': 'Initial exit1 compared the database envelope with the exported artifact including its separately stored id. A read-only key comparison established id as the only difference; the helper now verifies digest(envelope)==id and exact remaining bytes/fields. No retained artifact was changed.',
    'warranted_conclusion': 'No discrepancy found in the unchanged candidate synthetic check, saved accounting, exact case blob, case counts or interval aggregates. The result remains descriptive only.',
    'limitations': [
        'This pass reads the authorized retained case blob, not raw source market rows; the separately retained original-formula audit was reconciled, not rerun here.',
        'The arithmetic enclosures bound numerical calculation error; they are not confidence or prediction intervals and do not quantify statistical uncertainty.',
        'One condition-true observed case does not establish scientific support, reproducibility in unseen data, economic value or profitability.',
        'The provider reports model gpt-6.1-sol and catalog version6.1, but no immutable snapshot identifier; version status remains UNKNOWN.',
        'USD charges are conservative retained accounting under the frozen tariff, not a reconciled provider invoice.',
        'Grant closure and prior grants are checked against retained receipts, not by reopening the live spend ledger.',
        'No model call, registry/ledger mutation, raw market-row import, computation rerun, candidate replacement or scientific authority was created.'
    ], 'next_action': 'Retain this descriptive result and its limitations in the selected operational handoff; any later use must preserve existing currentness and authority gates.',
    'scientific_readiness': False}
with (WORK / 'independent-actual-accounting-and-execution.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(report_out, indent=2) + '\n')
print(json.dumps({key: report_out[key] for key in ('status', 'elapsed_seconds', 'execution_id',
    'new_total_tokens', 'new_charged_nano_usd', 'aggregate_total_tokens', 'aggregate_money',
    'case_blob', 'case_count', 'condition_counts', 'scope_count', 'condition_count')}))
