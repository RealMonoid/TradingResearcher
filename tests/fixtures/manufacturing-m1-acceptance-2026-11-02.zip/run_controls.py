"""Retain actual existing M1 control-check receipts; no research dispatch."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).parent
FILES = ('test_paired_breakout_host.py', 'test_paired_breakout_budget.py', 'test_researcher.py')
sources = {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
           for path in list((ROOT / 'trading_researcher').rglob('*.py')) +
           [ROOT / 'tests' / name for name in FILES]}
receipts = []
for name in FILES:
    command = [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tests', '-p', name, '-v']
    began = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=240)
    output = result.stdout + result.stderr
    path = WORK / (name + '.log')
    with path.open('x', encoding='utf-8') as stream:
        stream.write(output)
    count = re.search(r'Ran (\d+) tests?', output)
    receipt = {'command': command, 'exit_code': result.returncode,
               'test_count': int(count.group(1)) if count else 0,
               'elapsed_seconds': time.monotonic() - began,
               'output': str(path.relative_to(ROOT)),
               'output_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    receipts.append(receipt)
    print(json.dumps(receipt), flush=True)
    assert result.returncode == 0 and receipt['test_count'] > 0, output
assert all(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == value
           for name, value in sources.items())
report = {'status': 'PASS', 'at_utc': datetime.now(timezone.utc).isoformat(),
          'receipts': receipts, 'source_sha256': sources,
          'total_tests': sum(value['test_count'] for value in receipts),
          'scope': 'Existing independently authored owned breakout host/budget and '
                   'researcher control cases on the current unchanged source. Synthetic '
                   'providers/admission substitutes do not qualify scientific use or model quality.'}
with (WORK / 'control-checks.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(report, indent=2) + '\n')
