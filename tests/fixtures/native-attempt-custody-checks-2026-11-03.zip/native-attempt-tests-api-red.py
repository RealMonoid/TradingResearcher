"""Independent authenticated-phase custody and parent-only cancellation.

The actual source/case/stream/response/retention owners run over invented native
bytes and simulated numerical transport. Tiny isolated children exercise only
cancellation. Neither custody nor a known deadline grants retry/admission.
"""
from copy import deepcopy
import unittest
from unittest.mock import patch

from trading_researcher import study_runs
from trading_researcher.codec import Invalid


class NativeAttemptCustodyEntrypointIndependentTests(unittest.TestCase):
    def test_untrusted_custody_is_denied_before_tempfiles_or_child(self):
        with patch.object(study_runs.tempfile, 'TemporaryDirectory', side_effect=AssertionError('Input files created')):
            with self.assertRaises(Invalid):
                study_runs.execute_attempt({}, {}, {}, {'id': 'invented'}, b'', lambda: 1,
                    {'materialized_bytes': 0, 'accounting_complete': True}, [], _custody=object())


if __name__ == '__main__':
    unittest.main()
