"""Build a local qualification module with separately pinned build tools."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import sysconfig
import time

import numpy as np

work = Path(__file__).resolve().parent
tool_python = work / 'Scripts/python.exe'
source = work / '_trf_mt_probe.pyx'
generated = work / '_trf_mt_probe.c'
target = work / ('_trf_mt_probe' + sysconfig.get_config_var('EXT_SUFFIX'))
base = Path(sysconfig.get_config_var('base'))
header = Path(np.get_include()) / 'numpy/random/bitgen.h'
assert np.__version__ == '2.3.4' and (base / 'libs/python314.lib').is_file()
commands = [
    [str(tool_python), '-B', '-m', 'cython', '-3', str(source), '-o', str(generated)],
    [str(tool_python), '-B', '-m', 'ziglang', 'cc', '-shared', '-O3',
     '-target', 'x86_64-windows-gnu', '-ffp-contract=off', '-fno-fast-math',
     '-I' + sysconfig.get_path('include'), '-I' + np.get_include(),
     str(generated), str(base / 'libs/python314.lib'), '-o', str(target)],
]
task_environment = dict(os.environ)
task_environment['ZIG_GLOBAL_CACHE_DIR'] = str(work / 'zig-global-cache')
task_environment['ZIG_LOCAL_CACHE_DIR'] = str(work / 'zig-local-cache')
receipt = {'scope': 'local_build_qualification_only',
           'build_tools': {'Cython': '3.3.1', 'ziglang': '0.16.0'},
           'python': sys.version, 'numpy': np.__version__,
           'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
           'bitgen_header_sha256': hashlib.sha256(header.read_bytes()).hexdigest(),
           'commands': commands, 'steps': []}
for command in commands:
    started = time.monotonic()
    result = subprocess.run(command, env=task_environment, cwd=work,
                            capture_output=True, text=True)
    item = {'exit_code': result.returncode,
            'seconds': round(time.monotonic() - started, 6),
            'stdout': result.stdout, 'stderr': result.stderr}
    receipt['steps'].append(item)
    if result.returncode:
        (work / 'build-receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
        print(json.dumps(item), flush=True)
        raise SystemExit(result.returncode)
receipt['binary'] = {'path': str(target), 'size': target.stat().st_size,
                     'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}
receipt['generated_c_sha256'] = hashlib.sha256(generated.read_bytes()).hexdigest()
(work / 'build-receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps({'steps': receipt['steps'], 'binary': receipt['binary']}, indent=2))
