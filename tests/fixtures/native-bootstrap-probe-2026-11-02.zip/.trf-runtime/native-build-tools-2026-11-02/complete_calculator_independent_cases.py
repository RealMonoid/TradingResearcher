"""Fixed independent checks of the experimental complete-calculator adapter.

The unchanged scalar owner is compared with the already generated candidate,
including complete results, callback bytes, and semantic checkpoint order.
This script never calls candidate_module(): that generator writes files. No
resample constant is reduced, and no study, broker, provider or cache is used.
The native experiment intentionally refuses unsupported numeric prefixes;
these integration fixtures exercise its already qualified integer subset.
"""
from copy import deepcopy
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import patch


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests'))

import bootstrap_support
from test_stationary_bootstrap_adversarial import arithmetic_probe, quantity_report
from trading_researcher import stationary_bootstrap as scalar
from trading_researcher.codec import canonical


PINS = {
    'complete_calculator_probe.py': '623fd6b0b1fc562116c24fa33ad0340d2c34282252a3c2b61a4f8a23c9f9f75d',
    'stationary_bootstrap_candidate.py': 'bd297070c755c78313b263efbb6fbb5ea418efe02a9575ee55c4ee4b3233b55f',
    'calculator-candidate.diff': '5b7f063923b523194bd2bb1f2104c565331fe3295f48f8e4c274e7715b4eafb3',
    '_trf_mt_probe.cp314-win_amd64.pyd': '8b0c3f65afde2bdb534289dc3efbbaf568776aad9cade02929d872a48309c4a2',
}
SCALAR_SHA = '0f4978d9015d4e895ab6e5e1f386f055732ca5dc95f6b90333400d6386c60f00'
for name, expected in PINS.items():
    assert hashlib.sha256((HERE / name).read_bytes()).hexdigest() == expected, name
assert hashlib.sha256(Path(scalar.__file__).read_bytes()).hexdigest() == SCALAR_SHA

helper_spec = importlib.util.spec_from_file_location(
    '_independent_native_calculator_context', HERE / 'complete_calculator_probe.py')
assert helper_spec is not None and helper_spec.loader is not None
helper = importlib.util.module_from_spec(helper_spec)
helper_spec.loader.exec_module(helper)
source = (HERE / 'stationary_bootstrap_candidate.py').read_text(encoding='utf-8')
expected_diff = ''.join(difflib.unified_diff(
    Path(scalar.__file__).read_text(encoding='utf-8').splitlines(keepends=True),
    source.splitlines(keepends=True), fromfile='retained-grouped-source',
    tofile='isolated-native-candidate'))
assert expected_diff == (HERE / 'calculator-candidate.diff').read_text(encoding='utf-8')
candidate = types.ModuleType('trading_researcher._independent_native_calculator')
candidate.__package__ = 'trading_researcher'
candidate.__file__ = str(HERE / 'stationary_bootstrap_candidate.py')
candidate.NativeDraw = helper.NativeDraw
exec(compile(source, candidate.__file__, 'exec'), candidate.__dict__)
assert scalar.MAX_RESAMPLES == candidate.MAX_RESAMPLES == 19999


class CallbackFailure(RuntimeError):
    pass


class Clock:
    def __init__(self, control):
        self.control = control

    def monotonic(self):
        self.control.events.append(('clock', self.control.now))
        return self.control.now


class Control:
    def __init__(self, source, design, limits, *, stop_at=None, time_at_stop=None,
                 cancel_after_draw=False, time_after_draw=False, mutate=False,
                 fail_at=None, deadline_interval=None):
        self.source, self.design, self.limits = source, design, limits
        self.stop_at = stop_at
        self.time_at_stop = time_at_stop
        self.cancel_after_draw = cancel_after_draw
        self.time_after_draw = time_after_draw
        self.mutate = mutate
        self.fail_at = fail_at
        self.deadline_interval = deadline_interval
        self.now = 0
        self.cancelled = False
        self.stops = 0
        self.intervals = 0
        self.events = []
        self.records = []
        self.stream = bytearray()
        self.record_hash = hashlib.sha256()
        self.failure = CallbackFailure('fixed complete-calculator callback failure')

    def stop(self):
        self.stops += 1
        scope = sys._getframe(1).f_locals
        # Observe the same semantic global count at the actual checkpoint.
        # The experimental closure holds earlier draws in used_segments and
        # passes its current draw's accepted count as additional_segments.
        used = scope['used_segments'] + scope.get('additional_segments', 0)
        need = scope['need_segment']
        self.events.append(('stop', need, used, len(self.records)))
        if self.time_at_stop == self.stops:
            self.now = 2
        if self.fail_at == ('stop', self.stops):
            raise self.failure
        return self.cancelled or self.stop_at == self.stops

    def on_draw(self, record):
        encoded = canonical(record).encode()
        self.record_hash.update(encoded + b'\n')
        self.records.append((record['length'], record['index'], record['segments'],
                             record['scope_count'], record['condition_count'],
                             record['value'] is None))
        self.events.append(('draw', record['length'], record['index'], record['segments']))
        if self.cancel_after_draw:
            self.cancelled = True
        if self.time_after_draw:
            self.now = 2
        if self.mutate:
            self.source['cases'].clear()
            self.design['randomness']['seed'] = 999
            self.limits['max_segments'] = 1
            record['value'] = 'forged callback value'
            record['path_sha256'] = 'forged callback path'
        if self.fail_at == ('draw', len(self.records)):
            raise self.failure

    def on_bytes(self, encoded):
        assert type(encoded) is bytes
        self.stream.extend(encoded + b'\n')
        self.events.append(('bytes', len(self.records)))
        if self.fail_at == ('bytes', len(self.records)):
            raise self.failure

    def interval(self, original):
        def apply(*args):
            value = original(*args)
            self.intervals += 1
            self.events.append(('interval', self.intervals))
            if self.deadline_interval == self.intervals:
                self.now = 2
            return value
        return apply


def execute(calculator, report_factory=arithmetic_probe, *, cap=100000000,
            base=1, **control_options):
    report = report_factory()
    design = {'base_length': base, 'primary_count': 2,
              'randomness': scalar.randomness(713)}
    limits = {'max_seconds': 1, 'max_segments': cap}
    original = deepcopy((report, design, limits))
    control = Control(report, design, limits, **control_options)
    result = None
    caught = None
    with patch.object(calculator, 'time', Clock(control)), \
            patch.object(calculator, 'basic_interval', control.interval(calculator.basic_interval)):
        try:
            result = calculator.calculate(report, design, limits, stop=control.stop,
                                          on_draw=control.on_draw,
                                          on_draw_bytes=control.on_bytes)
        except CallbackFailure as error:
            assert error is control.failure
            caught = (type(error).__name__, error.args)
    return {'result': result, 'exception': caught, 'trace': control.events,
            'records': control.records, 'stream': bytes(control.stream),
            'record_sha256': control.record_hash.hexdigest(),
            'intervals': control.intervals, 'original': original,
            'caller_after': (report, design, limits)}


class CompleteCalculatorIndependentCases(unittest.TestCase):
    def compare(self, **options):
        before = execute(scalar, **options)
        after = execute(candidate, **options)
        # No result fields, retained bytes or checkpoints are filtered away.
        self.assertEqual(after, before)
        if after['result'] is not None:
            self.assertEqual(canonical(after['result']).encode(),
                             canonical(before['result']).encode())
            self.assertIs(after['result']['scientific_readiness'], False)
            self.assertIs(after['result']['classification_permitted'], False)
        return after

    def assert_stop(self, captured, reason):
        self.assertIsNone(captured['exception'])
        result = captured['result']
        self.assertEqual((result['status'], result['reason']), ('RESOURCE_STOP', reason))
        self.assertIsNone(result['interval'])
        return result

    def assert_stream(self, captured):
        self.assertEqual(hashlib.sha256(captured['stream']).hexdigest(),
                         captured['record_sha256'])
        self.assertEqual(captured['stream'].count(b'\n'), len(captured['records']))

    def test_earliest_prefix_predraw_and_generated_candidate_cancellation(self):
        for checkpoint in (1, 2, 3, 4, 5):
            with self.subTest(stop_at=checkpoint):
                captured = self.compare(stop_at=checkpoint)
                result = self.assert_stop(captured, 'caller_cancelled')
                self.assertEqual(captured['records'], [])
                self.assertEqual(captured['stream'], b'')
                if checkpoint <= 2:
                    self.assertEqual(result['cases'], [])
                elif checkpoint == 3:
                    self.assertEqual(result['cases'][0]['attempted'], 0)
                else:
                    current = result['cases'][0]
                    self.assertEqual((current['attempted'], current['defined'],
                                      current['undefined'], current['interrupted']), (1, 0, 0, 1))
                    self.assertEqual(current['interrupted_draw']['sampled_times'], checkpoint - 4)

    def test_global_segment_cap_across_completed_and_partial_draws(self):
        captured = self.compare(cap=7)
        result = self.assert_stop(captured, 'computation_segment_limit')
        self.assertEqual([(row[0], row[1], row[2]) for row in captured['records']],
                         [(1, 0, 3), (1, 1, 3)])
        current = result['cases'][0]
        self.assertEqual((current['attempted'], current['defined'] + current['undefined'],
                          current['interrupted']), (3, 2, 1))
        self.assertEqual(current['interrupted_draw']['sampled_times'], 1)
        checkpoints = [event for event in captured['trace'] if event[0] == 'stop']
        self.assertEqual(checkpoints[-1][1:3], (True, 7))
        self.assert_stream(captured)

    def test_global_segment_count_survives_complete_prescribed_length(self):
        # The actual 19,999 draws of the first length are retained. A two-row
        # existing fixture keeps this qualification small without changing B.
        first_length_segments = 2 * 19999
        captured = self.compare(report_factory=lambda: bootstrap_support.report(times=2),
                                cap=first_length_segments + 1)
        result = self.assert_stop(captured, 'computation_segment_limit')
        self.assertEqual(result['required_lengths'], [1, 2])
        self.assertEqual(result['cases'][0]['attempted'], 19999)
        self.assertEqual(result['cases'][0]['interrupted'], 0)
        first = [record for record in captured['records'] if record[0] == 1]
        self.assertEqual(len(first), 19999)
        self.assertEqual([record[1] for record in first], list(range(19999)))
        self.assertEqual(sum(record[2] for record in first), first_length_segments)
        self.assertEqual(len(result['cases']), 2)
        partial = result['cases'][1]['interrupted_draw']
        accepted = sum(record[2] for record in captured['records'])
        accepted += 0 if partial is None else partial['segments']
        self.assertEqual(accepted, first_length_segments + 1)
        self.assertEqual([event for event in captured['trace'] if event[0] == 'stop'][-1][2], accepted)
        self.assert_stream(captured)

    def test_postdraw_cancellation_retains_completed_record_and_both_callbacks(self):
        captured = self.compare(cancel_after_draw=True)
        result = self.assert_stop(captured, 'caller_cancelled')
        self.assertEqual(len(captured['records']), 1)
        self.assertEqual((result['cases'][0]['attempted'], result['cases'][0]['interrupted']), (1, 0))
        self.assertEqual(captured['trace'][-2:], [('bytes', 1), ('stop', False, 3, 1)])
        self.assert_stream(captured)

    def test_deterministic_time_check_precedes_segment_cap_but_follows_cancellation(self):
        cancelled = self.compare(stop_at=1, time_at_stop=1)
        self.assert_stop(cancelled, 'caller_cancelled')
        self.assertEqual(cancelled['trace'], [('clock', 0), ('stop', False, 0, 0)])
        prefix = self.compare(time_at_stop=2)
        self.assert_stop(prefix, 'computation_time_limit')
        self.assertEqual(prefix['result']['cases'], [])
        partial = self.compare(cap=1, time_at_stop=5)
        result = self.assert_stop(partial, 'computation_time_limit')
        self.assertEqual(result['cases'][0]['interrupted_draw']['sampled_times'], 1)
        self.assertEqual(partial['records'], [])
        self.assertEqual(partial['trace'][-2:], [('stop', True, 1, 0), ('clock', 2)])

    def test_deadline_after_completed_draw_retains_bytes_before_stopping(self):
        captured = self.compare(time_after_draw=True)
        result = self.assert_stop(captured, 'computation_time_limit')
        self.assertEqual(len(captured['records']), 1)
        self.assertEqual(result['cases'][0]['interrupted'], 0)
        self.assertEqual(captured['trace'][-3:],
                         [('bytes', 1), ('stop', False, 3, 1), ('clock', 2)])
        self.assert_stream(captured)
        cancelled = self.compare(cancel_after_draw=True, time_after_draw=True)
        self.assert_stop(cancelled, 'caller_cancelled')
        self.assertEqual(cancelled['trace'][-1], ('stop', False, 3, 1))

    def test_final_interval_deadline_cannot_publish_a_completed_result(self):
        captured = self.compare(report_factory=bootstrap_support.report,
                                deadline_interval=2)
        result = self.assert_stop(captured, 'computation_time_limit')
        self.assertEqual(captured['intervals'], 2)
        self.assertEqual([case['attempted'] for case in result['cases']], [19999, 19999])
        self.assertEqual(len(captured['records']), 39998)
        self.assertIsNone(result['cases'][-1]['interval'])
        self.assert_stream(captured)

    def test_callback_exceptions_propagate_with_identical_partial_observations(self):
        for failure in (('stop', 1), ('stop', 5), ('draw', 1), ('bytes', 1)):
            with self.subTest(failure=failure):
                captured = self.compare(fail_at=failure)
                self.assertIsNone(captured['result'])
                self.assertEqual(captured['exception'],
                                 ('CallbackFailure', ('fixed complete-calculator callback failure',)))
                if failure[0] == 'stop':
                    self.assertEqual(captured['records'], [])
                elif failure[0] == 'draw':
                    self.assertEqual(len(captured['records']), 1)
                    self.assertEqual(captured['stream'], b'')
                else:
                    self.assertEqual(len(captured['records']), 1)
                    self.assert_stream(captured)

    def test_caller_and_record_mutation_preserve_detached_inputs_and_encoded_bytes(self):
        pristine = self.compare(cap=3)
        mutated = self.compare(cap=3, mutate=True)
        self.assertEqual(mutated['result'], pristine['result'])
        self.assertEqual(mutated['records'], pristine['records'])
        self.assertEqual(mutated['stream'], pristine['stream'])
        self.assertEqual(mutated['trace'], pristine['trace'])
        self.assertEqual(mutated['caller_after'][0]['cases'], [])
        self.assertEqual(mutated['caller_after'][1]['randomness']['seed'], 999)
        self.assertEqual(mutated['caller_after'][2]['max_segments'], 1)
        self.assertEqual(mutated['result']['design'], mutated['original'][1])
        self.assertEqual(mutated['result']['limits'], mutated['original'][2])
        self.assert_stream(mutated)

    def test_signed_integer_fixture_preserves_baseline_and_condition_channels(self):
        def report():
            return quantity_report([['0', '0'], ['-7', '10'], ['4', '-2'], ['9', '0']],
                                   [[True, True], [True, None], [False, True], [True, False]],
                                   [[True, True], [True, True], [True, True], [False, False]])
        captured = self.compare(report_factory=report, cap=11, base=2)
        self.assert_stop(captured, 'computation_segment_limit')
        self.assertGreater(len(captured['records']), 0)
        self.assert_stream(captured)


if __name__ == '__main__':
    print(json.dumps({'scope': 'independent_experimental_complete_calculator_only',
                      'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                      'scalar_sha256': SCALAR_SHA, 'pins': PINS,
                      'resamples_per_length': 19999}, sort_keys=True), flush=True)
    unittest.main(verbosity=2)
