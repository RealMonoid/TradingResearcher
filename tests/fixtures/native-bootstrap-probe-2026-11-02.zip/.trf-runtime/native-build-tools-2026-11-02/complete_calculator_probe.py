"""Isolated candidate integration/timing; never an owned scientific invocation.

Retain the complete generated calculator and its exact diff. Nothing is loaded
through the production registry, and existing frozen callers are not retargeted.
"""
from copy import deepcopy
import difflib
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import random
import statistics
import sys
import time
import types

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests'))
from bootstrap_oracle import binary_report
from trading_researcher import stationary_bootstrap as scalar
from trading_researcher.codec import canonical

SOURCE = ROOT / 'trading_researcher/stationary_bootstrap.py'
SOURCE_SHA = '0f4978d9015d4e895ab6e5e1f386f055732ca5dc95f6b90333400d6386c60f00'
BINARY = HERE / '_trf_mt_probe.cp314-win_amd64.pyd'
spec = importlib.util.spec_from_file_location('_trf_mt_probe', BINARY)
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)


class NativeDraw:
    def __init__(self, seed, rows):
        seeded = random.Random(seed).getstate()[1]
        self.owner = np.random.MT19937(0)
        self.owner.state = {'bit_generator': 'MT19937',
                            'state': {'key': np.array(seeded[:-1], dtype=np.uint32),
                                      'pos': seeded[-1]}}
        self.candidate = native.Candidate(self.owner)
        if not self.candidate.configure_prefixes(rows):
            raise ValueError('This isolated experiment only covers the proven int64 subset')

    def draw(self, length, checker):
        logarithm = None if length == 1 else math.log1p(-1.0 / length)
        return self.candidate.draw(length, logarithm, checker, math.log1p, math.floor)


def candidate_module():
    raw = SOURCE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == SOURCE_SHA
    original = raw.decode('utf-8')
    altered = original
    replacements = [
        ('def interrupted(need_segment=False):',
         'def interrupted(need_segment=False, additional_segments=0):'),
        ("if need_segment and used_segments>=limits['max_segments']:",
         "if need_segment and used_segments+additional_segments>=limits['max_segments']:"),
        ('rng=random.Random(seed)', 'rng=NativeDraw(seed, prefix_rows)'),
    ]
    for old, new in replacements:
        assert altered.count(old) == 1, old
        altered = altered.replace(old, new)
    begin = '            n,total,nc,conditional=0,0,0,0\n'
    end = '            value=None\n'
    assert altered.count(begin) == altered.count(end) == 1
    start = altered.index(begin)
    finish = altered.index(end, start)
    altered = altered[:start] + '''            partial = rng.draw(length, interrupted)
            n = partial['scope_count']
            total = partial['scope_sum']
            nc = partial['condition_count']
            conditional = partial['condition_sum']
            sampled = partial['sampled_times']
            segments = partial['segments']
            used_segments += segments
            path_sha256 = partial['path_sha256']
            reason = partial['reason']
''' + altered[finish:]
    assert altered.count('path_hash.hexdigest()') == 2
    altered = altered.replace('path_hash.hexdigest()', 'path_sha256')
    generated = HERE / 'stationary_bootstrap_candidate.py'
    generated.write_text(altered, encoding='utf-8')
    difference = ''.join(difflib.unified_diff(original.splitlines(keepends=True),
        altered.splitlines(keepends=True), fromfile='retained-grouped-source',
        tofile='isolated-native-candidate'))
    (HERE / 'calculator-candidate.diff').write_text(difference, encoding='utf-8')
    module = types.ModuleType('trading_researcher._qualification_only_calculator')
    module.__package__ = 'trading_researcher'
    module.__file__ = str(generated)
    module.NativeDraw = NativeDraw
    exec(compile(altered, str(generated), 'exec'), module.__dict__)
    return module, hashlib.sha256(generated.read_bytes()).hexdigest()


def inputs():
    report = binary_report(4096)
    design = {'base_length': 8, 'primary_count': 2, 'randomness': scalar.randomness(713),
              'mc_policy': {'schema': 'mc-boundary-policy/1',
                            'noncoverage': {'numerator': '1', 'denominator': '100'},
                            'delta': {'numerator': '1', 'denominator': '20'},
                            'direction': 'positive'}}
    return report, design, {'max_seconds': 180, 'max_segments': 100000000}


def benchmark():
    candidate, generated_sha = candidate_module()
    report, design, limits = inputs()
    receipt = {'scope': 'isolated_complete_calculator_qualification_not_owned_runtime_or_science',
               'fixture': 'tests/bootstrap_oracle.py:binary_report(4096)',
               'scalar_source_sha256': SOURCE_SHA, 'candidate_source_sha256': generated_sha,
               'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               'extension_source_sha256': hashlib.sha256((HERE / '_trf_mt_probe.pyx').read_bytes()).hexdigest(),
               'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
               'numpy': np.__version__, 'python': sys.version,
               'design': design, 'limits': limits, 'observations': []}
    target = HERE / 'complete-calculator-benchmark.json'
    reference = None
    for label in ('scalar', 'native', 'native', 'scalar'):
        calculator = scalar if label == 'scalar' else candidate
        checksum = hashlib.sha256()
        draws = 0

        def retain(encoded):
            nonlocal draws
            checksum.update(encoded + b'\n')
            draws += 1

        started = time.monotonic()
        result = calculator.calculate(report, design, limits, on_draw_bytes=retain)
        seconds = time.monotonic() - started
        encoded_result = canonical(result).encode()
        actual = (encoded_result, checksum.hexdigest(), draws)
        if reference is None:
            reference = actual
        assert actual == reference
        assert result['status'] == 'COMPUTED_UNCALIBRATED'
        assert [case['attempted'] for case in result['cases']] == [19999] * 3
        assert draws == 59997
        observation = {'label': label, 'seconds': seconds,
                       'result_sha256': hashlib.sha256(encoded_result).hexdigest(),
                       'stream_sha256': checksum.hexdigest(), 'draws': draws,
                       'status': result['status']}
        receipt['observations'].append(observation)
        target.write_text(json.dumps(receipt, indent=2), encoding='utf-8')
        print(json.dumps(observation), flush=True)
    medians = {label: statistics.median(item['seconds'] for item in receipt['observations']
                                      if item['label'] == label) for label in ('scalar', 'native')}
    receipt.update(complete=True, median_seconds=medians,
                   ratio_scalar_over_native=medians['scalar'] / medians['native'],
                   identical_complete_results_and_streams=True,
                   limitations='Four fixed ABBA observations, no confidence/general-speed/full-series guarantee. '
                   'No deliberate concurrent project test; background load uncontrolled. Shared runtime/cache, '
                   'source capture, actual caller, replay, resources, fallback and scientific use not qualified.')
    target.write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps({'complete': True, 'median_seconds': medians,
                      'ratio_scalar_over_native': receipt['ratio_scalar_over_native']}), flush=True)


if __name__ == '__main__':
    benchmark()
