"""Independent, fixed-input qualification for the proposed native draw loop.

This script owns no implementation. Its scalar oracle is extracted from the
unchanged archived sampler, whose complete source bytes are pinned below.
Hand arithmetic cases additionally pin accepted paths and exact integer sums.
Only the local qualification extension at BINARY is loaded. No broker, study,
provider, retained research record, production module or file is changed.

An unsupported but valid prefix configuration must clear the old configuration;
an ensuing draw must refuse before RNG use/callbacks. Its exception is purposely
not assigned a type or message. No other invalid-input behavior is specified.
"""
import ast
from copy import deepcopy
from fractions import Fraction
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import random
import struct
import sys
import unittest
import zipfile

import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BINARY = HERE / '_trf_mt_probe.cp314-win_amd64.pyd'
ARCHIVE = ROOT / 'tests/fixtures/study-source-0f1bf36.zip'
ARCHIVE_SHA = 'ee335215005ce138a058ea3499c5424ac929003a9243e80c139ed0c18dc96e2f'
SAMPLER_SHA = '010810c61cbe9fc880aafb19a2c1b16ccedd4912ce8e7dd57e3a9e449dbae6d7'
LIMIT = (1 << 63) - 1
FIELDS = ('scope_count', 'scope_sum', 'condition_count', 'condition_sum')
KEYS = set(FIELDS) | {'sampled_times', 'segments', 'path_sha256', 'reason'}


def frozen_scalar_functions():
    raw_archive = ARCHIVE.read_bytes()
    assert hashlib.sha256(raw_archive).hexdigest() == ARCHIVE_SHA
    with zipfile.ZipFile(ARCHIVE) as archive:
        raw = archive.read('trading_researcher/stationary_bootstrap.py')
    assert hashlib.sha256(raw).hexdigest() == SAMPLER_SHA
    parsed = ast.parse(raw, filename=str(ARCHIVE) + ':stationary_bootstrap.py')
    selected = [node for node in parsed.body if isinstance(node, ast.FunctionDef)
                and node.name in {'_segments', '_segment_sum'}]
    assert {node.name for node in selected} == {'_segments', '_segment_sum'}
    namespace = {'math': math}
    exec(compile(ast.Module(body=selected, type_ignores=[]),
                 '<pinned-010810-scalar-oracle>', 'exec'), namespace)
    return namespace['_segments'], namespace['_segment_sum']


SCALAR_SEGMENTS, SCALAR_SUM = frozen_scalar_functions()
spec = importlib.util.spec_from_file_location('_trf_mt_probe', BINARY)
assert spec is not None and spec.loader is not None
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)
assert Path(native.__file__).resolve() == BINARY


def prefixes(buckets):
    """Construct fixtures from explicit bucket facts, not the candidate helper."""
    rows = [[0, 0, 0, 0]]
    for bucket in buckets:
        rows.append([rows[-1][field] + bucket[field] for field in range(4)])
    return rows


ARITHMETIC = [[0, 0, 0, 0], [2, 10, 1, 0],
              [3, 14, 2, 4], [3, 14, 2, 4]]
# Same independent facts as arithmetic_probe: (0,true),(10,unknown), then
# (4,true), then an empty aligned bucket. Unknown contributes baseline only.
SIGNED = prefixes([(1, -3, 1, -3), (1, 5, 0, 0), (1, -8, 1, -8),
                   (0, 0, 0, 0), (1, 13, 1, 13), (1, -21, 0, 0),
                   (1, 34, 1, 34)])
ALIGNED = prefixes([(0, 0, 0, 0), (1, -7, 0, 0),
                    (2, 11, 1, -3), (1, 5, 1, 5)] * 16)


def paired(seed=0, skip=0):
    reference = random.Random(seed)
    for _ in range(skip):
        reference.getrandbits(32)
    state = reference.getstate()[1]
    owner = np.random.MT19937(0)
    owner.state = {'bit_generator': 'MT19937',
                   'state': {'key': np.array(state[:-1], dtype=np.uint32),
                             'pos': state[-1]}}
    return reference, owner, native.Candidate(owner)


def owner_state(owner):
    state = owner.state['state']
    return tuple(map(int, state['key'])) + (int(state['pos']),)


def path_digest(path):
    checksum = hashlib.sha256()
    for start, count in path:
        checksum.update(struct.pack('>II', start, count))
    return checksum.hexdigest()


class Check:
    def __init__(self, stop_after=None, reason='fixed_resource_stop'):
        self.stop_after = stop_after
        self.reason = reason
        self.calls = []

    def __call__(self, need_segment, accepted):
        self.calls.append((need_segment, accepted))
        if self.stop_after is not None and accepted >= self.stop_after:
            return self.reason
        return None


def scalar_draw(rows, length, rng, checker):
    columns = tuple(zip(*rows))
    sums = [0, 0, 0, 0]
    path = []
    sampled = 0
    reason = None
    # Deliberately preserve the archived generator-before-check ordering. The
    # candidate that encounters a stop has already consumed its RNG words.
    for start, count in SCALAR_SEGMENTS(len(rows) - 1, length, rng):
        reason = checker(True, len(path))
        if reason:
            break
        path.append((start, count))
        sampled += count
        for field in range(4):
            sums[field] += SCALAR_SUM(columns[field], start, count)
    return {**dict(zip(FIELDS, sums)), 'sampled_times': sampled,
            'segments': len(path), 'path_sha256': path_digest(path),
            'reason': reason}, path


class IndependentDrawCases(unittest.TestCase):
    def configure(self, candidate, rows):
        return getattr(candidate, 'configure_prefixes')(rows)

    def draw(self, candidate, length, checker, log1p=math.log1p, floor=math.floor):
        logarithm = None if length == 1 else math.log1p(-1.0 / length)
        return getattr(candidate, 'draw')(length, logarithm, checker, log1p, floor)

    def assert_result(self, actual, expected):
        self.assertIs(type(actual), dict)
        self.assertEqual(set(actual), KEYS)
        self.assertEqual(actual, expected)
        for field in FIELDS + ('sampled_times', 'segments'):
            self.assertIs(type(actual[field]), int, field)

    def compare(self, rows, length, seed=0, skip=0, stop_after=None):
        reference, owner, candidate = paired(seed, skip)
        before = deepcopy(rows)
        self.assertIs(self.configure(candidate, rows), True)
        self.assertEqual(rows, before)
        self.assertEqual(owner_state(owner), reference.getstate()[1])
        reference_check = Check(stop_after)
        expected, path = scalar_draw(before, length, reference, reference_check)
        actual_check = Check(stop_after)
        actual = self.draw(candidate, length, actual_check)
        self.assert_result(actual, expected)
        self.assertEqual(actual_check.calls, reference_check.calls)
        self.assertTrue(all(type(need) is bool and need is True
                            and type(accepted) is int
                            for need, accepted in actual_check.calls))
        self.assertEqual(owner_state(owner), reference.getstate()[1])
        self.assertEqual(rows, before)
        return actual, path, actual_check.calls

    def test_hand_fixed_unknown_baseline_and_empty_grid(self):
        actual, path, calls = self.compare(ARITHMETIC, 1)
        self.assertEqual(path, [(1, 1), (1, 1), (0, 1)])
        self.assert_result(actual, {
            'scope_count': 4, 'scope_sum': 18, 'condition_count': 3,
            'condition_sum': 8, 'sampled_times': 3, 'segments': 3,
            'path_sha256': path_digest([(1, 1), (1, 1), (0, 1)]), 'reason': None})
        self.assertEqual(calls, [(True, 0), (True, 1), (True, 2)])

    def test_hand_fixed_complete_cycle_wrap_and_geometric_truncation(self):
        actual, path, calls = self.compare(ARITHMETIC, 100000)
        # Seed zero first chooses start=1. Its geometric block exceeds the
        # three remaining positions, so a wrapped full cycle is accepted once.
        self.assertEqual(path, [(1, 3)])
        self.assert_result(actual, {
            'scope_count': 3, 'scope_sum': 14, 'condition_count': 2,
            'condition_sum': 4, 'sampled_times': 3, 'segments': 1,
            'path_sha256': path_digest([(1, 3)]), 'reason': None})
        self.assertEqual(calls, [(True, 0)])

    def test_hand_one_position_exact_zero_unknown_and_signed_63_bit_edge(self):
        buckets = [(0, 0, 0, 0), (2, 10, 1, 0), (1, -7, 0, 0),
                   (1, (1 << 53) + 1, 1, -((1 << 53) + 1)),
                   (1, LIMIT, 1, -LIMIT)]
        for bucket in buckets:
            for length in (1, 2, 100000):
                with self.subTest(bucket=bucket, length=length):
                    actual, path, calls = self.compare(prefixes([bucket]), length, 713)
                    self.assertEqual(tuple(actual[field] for field in FIELDS), bucket)
                    self.assertEqual(path, [(0, 1)])
                    self.assertEqual(calls, [(True, 0)])

    def test_full_scalar_paths_signed_aligned_rows_and_final_mt_states(self):
        for name, rows in (('arithmetic', ARITHMETIC), ('signed', SIGNED),
                           ('aligned', ALIGNED)):
            for seed in (0, 713, (1 << 256) - 1):
                for skip in (0, 623, 625):
                    for length in (1, 2, 8, 100000):
                        with self.subTest(rows=name, seed=seed, skip=skip, length=length):
                            self.compare(rows, length, seed, skip)

    def test_hand_first_partial_last_stop_and_cap_at_completion(self):
        expected_facts = {
            0: ((0, 0, 0, 0), []),
            1: ((1, 4, 1, 4), [(1, 1)]),
            2: ((2, 8, 2, 8), [(1, 1), (1, 1)]),
            3: ((4, 18, 3, 8), [(1, 1), (1, 1), (0, 1)]),
        }
        for accepted, (sums, accepted_path) in expected_facts.items():
            with self.subTest(stop_after=accepted):
                actual, path, calls = self.compare(ARITHMETIC, 1, stop_after=accepted)
                self.assertEqual(tuple(actual[field] for field in FIELDS), sums)
                self.assertEqual(path, accepted_path)
                self.assertEqual(actual['path_sha256'], path_digest(accepted_path))
                self.assertEqual(actual['sampled_times'], accepted)
                self.assertEqual(actual['reason'], None if accepted == 3 else 'fixed_resource_stop')
                count = min(accepted + 1, 3)
                self.assertEqual(calls, [(True, index) for index in range(count)])

    def test_geometric_first_last_and_completion_stop_preserve_rng_consumption(self):
        reference = random.Random(713)
        _, path = scalar_draw(ALIGNED, 8, reference, Check())
        self.assertGreater(len(path), 1)
        for accepted in (0, 1, len(path) - 1, len(path)):
            with self.subTest(stop_after=accepted):
                self.compare(ALIGNED, 8, 713, stop_after=accepted)

    def test_length_one_skips_uniform_logarithm_and_floor(self):
        reference, owner, candidate = paired(713, 624)
        self.assertIs(self.configure(candidate, SIGNED), True)
        expected, _ = scalar_draw(SIGNED, 1, reference, Check())

        def unused(*args):
            raise AssertionError('Length one must not evaluate uniform/log1p/floor')

        check = Check()
        self.assert_result(self.draw(candidate, 1, check, unused, unused), expected)
        self.assertEqual(owner_state(owner), reference.getstate()[1])
        self.assertEqual(check.calls, [(True, index) for index in range(7)])

    def test_actual_python_math_callbacks_include_rejected_candidate(self):
        reference, owner, candidate = paired(713)
        self.assertIs(self.configure(candidate, ALIGNED), True)
        expected, _ = scalar_draw(ALIGNED, 8, reference, Check(1))
        math_calls = []

        def logarithm(value):
            math_calls.append(('log1p', value))
            return math.log1p(value)

        def flooring(value):
            math_calls.append(('floor', value))
            return math.floor(value)

        check = Check(1)
        self.assert_result(self.draw(candidate, 8, check, logarithm, flooring), expected)
        self.assertEqual([name for name, _ in math_calls], ['log1p', 'floor'] * 2)
        self.assertEqual(check.calls, [(True, 0), (True, 1)])
        self.assertEqual(owner_state(owner), reference.getstate()[1])

    def test_checker_exception_propagates_after_candidate_rng_consumption(self):
        class CallbackFailure(RuntimeError):
            pass

        sentinel = CallbackFailure('fixed independent callback exception')
        reference, owner, candidate = paired(713, 623)
        self.assertIs(self.configure(candidate, SIGNED), True)
        reference_calls, actual_calls = [], []

        def raising(calls):
            def check(need, accepted):
                calls.append((need, accepted))
                if accepted == 1:
                    raise sentinel
                return None
            return check

        with self.assertRaises(CallbackFailure) as expected_error:
            scalar_draw(SIGNED, 2, reference, raising(reference_calls))
        with self.assertRaises(CallbackFailure) as actual_error:
            self.draw(candidate, 2, raising(actual_calls))
        self.assertIs(expected_error.exception, sentinel)
        self.assertIs(actual_error.exception, sentinel)
        self.assertEqual(actual_calls, [(True, 0), (True, 1)])
        self.assertEqual(actual_calls, reference_calls)
        self.assertEqual(owner_state(owner), reference.getstate()[1])

    def test_configuration_detaches_nested_input_before_and_during_draw(self):
        original = deepcopy(ARITHMETIC)
        for when in ('before', 'during'):
            with self.subTest(mutate=when):
                rows = deepcopy(original)
                reference, owner, candidate = paired(0)
                self.assertIs(self.configure(candidate, rows), True)
                self.assertEqual(rows, original)
                expected, _ = scalar_draw(original, 1, reference, Check())

                def mutate():
                    rows[1][:] = [99, -999, 77, 888]
                    rows[-1][:] = [100, 1234, 88, -1234]
                    rows.append([123, 456, 78, 90])

                if when == 'before':
                    mutate()
                calls = []

                def check(need, accepted):
                    calls.append((need, accepted))
                    if when == 'during' and accepted == 0:
                        mutate()
                    return None

                self.assert_result(self.draw(candidate, 1, check), expected)
                self.assertEqual(calls, [(True, 0), (True, 1), (True, 2)])
                self.assertEqual(owner_state(owner), reference.getstate()[1])
                self.assertEqual(rows, [[0, 0, 0, 0], [99, -999, 77, 888],
                                        [3, 14, 2, 4], [100, 1234, 88, -1234],
                                        [123, 456, 78, 90]])

    def test_valid_unsupported_prefixes_clear_old_configuration_without_rng_use(self):
        unsupported = [
            prefixes([(1, Fraction(1, 3), 1, Fraction(1, 3))]),
            prefixes([(1, Fraction(2), 1, Fraction(2))]),
            prefixes([(1, 1 << 8191, 1, -(1 << 8191))]),
            prefixes([(1, LIMIT + 1, 0, 0)]),
            prefixes([(1, -LIMIT - 1, 0, 0)]),
        ]
        # Check the conservative N*max_abs_delta bound in each of four fields,
        # even when signed cancellation makes the final prefix small.
        for field in range(4):
            bucket = [0, 0, 0, 0]
            bucket[field] = LIMIT // 3 + 1
            unsupported.append(prefixes([bucket, [-x for x in bucket], [0, 0, 0, 0]]))
        for index, rows in enumerate(unsupported):
            with self.subTest(case=index):
                reference, owner, candidate = paired(713)
                initial = reference.getstate()[1]
                self.assertIs(self.configure(candidate, ARITHMETIC), True)
                before = deepcopy(rows)
                self.assertIs(self.configure(candidate, rows), False)
                self.assertEqual(rows, before)
                self.assertEqual(owner_state(owner), initial)
                check = Check()
                with self.assertRaises(Exception):
                    self.draw(candidate, 1, check)
                self.assertEqual(check.calls, [])
                self.assertEqual(owner_state(owner), initial)
                # The next valid configuration starts from the same RNG state.
                self.assertIs(self.configure(candidate, ARITHMETIC), True)
                expected, _ = scalar_draw(ARITHMETIC, 1, reference, Check())
                self.assert_result(self.draw(candidate, 1, Check()), expected)
                self.assertEqual(owner_state(owner), reference.getstate()[1])

    def test_supported_integer_delta_bound_preserves_exact_cancellation(self):
        for field in range(4):
            bucket = [0, 0, 0, 0]
            bucket[field] = LIMIT // 3
            rows = prefixes([bucket, [-x for x in bucket], [0, 0, 0, 0]])
            for length in (1, 2, 100000):
                with self.subTest(field=field, length=length):
                    self.compare(rows, length, 713)
        edge = LIMIT // 2
        self.compare(prefixes([(1, edge, 1, -edge), (1, -edge, 1, edge)]), 1, 0)

    def test_upper_size_and_length_boundary_with_all_empty_aligned_buckets(self):
        rows = [(0, 0, 0, 0)] * 100001
        actual, _, calls = self.compare(rows, 100000, 713, 625)
        self.assertEqual(tuple(actual[field] for field in FIELDS), (0, 0, 0, 0))
        self.assertEqual(actual['sampled_times'], 100000)
        self.assertEqual(actual['reason'], None)
        self.assertEqual(len(calls), actual['segments'])


if __name__ == '__main__':
    print(json.dumps({
        'scope': 'fixed_independent_native_draw_qualification_only_no_production_activation',
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'binary_path': str(BINARY),
        'binary_sha256': hashlib.sha256(BINARY.read_bytes()).hexdigest(),
        'archive_sha256': ARCHIVE_SHA, 'scalar_sampler_sha256': SAMPLER_SHA,
        'python': sys.version, 'numpy': np.__version__,
    }, sort_keys=True), flush=True)
    unittest.main(verbosity=2)
