# cython: language_level=3
"""Qualification-only CPython-operation adapter; no production activation."""
from cpython.pycapsule cimport PyCapsule_GetPointer, PyCapsule_IsValid
from libc.stdint cimport uint32_t
import numpy as np

cdef extern from "numpy/random/bitgen.h":
    ctypedef struct bitgen_t:
        void *state
        uint32_t (*next_uint32)(void *) noexcept
        double (*next_double)(void *) noexcept

cdef class Candidate:
    cdef object _owner
    cdef object _lock
    cdef bitgen_t *_core

    def __cinit__(self, owner):
        if np.__version__ != '2.3.4' or type(owner) is not np.random.MT19937:
            raise TypeError('Qualification requires the selected NumPy MT19937')
        self._owner = owner
        self._lock = owner.lock
        capsule = owner.capsule
        if not PyCapsule_IsValid(capsule, b'BitGenerator'):
            raise ValueError('Invalid selected bit-generator capsule')
        self._core = <bitgen_t *>PyCapsule_GetPointer(capsule, b'BitGenerator')

    def randrange(self, size):
        cdef uint32_t value, bound
        cdef unsigned int bits
        if type(size) is not int:
            raise TypeError('Exact integer fixture size required')
        if not 1 <= size <= 100000:
            raise ValueError('Outside this qualification domain')
        bound = size
        bits = size.bit_length()
        with self._lock:
            value = self._core.next_uint32(self._core.state) >> (32 - bits)
            while value >= bound:
                value = self._core.next_uint32(self._core.state) >> (32 - bits)
        return value

    def random(self):
        cdef double value
        with self._lock:
            value = self._core.next_double(self._core.state)
        return value

def qualification_info():
    return {'scope': 'qualification_only_no_production_activation',
            'numpy': np.__version__, 'bitgen_struct_bytes': sizeof(bitgen_t)}
