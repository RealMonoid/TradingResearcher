"""Thin canonical-module invocation of the already pinned build toolchain.

Keep the old qualification builder, source and binary unchanged. An emitted
binary is an input needing qualification; this command supplies no admission.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import sysconfig
import time
import zipfile

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
TOOLS = ROOT / '.trf-runtime/native-build-tools-2026-11-02'
WORK = HERE / 'kernel-v1'
WORK.mkdir(exist_ok=True)
source = ROOT / 'trading_researcher/native/_trf_stationary_native.pyx'
assert hashlib.sha256(source.read_bytes()).hexdigest() == '7032309223049cd250f9774b26f5e44829e878693f3e1114df71b7f2b5b794ba'
assert np.__version__ == '2.3.4'
header = Path(np.get_include()) / 'numpy/random/bitgen.h'
with zipfile.ZipFile(HERE / 'numpy-2.3.4-cp314-cp314-win_amd64.whl') as wheel:
    assert header.read_bytes() == wheel.read('numpy/_core/include/numpy/random/bitgen.h')
generated = WORK / '_trf_stationary_native.c'
target = WORK / ('_trf_stationary_native' + sysconfig.get_config_var('EXT_SUFFIX'))
if target.exists():
    retained = json.loads((WORK / 'build-receipt.json').read_text())
    assert retained['abi'] == 'stationary-native-int64/1'
    assert retained['source_sha256'] == hashlib.sha256(source.read_bytes()).hexdigest()
    assert retained['bitgen_header_sha256'] == hashlib.sha256(header.read_bytes()).hexdigest()
    assert retained['binary']['sha256'] == hashlib.sha256(target.read_bytes()).hexdigest()
    assert retained['binary']['size'] == target.stat().st_size
    print(json.dumps({'status': 'RETAINED_INPUT_VERIFIED_NOT_REBUILT', 'binary': retained['binary']}))
    raise SystemExit(0)
base = Path(sysconfig.get_config_var('base'))
commands = [
    [str(TOOLS / 'Scripts/python.exe'), '-B', '-m', 'cython', '-3', str(source), '-o', str(generated)],
    [str(TOOLS / 'Scripts/python.exe'), '-B', '-m', 'ziglang', 'cc', '-shared', '-O3',
     '-target', 'x86_64-windows-gnu', '-ffp-contract=off', '-fno-fast-math',
     '-I' + sysconfig.get_path('include'), '-I' + np.get_include(), str(generated),
     str(base / 'libs/python314.lib'), '-o', str(target)],
]
environment = dict(os.environ)
environment['ZIG_GLOBAL_CACHE_DIR'] = str(TOOLS / 'zig-global-cache')
environment['ZIG_LOCAL_CACHE_DIR'] = str(TOOLS / 'zig-local-cache')
receipt = {'scope': 'Versioned exact native kernel build input, not runtime qualification or scientific admission',
    'abi': 'stationary-native-int64/1', 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'bitgen_header_sha256': hashlib.sha256(header.read_bytes()).hexdigest(),
    'build_tools': {'Cython': '3.3.1', 'ziglang': '0.16.0'}, 'numpy': np.__version__,
    'python': sys.version, 'commands': commands, 'steps': []}
for command in commands:
    started = time.monotonic()
    result = subprocess.run(command, cwd=WORK, env=environment, capture_output=True, text=True)
    receipt['steps'].append({'exit_code': result.returncode, 'seconds': str(time.monotonic() - started),
                             'stdout': result.stdout, 'stderr': result.stderr})
    if result.returncode:
        (WORK / 'build-receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
        print(json.dumps(receipt), flush=True)
        raise SystemExit(result.returncode)
receipt['binary'] = {'path': str(target), 'size': target.stat().st_size,
                     'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}
receipt['generated_c_sha256'] = hashlib.sha256(generated.read_bytes()).hexdigest()
(WORK / 'build-receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
print(json.dumps({'abi': receipt['abi'], 'steps': receipt['steps'], 'binary': receipt['binary']}))
