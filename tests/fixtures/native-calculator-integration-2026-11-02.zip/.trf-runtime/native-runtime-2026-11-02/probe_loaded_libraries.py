"""Read-only own-process Windows module snapshot around retained native import.

This diagnoses required environment bindings, not runtime membership/admission.
Use Microsoft loader APIs through the existing standard-library ctypes bridge.
"""
import ctypes
from ctypes import wintypes
import hashlib
import importlib.util
import json
from pathlib import Path
import sys


def modules():
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.GetCurrentProcess.argtypes = []
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    kernel.K32EnumProcessModules.argtypes = [wintypes.HANDLE,
        ctypes.POINTER(wintypes.HMODULE), wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
    kernel.K32EnumProcessModules.restype = wintypes.BOOL
    kernel.GetModuleFileNameW.argtypes = [wintypes.HMODULE, wintypes.LPWSTR, wintypes.DWORD]
    kernel.GetModuleFileNameW.restype = wintypes.DWORD
    handles = (wintypes.HMODULE * 4096)()
    needed = wintypes.DWORD()
    if not kernel.K32EnumProcessModules(kernel.GetCurrentProcess(), handles,
            ctypes.sizeof(handles), ctypes.byref(needed)):
        raise ctypes.WinError(ctypes.get_last_error())
    if needed.value > ctypes.sizeof(handles) or needed.value % ctypes.sizeof(wintypes.HMODULE):
        raise ValueError('Module snapshot exceeds the explicit bounded buffer')
    result = {}
    for handle in handles[:needed.value // ctypes.sizeof(wintypes.HMODULE)]:
        buffer = ctypes.create_unicode_buffer(32768)
        length = kernel.GetModuleFileNameW(handle, buffer, len(buffer))
        if not length or length >= len(buffer) - 1:
            raise ValueError('Module path failed or may be truncated')
        path = Path(buffer.value).resolve()
        raw = path.read_bytes()
        if str(path).casefold() in result:
            raise ValueError('Module paths alias')
        result[str(path).casefold()] = {'path': str(path), 'size': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}
    return result


def stable_modules():
    # Hashing itself must not leave an unobserved newly loaded dependency.
    for _ in range(3):
        before = modules()
        after = modules()
        if before == after:
            return after
    raise ValueError('Own-process loader inventory did not stabilize')


def probe():
    if sys.platform != 'win32' or ctypes.sizeof(ctypes.c_void_p) != 8:
        raise ValueError('This engineering probe is Windows64 only')
    cache, target = map(Path, sys.argv[1:])
    before = stable_modules()
    sys.path.insert(0, str(cache))
    import numpy as np
    assert np.__version__ == '2.3.4' and Path(np.__file__).resolve().is_relative_to(cache)
    path = cache / '_trf_mt_probe.cp314-win_amd64.pyd'
    spec = importlib.util.spec_from_file_location('_trf_mt_probe', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.Candidate(np.random.MT19937(0)).random()
    after = stable_modules()
    virtual = [{'name': name,
                'origin': str(getattr(getattr(value, '__spec__', None), 'origin', None)),
                'loader': type(getattr(value, '__loader__', None)).__name__}
               for name, value in tuple(sys.modules.items())
               if (name.split('.')[0] == 'numpy' or name == '_trf_mt_probe')
               and not getattr(value, '__file__', None)]
    result = {'scope': 'Loader file-path/hash observation, not in-memory image identity, complete transitive static dependency proof or scientific admission.',
              'isolation': {'isolated': sys.flags.isolated, 'no_site': sys.flags.no_site,
                            'ignore_environment': sys.flags.ignore_environment,
                            'no_bytecode_writes': int(sys.dont_write_bytecode)},
              'before': list(before.values()), 'after': list(after.values()),
              'added': [value for key, value in after.items() if key not in before],
              'removed': [value for key, value in before.items() if key not in after],
              'virtual_native_modules': virtual}
    target.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps({'before': len(before), 'after': len(after),
                      'added': len(result['added']), 'removed': len(result['removed']),
                      'receipt': str(target)}))


if __name__ == '__main__':
    probe()
