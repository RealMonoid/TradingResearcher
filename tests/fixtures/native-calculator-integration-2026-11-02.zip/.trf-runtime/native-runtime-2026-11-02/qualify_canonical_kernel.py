"""Existing independent cases and recorded full-calculator gold for new ABI.

No study/registry, resource grant, scientific selection or runtime certificate.
The original loop assertions change only their explicit binary loader selection.
"""
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests'))
from bootstrap_oracle import binary_report
from trading_researcher.codec import canonical
from trading_researcher.native_backend import make_draw_factory, INFO
from trading_researcher.stationary_bootstrap import calculate

import numpy as np


def qualify():
    target = HERE / 'kernel-v1/_trf_stationary_native.cp314-win_amd64.pyd'
    assert hashlib.sha256(target.read_bytes()).hexdigest() == '46d1c2efc66e8cd3546e72027970f7951360e6f18dd1f868d82efbe83e78d509'
    original = ROOT / '.trf-runtime/native-build-tools-2026-11-02/draw_independent_cases.py'
    raw = original.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == '342dd443823df5015109768428e15a425b5fba113d5abee8f27bf94ac9dcc0a9'
    source = raw.decode()
    for before, after in (
        ("BINARY = HERE / '_trf_mt_probe.cp314-win_amd64.pyd'", 'BINARY = Path(sys.argv.pop(1))'),
        ("spec_from_file_location('_trf_mt_probe', BINARY)", "spec_from_file_location('_trf_stationary_native', BINARY)")):
        assert source.count(before) == 1
        source = source.replace(before, after)
    generated = HERE / 'canonical_draw_independent_cases.py'
    generated.write_bytes(source.encode())
    difference = ''.join(difflib.unified_diff(raw.decode().splitlines(keepends=True), source.splitlines(keepends=True),
        fromfile='original-independent-loop-cases', tofile='canonical-ABI-binary-selection'))
    (HERE / 'canonical-case-selection.diff').write_text(difference, encoding='utf-8')
    child = subprocess.run([sys.executable, '-B', str(generated), str(target)],
                           capture_output=True, text=True, timeout=30)
    (HERE / 'canonical-loop-stdout.txt').write_text(child.stdout, encoding='utf-8')
    (HERE / 'canonical-loop-stderr.txt').write_text(child.stderr, encoding='utf-8')
    receipt = {'scope': 'Numerical ABI/owned-factory qualification only; not isolated study/source/runtime or scientific admission.',
        'binary_sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
        'generated_case_source_sha256': hashlib.sha256(generated.read_bytes()).hexdigest(),
        'loop_child_exit_code': child.returncode, 'binary_selection_diff': difference}
    try:
        assert child.returncode == 0 and 'Ran 13 tests' in child.stderr and '\nOK\n' in child.stderr, child.stderr
        spec = importlib.util.spec_from_file_location('_trf_stationary_native', target)
        core = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(core)
        assert core.implementation_info() == INFO
        factory = make_draw_factory(core, np)
        calls = []

        def selected(rng, rows, length):
            before = rng.getstate()
            engine = factory(rng, rows, length)
            assert rng.getstate() == before
            calls.append({'length': length, 'native': engine is not None})
            return engine

        baseline = json.loads((ROOT / '.trf-runtime/scientific-profile-2026-11-02/grouped-calculation-benchmark.json').read_text())
        assert baseline['fixture'] == 'tests/bootstrap_oracle.py:binary_report(4096)'
        stream = hashlib.sha256()
        draws = 0

        def retain(encoded):
            nonlocal draws
            stream.update(encoded + b'\n')
            draws += 1

        started = time.monotonic()
        result = calculate(binary_report(4096), baseline['design'], baseline['limits'],
                           on_draw_bytes=retain, _draw_factory=selected)
        receipt['calculator_seconds'] = str(time.monotonic() - started)
        result_sha = hashlib.sha256(canonical(result).encode()).hexdigest()
        assert result_sha == '720ac237f2ad3e29a5a9d94191af68a90a549f476c6e0f2d5bae36b537901b09'
        assert stream.hexdigest() == '76c3fb49b827455afaf488104f0ee88788254446e4bcf1fad07f73b42cb4f533'
        assert draws == 59997 and all(item['attempted'] == 19999 for item in result['cases'])
        assert calls == [{'length': length, 'native': True} for length in (4, 8, 16)]
        receipt.update(status='PASS', native_lengths=calls, draws=draws,
                       complete_result_sha256=result_sha, complete_stream_sha256=stream.hexdigest())
    except BaseException as error:
        receipt['failure'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        (HERE / 'canonical-kernel-qualification.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
        print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    qualify()
