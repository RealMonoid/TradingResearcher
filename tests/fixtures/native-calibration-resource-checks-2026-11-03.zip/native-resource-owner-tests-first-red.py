"""Independent Registry resource-owner controls, not series admission.

Retired financial metadata is synthetic and disclosed. Its actual unchanged
history parser, immutable Registry, blobs and transaction owners must run; the
only authority substitution is an explicitly trusted test-authority seam.
"""
import importlib
import importlib.util
import unittest


def owner():
    return importlib.import_module('trading_researcher.native_calibration_runs')


class NativeResourceOwnerEntrypointIndependentTests(unittest.TestCase):
    def test_private_registry_owner_exists_before_domain_cases_can_run(self):
        self.assertIsNotNone(importlib.util.find_spec('trading_researcher.native_calibration_runs'),
                             'Registry resource owner absent; zero domain-flow coverage')
        self.assertTrue(callable(getattr(owner(), 'NativeCalibrationResources', None)))


if __name__ == '__main__':
    unittest.main()
