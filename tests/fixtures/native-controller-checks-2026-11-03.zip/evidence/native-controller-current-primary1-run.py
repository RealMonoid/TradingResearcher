import pathlib,hashlib,json,ast,sys,io,time,unittest,datetime,zipfile
ROOT=pathlib.Path.cwd();WORK=ROOT/'.trf-runtime/native-final-calibration-2026-11-03';PREFIX='native-controller-current-primary1'
paths=['tests/test_native_calibration_controller_independent.py','tests/test_native_calibration_resource_owner_independent.py','trading_researcher/native_calibration_controller.py','trading_researcher/native_calibration_runs.py','trading_researcher/native_calibration_resources.py','trading_researcher/storage.py','trading_researcher/coordination.py','trading_researcher/revocations.py','trading_researcher/calibration_recovery.py','trading_researcher/codec.py','tools/calibration/native_parallel.py']
def pins():return {p:{'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest(),'size':(ROOT/p).stat().st_size} for p in paths}
def project():return {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'trading_researcher').glob('*.py'))}
before=pins(); full_before=project()
for p in paths:(WORK/(PREFIX+'-'+pathlib.Path(p).name)).write_bytes((ROOT/p).read_bytes())
with zipfile.ZipFile(WORK/(PREFIX+'-project-source.zip'),'w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted((ROOT/'trading_researcher').glob('*.py')):z.writestr(p.relative_to(ROOT).as_posix(),p.read_bytes())
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'));import test_native_calibration_controller_independent as m
names=['test_primary_callback_failure_survives_failed_durable_stop_and_still_cancels_before_join']
suite=unittest.TestSuite(m.NativeControllerSchedulerIndependentTests(n) for n in names);count=suite.countTestCases();stream=io.StringIO()
class Result(unittest.TextTestResult):
 def startTest(self,test):super().startTest(test);print('START',test.id(),flush=True)
 def addSuccess(self,test):super().addSuccess(test);print('PASS',test.id(),flush=True)
started=datetime.datetime.now(datetime.timezone.utc).isoformat();timer=time.perf_counter();result=unittest.TextTestRunner(stream=stream,verbosity=2,failfast=False,resultclass=Result).run(suite);elapsed=time.perf_counter()-timer;raw=stream.getvalue();(WORK/(PREFIX+'-stdout.txt')).write_text(raw,encoding='utf-8')
r={'started_at_utc':started,'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Hand-fixed pure engineering forecasts; actual public monitor with explicit admission/copy/private_run metadata seams; genuine small Registry/resource/scheduler with synthetic caller settlements. No actual native/scalar numerical work or actual series/scientific admission.','discovered':count,'executed':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'elapsed_seconds':elapsed,'exit_code':int(not result.wasSuccessful()),'pins_before':before,'pins_after':pins(),'full_project_before':full_before,'full_project_after':project(),'raw_stdout':raw};r['pins_unchanged']=r['pins_before']==r['pins_after'];r['full_project_unchanged']=r['full_project_before']==r['full_project_after'];p=WORK/(PREFIX+'-check.json');p.write_text(json.dumps(r,indent=2),encoding='utf-8');print(raw);print('RECEIPT',p,'SHA256',hashlib.sha256(p.read_bytes()).hexdigest(),flush=True);sys.exit(r['exit_code'])
