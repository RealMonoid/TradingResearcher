"""Version retained probe inputs without changing any old archive or file byte."""
import hashlib
import json
from pathlib import Path
import sys
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from trading_researcher.codec import canonical, decode, digest
from trading_researcher.native_backend import SOURCE_SHA256
from trading_researcher.native_runtime import validate_archive

original = HERE / 'native-probe-runtime.zip'
assert hashlib.sha256(original.read_bytes()).hexdigest() == 'd8491798f79ab6265fcfaf57641c84742ba44a543716a92b8c9ecc777038c126'
manifest = decode((HERE / 'native-probe-runtime-manifest.json').read_bytes())
validate_archive(original.read_bytes(), manifest)
kernel = HERE / 'kernel-v1/_trf_stationary_native.cp314-win_amd64.pyd'
source = ROOT / 'trading_researcher/native/_trf_stationary_native.pyx'
receipt = HERE / 'kernel-v1/build-receipt.json'
assert hashlib.sha256(source.read_bytes()).hexdigest() == SOURCE_SHA256
assert hashlib.sha256(kernel.read_bytes()).hexdigest() == '46d1c2efc66e8cd3546e72027970f7951360e6f18dd1f868d82efbe83e78d509'
build = json.loads(receipt.read_text())
assert build['source_sha256'] == SOURCE_SHA256
assert build['binary']['sha256'] == hashlib.sha256(kernel.read_bytes()).hexdigest()
target = HERE / 'canonical-native-runtime.zip'
files = {}


def retain(archive, name, raw):
    assert name not in files
    info = zipfile.ZipInfo(name, date_time=(2026, 11, 2, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    archive.writestr(info, raw)
    files[name] = {'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


with zipfile.ZipFile(original) as old, zipfile.ZipFile(target, 'x') as new:
    for name in old.namelist():
        selected = 'provenance/previous-probe/' + name if name == '_trf_mt_probe.cp314-win_amd64.pyd' else name
        raw = old.read(name)
        assert {'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()} == manifest['files'][name]
        retain(new, selected, raw)
    for name, path in {
        '_trf_stationary_native.cp314-win_amd64.pyd': kernel,
        'provenance/stationary-native-v1.pyx': source,
        'provenance/stationary-native-v1-build.json': receipt}.items():
        retain(new, name, path.read_bytes())
manifest['files'] = files
manifest['dependencies']['owned-stationary-native'] = {
    'version': 'stationary-native-int64/1', 'distribution_sha256': SOURCE_SHA256,
    'license_files': manifest['dependencies']['owned-adapter-probe']['license_files']}
validate_archive(target.read_bytes(), manifest)
(HERE / 'canonical-native-runtime-manifest.json').write_text(canonical(manifest), encoding='utf-8')
result = {'scope': 'Retained canonical input version only; no study or runtime/scientific certificate.',
          'archive_sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'archive_bytes': target.stat().st_size,
          'manifest_sha256': digest(manifest), 'manifest_bytes': len(canonical(manifest).encode()),
          'files': len(files), 'unpacked_bytes': sum(item['size'] for item in files.values()),
          'old_member_bytes_preserved': len(files) - 3,
          'old_probe_relocated_to_nonimported_provenance': True}
(HERE / 'canonical-runtime-preparation.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result))
