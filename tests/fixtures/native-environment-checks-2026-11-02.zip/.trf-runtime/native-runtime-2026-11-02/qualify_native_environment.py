"""Two isolated metadata phases against retained canonical input bytes.

A reference loader observation is a provisional host input, not a certificate.
A separate child and a NumPy-free controller check its fixed binding afterward.
"""
from datetime import datetime, timezone
import hashlib
import importlib
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from trading_researcher.binding import environment
from trading_researcher.codec import canonical, decode, digest
from trading_researcher.coordination import Broker
from trading_researcher.evaluation_plans import source_bundle, footprint
from trading_researcher.native_backend import INFO, make_draw_factory
from trading_researcher.native_environment import NativeContext, _loaded_images, current
from trading_researcher.native_runtime import NativeRuntimes


def expected_source():
    return {**footprint(source_bundle()),
            Path(__file__).resolve().relative_to(ROOT).as_posix(): hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}


def child(request_path, output):
    request = decode(Path(request_path).read_bytes())
    assert expected_source() == request['source']
    cache = Path(request['directory'])
    sys.path.insert(1, str(cache))
    import numpy as np
    core = importlib.import_module('_trf_stationary_native')
    assert core.implementation_info() == INFO
    assert Path(np.__file__).resolve().is_relative_to(cache)
    assert Path(core.__file__).resolve().is_relative_to(cache)
    core.Candidate(np.random.MT19937(0)).random()
    if request['mode'] == 'reference':
        images = _loaded_images()
        result = {'scope': 'Provisional observed host input, not independently issued runtime admission',
                  'host_images': [value for value in images if not Path(value['path']).is_relative_to(cache)],
                  'image_count': len(images), 'source': request['source']}
    else:
        context = NativeContext(request['runtime_id'], request['manifest'], cache, request['host_images'])
        before = environment(request['source'], _native=context)
        assert 'Lib/ctypes/__init__.py' in before['standard_library']
        factory = make_draw_factory(core, np)
        rng = random.Random(713)
        state = rng.getstate()
        engine = factory(rng, ((0, 0, 0, 0), (2, 10, 1, 0), (3, 14, 2, 4), (3, 14, 2, 4)), 2)
        assert engine is not None and rng.getstate() == state
        draw = engine.draw(2, lambda *args: None)
        assert draw['reason'] is None and draw['sampled_times'] == 3
        after = environment(request['source'], _native=context)
        assert before['native_runtime']['runtime_images'] == after['native_runtime']['runtime_images']
        result = {'before': before, 'after': after, 'draw': draw, 'source': request['source']}
    Path(output).write_text(canonical(result), encoding='utf-8')


def qualify():
    started = time.monotonic()
    manifest = decode((HERE / 'canonical-native-runtime-manifest.json').read_bytes())
    archive = HERE / 'canonical-native-runtime.zip'
    receipt = {'scope': 'Actual environment adapter proof only; provisional baseline, no runtime/study/scientific certificate.',
        'utc': datetime.now(timezone.utc).isoformat(), 'manifest_sha256': digest(manifest),
        'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'phases': []}
    assert 'numpy' not in sys.modules
    try:
        with tempfile.TemporaryDirectory(prefix='trf-native-env-') as temporary:
            directory = Path(temporary)
            broker = Broker(directory / 'registry')
            try:
                supplied = broker.call(broker.admin_token, 'add_blob_source', path=str(archive), data_class='operations',
                    description='Canonical native input environment fixture; not a certificate')
                package = broker.call(broker.admin_token, 'retain_native_runtime', key='environment-input',
                                      archive_id=supplied['id'], manifest=manifest)
                meter = {'materialized_bytes': 0}
                cache = NativeRuntimes(broker)._materialize(package['id'], meter)
                receipt['materialized_bytes'] = meter['materialized_bytes']
                request = {'mode': 'reference', 'source': expected_source(), 'runtime_id': package['id'],
                           'manifest': manifest, 'directory': str(cache)}
                reference = None
                for mode in ('reference', 'check'):
                    request['mode'] = mode
                    request_path = directory / (mode + '-request.json')
                    output = directory / (mode + '-output.json')
                    request_path.write_text(canonical(request), encoding='utf-8')
                    result = subprocess.run([sys.executable, '-I', '-S', '-B', str(Path(__file__).resolve()),
                        'child', str(request_path), str(output)], capture_output=True, text=True, timeout=30)
                    (HERE / ('environment-' + mode + '-stdout.txt')).write_text(result.stdout, encoding='utf-8')
                    (HERE / ('environment-' + mode + '-stderr.txt')).write_text(result.stderr, encoding='utf-8')
                    receipt['phases'].append({'phase': mode, 'exit_code': result.returncode})
                    assert result.returncode == 0, result.stderr
                    observed = decode(output.read_bytes())
                    (HERE / ('environment-' + mode + '-observation.json')).write_bytes(output.read_bytes())
                    if mode == 'reference':
                        reference = observed
                        request['host_images'] = reference['host_images']
                        receipt['reference_host_images'] = len(reference['host_images'])
                    else:
                        for phase in ('before', 'after'):
                            assert current(observed[phase], package['id'], manifest, cache, reference['host_images'])
                        receipt['runtime_module_files'] = len(observed['after']['native_runtime']['module_files'])
                        receipt['runtime_images'] = len(observed['after']['native_runtime']['runtime_images'])
                        receipt['standard_library_files'] = len(observed['after']['standard_library'])
                        receipt['controller_numpy_imported'] = 'numpy' in sys.modules
                        assert not receipt['controller_numpy_imported']
                        receipt['pre_post_current'] = True
                receipt['status'] = 'PASS'
            finally:
                broker.close()
    except BaseException as error:
        receipt['failure'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        receipt['seconds'] = str(time.monotonic() - started)
        (HERE / 'native-environment-qualification.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
        print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    if len(sys.argv) == 4 and sys.argv[1] == 'child':
        child(sys.argv[2], sys.argv[3])
    else:
        qualify()
