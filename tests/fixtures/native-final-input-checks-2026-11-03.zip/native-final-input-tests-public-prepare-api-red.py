"""Independent native-final INPUT controls, not final execution qualification.

The shared fixture uses genuine normalization/certification/compile owners,
then explicitly substitutes qualification membership and tiny development
numerical transport. No final numerical world is executed or admitted here.
"""
from contextlib import closing
from copy import deepcopy
import hashlib
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from trading_researcher.coordination import Broker, Conflict, Denied, Invalid
from trading_researcher import native_study_runs, study_runs
from trading_researcher.native_runtime import NativeRuntimes


class NativeCalibrationPublicBoundaryIndependentTests(unittest.TestCase):
    def test_public_prepare_dispatches_owned_request_validation(self):
        with tempfile.TemporaryDirectory(prefix='trf-native-final-api-') as temporary:
            with closing(Broker(Path(temporary) / 'registry')) as broker:
                with self.assertRaises(Invalid):
                    broker.call(broker.admin_token, 'prepare_native_family_calibration')

    def test_public_advance_is_denied_before_inputs_cache_child_or_reservation(self):
        with tempfile.TemporaryDirectory(prefix='trf-native-final-boundary-') as temporary:
            with closing(Broker(Path(temporary) / 'registry')) as broker:
                before = list(broker._db.execute('SELECT seq,hash FROM events'))
                with patch.object(study_runs, 'execute_attempt', side_effect=AssertionError('Final world executed')), \
                        patch.object(NativeRuntimes, '_materialize', side_effect=AssertionError('Runtime materialized')):
                    with self.assertRaises(Denied):
                        broker.call(broker.admin_token, 'advance_native_family_calibration',
                                    calibration_id='1' * 64)
                self.assertEqual(list(broker._db.execute('SELECT seq,hash FROM events')), before)


if __name__ == '__main__':
    unittest.main()
