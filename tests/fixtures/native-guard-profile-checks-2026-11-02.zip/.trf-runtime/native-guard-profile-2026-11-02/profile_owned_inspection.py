"""One bounded read-only owned qualification inspection; no numerical work."""
from contextlib import closing
import cProfile
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import pstats
import sqlite3
import sys
import time

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
sys.path.insert(0, str(ROOT))
from trading_researcher.coordination import Broker
from trading_researcher.evaluation_plans import source_bundle, footprint

REGISTRY = ROOT / '.trf-runtime/native-packing-call-2026-11-02/registry'
QUALIFICATION = '54f7a5e5e3bab0091818de427bf916bf129f5c4ff724f9d7deb5f3847ec8e00c'

def snapshot():
    with closing(sqlite3.connect(REGISTRY.joinpath('registry.sqlite3').as_uri() + '?mode=ro', uri=True)) as db:
        db.execute('PRAGMA query_only=ON')
        schema = list(db.execute('SELECT type,name,tbl_name,sql FROM sqlite_master ORDER BY type,name'))
        tables = {}
        for (name,) in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
            quoted = '"' + name.replace('"', '""') + '"'
            rows = sorted(repr(tuple(row)).encode() for row in db.execute('SELECT * FROM ' + quoted))
            tables[name] = {'count': len(rows), 'sha256': hashlib.sha256(b'\0'.join(rows)).hexdigest()}
    return {'schema_sha256': hashlib.sha256(repr(schema).encode()).hexdigest(), 'tables': tables}

def cache_metadata():
    base = REGISTRY / 'native-runtime-cache'
    return sorted((p.relative_to(base).as_posix(), p.stat().st_size, p.stat().st_mtime_ns)
                  for p in base.rglob('*') if p.is_file())

def run():
    assert not (WORK / 'intent.json').exists() and not (WORK / 'receipt.json').exists()
    intent = {'purpose': 'Identify source/currentness/input/cache/metadata costs in exactly one warm read-only owned qualification inspection; use findings to select a concrete exact acceleration inquiry, never to skip a required control.',
        'object': {'registry': str(REGISTRY), 'qualification_id': QUALIFICATION,
                   'operation': 'inspect_native_runtime_qualification', 'source_base_commit': '3e15c0d'},
        'uncertainty': 'Which generic operations dominate this inspection? This does not itself attribute whole-caller costs or prove that any check is redundant.',
        'reuse': 'Existing Broker inspection and pinned Python3.14.2 cProfile/pstats/hashlib/sqlite3; no new library, implementation platform, model or numerical method.',
        'limit': 'Exactly one inspection, outer60second process bound, no retry, qualifier, materialization, world generation, numerical replay, continuation, grant or paid operation. Query-only enabled before operation; full schema/table and cache metadata equality guarded.',
        'prior_unselected_option': 'Per-member metadata tree candidate remains uninstalled: prior1.566928vs1.554073s ABBA did not establish a convincing gain. This inquiry does not revive it without new grounded evidence.',
        'scope': 'Profiled warm-operation attribution only. Nested cumulative times overlap; do not sum them or claim an unprofiled speedup/scientific/whole-series result.',
        'created_utc': datetime.now(timezone.utc).isoformat()}
    (WORK / 'intent.json').write_text(json.dumps(intent, indent=2), encoding='utf-8')
    receipt = {'status': 'STARTED', 'scope': intent['purpose'], 'inspection_calls': 0}
    broker = None
    began = time.monotonic()
    try:
        source = footprint(source_bundle())
        before, cache_before = snapshot(), cache_metadata()
        assert before['tables']['artifacts']['count'] == 318 and before['tables']['events']['count'] == 394
        assert len(cache_before) == 933
        broker = Broker(REGISTRY)
        broker._db.execute('PRAGMA query_only=ON')
        assert snapshot() == before, 'Broker startup changed the existing settled Registry'
        profiler = cProfile.Profile()
        receipt['inspection_calls'] = 1
        clock = time.perf_counter()
        observed = profiler.runcall(broker.call, broker.admin_token, 'inspect_native_runtime_qualification', qualification_id=QUALIFICATION)
        receipt['profiled_inspection_seconds'] = str(time.perf_counter() - clock)
        profiler.dump_stats(str(WORK / 'inspection.pstats'))
        assert observed['status'] == 'CURRENT'
        stats = pstats.Stats(profiler)
        rows = [{'file': key[0], 'line': key[1], 'function': key[2], 'primitive_calls': value[0],
                 'total_calls': value[1], 'self_seconds': value[2], 'cumulative_seconds': value[3]}
                for key, value in stats.stats.items()]
        receipt['top_cumulative'] = sorted(rows, key=lambda value:value['cumulative_seconds'], reverse=True)[:35]
        receipt['top_self'] = sorted(rows, key=lambda value:value['self_seconds'], reverse=True)[:20]
        receipt['operation_result'] = observed
        receipt['database_before_after_equal'] = snapshot() == before
        receipt['cache_metadata_before_after_equal'] = cache_metadata() == cache_before
        assert receipt['database_before_after_equal'] and receipt['cache_metadata_before_after_equal']
        assert footprint(source_bundle()) == source
        assert 'numpy' not in sys.modules and '_trf_stationary_native' not in sys.modules
        receipt['source_footprint'] = source
        receipt['database_snapshot'] = before
        receipt['cache_files'] = len(cache_before)
        receipt['controller_numpy_imported'] = False
        receipt['status'] = 'PASS_READ_ONLY_PROFILE_NOT_A_SPEEDUP_OR_SCIENTIFIC_RESULT'
    except BaseException as exc:
        receipt.update(status='FAILED_RETAINED_NO_RETRY', failure={'type':type(exc).__name__, 'message':str(exc)})
        raise
    finally:
        try:
            if broker is not None:
                broker.close()
        except BaseException as exc:
            receipt.update(status='FAILED_RETAINED_NO_RETRY', close_failure={'type':type(exc).__name__, 'message':str(exc)})
            raise
        finally:
            receipt['whole_observer_seconds'] = str(time.monotonic() - began)
            with (WORK / 'receipt.json').open('x', encoding='utf-8') as stream:
                json.dump(receipt, stream, indent=2)
            print(json.dumps({k:v for k,v in receipt.items() if k in ('status','failure','close_failure','inspection_calls','profiled_inspection_seconds','whole_observer_seconds')}), flush=True)

if __name__ == '__main__':
    run()
