"""Run exactly the two predeclared ordinal-zero owned calls, then stop."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from trading_researcher.codec import digest
from trading_researcher.coordination import Broker
from trading_researcher.evaluation_plans import source_bundle, footprint
from trading_researcher.study_stream import decode_stream


def utc():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def retain(name, value):
    with (HERE / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)


def run():
    assert not (HERE / 'comparison-intent.json').exists()
    assert not (HERE / 'comparison-receipt.json').exists()
    preparation = json.loads((HERE / 'preparation-receipt.json').read_text(encoding='utf-8'))
    inputs = json.loads((HERE / 'prepared-inputs.json').read_text(encoding='utf-8'))
    declared = json.loads((HERE / 'preparation-intent.json').read_text(encoding='utf-8'))
    review = json.loads((HERE / 'pre-call-independent-review.json').read_text(encoding='utf-8'))
    assert preparation['status'] == 'PREPARED_NOT_EXECUTED' and preparation['study_advances'] == 0
    assert review['status'].startswith('PASS'), 'Independent fixed-input review must pass before actual calls'
    assert hashlib.sha256((HERE / 'prepared-inputs.json').read_bytes()).hexdigest() == preparation['prepared_inputs_sha256']
    assert hashlib.sha256((HERE / 'prepare_probe.py').read_bytes()).hexdigest() == declared['script_sha256']
    assert review['prepared_inputs_sha256'] == preparation['prepared_inputs_sha256']
    assert review['script_sha256'] == declared['script_sha256']
    assert review['preparation_receipt']['sha256'] == hashlib.sha256((HERE / 'preparation-receipt.json').read_bytes()).hexdigest()
    assert review['preparation_intent_sha256'] == hashlib.sha256((HERE / 'preparation-intent.json').read_bytes()).hexdigest()
    assert review['source_archive']['sha256'] == hashlib.sha256((HERE / 'source.zip').read_bytes()).hexdigest()
    assert review['scalar_study_id'] == preparation['studies']['scalar'] == inputs['scalar']['id']
    assert review['native_study_id'] == preparation['studies']['native'] == inputs['native']['id']
    expected_source = inputs['scalar']['body']['source_footprint']
    assert footprint(source_bundle()) == expected_source == inputs['native']['body']['source_footprint']
    manifest = inputs['scalar']['body']['manifest']
    assert manifest == inputs['native']['body']['manifest']
    assert len(manifest['worlds']) == 4 and manifest['required_lengths'] == [4, 8, 16]
    selected = manifest['worlds'][0]
    assert selected == inputs['comparison']['selected_world'] and selected['time_rows'] == 4096
    assert review['selected_world'] == selected
    assert review['manifest_sha256'] == digest(manifest)
    assert review['limits_each_study'] == manifest['profile']['budget']
    assert selected['id'] == inputs['views_before_any_advance']['scalar']['next_world_id']
    assert not (HERE / 'registry/native-runtime-cache').exists(), 'Cold native setup must remain inside its reserved call'
    intent = {'purpose': 'One fixed complete4096row family-world scalar/native owned comparison, ordinal0 only, once each. No later world, retry, grant or scientific inference.',
        'created_utc': utc(), 'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'prepared_inputs_sha256': preparation['prepared_inputs_sha256'], 'independent_review_sha256': hashlib.sha256((HERE / 'pre-call-independent-review.json').read_bytes()).hexdigest(),
        'selected_world': selected, 'source_footprint': expected_source,
        'study_ids': preparation['studies'], 'limits': manifest['profile']['budget'],
        'order': ['scalar', 'native'], 'expected_components': ['a', 'b'],
        'expected_draws_per_component': 59997, 'expected_draws_per_generation': 119994,
        'cold_native_bytes': 56944242,
        'timing_scope': 'Each outer timer encloses the complete public advance call including final commit/view. Owned settlement separately measures through output staging. Setup/independent checks and final byte comparison are retained separately, never hidden or treated as typical throughput.'}
    retain('comparison-intent.json', intent)
    receipt = {'scope': intent['purpose'], 'started_utc': utc(), 'attempts': {},
               'setup_seconds': preparation['setup_seconds'], 'calls_planned': 2, 'calls_started': 0}
    begun = time.monotonic()
    broker = None
    def op(operation, **args):
        assert operation != 'continue_study' and not operation.startswith('qualify_')
        return broker.call(broker.admin_token, operation, **args)
    try:
        broker = Broker(HERE / 'registry')
        bodies = {}
        for mode in ('scalar', 'native'):
            study = inputs[mode]
            suffix = ('native_' if mode == 'native' else '') + 'family_study'
            before = op('inspect_' + suffix, study_id=study['id'])
            assert before['status'] == 'READY' and not before['attempt_artifact_ids'] and not before['continuation_ids']
            assert before['next_world_id'] == selected['id']
            record = {'study_id': study['id'], 'started_utc': utc()}
            receipt['attempts'][mode] = record
            receipt['calls_started'] += 1
            clock = time.perf_counter()
            view = op('advance_' + suffix, study_id=study['id'])
            record['outer_call_seconds'] = str(time.perf_counter() - clock)
            record['ended_utc'], record['view'] = utc(), view
            assert len(view['attempt_artifact_ids']) == 1
            attempt = op('get_artifact', artifact_id=view['attempt_artifact_ids'][0])
            retain(mode + '-attempt.json', attempt)
            body = attempt['body']
            record.update(artifact_id=attempt['id'], settlement=body['settlement'], failure=body['failure'], outcome=body['outcome'])
            print(json.dumps({'mode': mode, 'outer_call_seconds': record['outer_call_seconds'],
                              'outcome_state': body['outcome']['state'], 'failure': body['failure']}), flush=True)
            assert body['failure'] is None and body['world_id'] == selected['id']
            assert body['outcome']['state'] in ('VERIFIED', 'INFORMATION_GAP') and len(body['proofs']) == 2
            assert body['settlement']['usage_known'] is True and not view['budget']['usage_uncertain']
            assert body['scientific_readiness'] is False and body['result']['classification_permitted'] is False
            assert body['result']['n_min'] is None and view['n_min'] is None
            assert view['status'] == 'RESOURCE_STOP' and not view['continuation_ids']
            assert view['summary']['recorded_worlds'] == 1 and not view['summary']['complete']
            assert view['summary']['candidate_time_rows'] is None and view['next_world_id'] is None
            assert op('get_artifact', artifact_id=study['id']) == study
            bootstraps = body['result']['bootstraps']
            assert [item['id'] for item in bootstraps] == ['a', 'b']
            for item in bootstraps:
                calculation = item['result']
                assert calculation['status'] == 'COMPUTED_UNCALIBRATED'
                assert [case['length'] for case in calculation['cases']] == [4, 8, 16]
                assert [case['attempted'] for case in calculation['cases']] == [19999] * 3
                assert all(case['interrupted'] == 0 for case in calculation['cases'])
            assert body['output_blobs']['generate/stream.jsonl.gz'] == body['output_blobs']['replay/expected-stream.jsonl.gz']
            if mode == 'native':
                expected_engines = [{'length': length, 'native': True} for length in [4, 8, 16] * 2]
                assert all(proof['draw_engines'] == expected_engines for proof in body['proofs'])
            record['result_sha256'] = digest(body['result'])
            record['stream'] = body['output_blobs']['generate/stream.jsonl.gz']
            record['stream_encoding'] = body['proofs'][0]['stream_encoding']
            bodies[mode] = body
        comparison_start = time.perf_counter()
        assert bodies['scalar']['result'] == bodies['native']['result']
        streams, decoded = {}, {}
        for mode, body in bodies.items():
            raw = broker._read_blob_bytes(body['output_blobs']['generate/stream.jsonl.gz']['sha256'])
            streams[mode] = raw
            decoded[mode] = decode_stream(raw, body['proofs'][0]['stream_encoding'])
        assert streams['scalar'] == streams['native'] and decoded['scalar'] == decoded['native']
        receipt['byte_comparison_seconds'] = str(time.perf_counter() - comparison_start)
        receipt['comparison'] = {'results_equal': True, 'encoded_equal': True, 'decoded_equal': True,
            'encoded_bytes_each': len(streams['scalar']), 'decoded_bytes_each': len(decoded['scalar']),
            'encoded_sha256': hashlib.sha256(streams['scalar']).hexdigest(),
            'decoded_sha256': hashlib.sha256(decoded['scalar']).hexdigest(),
            'draws_per_generation': 119994, 'generation_and_replay_draws_per_route': 239988}
        receipt['qualification_after'] = op('inspect_native_runtime_qualification', qualification_id=inputs['qualification_id'])
        assert receipt['qualification_after']['status'] == 'CURRENT'
        assert op('verify')['status'] == 'PASS'
        assert receipt['calls_started'] == receipt['calls_planned'] == 2
        assert footprint(source_bundle()) == expected_source
        assert 'numpy' not in sys.modules and '_trf_stationary_native' not in sys.modules
        receipt['controller_numpy_imported'] = False
        receipt['unverified'] = 'One fixed cold-native observation, scalar first; background load uncontrolled, no repeated pairs/uncertainty, no general speed or final-series feasibility claim. Four-world inventories remain incomplete RESOURCE_STOP; no continuation is planned.'
        receipt['status'] = 'PASS'
    except BaseException as exc:
        receipt['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        receipt['status'] = 'FAILED_RETAINED_NO_RETRY'
        raise
    finally:
        try:
            if broker is not None:
                broker.close()
        except BaseException as exc:
            receipt['close_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
            receipt['status'] = 'FAILED_RETAINED_NO_RETRY'
            raise
        finally:
            receipt['ended_utc'], receipt['comparison_path_seconds'] = utc(), str(time.monotonic() - begun)
            retain('comparison-receipt.json', receipt)
            print(json.dumps({k:v for k,v in receipt.items() if k in
                ('status', 'failure', 'close_failure', 'calls_started', 'comparison_path_seconds')}), flush=True)


if __name__ == '__main__':
    assert len(sys.argv) == 1
    run()
