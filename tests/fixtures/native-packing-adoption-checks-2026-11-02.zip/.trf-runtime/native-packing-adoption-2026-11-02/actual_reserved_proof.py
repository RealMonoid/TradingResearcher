"""Bounded actual synthetic caller/restore proof; never final calibration."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import time
from zipfile import ZipFile, ZIP_DEFLATED

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'tests')]
from family_run_support import FamilyFixture
from test_information_study import profile
from trading_researcher.coordination import Broker
from trading_researcher.codec import decode, digest
from trading_researcher.evaluation_plans import source_bundle, footprint
from trading_researcher.native_qualification_profile import capture_source
from trading_researcher.storage import restore_bundle


def run(version):
    assert version.isascii() and version.replace('-', '').isalnum()
    target = HERE / version
    target.mkdir(exist_ok=False)
    begun = time.monotonic()
    receipt = {'scope': 'Fixed existing16row engineering shape; genuine synthetic inputs, v2ownedqualification and scalar/native reserved callers with coldrestore/fullreplay. No final/calibration/market/model or newscientifictarget.',
               'status': 'RUNNING', 'views': {}, 'planned_attempts': 14}
    broker = None
    try:
        source = capture_source()
        receipt['source_footprint'] = footprint(source)
        with ZipFile(target / 'source.zip', 'x', ZIP_DEFLATED) as archive:
            for name, raw in source.items():
                archive.writestr(name, raw)
        fixture = FamilyFixture()
        try:
            execution = fixture.execution
            family_plan, family_diagnostic = fixture.plan, fixture.diagnostics
            single_plan = fixture.op('prepare_evaluation_plan', key='native-single-proof',
                compiled_id=execution['body']['compiled_id'], primary_count=1,
                dependence=deepcopy(family_plan['body']['request']['dependence']))
            single_diagnostic = fixture.op('prepare_information_diagnostics', key='native-single-proof',
                plan_id=single_plan['id'], execution_id=execution['id'], lags=[1, 2], limits={'max_seconds': 60})
            backup = target / 'base-backup'
            fixture.op('backup_bundle', destination=str(backup))
            restore_bundle(backup, target / 'registry', fixture.broker.directory / 'operator.key')
        finally:
            fixture.close()
        broker = Broker(target / 'registry')
        def op(operation, **args):
            return broker.call(broker.admin_token, operation, **args)
        inputs = HERE
        raw = inputs / 'canonical-native-runtime-v2.zip'
        manifest = decode((inputs / 'canonical-native-runtime-v2-manifest.json').read_bytes())
        assert hashlib.sha256(raw.read_bytes()).hexdigest() == '4d379ab0dc5d689445c1f720b967b923b8106af4184de1576418837c23853976'
        archive_source = op('add_blob_source', path=str(raw), data_class='operations', description='Fixed pinned native proof input')
        runtime = op('retain_native_runtime', key='fixed-native-proof', archive_id=archive_source['id'], manifest=manifest)
        certificate = op('qualify_native_runtime', key='fixed-study-source-proof', runtime_id=runtime['id'])
        receipt['qualification'] = {'id': certificate['id'], 'status': certificate['body']['status'],
                                    'settlement': certificate['body']['settlement'], 'failure': certificate['body']['failure']}
        assert certificate['body']['status'] == 'CERTIFIED', certificate['body']['failure']
        assert certificate['body']['profile'] == 'stationary-native-runtime/2'
        assert all(proof['result']['tests'] == 21 for proof in certificate['body']['report']['proofs'])
        print(json.dumps({'phase': 'qualified', 'certificate_id': certificate['id']}), flush=True)
        assert op('inspect_native_runtime_qualification', qualification_id=certificate['id'])['status'] == 'CURRENT'
        estimate = {'world_time_rows': 16, 'observed_compute_ms': 1, 'observed_storage_bytes': 1,
                    'qualification': 'Fixed engineering proof estimate; unauthenticated, no performance claim.'}
        cost = op('add_source', data_class='development', body={'schema': 'development-study-cost-estimate/1', **estimate})
        studies = {}
        pairs = []
        receipt['attempts'] = []
        for kind, plan, diagnostic in (('information', single_plan, single_diagnostic), ('family', family_plan, family_diagnostic)):
            config = profile()
            config.update(targets=[16], worlds_per_cell=1, seed=8126,
                          cost_estimate={'source_ref': cost['id'], **estimate})
            config['budget'].update(max_compute_ms=360000, attempt_compute_ms=120000,
                max_storage_bytes=2*1024**3, attempt_storage_bytes=256*1024**2, max_attempts=1)
            if kind == 'family':
                config.update(responses=['a', 'b'], patterns=[[0, 0], [0, 1], [1, 1], [2, 2]])
            request = {'plan_id': plan['id'], 'execution_id': execution['id'], 'diagnostics_id': diagnostic['id'], 'profile': config}
            scalar = op('prepare_' + kind + '_study', key='scalar-' + kind, **request)
            native = op('prepare_native_' + kind + '_study', key='native-' + kind,
                        native_qualification_id=certificate['id'], **request)
            assert native['body']['manifest'] == scalar['body']['manifest']
            studies[kind] = native
            pairs.append((kind, scalar, native))
        with (target / 'prepared-studies.json').open('x', encoding='utf-8') as stream:
            json.dump({'qualification': certificate, 'pairs': pairs, 'purpose': receipt['scope']}, stream, indent=2)
        # Preserve every capsule before execution; restore from this exact backup
        # without the qualifier's derived cache. No old uncertain study is used.
        receipt['backup'] = op('backup_bundle', destination=str(target / 'study-backup'))
        key = broker.directory / 'operator.key'
        broker.close(); broker = None
        restore_bundle(target / 'study-backup', target / 'restored', key)
        broker = Broker(target / 'restored')
        assert not (broker.directory / 'native-runtime-cache').exists()
        assert op('inspect_native_runtime_qualification', qualification_id=certificate['id'])['status'] == 'STALE'
        print(json.dumps({'phase': 'restored_without_cache', 'blobs': receipt['backup']['blobs']}), flush=True)
        for kind, scalar, native in pairs:
            engine_uses = 0
            worlds = native['body']['manifest']['worlds']
            for world in worlds:
                observed = []
                for selected, study in (('scalar', scalar), ('native', native)):
                    operation = 'advance_' + ('native_' if selected == 'native' else '') + kind + '_study'
                    call_started = time.perf_counter()
                    view = op(operation, study_id=study['id'])
                    outer_seconds = str(time.perf_counter() - call_started)
                    receipt['views'][kind + '/' + selected] = view
                    attempt = op('get_artifact', artifact_id=view['attempt_artifact_ids'][-1])
                    body = attempt['body']
                    assert body['world_id'] == world['id']
                    receipt['attempts'].append({'kind': kind, 'engine': selected, 'study_id': study['id'],
                        'attempt_id': attempt['id'], 'state': body['outcome']['state'], 'failure': body['failure'],
                        'settlement': body['settlement'], 'outer_call_seconds': outer_seconds, 'draw_engines': [p.get('draw_engines') for p in body['proofs']],
                        'stream_encoding': [p.get('stream_encoding') for p in body['proofs']]})
                    assert body['failure'] is None and body['outcome']['state'] in ('VERIFIED', 'INFORMATION_GAP')
                    assert len(body['proofs']) == 2 and body['scientific_readiness'] is False
                    print(json.dumps({'phase': 'checked_world', 'kind': kind, 'engine': selected,
                                      'world_id': world['id'], 'state': body['outcome']['state']}), flush=True)
                    stream = body['output_blobs']['generate/stream.jsonl.gz']
                    assert stream == body['output_blobs']['replay/expected-stream.jsonl.gz']
                    observed.append((body['result'], stream))
                    if selected == 'native':
                        engine_uses += sum(item['native'] for item in body['proofs'][0]['draw_engines'])
                assert observed[0] == observed[1], 'Full scalar/native world result or stream differs'
            receipt[kind + '_native_engine_uses'] = engine_uses
            assert engine_uses > 0, 'Fixed complete engineering fixture never invoked native calculation'
            assert view['status'] == 'COMPLETE'
        for study in studies.values():
            assert op('get_artifact', artifact_id=study['id']) == study
        assert len(receipt['attempts']) == receipt['planned_attempts']
        assert len(receipt['views']) == 4
        for view in receipt['views'].values():
            assert view['status'] == 'COMPLETE' and not view['continuation_ids']
            assert not view['budget']['usage_uncertain'] and view['scientific_readiness'] is False
        assert op('get_artifact', artifact_id=certificate['id']) == certificate
        assert op('inspect_native_runtime_qualification', qualification_id=certificate['id'])['status'] == 'CURRENT'
        assert op('verify')['status'] == 'PASS'
        assert 'numpy' not in sys.modules and '_trf_stationary_native' not in sys.modules
        assert footprint(source_bundle()) == {k:v for k,v in receipt['source_footprint'].items() if k.startswith('trading_researcher/')}
        receipt['controller_numpy_imported'] = False
        receipt['status'] = 'PASS'
    except BaseException as exc:
        receipt['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        receipt['status'] = 'FAILED_RETAINED_NO_RETRY'
        raise
    finally:
        try:
            if broker is not None:
                broker.close()
        except BaseException as exc:
            receipt['status'] = 'FAILED_RETAINED_NO_RETRY'
            receipt['close_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
            raise
        finally:
            receipt['seconds'] = str(time.monotonic() - begun)
            with (target / 'receipt.json').open('x', encoding='utf-8') as stream:
                json.dump(receipt, stream, indent=2)
            print(json.dumps({k:v for k,v in receipt.items() if k in
                ('status', 'failure', 'close_failure', 'seconds', 'information_native_engine_uses', 'family_native_engine_uses')}), flush=True)


if __name__ == '__main__':
    assert len(sys.argv) == 2
    run(sys.argv[1])
