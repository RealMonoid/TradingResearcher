"""Corrected pinned-tool preflight, retaining every setup/build outcome."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import sysconfig
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
TOOLS = ROOT / '.trf-runtime/native-build-tools-2026-11-02'
CACHE = ROOT / '.trf-runtime/native-call-benchmark-2026-11-02/registry/native-runtime-cache/94c8427a738e281383a83255107595738d82ca2f03d7b8b9430401ca39fccf13'
source = HERE / '_trf_stationary_native.pyx'
generated = HERE / '_trf_stationary_native.c'
target = HERE / ('_trf_stationary_native' + sysconfig.get_config_var('EXT_SUFFIX'))
assert not target.exists() and not generated.exists() and not (HERE / 'canonical-build.json').exists()
receipt = {'scope': 'Canonical packing runtime input; requires new fixed qualification, no certificate yet.',
           'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
           'python': sys.version, 'steps': [], 'status': 'STARTED'}
try:
    command = [str(TOOLS / 'Scripts/python.exe'), '-I', '-B', '-c',
        "import importlib.metadata,json; print(json.dumps({k:importlib.metadata.version(k) for k in ('Cython','ziglang')}))"]
    versions = subprocess.run(command, capture_output=True, text=True, timeout=30)
    receipt['tool_preflight'] = {'command': command, 'exit_code': versions.returncode,
                                'stdout': versions.stdout, 'stderr': versions.stderr}
    assert versions.returncode == 0, versions.stderr
    receipt['versions'] = json.loads(versions.stdout)
    assert receipt['versions'] == {'Cython': '3.3.1', 'ziglang': '0.16.0'}
    inputs = json.loads((ROOT / '.trf-runtime/native-call-benchmark-2026-11-02/prepared-inputs.json').read_text(encoding='utf-8'))
    manifest = inputs['native']['body']['native_binding']['runtime_manifest']
    assert manifest['dependencies']['numpy']['version'] == '2.3.4'
    receipt['numpy_headers_version'] = '2.3.4'
    header_name = 'numpy/_core/include/numpy/random/bitgen.h'
    header_raw = (CACHE / header_name).read_bytes()
    header_sha = hashlib.sha256(header_raw).hexdigest()
    assert manifest['files'][header_name] == {'sha256': header_sha, 'size': len(header_raw)}
    old = json.loads((ROOT / '.trf-runtime/native-runtime-2026-11-02/kernel-v1/build-receipt.json').read_text(encoding='utf-8'))
    assert header_sha == old['bitgen_header_sha256']
    receipt['header_sha256'] = header_sha
    base = Path(sysconfig.get_config_var('base'))
    commands = [
        [str(TOOLS / 'Scripts/python.exe'), '-B', '-m', 'cython', '-3', str(source), '-o', str(generated)],
        [str(TOOLS / 'Scripts/python.exe'), '-B', '-m', 'ziglang', 'cc', '-shared', '-O3',
         '-target', 'x86_64-windows-gnu', '-ffp-contract=off', '-fno-fast-math',
         '-I' + sysconfig.get_path('include'), '-I' + str(CACHE / 'numpy/_core/include'),
         str(generated), str(base / 'libs/python314.lib'), '-o', str(target)],
    ]
    receipt['commands'] = commands
    env = dict(os.environ)
    env['ZIG_GLOBAL_CACHE_DIR'] = str(TOOLS / 'zig-global-cache')
    env['ZIG_LOCAL_CACHE_DIR'] = str(TOOLS / 'zig-local-cache')
    for command in commands:
        begun = time.perf_counter()
        result = subprocess.run(command, cwd=HERE, env=env, capture_output=True, text=True, timeout=120)
        receipt['steps'].append({'exit_code': result.returncode, 'seconds': str(time.perf_counter() - begun),
                                 'stdout': result.stdout, 'stderr': result.stderr})
        assert result.returncode == 0, result.stderr
    receipt['generated_c_sha256'] = hashlib.sha256(generated.read_bytes()).hexdigest()
    receipt['binary'] = {'path': str(target), 'size': target.stat().st_size,
                         'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}
    receipt['status'] = 'BUILT_UNQUALIFIED_EXPERIMENT_ONLY'
except BaseException as exc:
    receipt['status'] = 'FAILED_RETAINED'
    receipt['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
    raise
finally:
    with (HERE / 'canonical-build.json').open('x', encoding='utf-8') as stream:
        json.dump(receipt, stream, indent=2)
    print(json.dumps({key: receipt[key] for key in ('status', 'failure', 'binary', 'steps') if key in receipt}), flush=True)
