"""Real v1 backup/history under v2 reader; no dispatch or old study advance."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from trading_researcher.coordination import Broker
from trading_researcher.errors import Denied
from trading_researcher.codec import Invalid
from trading_researcher.native_qualification import NativeQualifications
from trading_researcher import native_qualification_profile as profile
from trading_researcher.native_runtime import NativeRuntimes
from trading_researcher.storage import restore_bundle

old = ROOT / '.trf-runtime/native-study-2026-11-02/actual-v2'
restored = HERE / 'legacy-restored'
assert not restored.exists() and not (HERE / 'legacy-read-receipt.json').exists()
receipt = {'scope': 'Restore existing actual v1 backup and check immutable history/explicit stale-use denial under v2; no world/qualifier dispatch/cache write or new grant.', 'status': 'STARTED'}
broker = None
try:
    receipt['restore'] = restore_bundle(old / 'study-backup', restored, old / 'registry/operator.key')
    broker = Broker(restored)
    before = {row[0]: row[1] for row in broker._db.execute('SELECT id,envelope FROM artifacts')}
    before_events = list(broker._db.execute('SELECT seq,envelope FROM events ORDER BY seq'))
    identity = '4f1f6e3dbc6c963c258feafe708f92e2c9e0780f828f37d7393c5223dc0827b8'
    certificate = broker.call(broker.admin_token, 'get_artifact', artifact_id=identity)
    assert certificate['body']['profile'] == 'stationary-native-runtime/1'
    with patch.object(profile, 'capture_source', side_effect=AssertionError('Legacy history captured new source')), \
            patch.object(profile, 'execute', side_effect=AssertionError('Legacy history dispatched qualifier')), \
            patch.object(NativeRuntimes, '_materialize', side_effect=AssertionError('Legacy history built cache')):
        view = broker.call(broker.admin_token, 'inspect_native_runtime_qualification', qualification_id=identity)
        assert view['status'] == 'STALE'
        returned = broker.call(broker.admin_token, 'qualify_native_runtime', **certificate['body']['request'])
        assert returned == certificate
        try:
            NativeQualifications(broker)._require_inputs(identity)
        except (Invalid, Denied) as exc:
            receipt['use_denial'] = {'type': type(exc).__name__, 'message': str(exc)}
        else:
            raise AssertionError('Historical certificate admitted current use')
    schema_operations = {'information-study-input/1': 'information_study',
        'native-information-study-input/1': 'native_information_study',
        'family-study-input/1': 'family_study', 'native-family-study-input/1': 'native_family_study'}
    studies = []
    for identity in before:
        item = broker._artifact(identity)
        schema = item['body'].get('schema') if type(item.get('body')) is dict else None
        if schema not in schema_operations:
            continue
        observed = broker.call(broker.admin_token, 'inspect_' + schema_operations[schema], study_id=identity)
        assert observed['status'] == 'READY' and not observed['attempt_artifact_ids'] and not observed['continuation_ids']
        studies.append({'id': identity, 'schema': schema, 'status': observed['status'], 'budget': observed['budget']})
    assert len(studies) == 4
    assert not (restored / 'native-runtime-cache').exists()
    assert {row[0]: row[1] for row in broker._db.execute('SELECT id,envelope FROM artifacts')} == before
    assert list(broker._db.execute('SELECT seq,envelope FROM events ORDER BY seq')) == before_events
    assert broker.call(broker.admin_token, 'verify')['status'] == 'PASS'
    receipt.update(status='PASS_LEGACY_HISTORY_NO_CURRENT_USE', certificate_id=certificate['id'],
                   inspection=view, artifacts_unchanged=len(before), events_unchanged=len(before_events),
                   old_studies=studies, controller_numpy_imported='numpy' in sys.modules)
    assert not receipt['controller_numpy_imported']
finally:
    if broker is not None:
        broker.close()
    with (HERE / 'legacy-read-receipt.json').open('x', encoding='utf-8') as stream:
        json.dump(receipt, stream, indent=2)
    print(json.dumps({key: receipt[key] for key in ('status', 'use_denial', 'artifacts_unchanged', 'events_unchanged') if key in receipt}), flush=True)
