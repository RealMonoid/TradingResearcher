"""Bounded actual synthetic caller/restore proof; never final calibration."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import time
from zipfile import ZipFile, ZIP_DEFLATED

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'tests')]
from family_run_support import FamilyFixture
from test_information_study import profile
from trading_researcher.coordination import Broker
from trading_researcher.codec import decode, digest
from trading_researcher.evaluation_plans import source_bundle, footprint
from trading_researcher.native_qualification_profile import capture_source
from trading_researcher.storage import restore_bundle


def run(version):
    assert version.isascii() and version.replace('-', '').isalnum()
    target = HERE / version
    assert target.is_dir() and not (target / 'completion-receipt.json').exists()
    begun = time.monotonic()
    receipt = {'scope': 'Complete existing3row engineering fixture after unadmitted16row request denial; reuse successfulgenuineinputs/qualification exactly, full7world scalar/native inventory with coldrestore/replay. No numericalretry/newfinal/scientifictarget.',
               'status': 'RUNNING', 'views': {}, 'planned_attempts': 14}
    broker = None
    try:
        prior = json.loads((target / 'receipt.json').read_text(encoding='utf-8'))
        assert prior['status'] == 'FAILED_RETAINED_NO_RETRY'
        assert prior['failure']['message'] == 'Target exceeds the available historical grid or has no nonterminal positions'
        source = capture_source()
        assert footprint(source) == prior['source_footprint']
        receipt['source_footprint'] = prior['source_footprint']
        broker = Broker(target / 'registry')
        def op(operation, **args):
            return broker.call(broker.admin_token, operation, **args)
        assert broker._db.execute("SELECT COUNT(*) FROM events WHERE json_extract(envelope,'$.action')='information_study_reserved'").fetchone()[0] == 0
        assert broker._db.execute("SELECT COUNT(*) FROM artifacts WHERE json_extract(envelope,'$.body.schema') IN ('information-study-input/1','native-information-study-input/1','family-study-input/1','native-family-study-input/1')").fetchone()[0] == 0
        certificate = op('get_artifact', artifact_id='54f7a5e5e3bab0091818de427bf916bf129f5c4ff724f9d7deb5f3847ec8e00c')
        assert certificate['body']['profile'] == 'stationary-native-runtime/2' and certificate['body']['status'] == 'CERTIFIED'
        assert op('inspect_native_runtime_qualification', qualification_id=certificate['id'])['status'] == 'CURRENT'
        execution = op('get_artifact', artifact_id='095ad701b1608323eecbe419868f3e375cd2632890e4301e6bc87f746c9c9d28')
        family_plan = op('get_artifact', artifact_id='0a7bb218818054f2aab2176feffaba67ebd80e66e887216b74aba5109d8d676a')
        family_diagnostic = op('get_artifact', artifact_id='ec3c05e2202151527073fae4ade54e95c242ed0a2d3d901095b34f523d47b1ac')
        single_plan = op('get_artifact', artifact_id='8cf8bc3409b761b8258038b2fd74ef68d777718fad15d8dca9f9ed763e1c3c28')
        single_diagnostic = op('get_artifact', artifact_id='31b0c9d9632a7465f955d17f7c4b35774fb6af2ba03f1029a9472c6a47eb6dca')
        report = execution['body']['result']['report']
        available = report['expected_case_count'] // len(report['request']['universe']['instruments'])
        assert available == 3 and report['request']['horizon_bars'] < 3
        receipt['qualification'] = prior['qualification']
        receipt['prior_failure_retained'] = prior['failure']
        receipt['available_time_rows'] = available
        with (target / 'completion-intent.json').open('x', encoding='utf-8') as stream:
            json.dump({'purpose': receipt['scope'], 'source_footprint': receipt['source_footprint'],
                       'reused_qualification_id': certificate['id'], 'available_time_rows': available,
                       'target_time_rows': 3, 'all_single3_family4_once_each_route': True,
                       'original_caps_unchanged': True, 'preexisting_reservations': 0,
                       'preexisting_studies': 0}, stream, indent=2)
        estimate = {'world_time_rows': 3, 'observed_compute_ms': 1, 'observed_storage_bytes': 1,
                    'qualification': 'Fixed engineering proof estimate; unauthenticated, no performance claim.'}
        cost = op('add_source', data_class='development', body={'schema': 'development-study-cost-estimate/1', **estimate})
        studies = {}
        pairs = []
        receipt['attempts'] = []
        for kind, plan, diagnostic in (('information', single_plan, single_diagnostic), ('family', family_plan, family_diagnostic)):
            config = profile()
            config.update(targets=[3], worlds_per_cell=1, seed=8126,
                          cost_estimate={'source_ref': cost['id'], **estimate})
            config['budget'].update(max_compute_ms=360000, attempt_compute_ms=120000,
                max_storage_bytes=2*1024**3, attempt_storage_bytes=256*1024**2, max_attempts=1)
            if kind == 'family':
                config.update(responses=['a', 'b'], patterns=[[0, 0], [0, 1], [1, 1], [2, 2]])
            request = {'plan_id': plan['id'], 'execution_id': execution['id'], 'diagnostics_id': diagnostic['id'], 'profile': config}
            scalar = op('prepare_' + kind + '_study', key='scalar-' + kind, **request)
            native = op('prepare_native_' + kind + '_study', key='native-' + kind,
                        native_qualification_id=certificate['id'], **request)
            assert native['body']['manifest'] == scalar['body']['manifest']
            studies[kind] = native
            pairs.append((kind, scalar, native))
        with (target / 'prepared-studies-3row.json').open('x', encoding='utf-8') as stream:
            json.dump({'qualification': certificate, 'pairs': pairs, 'purpose': receipt['scope']}, stream, indent=2)
        # Preserve every capsule before execution; restore from this exact backup
        # without the qualifier's derived cache. No old uncertain study is used.
        receipt['backup'] = op('backup_bundle', destination=str(target / 'study-backup-3row'))
        key = broker.directory / 'operator.key'
        broker.close(); broker = None
        restore_bundle(target / 'study-backup-3row', target / 'restored-3row', key)
        broker = Broker(target / 'restored-3row')
        assert not (broker.directory / 'native-runtime-cache').exists()
        assert op('inspect_native_runtime_qualification', qualification_id=certificate['id'])['status'] == 'STALE'
        print(json.dumps({'phase': 'restored_without_cache', 'blobs': receipt['backup']['blobs']}), flush=True)
        for kind, scalar, native in pairs:
            engine_uses = 0
            worlds = native['body']['manifest']['worlds']
            for world in worlds:
                observed = []
                for selected, study in (('scalar', scalar), ('native', native)):
                    operation = 'advance_' + ('native_' if selected == 'native' else '') + kind + '_study'
                    call_started = time.perf_counter()
                    view = op(operation, study_id=study['id'])
                    outer_seconds = str(time.perf_counter() - call_started)
                    receipt['views'][kind + '/' + selected] = view
                    attempt = op('get_artifact', artifact_id=view['attempt_artifact_ids'][-1])
                    body = attempt['body']
                    assert body['world_id'] == world['id']
                    receipt['attempts'].append({'kind': kind, 'engine': selected, 'study_id': study['id'],
                        'attempt_id': attempt['id'], 'state': body['outcome']['state'], 'failure': body['failure'],
                        'settlement': body['settlement'], 'outer_call_seconds': outer_seconds, 'draw_engines': [p.get('draw_engines') for p in body['proofs']],
                        'stream_encoding': [p.get('stream_encoding') for p in body['proofs']]})
                    assert body['failure'] is None and body['outcome']['state'] in ('VERIFIED', 'INFORMATION_GAP')
                    assert len(body['proofs']) == 2 and body['scientific_readiness'] is False
                    print(json.dumps({'phase': 'checked_world', 'kind': kind, 'engine': selected,
                                      'world_id': world['id'], 'state': body['outcome']['state']}), flush=True)
                    stream = body['output_blobs']['generate/stream.jsonl.gz']
                    assert stream == body['output_blobs']['replay/expected-stream.jsonl.gz']
                    observed.append((body['result'], stream))
                    if selected == 'native':
                        engine_uses += sum(item['native'] for item in body['proofs'][0]['draw_engines'])
                assert observed[0] == observed[1], 'Full scalar/native world result or stream differs'
            receipt[kind + '_native_engine_uses'] = engine_uses
            assert engine_uses > 0, 'Fixed complete engineering fixture never invoked native calculation'
            assert view['status'] == 'COMPLETE'
        for study in studies.values():
            assert op('get_artifact', artifact_id=study['id']) == study
        assert len(receipt['attempts']) == receipt['planned_attempts']
        assert len(receipt['views']) == 4
        for view in receipt['views'].values():
            assert view['status'] == 'COMPLETE' and not view['continuation_ids']
            assert not view['budget']['usage_uncertain'] and view['scientific_readiness'] is False
        assert op('get_artifact', artifact_id=certificate['id']) == certificate
        assert op('inspect_native_runtime_qualification', qualification_id=certificate['id'])['status'] == 'CURRENT'
        assert op('verify')['status'] == 'PASS'
        assert 'numpy' not in sys.modules and '_trf_stationary_native' not in sys.modules
        assert footprint(source_bundle()) == {k:v for k,v in receipt['source_footprint'].items() if k.startswith('trading_researcher/')}
        receipt['controller_numpy_imported'] = False
        receipt['status'] = 'PASS'
    except BaseException as exc:
        receipt['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        receipt['status'] = 'FAILED_RETAINED_NO_RETRY'
        raise
    finally:
        try:
            if broker is not None:
                broker.close()
        except BaseException as exc:
            receipt['status'] = 'FAILED_RETAINED_NO_RETRY'
            receipt['close_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
            raise
        finally:
            receipt['seconds'] = str(time.monotonic() - begun)
            with (target / 'completion-receipt.json').open('x', encoding='utf-8') as stream:
                json.dump(receipt, stream, indent=2)
            print(json.dumps({k:v for k,v in receipt.items() if k in
                ('status', 'failure', 'close_failure', 'seconds', 'information_native_engine_uses', 'family_native_engine_uses')}), flush=True)


if __name__ == '__main__':
    assert len(sys.argv) == 2
    run(sys.argv[1])
