"""Export this completed adoption proof; no Registry mutation or execution."""
import hashlib
import json
from pathlib import Path
import sqlite3
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
ACTUAL = WORK / 'actual-v2-runtime'
receipt = json.loads((ACTUAL / 'completion-receipt.json').read_text(encoding='utf-8'))
process = json.loads((WORK / 'completion-process.json').read_text(encoding='utf-8'))
review = json.loads((WORK / 'independent-adoption-review.json').read_text(encoding='utf-8'))
assert receipt['status'] == 'PASS' and process['exit_code'] == 0
assert len(receipt['attempts']) == 14 and len(receipt['views']) == 4
# The independent review owns its explicit scoped status; retain it verbatim.
assert 'PASS' in review['status']
registry = ACTUAL / 'restored-3row'
db = sqlite3.connect(registry.joinpath('registry.sqlite3').as_uri() + '?mode=ro', uri=True)
db.execute('PRAGMA query_only=ON')
artifacts = {i: json.loads(raw) for i, raw in db.execute('SELECT id,envelope FROM artifacts')}
events = [{'seq': n, 'previous_hash': previous, 'envelope': json.loads(raw), 'hash': checksum}
          for n, previous, raw, checksum in db.execute('SELECT seq,previous_hash,envelope,hash FROM events ORDER BY seq')]
selected = {a['attempt_id'] for a in receipt['attempts']} | {a['study_id'] for a in receipt['attempts']} | {receipt['qualification']['id']}
closure = set()
def visit(identity):
    if identity in closure:
        return
    item = artifacts[identity]
    closure.add(identity)
    for ref in item['source_refs']:
        visit(ref)
for identity in sorted(selected):
    visit(identity)
metadata = {'scope': 'Exact artifact ancestry/events for completed engineering proof; source and distinct generated streams retained separately. No DB, credentials, cache, wheel or runtime binary exported.',
            'artifacts': [artifacts[i] for i in sorted(closure)], 'events': events}
(WORK / 'actual-artifacts-and-events.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
streams = {}
for attempt in receipt['attempts']:
    body = artifacts[attempt['attempt_id']]['body']
    desc = body['output_blobs']['generate/stream.jsonl.gz']
    assert desc == body['output_blobs']['replay/expected-stream.jsonl.gz']
    streams[desc['sha256']] = desc['size']
files = {}
def include(path):
    path = Path(path)
    assert path.is_file()
    name = path.relative_to(ROOT).as_posix()
    assert name not in files
    files[name] = path.read_bytes()
for path in sorted(WORK.iterdir()):
    if path.is_file() and path.suffix in {'.py', '.pyx', '.c', '.json', '.txt', '.diff', '.zip'}:
        if path.name not in {'canonical-native-runtime-v2.zip', 'archive-receipt.json'}:
            include(path)
for name in ['source.zip', 'receipt.json', 'completion-intent.json', 'completion-receipt.json', 'prepared-studies-3row.json']:
    include(ACTUAL / name)
for name in ['tests/test_native_profile_versions_independent.py', 'tests/test_native_qualification_independent.py',
             'tests/test_native_study_independent.py', 'tests/test_native_study_transport_independent.py',
             'tests/test_native_study_provenance_independent.py',
             'trading_researcher/native/_trf_stationary_native.pyx', 'trading_researcher/native_backend.py',
             'trading_researcher/native_qualification.py', 'trading_researcher/native_qualification_profile.py']:
    include(ROOT / name)
for identity, size in sorted(streams.items()):
    path = registry / 'blobs' / identity[:2] / identity
    raw = path.read_bytes()
    assert len(raw) == size and hashlib.sha256(raw).hexdigest() == identity
    files['retained-world-streams/' + identity + '.jsonl.gz'] = raw
qualification_outputs = artifacts[receipt['qualification']['id']]['body']['output_blobs']
for desc in qualification_outputs.values():
    identity, size = desc['sha256'], desc['size']
    name = 'retained-qualification-outputs/' + identity
    if name not in files:
        raw = (registry / 'blobs' / identity[:2] / identity).read_bytes()
        assert len(raw) == size and hashlib.sha256(raw).hexdigest() == identity
        files[name] = raw
manifest = {name: {'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()} for name, raw in files.items()}
files['retention-manifest.json'] = json.dumps(manifest, indent=2).encode()
destination = ROOT / 'tests/fixtures/native-packing-adoption-checks-2026-11-02.zip'
assert not destination.exists()
with ZipFile(destination, 'x', compression=ZIP_DEFLATED, compresslevel=6) as archive:
    for name, raw in files.items():
        archive.writestr(name, raw)
with ZipFile(destination) as archive:
    assert archive.testzip() is None and set(archive.namelist()) == set(files)
    for name, raw in files.items():
        assert archive.read(name) == raw
result = {'path': destination.relative_to(ROOT).as_posix(), 'bytes': destination.stat().st_size,
          'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(), 'members': len(files),
          'selected_artifact_ancestry': len(closure), 'events': len(events),
          'distinct_full_world_streams': len(streams), 'CRC_all_raw_readback': 'PASS',
          'scope': metadata['scope']}
(WORK / 'archive-receipt.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result))
db.close()
