"""Version the selected canonical input; retain every v1 member and dependency."""
import copy
import hashlib
import json
from pathlib import Path
import sys
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from trading_researcher.codec import canonical, decode, digest
from trading_researcher.native_runtime import validate_archive

previous = ROOT / '.trf-runtime/native-runtime-2026-11-02'
original = previous / 'canonical-native-runtime.zip'
raw = original.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '8c0458b745399a3bc92f912bb129ea1c6969466a0cad3239d5c361c23746dc21'
old_manifest = decode((previous / 'canonical-native-runtime-manifest.json').read_bytes())
assert digest(old_manifest) == '384f70b80d41878c3b7a35c7e3b7b981ea891aa6dabe5df79e9893ead707ee33'
validate_archive(raw, old_manifest)
manifest = copy.deepcopy(old_manifest)
kernel_name = '_trf_stationary_native.cp314-win_amd64.pyd'
kernel = HERE / kernel_name
source = HERE / '_trf_stationary_native.pyx'
build = HERE / 'canonical-build.json'
assert hashlib.sha256(kernel.read_bytes()).hexdigest() == '318b5a84c357902af965c154bd0652c837503e5783a156f506c13872e1639a36'
assert hashlib.sha256(source.read_bytes()).hexdigest() == 'b4fb9106bb2b2e7715a5b7e34a2d468d4f950cc5e60dc1571531397ea3a8f5b6'
target = HERE / 'canonical-native-runtime-v2.zip'
files = {}


def retain(archive, name, data):
    assert name not in files
    info = ZipInfo(name, date_time=(2026, 11, 2, 0, 0, 0))
    info.compress_type = ZIP_DEFLATED
    archive.writestr(info, data)
    files[name] = {'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


with ZipFile(original) as old, ZipFile(target, 'x') as new:
    for name in old.namelist():
        data = old.read(name)
        assert old_manifest['files'][name] == {'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        selected = 'provenance/previous-kernels/v1/' + name if name == kernel_name else name
        retain(new, selected, data)
    for name, path in {kernel_name: kernel, 'provenance/stationary-native-v2.pyx': source,
                       'provenance/stationary-native-v2-build.json': build}.items():
        retain(new, name, path.read_bytes())
manifest['files'] = files
manifest['dependencies']['owned-stationary-native-v1'] = copy.deepcopy(old_manifest['dependencies']['owned-stationary-native'])
manifest['dependencies']['owned-stationary-native'] = {
    'version': 'stationary-native-int64/1+packing.1',
    'distribution_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'license_files': old_manifest['dependencies']['owned-stationary-native']['license_files']}
validate_archive(target.read_bytes(), manifest)
with (HERE / 'canonical-native-runtime-v2-manifest.json').open('x', encoding='utf-8') as stream:
    stream.write(canonical(manifest))
receipt = {'scope': 'New immutable input version only; no runtime/scientific certificate.',
           'archive_sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'archive_bytes': target.stat().st_size,
           'manifest_sha256': digest(manifest), 'files': len(files),
           'unpacked_bytes': sum(value['size'] for value in files.values()),
           'old930_members_preserved_bytewise': len(old_manifest['files']),
           'old_kernel_nonimported_provenance': 'provenance/previous-kernels/v1/' + kernel_name,
           'new_kernel_sha256': files[kernel_name]['sha256']}
with (HERE / 'runtime-preparation.json').open('x', encoding='utf-8') as stream:
    json.dump(receipt, stream, indent=2)
print(json.dumps(receipt))
