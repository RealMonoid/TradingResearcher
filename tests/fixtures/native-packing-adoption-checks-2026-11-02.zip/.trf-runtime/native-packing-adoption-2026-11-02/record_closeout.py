"""Update only the existing adoption work item after retained independent closeout."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
PROGRESS = ROOT / 'docs/reviews/implementation-2026-10-25/progress.json'
def read(name):
    return json.loads((WORK / name).read_text(encoding='utf-8'))
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def evidence(name):
    p = WORK / name
    return {'path': p.relative_to(ROOT).as_posix(), 'sha256': sha(p)}
receipt = read('actual-v2-runtime/completion-receipt.json')
archive = read('archive-receipt.json')
review = read('independent-adoption-review.json')
assert receipt['status'] == 'PASS' and 'PASS' in review['status']
text = PROGRESS.read_bytes().decode('utf-8')
original = json.loads(text)
profile = original['scientific_information_profile_2026_11_02']
exact = profile['exact_acceleration']
packing = exact['native_path_packing']
assert 'canonical_adoption' not in packing
old_next = packing['next_action']
next_action = ('Measure canonical runtime/2 on the existing fixed4096-row owned caller workload with one predeclared scalar/native ordinal-zero pair and complete separate replay under the existing300000ms/256MiB per-attempt, one-attempt and fixed four-world inventory limits. Reuse the established preparation/caller and qualified immutable runtime; preserve all prior charges/attempts/exposure and fresh source-bound certification. Source-derived seeds may change with fresh bindings, so do not substitute an unmatched historical scalar result or retarget an old capsule. Retain complete public-call/setup/settlement timing and actual storage. No later world, continuation, new final series, budget increase, native-libm replacement, skipped checker, protected2024/scientific/API/grant authority or original-A continuation. Reassess whole-series feasibility only from applicable measured evidence under the selected existing limits; remaining package3/4 acceptance stays open.')
test_groups = {
 'profile_versions': {'methods':16,'new':16,'seconds':'2.963','exit_code':0,'record':evidence('version-green.json'),'scope':'Independent metadata/source/version/alias cases; explicit private seams, no real numerical world.'},
 'runtime_qualification': {'methods':31,'seconds':'12.614','exit_code':0,'record':evidence('checks-qualification-v2.json'),'scope':'All30 prior test bodies retained; current profile metadata fixture refreshed and one legacy13case-report rejection added. Original3 old-metadata errors retained.'},
 'study_lifecycle_transport': {'methods':36,'full_run_seconds':'379.058','full_run_exit_code':1,'full_run':evidence('checks-study-lifecycle-transport.json'),'scope':'35 methods pass; one method fails only obsolete expected profile1 literal in two subtests. Independent exactly-one-byte fixture correction then ONLY that open method passes in153.970s; no rerun of35passes.', 'targeted_methods':1,'targeted_seconds':'153.970','targeted_exit_code':0,'targeted_record':evidence('binding-method-complete.json')},
 'legacy_provenance': {'methods':15,'seconds':'2.064','exit_code':0,'scope':'Unchanged v1 provenance assertion bodies at final production source; real v1 restore/read-only denial independently reconciled separately.'},
 'canonical_loop': {'methods':21,'seconds':'2.205','exit_code':0,'record':evidence('canonical-loop-check.json'),'scope':'Same byte-pinned21 independently authored methods as selected probe; canonical export name/binary supplied, no assertion or old source guard changed.'},
 'canonical_factory': {'methods':10,'seconds':'6.037647499993909','exit_code':0,'record':evidence('canonical-factory-qualification.json'),'scope':'Same existing actual factory/fallback assertions;17native and5declined lengths. No new method count from binary contexts.'}}
node = {
 'status':'PASS_CANONICAL_RUNTIME_2_RESERVED_DEVELOPMENT_ONLY',
 'criterion':'Existing Package4 exact acceleration and REQ-005/020/024/029: complete the selected packing implementation through independently qualified immutable inputs, actual reserved single/family callers, full separate replay, strict currentness/admission, resource/failure/revocation/recovery and cache-free restore paths. This is technical completion of one slice, not scientific admission or full package completion.',
 'purpose':'Adopt the already selected exact eight-store delta without changing mathematics, random consumption, checker order, fallback, scientific meaning or resource authority.',
 'prior_status':packing['status'],'completed_prior_next_action':old_next,'source_base':'44be0f1',
 'reuse':'Existing pinned NumPy2.3.4/Cython3.3.1/Zig0.16.0 build, owned int64/wire adapter, Registry/runtime/cache, source and environment qualification, immutable study/attempt ledger, backup/restore and separate child replay. No new library, generic platform or scientific method; struct packing remains the independent byte oracle.',
 'version_binding':{'current':'stationary-native-runtime/2','legacy':'stationary-native-runtime/1','numeric_ABI':'stationary-native-int64/1','source_sha256':sha(ROOT/'trading_researcher/native/_trf_stationary_native.pyx'),'binary_sha256':'318b5a84c357902af965c154bd0652c837503e5783a156f506c13872e1639a36','archive_sha256':'4d379ab0dc5d689445c1f720b967b923b8106af4184de1576418837c23853976','manifest_sha256':'20151908bc9fd2b09ac407caebc5d7bbc2f79016315b8b59d736d2427297c848','archive_bytes':26258151,'files':933,'cold_bytes':57323346,'policy':'Explicit known1/2 metadata ownership and same-profile source/input/certificate closure. Current2 required before code/cache/use. Legacy1 exact old membership remains metadata-only; original certificate body/key history is unchanged but inspection is stale, never current. Aliases cannot replace original study/source/runtime binding or reset inventory/charges. Old binary retained as non-imported provenance; ABI/domain/128files/16MiB source and all scientific limits unchanged.'},
 'source':{'files':121,'bytes':10819160,'project_files':111,'archive':evidence('actual-v2-runtime/source.zip'),'owners':{n:sha(ROOT/n) for n in ['trading_researcher/native_backend.py','trading_researcher/native_qualification.py','trading_researcher/native_qualification_profile.py']},'historical_guards':'Original013a4061 packing cases and342dd443 oracle are unchanged, including old703kernel/db03generated-C guards. Adapter imports their definitions, verifies retained old inputs, then supplies current canonical core; standalone legacy guards are not repinned.'},
 'checks':{'distinct_affected_methods':129,'groups':test_groups,'count_scope':'Same methods executed in different binary/qualifier contexts are not additional distinct methods. The full36run remains exit1 history; its35passes plus corrected single-method pass cover36, not a newly green full36 rerun. Unchanged prerequisite cache/storage/publication evidence retains its original source/scope; no needless numerical rerun.'},
 'actual_qualification':{**receipt['qualification'],'runtime_id':'03d76efecd8c94d622571e5792ad28b2bab4a0dbb13fa4e86a1c3e94e8957c5f','input_id':'9a58de49935df02a7e6c9a9611ac4806abd1641b12ad0b168d5082139cb47195','source_package_id':'64e4783dfb1089b0980ccb1af43bb05d84ba257ffb0356f343517e0d8ce6bcce','separate_children':2,'cases_each':21,'draws_each':59997,'complete_result_sha256':'720ac237f2ad3e29a5a9d94191af68a90a549f476c6e0f2d5bae36b537901b09','complete_stream_sha256':'76c3fb49b827455afaf488104f0ee88788254446e4bcf1fad07f73b42cb4f533','complete_stream_bytes':15143319,'scope':'One actual qualifier call completed successfully before the denied study preparation. Reused exactly, never requalified for correction; source/host/runtime/output currentness checked at actual intended use.'},
 'actual_reserved_callers':{'status':receipt['status'],'receipt':evidence('actual-v2-runtime/completion-receipt.json'),'process':evidence('completion-process.json'),'whole_correction_path_seconds':receipt['seconds'],'process_seconds':read('completion-process.json')['seconds'],'target_time_rows':3,'scope':'Genuine existing3-row engineering grid, horizon1. All4capsules frozen before151blob cache-free restore; all3single+4family worlds once per route,14attempts/28generation-replay proofs. Full paired result and encoded/decoded stream equality; no favorable-outcome retry, grant or missing world. All14outcomes INFORMATION_GAP; n_min/scientific readiness stay unqualified.','native_generation_uses':{'single':receipt['information_native_engine_uses'],'family':receipt['family_native_engine_uses']},'views':{k:{'study_id':v['study_id'],'status':v['status'],'attempts':len(v['attempt_artifact_ids']),'budget':v['budget'],'continuation_ids':v['continuation_ids'],'scientific_readiness':v['scientific_readiness']} for k,v in receipt['views'].items()},'timing_limit':'All14complete public-call timers and owned settlements retained separately in receipt. Tiny native calls are slower than scalar calls; no caller speedup or full-series feasibility inferred from the earlier13.58percent calculator fixture.'},
 'independent_closeout':{'status':review['status'],'record':evidence('independent-adoption-review.json'),'source_test_and_driver_review':evidence('independent-static-reviews.json'),'scope':'Separate reviewer read-only source/Registry/proof/byte/ordinal/replicate/accounting/currentness and preservation reconciliation. Root checks exact source121/project111 and retained outcomes, then archive creation rehashes/readbacks every selected payload. No additional numerical execution.'},
 'failures_retained':{'version_red':evidence('version-red.json'),'old_qualifier_metadata_errors':evidence('checks-qualification.json'),'old_study_expected_version_failure':evidence('checks-study-lifecycle-transport.json'),'targeted_outer_timeout':evidence('binding-method-outer-timeout.json'),'targeted_resolution':'Outer120s diagnostic wrapper expired before genuine fixture setup completed. No pass inferred; no owned child remained. Only open method rerun with600s outer observation, framework caps unchanged, passes153.970s.','invalid_initial_target':{'record':evidence('actual-v2-runtime/receipt.json'),'status':'FAILED_RETAINED_NO_RETRY','path_seconds':'239.61054510000395','failure':'Target16 exceeds actual assigned3-row grid; denied by first scalarprepare before any study input or reservation. Existing successful qualifier and genuine inputs preserved; initial target3 correction precedes all study work, not a frozen-study retarget.'},'readonly_diagnostics':'Initial preexecution review missed assigned-grid dependency; corrected review checks actual report/owners. Later central projection KeyError(proofs) corrected to owning certificate.report.proofs without any numerical retry. Conditional driver engine-use assertion could stop remaining inventory if zero, but it passes here; INFO_GAP alone does not imply zero native draws.'},
 'legacy_preservation':{'record':evidence('legacy-read-receipt.json'),'status':'PASS_LEGACY_HISTORY_NO_CURRENT_USE','artifacts_unchanged':156,'events_unchanged':171,'old_studies_unchanged':4,'use_denial':'Historical native profile is read-only; current qualification required','source_binary_certificate_capsules':'Original v1 snapshots and all old charges/exposure preserved; no old source/currentness promotion or study retarget. Original completed32-world development and derived final remain bound to their calculator.'},
 'completed_acceptance':['Canonical kernel/runtime2 binds exact selected source and unchanged independent oracle/math/random/check/fallback behavior; source/input/certificate profile mismatches and unsupported membership deny.','Actual owned qualifier and all fixed reserved single/family callers complete full separate replay with immutable inputs, current source/host/cache/output checks and NumPy-free controller.','Existing admission/resource/failure/unknown-use/revocation/recovery controls checked at final source; actual cache-free restore charges exact cold materialization once and preserves every attempt and initial charge.','Independent legacy restoration and version/alias controls retain historical body/readability while denying new stale use; no promotion, retarget, budget reset or discarded failure.'],
 'unverified':['Full fixed4096-row caller cost/benefit for canonical runtime2 and whole-series feasibility under existing limits.','Scientific model adequacy, defensible N_min, fresh final calibration and remaining package3/4 acceptance; no native final selector or transfer of completed study.','Hard OS containment/reclamation, RAM/disk/CPU quotas, memory-image security identity, cross-platform/cross-Python historical compatibility, general acceleration/economic quality and global anti-rollback across cloned Registries.'],
 'preservation':{'auxiliary_draft_sha256':'6ca0e43035e57cd8ad0db7a07a2010ba6b30627bf0785617e4787f35e537b289','research_calls':53,'USD_remaining':'0.574585','old_revoked_grants':7,'scope':'No paid inference/count/API/grant/production enrollment or protected2024/scientific/final/capital operation. Original A/AgentWorkflow stay paused. Source/Blob/attempt limits unchanged; no live owned probe remains at closeout.'},
 'archive':archive,'construction_effort':'Canonical build1.331474/3.2832375s; qualifier80634ms; initial failed preparation path239.6105451s; corrected complete path505.0232793s/process505.7531124s. Test contexts and retained failures carry exact timers above. Independent coordination/review/waiting and total construction CPU/RSS/disk/model tokens/cash remain unknown; no overall speed/quality-equivalence claim.',
 'next_action':next_action}
# Replace only selected current pointers and bounded packing node; retain all other values.
for indent in (2,4,6):
    before='\n'+' '*indent+'"next_action": '+json.dumps(old_next)
    after='\n'+' '*indent+'"next_action": '+json.dumps(next_action)
    assert text.count(before)==1,(indent,'next pointer count')
    text=text.replace(before,after,1)
status_before='\n      "status": '+json.dumps(exact['status'])
assert text.count(status_before)==1
text=text.replace(status_before,'\n      "status": "CANONICAL_RUNTIME_2_ADOPTED_FULL_CALLER_MEASUREMENT_NEXT"',1)
tag='\n      "native_path_packing": '
assert text.count(tag)==1
start=text.index(tag)+len(tag)
old_node,end=json.JSONDecoder().raw_decode(text[start:]);end+=start
assert old_node==packing
old_node['status']='PASS_CANONICAL_RUNTIME_2_TECHNICAL_ADOPTION'
old_node['next_action']=next_action
old_node['canonical_adoption']=node
encoded=json.dumps(old_node,indent=2,ensure_ascii=True).splitlines()
encoded='\n'.join([encoded[0]]+['      '+line for line in encoded[1:]])
text=text[:start]+encoded+text[end:]
updated=json.loads(text)
expected=json.loads(json.dumps(original))
expected['next_action']=next_action
expected['scientific_information_profile_2026_11_02']['next_action']=next_action
expected_exact=expected['scientific_information_profile_2026_11_02']['exact_acceleration']
expected_exact['next_action']=next_action;expected_exact['status']='CANONICAL_RUNTIME_2_ADOPTED_FULL_CALLER_MEASUREMENT_NEXT'
expected_exact['native_path_packing']=old_node
assert updated==expected,'Unrelated progress values changed'
PROGRESS.write_bytes(text.encode('utf-8'))
(WORK/'adoption-record.json').write_text(json.dumps(node,indent=2),encoding='utf-8')
print(json.dumps({'status':node['status'],'unrelated_progress_values_preserved':True,'archive_sha256':archive['sha256'],'next_action':next_action}))
