"""Retain this completed fixed caller comparison; no execution or DB writes."""
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
assert len(sys.argv) == 2, 'Sealed final independent review SHA required'
review_raw = (WORK / 'post-call-independent-review.json').read_bytes()
assert hashlib.sha256(review_raw).hexdigest() == sys.argv[1]
review = json.loads(review_raw)
receipt = json.loads((WORK / 'comparison-receipt.json').read_text(encoding='utf-8'))
process = json.loads((WORK / 'comparison-process.json').read_text(encoding='utf-8'))
assert review['status'].startswith('PASS') and receipt['status'] == 'PASS' and process['exit_code'] == 0
assert receipt['calls_started'] == receipt['calls_planned'] == 2
registry = WORK / 'registry'
db = sqlite3.connect(registry.joinpath('registry.sqlite3').as_uri() + '?mode=ro', uri=True)
db.execute('PRAGMA query_only=ON')
artifacts = {i:json.loads(raw) for i,raw in db.execute('SELECT id,envelope FROM artifacts')}
events = [{'seq':n,'previous_hash':previous,'envelope':json.loads(raw),'hash':checksum}
          for n,previous,raw,checksum in db.execute('SELECT seq,previous_hash,envelope,hash FROM events ORDER BY seq')]
selected = set()
for attempt in receipt['attempts'].values():
    selected.update([attempt['artifact_id'], attempt['study_id']])
closure = set()
def visit(identity):
    if identity in closure:
        return
    item = artifacts[identity]
    closure.add(identity)
    for ref in item['source_refs']:
        visit(ref)
for identity in sorted(selected):
    visit(identity)
meta = {'scope':'Exact current2 fixed4096caller artifact ancestry and event chain; qualified source and full shared stream retained, no database/key/cache/wheel/runtime binary.',
        'artifacts':[artifacts[i] for i in sorted(closure)],'events':events}
(WORK / 'comparison-artifacts-and-events.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
streams = []
for attempt in receipt['attempts'].values():
    body = artifacts[attempt['artifact_id']]['body']
    desc = body['output_blobs']['generate/stream.jsonl.gz']
    assert desc == body['output_blobs']['replay/expected-stream.jsonl.gz']
    raw = (registry / 'blobs' / desc['sha256'][:2] / desc['sha256']).read_bytes()
    assert len(raw) == desc['size'] and hashlib.sha256(raw).hexdigest() == desc['sha256']
    streams.append(raw)
assert streams[0] == streams[1]
with (WORK / 'shared-stream.jsonl.gz').open('xb') as stream:
    stream.write(streams[0])
files = {}
def include(path):
    path = Path(path)
    name = path.relative_to(ROOT).as_posix()
    assert name not in files
    files[name] = path.read_bytes()
for path in sorted(WORK.iterdir()):
    if path.is_file() and path.suffix in {'.py','.json','.txt','.diff','.zip','.gz','.jsonl'} and path.name != 'archive-receipt.json':
        include(path)
intent = json.loads((WORK / 'preparation-intent.json').read_text(encoding='utf-8'))
for name, expected in intent['fixture_sources'].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected
    include(ROOT / name)
include(ROOT / 'trading_researcher/native/_trf_stationary_native.pyx')
manifest = {name:{'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in files.items()}
files['retention-manifest.json'] = json.dumps(manifest,indent=2).encode()
destination = ROOT / 'tests/fixtures/native-packing-owned-call-comparison-2026-11-02.zip'
assert not destination.exists()
with ZipFile(destination,'x',ZIP_DEFLATED,compresslevel=6) as archive:
    for name,raw in files.items():
        archive.writestr(name,raw)
with ZipFile(destination) as archive:
    assert archive.testzip() is None and set(archive.namelist()) == set(files)
    for name,raw in files.items():
        assert archive.read(name) == raw
result = {'path':destination.relative_to(ROOT).as_posix(),'bytes':destination.stat().st_size,
          'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'members':len(files),
          'selected_artifact_ancestry':len(closure),'events':len(events),'full_shared_stream_bytes':len(streams[0]),
          'CRC_all_raw_readback':'PASS','sealed_post_review_sha256':sys.argv[1],'scope':meta['scope']}
(WORK / 'archive-receipt.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
db.close()
