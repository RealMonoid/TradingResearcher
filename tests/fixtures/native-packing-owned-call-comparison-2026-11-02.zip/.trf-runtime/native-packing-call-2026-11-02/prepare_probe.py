"""Prepare, but NEVER advance, one fixed owned scalar/native family comparison.

This offline engineering fixture preserves the actual BindingFixture delay=0
semantics. That value is synthetic exact availability, not a market-publication
assumption. Reference/feature qualification and development execution use their
real owners. The scripted formalizer makes no natural-language fidelity claim.

Run only after central source/intent review. This command refuses a used target,
retains failure receipts, and contains no study advance, grant, retry, network,
model, final-calibration or protected-data operation. A later separately reviewed
driver may advance ONLY ordinal zero of each newly prepared study, once each.
"""
from contextlib import closing
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import time
from zipfile import ZipFile, ZIP_DEFLATED


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'tests')]

from binding_support import fixture as binding_fixture, resolve
from test_binance_normalize import NormalizeTests
from test_binance_quality import row
from test_information_study import profile as scalar_profile
from trading_researcher.codec import canonical, decode, digest
from trading_researcher.coordination import Broker
from trading_researcher.evaluation_plans import source_bundle, footprint
from trading_researcher.native_qualification_profile import capture_source
from trading_researcher.storage import restore_bundle


BASE = ROOT / '.trf-runtime/native-packing-adoption-2026-11-02/actual-v2-runtime'
BACKUP = HERE / 'baseline-backup'
BACKUP_MANIFEST_SHA = 'd952aeca735de097cc47561b575a36eca59a1a8185be5c286565265d94b8c7fa'
QUALIFICATION = '54f7a5e5e3bab0091818de427bf916bf129f5c4ff724f9d7deb5f3847ec8e00c'
RUNTIME_SOURCE_SHA = '4f3a2097380a640c14dfeaa89c9e12a35aee54f7768aba251a795c21e8382e74'
REGISTRY = HERE / 'registry'
RAW_ROWS = 4097
TEST_ROWS = 4096
DELAY_SECONDS = 0
SEED = 713
START_OPEN = datetime(2020, 1, 1, tzinfo=timezone.utc)
FIRST_NORMALIZED = START_OPEN + timedelta(seconds=900)
SNAPSHOT_END = FIRST_NORMALIZED + timedelta(seconds=RAW_ROWS * 900)
TEST_END = FIRST_NORMALIZED + timedelta(seconds=TEST_ROWS * 900)
STUDY_SCHEMAS = {'information-study-input/1', 'native-information-study-input/1',
                 'family-study-input/1', 'native-family-study-input/1'}
LIMITS = {'max_compute_ms': 300000, 'attempt_compute_ms': 300000,
          'max_storage_bytes': 1024**3, 'attempt_storage_bytes': 256 * 1024**2,
          'max_attempts': 1}


def stamp(value):
    return value.strftime('%Y-%m-%dT%H:%M:%SZ')


def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def retain_json(name, value):
    with (HERE / name).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')


def artifact_inventory(directory):
    """Read-only enumeration, since Broker has no operator list-artifacts API.

    Records are subsequently fetched and integrity-checked by public get_artifact.
    This function writes nothing and creates no certificate or controller record.
    """
    with closing(sqlite3.connect((directory / 'registry.sqlite3').as_uri() + '?mode=ro', uri=True)) as db:
        records = {identity: decode(raw) for identity, raw in db.execute('SELECT id,envelope FROM artifacts')}
        for identity, envelope in records.items():
            assert digest(envelope) == identity, 'Read-only immutable artifact mismatch'
        reserved = [decode(raw) for raw, in db.execute('SELECT envelope FROM events ORDER BY seq')
                    if decode(raw)['action'] == 'information_study_reserved']
    return records, reserved


def synthetic_months():
    """Reuse the CSV row fixture, replacing its fixed small-price OHLC fields."""
    months = {}
    for index in range(RAW_ROWS):
        opened = START_OPEN + timedelta(seconds=index * 900)
        price = (100, 102, 103)[index % 3]
        fields = row(int(opened.timestamp()) * 1000).decode('ascii').strip().split(',')
        assert len(fields) == 12
        fields[1:5] = [str(price), str(price + 1), str(price - 1), str(price)]
        fields[7] = str(price * 5)
        fields[10] = str(price * 2)
        months.setdefault(opened.strftime('%Y-%m'), []).append((','.join(fields) + '\n').encode('ascii'))
    assert set(months) == {'2020-01', '2020-02'}
    values = {month: b''.join(lines) for month, lines in months.items()}
    assert sum(len(value.splitlines()) for value in values.values()) == RAW_ROWS
    return values


def run():
    # Fail closed rather than overwriting receipts or silently repairing a failed
    # setup. Parent review must select any later attempt explicitly.
    assert not REGISTRY.exists(), 'Preparation target already exists; inspect retained history'
    for name in ('preparation-intent.json', 'preparation-receipt.json', 'source.zip', 'prepared-inputs.json'):
        assert not (HERE / name).exists(), 'Preparation artifact already exists: ' + name
    begun = time.monotonic()
    receipt = {'purpose': 'Prepare only one predeclared ordinal-zero scalar/native owned family-world comparison.',
               'started_utc': now(), 'phases': [], 'status': 'INCOMPLETE',
               'study_advances': 0, 'scientific_readiness': False}
    broker = None
    normalizer = None
    current_phase = 'preparation_intent'
    phase_start = begun

    def phase(name):
        nonlocal current_phase, phase_start
        ended = time.monotonic()
        receipt['phases'].append({'name': current_phase, 'ended_utc': now(),
                                  'seconds': str(ended - phase_start)})
        current_phase, phase_start = name, ended
        print(json.dumps({'phase': name, 'utc': now()}), flush=True)

    def op(operation, **args):
        assert not operation.startswith('advance_'), 'This preparation never advances any study'
        assert operation not in {'continue_study', 'qualify_native_runtime', 'create_research_epoch',
                                 'reserve_research_call', 'finish_research_call'}
        return broker.call(broker.admin_token, operation, **args)

    try:
        project = source_bundle()
        source = capture_source()
        original = decode((BASE / 'completion-receipt.json').read_bytes())
        assert original['status'] == 'PASS' and len(original['attempts']) == 14
        assert len(project) == 111
        assert sha(project['trading_researcher/native_runtime.py']) == RUNTIME_SOURCE_SHA
        assert footprint(source) == original['source_footprint'], 'Qualified source changed; do not requalify implicitly'
        assert original['qualification']['id'] == QUALIFICATION
        assert sha((BACKUP / 'manifest.json').read_bytes()) == BACKUP_MANIFEST_SHA
        backup_manifest = decode((BACKUP / 'manifest.json').read_bytes())
        assert len(backup_manifest['blobs']) == 192 and backup_manifest['credentials_included'] is False
        fixed = binding_fixture()
        assert fixed['baseline']['delay_seconds'] == DELAY_SECONDS == 0
        months = synthetic_months()
        intent = {
            'schema': 'fixed-owned-native-family-comparison-intent/1', 'created_utc': now(),
            'base_commit': '940dfcd', 'source_footprint': footprint(source),
            'script_sha256': sha(Path(__file__).read_bytes()),
            'backup': {'path': str(BACKUP), 'manifest_sha256': BACKUP_MANIFEST_SHA, 'blobs': 192},
            'qualification_id': QUALIFICATION,
            'fixture': {'symbol': 'BTCUSDT', 'raw_open_start': stamp(START_OPEN), 'raw_rows': RAW_ROWS,
                'close_cycle': [100, 102, 103], 'delay_seconds': DELAY_SECONDS,
                'availability_scope': 'Invented exact availability; actual BindingFixture baseline is zero, not NormalizeTests default five. No market-publication claim.',
                'snapshot_universe': {'start': stamp(FIRST_NORMALIZED), 'end': stamp(SNAPSHOT_END), 'instruments': ['BTCUSDT']},
                'test_universe': {'start': stamp(FIRST_NORMALIZED), 'end': stamp(TEST_END), 'instruments': ['BTCUSDT']},
                'raw_months': {month: {'sha256': sha(raw), 'size': len(raw), 'rows': len(raw.splitlines())}
                               for month, raw in months.items()},
                'program': 'FamilyFixture direct close>101 condition and next-observation close>102 binary outcome; whole-scope equal-row difference, horizon one.',
                'formalization': 'Scripted existing fixture semantic mapping; no LLM or independent natural-language fidelity claim.'},
            'study': {'primary_count': 2, 'base_length': 8, 'lags': [1, 2], 'targets': [TEST_ROWS],
                'worlds_per_cell': 1, 'seed': SEED, 'responses': ['a', 'b'],
                'patterns': [[0, 0], [0, 1], [1, 1], [2, 2]], 'budget': LIMITS,
                'selection': 'Only fixed ordinal zero in each study, once, regardless of its outcome. No retry, continuation or later world.',
                'comparison_order': ['scalar', 'native'],
                'claim_scope': 'One controlled owned caller observation including replay, cold native materialization and binding checks; no typical throughput, full-series feasibility, scientific calibration or benefit inference.'},
            'fixture_sources': {name: sha((ROOT / name).read_bytes()) for name in (
                'tests/binding_support.py', 'tests/family_run_support.py', 'tests/test_binance_normalize.py',
                'tests/test_binance_quality.py', 'tests/test_information_study.py',
                'tests/fixtures/reference_binding_cases.json')},
        }
        retain_json('preparation-intent.json', intent)
        receipt['intent_sha256'] = sha((HERE / 'preparation-intent.json').read_bytes())
        with ZipFile(HERE / 'source.zip', 'x', ZIP_DEFLATED) as archive:
            for name, raw in source.items(): archive.writestr(name, raw)
        receipt['source_archive'] = {'sha256': sha((HERE / 'source.zip').read_bytes()),
                                     'size': (HERE / 'source.zip').stat().st_size}
        phase('restore_new_registry')
        receipt['restore'] = restore_bundle(BACKUP, REGISTRY, BASE / 'restored-3row/operator.key')
        assert not (REGISTRY / 'native-runtime-cache').exists()
        broker = Broker(REGISTRY)
        original_records, original_reservations = artifact_inventory(REGISTRY)
        old_studies = {identity: envelope for identity, envelope in original_records.items()
                       if isinstance(envelope.get('body'), dict) and envelope['body'].get('schema') in STUDY_SCHEMAS}
        assert len(old_studies) == 4 and len(original_reservations) == 14
        assert len(original_records) == 171
        receipt['preserved_prior_attempt_ids'] = [item['attempt_id'] for item in original['attempts']]
        documents = [identity for identity, envelope in original_records.items()
                     if isinstance(envelope.get('body'), dict)
                     and envelope['body'].get('schema') == 'binance-provider-documents/1']
        assert len(documents) == 1
        receipt['provider_documents_id'] = documents[0]
        receipt['preserved_old_study_ids'] = sorted(old_studies)
        certificate = op('get_artifact', artifact_id=QUALIFICATION)
        assert certificate['body']['status'] == 'CERTIFIED'
        receipt['qualification_before'] = op('inspect_native_runtime_qualification', qualification_id=QUALIFICATION)
        assert receipt['qualification_before']['status'] == 'STALE', 'Missing cache must not count as execution current'
        phase('offline_monthly_sources_and_normalization')
        normalizer = NormalizeTests()
        # Reuse the existing source and isolated-normalization owners without its
        # setUp/tearDown, which would create or delete a different temporary DB.
        normalizer.root, normalizer.broker = HERE, broker
        normalizer.token, normalizer.docs = broker.admin_token, documents[0]
        sources = [normalizer.source(raw, month=month) for month, raw in sorted(months.items())]
        receipt['monthly_source_ids'] = [source['id'] for source in sources]
        normalized = normalizer.run_normalize(sources, start=stamp(FIRST_NORMALIZED),
            end=stamp(SNAPSHOT_END), instruments=['BTCUSDT'], partition='development', delay=DELAY_SECONDS)
        broker = normalizer.broker
        snapshot = normalized['snapshot']
        assert snapshot['body']['coverage']['expected_rows'] == RAW_ROWS
        assert snapshot['body']['coverage']['observed_rows'] == RAW_ROWS
        assert snapshot['body']['coverage']['missing_rows'] == 0
        assert normalized['normalization']['body']['selected_invalid_rows'] == 0
        receipt['normalization_id'], receipt['snapshot_id'] = normalized['normalization']['id'], snapshot['id']
        phase('genuine_feature_and_reference_certification')
        feature = op('certify_features', data_snapshot_id=snapshot['id'])
        receipt['feature_certificate_id'] = feature['id']
        assert feature['body']['status'] == 'CERTIFIED', feature['body']
        reference = op('certify_reference')
        receipt['reference_certificate_id'] = reference['id']
        assert reference['body']['status'] == 'CERTIFIED', reference['body']
        phase('scripted_formalization_compile_and_development_execution')
        # Minimal adapter of BindingFixture.create_formalization: that helper's
        # hardcoded worker/key already exist in the restored backup. Use fresh
        # identities with the same public record/lease/submit owner sequence.
        base = fixed['baseline']
        idea_text = ('Synthetic binary family engineering template: compare next-observation close>102 '
                     'against whole scope when current close>101; exact synthetic availability only.')
        idea = op('add_research', kind='idea', content={'text': idea_text}, scope={}, source_refs=[])
        candidate = resolve(deepcopy(base['candidate']), {'fixture:idea': idea['id'], 'fixture:data_snapshot': snapshot['id']})
        candidate['test_universe'].update(start=stamp(FIRST_NORMALIZED), end=stamp(TEST_END))
        candidate['estimand']['unit'] = 'ratio'
        candidate['outcome']['scale'] = 'binary_probability'
        candidate['outcome']['program']['expression'] = {'op': 'gt',
            'left': {'op': 'feature', 'ref': 'BTCUSDT.close@binance-spot-15m-v1'},
            'right': {'op': 'literal', 'type': 'real', 'unit': 'USDT/BTC', 'value': '102'}}
        candidate['parameter_origins'].append({'path': '/outcome/program/expression/right/value',
            'basis': 'preexisting_specification', 'source_refs': [], 'rationale': 'Fixed synthetic FamilyFixture program; no outcome selection.'})
        worker_name = 'fixed-4096-engineering-formalizer'
        worker = op('register_worker', name=worker_name, role='formalizer', capabilities=['formalization/v1'])['token']
        semantic = deepcopy(base['semantic_report'])
        semantic['segments'][0]['text'] = idea_text
        context = op('create_context', role='formalizer', epoch=1001,
                     artifact_ids=[idea['id'], snapshot['body']['catalog_id'], snapshot['id']])
        job = op('enqueue', key='fixed-4096-engineering-formalization', spec={
            'kind': 'formalization/v1', 'context_id': context['id'],
            'purpose': 'Fixed offline engineering fixture; scripted semantic assertion only.',
            'allowed_workers': [worker_name], 'max_attempts': 1, 'lease_seconds': 300,
            'deadline': int(time.time()) + 1800, 'dependencies': []})
        lease = broker.call(worker, 'claim')['lease']
        formalization = broker.call(worker, 'record_formalization', lease=lease, idea_id=idea['id'],
            catalog_id=snapshot['body']['catalog_id'], candidate=candidate, semantic_report=semantic)
        submitted = broker.call(worker, 'submit', lease=lease, artifact_id=formalization['id'])
        assert submitted['accepted'], submitted
        receipt['scripted_formalization'] = {'idea_id': idea['id'], 'context_id': context['id'],
            'job_id': job['id'], 'formalization_id': formalization['id'], 'worker_name': worker_name,
            'scope': 'Existing scripted fixture semantics; no model call or natural-language fidelity certificate.'}
        compiled = op('compile_hypothesis', formalization_id=formalization['id'],
            feature_certificate_id=feature['id'], reference_certificate_id=reference['id'],
            as_of=stamp(TEST_END - timedelta(seconds=1)), max_steps=1000000)
        assert compiled['body']['status'] == 'COMPILED', compiled['body']
        execution = op('execute_development', compiled_id=compiled['id'])
        assert execution['body']['status'] == 'DESCRIPTIVE_EXECUTION', execution['body']
        report = execution['body']['result']['report']
        assert report['expected_case_count'] == TEST_ROWS and report['processing_complete'] is True
        assert execution['body']['result']['scientific_readiness'] is False
        receipt['compiled_id'], receipt['execution_id'] = compiled['id'], execution['id']
        receipt['case_blob'] = execution['body']['result']['case_blob']
        cases = broker._read_blob_bytes(receipt['case_blob']['sha256'])
        assert sha(cases) == receipt['case_blob']['sha256'] and len(cases) == receipt['case_blob']['size']
        assert len(cases.splitlines()) == TEST_ROWS
        with (HERE / 'prepared-cases.jsonl').open('xb') as stream: stream.write(cases)
        phase('family_plan_and_owned_diagnostics')
        plan = op('prepare_evaluation_plan', key='fixed-4096-family-plan', compiled_id=compiled['id'], primary_count=2,
            dependence={'base_length': 8, 'rationale': 'Fixed engineering comparison value; not fitted model adequacy.',
                'development_refs': [execution['id']],
                'randomness': {'algorithm': 'not-used-by-family', 'version': '1', 'seed': 1}})
        diagnostic = op('prepare_information_diagnostics', key='fixed-4096-family-diagnostics',
            plan_id=plan['id'], execution_id=execution['id'], lags=[1, 2], limits={'max_seconds': 60})
        totals = diagnostic['body']['result']['totals']
        assert totals is not None and totals['scope']['count'] > 0
        assert totals['true']['count'] > 0 and totals['false']['count'] > 0 and totals['unknown']['count'] == 0
        assert 0 < int(totals['scope']['rate']['numerator']) < int(totals['scope']['rate']['denominator'])
        receipt['plan_id'], receipt['diagnostics_id'], receipt['support_totals'] = plan['id'], diagnostic['id'], totals
        phase('prepare_both_fixed_study_capsules_only')
        costs = [identity for identity, envelope in original_records.items()
                 if isinstance(envelope.get('body'), dict)
                 and envelope['body'].get('schema') == 'development-study-cost-estimate/1']
        # Select the exact already-used row3 cost root; retain the unused denied
        # target16 estimate without relabelling it or importing it into this recipe.
        prior_scalar = old_studies[original['views']['information/scalar']['study_id']]
        cost_id = prior_scalar['body']['request']['profile']['cost_estimate']['source_ref']
        assert cost_id in costs and len(costs) == 2
        cost = op('get_artifact', artifact_id=cost_id)
        assert cost['body']['world_time_rows'] == 3
        # Reuse the prior retained unauthenticated tiny-fixture planning claim.
        # It is not relabeled as observed 4096-row cost or runtime feasibility.
        estimate = {key: value for key, value in cost['body'].items() if key != 'schema'}
        config = scalar_profile()
        config.update(targets=[TEST_ROWS], worlds_per_cell=1, seed=SEED,
                      cost_estimate={'source_ref': cost['id'], **estimate},
                      responses=['a', 'b'], patterns=[[0, 0], [0, 1], [1, 1], [2, 2]], budget=deepcopy(LIMITS))
        request = {'plan_id': plan['id'], 'execution_id': execution['id'],
                   'diagnostics_id': diagnostic['id'], 'profile': config}
        scalar = op('prepare_family_study', key='fixed-4096-scalar-family', **request)
        native = op('prepare_native_family_study', key='fixed-4096-native-family',
                    native_qualification_id=QUALIFICATION, **request)
        assert scalar['body']['manifest'] == native['body']['manifest']
        study_manifest = scalar['body']['manifest']
        assert len(study_manifest['worlds']) == 4 and study_manifest['required_lengths'] == [4, 8, 16]
        assert scalar['body']['source_footprint'] == native['body']['source_footprint'] == footprint(project)
        assert scalar['body']['payload']['case_blob'] == native['body']['payload']['case_blob'] == receipt['case_blob']
        views = {'scalar': op('inspect_family_study', study_id=scalar['id']),
                 'native': op('inspect_native_family_study', study_id=native['id'])}
        selected_world = study_manifest['worlds'][0]
        for view in views.values():
            assert view['status'] == 'READY' and not view['attempt_artifact_ids']
            assert view['next_world_id'] == selected_world['id'] and not view['continuation_ids']
        assert not (REGISTRY / 'native-runtime-cache').exists(), 'Preparation must not materialize native files'
        retained, reservations = artifact_inventory(REGISTRY)
        assert reservations == original_reservations and len(reservations) == 14, 'Preparation added or changed a prior numerical reservation'
        for identity, envelope in original_records.items():
            assert retained[identity] == envelope
            assert op('get_artifact', artifact_id=identity) == {'id': identity, **envelope}
        assert op('get_artifact', artifact_id=QUALIFICATION) == certificate
        assert footprint(capture_source()) == intent['source_footprint']
        assert sha((BACKUP / 'manifest.json').read_bytes()) == BACKUP_MANIFEST_SHA
        assert 'numpy' not in sys.modules and '_trf_stationary_native' not in sys.modules
        receipt['verify'] = op('verify')
        assert receipt['verify']['status'] == 'PASS'
        retained_inputs = {'snapshot': snapshot, 'normalization': normalized['normalization'],
            'feature_certificate': feature, 'reference_certificate': reference, 'compiled': compiled,
            'execution': execution, 'plan': plan, 'diagnostics': diagnostic,
            'qualification_id': QUALIFICATION, 'cost_source': cost, 'scalar': scalar, 'native': native,
            'views_before_any_advance': views,
            'comparison': {'only_world_ordinal': 0, 'selected_world': selected_world,
                'other_world_ids': [world['id'] for world in study_manifest['worlds'][1:]],
                'max_advances_per_study': 1, 'order': ['scalar', 'native'],
                'no_retry_or_continuation': True, 'scientific_readiness': False}}
        retain_json('prepared-inputs.json', retained_inputs)
        receipt['prepared_inputs_sha256'] = sha((HERE / 'prepared-inputs.json').read_bytes())
        receipt['studies'] = {'scalar': scalar['id'], 'native': native['id']}
        receipt['selected_world'] = selected_world
        receipt['cost_estimate_scope'] = 'Original tiny engineering fixture planning input retained verbatim; unauthenticated, no 4096-row measured-cost or feasibility claim.'
        receipt['views'] = views
        receipt['status'] = 'PREPARED_NOT_EXECUTED'
        phase('closed')
    except BaseException as exc:
        receipt['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        receipt['status'] = 'FAILED_RETAINED'
        raise
    finally:
        try:
            if normalizer is not None:
                normalizer.broker.close()
            elif broker is not None:
                broker.close()
        except BaseException as exc:
            receipt['status'] = 'FAILED_RETAINED'
            receipt['close_failure'] = {'type': type(exc).__name__, 'message': str(exc)}
            raise
        finally:
            receipt['phases'].append({'name': current_phase, 'ended_utc': now(),
                                      'seconds': str(time.monotonic() - phase_start)})
            receipt['ended_utc'], receipt['setup_seconds'] = now(), str(time.monotonic() - begun)
            retain_json('preparation-receipt.json', receipt)
            print(json.dumps({key: receipt[key] for key in ('status', 'study_advances', 'setup_seconds')}
                             | ({'failure': receipt['failure']} if 'failure' in receipt else {})), flush=True)


if __name__ == '__main__':
    assert len(sys.argv) == 1, 'This one fixed preparation accepts no retargeting options'
    run()
