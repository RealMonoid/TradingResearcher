"""Same pinned Cython/Zig recipe; one uninstalled packing-only input."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import sysconfig
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
TOOLS = ROOT / '.trf-runtime/native-build-tools-2026-11-02'
CACHE = ROOT / '.trf-runtime/native-call-benchmark-2026-11-02/registry/native-runtime-cache/94c8427a738e281383a83255107595738d82ca2f03d7b8b9430401ca39fccf13'
source = HERE / '_trf_stationary_pack_probe.pyx'
generated = HERE / '_trf_stationary_pack_probe.c'
target = HERE / ('_trf_stationary_pack_probe' + sysconfig.get_config_var('EXT_SUFFIX'))
assert not target.exists() and not generated.exists() and not (HERE / 'packing-build.json').exists()
versions = subprocess.run([str(TOOLS / 'Scripts/python.exe'), '-I', '-B', '-c',
    "import importlib.metadata,json; print(json.dumps({k:importlib.metadata.version(k) for k in ('Cython','ziglang','numpy')}))"],
    capture_output=True, text=True, check=True)
assert json.loads(versions.stdout) == {'Cython': '3.3.1', 'ziglang': '0.16.0', 'numpy': '2.3.4'}
base = Path(sysconfig.get_config_var('base'))
header = CACHE / 'numpy/_core/include/numpy/random/bitgen.h'
old = json.loads((ROOT / '.trf-runtime/native-runtime-2026-11-02/kernel-v1/build-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256(header.read_bytes()).hexdigest() == old['bitgen_header_sha256']
commands = [
    [str(TOOLS / 'Scripts/python.exe'), '-B', '-m', 'cython', '-3', str(source), '-o', str(generated)],
    [str(TOOLS / 'Scripts/python.exe'), '-B', '-m', 'ziglang', 'cc', '-shared', '-O3',
     '-target', 'x86_64-windows-gnu', '-ffp-contract=off', '-fno-fast-math',
     '-I' + sysconfig.get_path('include'), '-I' + str(CACHE / 'numpy/_core/include'),
     str(generated), str(base / 'libs/python314.lib'), '-o', str(target)],
]
env = dict(os.environ)
env['ZIG_GLOBAL_CACHE_DIR'] = str(TOOLS / 'zig-global-cache')
env['ZIG_LOCAL_CACHE_DIR'] = str(TOOLS / 'zig-local-cache')
receipt = {'scope': 'Uninstalled packing-only experiment; no Registry/profile/runtime certificate.',
    'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'header_sha256': hashlib.sha256(header.read_bytes()).hexdigest(), 'versions': json.loads(versions.stdout),
    'python': sys.version, 'commands': commands, 'steps': [], 'status': 'STARTED'}
try:
    for command in commands:
        begun = time.perf_counter()
        result = subprocess.run(command, cwd=HERE, env=env, capture_output=True, text=True, timeout=120)
        receipt['steps'].append({'exit_code': result.returncode, 'seconds': str(time.perf_counter() - begun),
                                 'stdout': result.stdout, 'stderr': result.stderr})
        assert result.returncode == 0, result.stderr
    receipt['generated_c_sha256'] = hashlib.sha256(generated.read_bytes()).hexdigest()
    receipt['binary'] = {'path': str(target), 'size': target.stat().st_size,
                         'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}
    receipt['status'] = 'BUILT_UNQUALIFIED_EXPERIMENT_ONLY'
except BaseException as exc:
    receipt['status'] = 'FAILED_RETAINED_NO_RETRY'
    receipt['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
    raise
finally:
    with (HERE / 'packing-build.json').open('x', encoding='utf-8') as stream:
        json.dump(receipt, stream, indent=2)
    print(json.dumps({key: receipt[key] for key in ('status', 'failure', 'binary', 'steps') if key in receipt}), flush=True)
