"""One qualification fixture then one fixed complete ABBA; no study/world."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CACHE = ROOT / '.trf-runtime/native-call-benchmark-2026-11-02/registry/native-runtime-cache/94c8427a738e281383a83255107595738d82ca2f03d7b8b9430401ca39fccf13'
sys.path[:0] = [str(ROOT), str(ROOT / 'tests'), str(CACHE)]
from bootstrap_oracle import binary_report
from trading_researcher.codec import digest
from trading_researcher.evaluation_plans import source_bundle, footprint
from trading_researcher.native_backend import make_draw_factory, INFO
from trading_researcher.stationary_bootstrap import calculate


def retain(name, body):
    with (HERE / name).open('x', encoding='utf-8') as stream:
        json.dump(body, stream, indent=2)


def main():
    assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    assert not (HERE / 'packing-comparison-intent.json').exists()
    assert not (HERE / 'packing-comparison-receipt.json').exists()
    tests = {}
    for mode in ('baseline', 'probe'):
        tests[mode] = json.loads((HERE / ('packing-' + mode + '-tests.json')).read_text(encoding='utf-8'))
        assert tests[mode]['exit_code'] == 0 and 'Ran 21 tests' in tests[mode]['stderr']
    old = json.loads((ROOT / '.trf-runtime/scientific-profile-2026-11-02/grouped-calculation-benchmark.json').read_text(encoding='utf-8'))
    profile = json.loads((HERE / 'profile-intent.json').read_text(encoding='utf-8'))
    build = json.loads((HERE / 'packing-build.json').read_text(encoding='utf-8'))
    assert footprint(source_bundle()) == profile['source_footprint']
    assert old['fixture'] == 'tests/bootstrap_oracle.py:binary_report(4096)'
    assert old['limits'] == {'max_seconds': 180, 'max_segments': 100000000}
    import numpy
    import _trf_stationary_native as baseline
    assert numpy.__version__ == '2.3.4' and baseline.implementation_info() == INFO
    assert hashlib.sha256(Path(baseline.__file__).read_bytes()).hexdigest() == '46d1c2efc66e8cd3546e72027970f7951360e6f18dd1f868d82efbe83e78d509'
    binary = Path(build['binary']['path'])
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == build['binary']['sha256']
    spec = importlib.util.spec_from_file_location('_trf_stationary_pack_probe', binary)
    probe = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = probe
    spec.loader.exec_module(probe)
    assert probe.implementation_info() == INFO
    factories = {mode: make_draw_factory(core, numpy) for mode, core in (('baseline', baseline), ('probe', probe))}
    intent = {'purpose': 'One existing1024row probe gold fixture, then fixed unprofiled4096row baseline/probe/probe/baseline; no study/final world/Registry/certificate or retry.',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'source_footprint': profile['source_footprint'], 'probe_build': build['binary'],
        'probe_source_sha256': build['source_sha256'], 'design': old['design'], 'limits_each': old['limits'],
        'qualification': {'rows': 1024, 'mode': 'probe', 'result_sha256': profile['expected_result_hash'],
                          'stream_sha256': '1578304f089f002d52ac22b8914fc10a2e22cfa77a510c81783c4c403679099d'},
        'comparison': {'rows': 4096, 'order': ['baseline', 'probe', 'probe', 'baseline'],
                       'result_sha256': '720ac237f2ad3e29a5a9d94191af68a90a549f476c6e0f2d5bae36b537901b09',
                       'stream_sha256': '76c3fb49b827455afaf488104f0ee88788254446e4bcf1fad07f73b42cb4f533',
                       'stream_size': 15143319},
        'scope': 'Each timer includes full calculate validation/prefix/factory/draw/interval/MC and hash-byte-sink work. Import/setup excluded and complete path retained separately. Serial, no profiler/intended concurrent numeric checks; background load uncontrolled. No whole-caller/final-feasibility guarantee.'}
    retain('packing-comparison-intent.json', intent)
    receipt = {'status': 'STARTED', 'observations': [], 'scope': intent['scope']}
    begun = time.perf_counter()
    try:
        schedule = [('probe', 1024), *[(mode, 4096) for mode in intent['comparison']['order']]]
        for ordinal, (mode, rows) in enumerate(schedule):
            report = binary_report(rows)
            checksum, draws, size = hashlib.sha256(), 0, 0
            selections = []
            def select(rng, prefixes, length):
                initial = rng.getstate()
                engine = factories[mode](rng, prefixes, length)
                assert rng.getstate() == initial
                selections.append({'length': length, 'native': engine is not None})
                return engine
            def sink(encoded):
                nonlocal draws, size
                line = encoded + b'\n'
                checksum.update(line)
                draws += 1
                size += len(line)
            clock = time.perf_counter()
            result = calculate(report, old['design'], old['limits'], on_draw_bytes=sink, _draw_factory=select)
            seconds = time.perf_counter() - clock
            observation = {'ordinal': ordinal, 'mode': mode, 'rows': rows, 'seconds': str(seconds),
                           'result_sha256': digest(result), 'stream_sha256': checksum.hexdigest(),
                           'stream_bytes': size, 'draws': draws, 'selections': selections,
                           'status': result['status'], 'attempted': [case['attempted'] for case in result['cases']]}
            receipt['observations'].append(observation)
            retain('packing-calculation-' + str(ordinal) + '.json', {'observation': observation, 'result': result})
            print(json.dumps(observation), flush=True)
            gold = intent['qualification' if rows == 1024 else 'comparison']
            assert observation['result_sha256'] == gold['result_sha256']
            assert observation['stream_sha256'] == gold['stream_sha256']
            if rows == 4096:
                assert size == gold['stream_size']
            assert draws == 59997 and observation['attempted'] == [19999] * 3
            assert selections == [{'length': length, 'native': True} for length in (4, 8, 16)]
        medians = {mode: statistics.median(float(item['seconds']) for item in receipt['observations'][1:] if item['mode'] == mode)
                   for mode in ('baseline', 'probe')}
        receipt.update(median_seconds=medians, observed_reduction_percent=100 * (1 - medians['probe'] / medians['baseline']),
                       full_result_and_stream_gold_equal=True)
        assert footprint(source_bundle()) == profile['source_footprint']
        receipt['status'] = 'PASS_FIXED_COMPLETE_EXPERIMENT_NOT_RUNTIME_ADOPTION'
    except BaseException as exc:
        receipt.update(status='FAILED_RETAINED_NO_RETRY', failure={'type': type(exc).__name__, 'message': str(exc)})
        raise
    finally:
        receipt['path_seconds_after_import_setup'] = str(time.perf_counter() - begun)
        retain('packing-comparison-receipt.json', receipt)
        print(json.dumps({key: receipt[key] for key in ('status', 'failure', 'median_seconds', 'observed_reduction_percent') if key in receipt}), flush=True)


if __name__ == '__main__':
    main()
