"""Pre-candidate exact path-packing cases; no study or runtime activation.

The original thirteen loop cases and archived scalar oracle are reused without
changing their bodies or expectations. Only their old hardcoded extension-loader
statements are omitted; the explicitly selected binary supplies `native`.
Additional facts use Python struct.pack('>II'), explicit hex bytes, independently
constructed MT states, and tiny accepted segment counts even for 100,000 rows.

Run each binary in a fresh process. Example (the build venv supplies NumPy):
  python -I -B packing_independent_cases.py --binary ABSOLUTE.pyd \
      --module-name _trf_stationary_native
An isolated -S caller may supply --numpy-root for an explicit retained tree.
This driver writes nothing, loads only the requested extension, and certifies no
scientific meaning, selected runtime, market model, world or resource budget.
"""
import argparse
import ast
from copy import deepcopy
from functools import lru_cache
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import random
import re
import struct
import sys
import types
import unittest


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ORIGINAL = ROOT / '.trf-runtime/native-build-tools-2026-11-02/draw_independent_cases.py'
ORIGINAL_SHA = '342dd443823df5015109768428e15a425b5fba113d5abee8f27bf94ac9dcc0a9'
BASELINE_SOURCE = ROOT / 'trading_researcher/native/_trf_stationary_native.pyx'
BASELINE_SOURCE_SHA = '7032309223049cd250f9774b26f5e44829e878693f3e1114df71b7f2b5b794ba'
BASELINE_C = ROOT / '.trf-runtime/native-runtime-2026-11-02/kernel-v1/_trf_stationary_native.c'
BASELINE_C_SHA = 'db03b01939ae2b8e4add25db641c9e019b8f77ae526702976dd486ea31a4d89c'
SIZES = (255, 256, 257, 65535, 65536, 65537, 100000)
LENGTHS = (1, 2, 100000)


def load_fixed_cases(native):
    raw = ORIGINAL.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == ORIGINAL_SHA
    parsed = ast.parse(raw, filename=str(ORIGINAL))
    selected = []
    omitted = []
    for node in parsed.body:
        assigned = {child.id for child in ast.walk(node) if isinstance(child, ast.Name)
                    and isinstance(child.ctx, ast.Store)} if isinstance(node, ast.Assign) else set()
        if isinstance(node, ast.Assign) and assigned & {'spec', 'native'}:
            omitted.append(ast.get_source_segment(raw.decode(), node))
        elif isinstance(node, ast.Assert):
            # The pinned file has exactly the two original extension-loader
            # assertions here, checked explicitly below. No case assertion moves.
            omitted.append(ast.get_source_segment(raw.decode(), node))
        elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
            if ast.unparse(node.value) == 'spec.loader.exec_module(native)':
                omitted.append(ast.get_source_segment(raw.decode(), node))
            else:
                raise AssertionError('Unexpected top-level oracle side effect')
        elif isinstance(node, ast.If):
            assert ast.unparse(node.test) == "__name__ == '__main__'"
        else:
            selected.append(node)
    assert omitted == [
        "spec = importlib.util.spec_from_file_location('_trf_mt_probe', BINARY)",
        'assert spec is not None and spec.loader is not None',
        'native = importlib.util.module_from_spec(spec)',
        'spec.loader.exec_module(native)',
        'assert Path(native.__file__).resolve() == BINARY',
    ], omitted
    namespace = {'__name__': 'unchanged_fixed_draw_cases', '__file__': str(ORIGINAL), 'native': native}
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(ORIGINAL), 'exec'), namespace)
    namespace['BINARY'] = Path(native.__file__).resolve()
    original_methods = [name for name in namespace['IndependentDrawCases'].__dict__ if name.startswith('test_')]
    assert len(original_methods) == 13
    return types.SimpleNamespace(**namespace)


def inverse_temper(output):
    """Invert the public MT19937 word transform, solely to author fixture states.

    This is independent of extension code. Reference CPython getrandbits checks
    every requested output word before any native candidate is constructed.
    """
    value = output
    for shift, mask, left in ((18, 0xffffffff, False), (15, 0xefc60000, True),
                              (7, 0x9d2c5680, True), (11, 0xffffffff, False)):
        original = value
        for _ in range(6):
            value = original ^ (((value << shift) & mask) if left else (value >> shift))
        value &= 0xffffffff
    return value


def fixed_pair(np, native, size, starts, length):
    """Give CPython and NumPy the same small predeclared stream, without search."""
    words = []
    for start in starts:
        assert 0 <= start < size
        words.append(start << (32 - size.bit_length()))
        if length != 1:
            # CPython random() consumes these two zero words and returns 0.0.
            words.extend((0, 0))
    assert len(words) < 624
    untempered = [inverse_temper(value) for value in words] + [0] * (624 - len(words))
    state = (3, tuple(untempered) + (0,), None)
    witness = random.Random()
    witness.setstate(state)
    assert [witness.getrandbits(32) for _ in words] == words
    reference = random.Random()
    reference.setstate(state)
    owner = np.random.MT19937(0)
    owner.state = {'bit_generator': 'MT19937',
                   'state': {'key': np.array(untempered, dtype=np.uint32), 'pos': 0}}
    return reference, owner, native.Candidate(owner)


@lru_cache(maxsize=7)
def ruler_rows(size):
    # Each bucket contributes exactly (1,3,1,-2), independently of its index.
    # Thus every accepted count gives hand-checkable sums even across a wrap.
    return tuple((index, 3 * index, index, -2 * index) for index in range(size + 1))


def expected_result(oracle, path, reason=None):
    sampled = sum(count for start, count in path)
    return dict(zip(oracle.FIELDS, (sampled, 3 * sampled, sampled, -2 * sampled))) | {
        'sampled_times': sampled, 'segments': len(path),
        'path_sha256': hashlib.sha256(b''.join(struct.pack('>II', *item) for item in path)).hexdigest(),
        'reason': reason}


def make_cases(oracle, native, np):
    class PackingBoundaryCases(oracle.IndependentDrawCases):
        def require_state(self, owner, reference):
            self.assertEqual(oracle.owner_state(owner), reference.getstate()[1])

        def advance_reference(self, reference, size, length, starts):
            for expected in starts:
                self.assertEqual(reference.randrange(size), expected)
                if length != 1: self.assertEqual(reference.random(), 0.0)

        def test_boundary_sizes_and_lengths_keep_scalar_paths_with_two_segment_stops(self):
            # All seven sizes and three mean lengths; at most three candidates
            # are generated for length one, never 100,000 unit segments.
            for size in SIZES:
                for length in LENGTHS:
                    with self.subTest(size=size, length=length):
                        actual, path, calls = self.compare(ruler_rows(size), length, seed=713, stop_after=2)
                        self.assertLessEqual(actual['segments'], 2)
                        self.assertLessEqual(len(calls), 3)
                        self.assertEqual(actual['path_sha256'], oracle.path_digest(path))

        def test_hand_start_bytes_cross_eight_and_sixteen_bit_boundaries(self):
            fixtures = ((255, 254, '000000fe00000001'), (256, 255, '000000ff00000001'),
                        (257, 256, '0000010000000001'), (65535, 65534, '0000fffe00000001'),
                        (65536, 65535, '0000ffff00000001'), (65537, 65536, '0001000000000001'),
                        (100000, 99999, '0001869f00000001'))
            for size, start, encoded_hex in fixtures:
                with self.subTest(size=size, start=start):
                    reference, owner, candidate = fixed_pair(np, native, size, [start, 0], 1)
                    self.assertIs(self.configure(candidate, ruler_rows(size)), True)
                    check = oracle.Check(1)
                    actual = self.draw(candidate, 1, check)
                    self.assert_result(actual, expected_result(oracle, [(start, 1)], 'fixed_resource_stop'))
                    self.assertEqual(struct.pack('>II', start, 1), bytes.fromhex(encoded_hex))
                    self.assertEqual(actual['path_sha256'], hashlib.sha256(bytes.fromhex(encoded_hex)).hexdigest())
                    self.assertEqual(check.calls, [(True, 0), (True, 1)])
                    self.advance_reference(reference, size, 1, [start, 0])
                    self.require_state(owner, reference)

        def test_hand_count_bytes_wrap_complete_cycles_and_finish_at_exact_cap(self):
            fixtures = ((255, '000000fe000000ff'), (256, '000000ff00000100'),
                        (257, '0000010000000101'), (65535, '0000fffe0000ffff'),
                        (65536, '0000ffff00010000'), (65537, '0001000000010001'),
                        (100000, '0001869f000186a0'))
            for size, encoded_hex in fixtures:
                for length in (2, 100000):
                    with self.subTest(size=size, length=length):
                        start = size - 1
                        reference, owner, candidate = fixed_pair(np, native, size, [start], length)
                        self.assertIs(self.configure(candidate, ruler_rows(size)), True)
                        check = oracle.Check(1)
                        floors = []
                        def floor(value):
                            floors.append(value)
                            return size - 1
                        actual = self.draw(candidate, length, check, math.log1p, floor)
                        self.assert_result(actual, expected_result(oracle, [(start, size)]))
                        self.assertEqual(struct.pack('>II', start, size), bytes.fromhex(encoded_hex))
                        self.assertEqual(actual['path_sha256'], hashlib.sha256(bytes.fromhex(encoded_hex)).hexdigest())
                        self.assertEqual(check.calls, [(True, 0)])
                        self.assertEqual(len(floors), 1)
                        self.advance_reference(reference, size, length, [start])
                        self.require_state(owner, reference)

        def test_partial_wrapping_segments_hash_only_accepted_bytes_and_preserve_offset(self):
            size = 65537
            for length in (2, 100000):
                for accepted in (0, 1, 2):
                    with self.subTest(length=length, accepted=accepted):
                        starts = [65536, 255, 65535]
                        reference, owner, candidate = fixed_pair(np, native, size, starts, length)
                        self.assertIs(self.configure(candidate, ruler_rows(size)), True)
                        check = oracle.Check(accepted)
                        actual = self.draw(candidate, length, check, math.log1p, lambda value: 255)
                        path = [(start, 256) for start in starts[:accepted]]
                        self.assert_result(actual, expected_result(oracle, path, 'fixed_resource_stop'))
                        fixed_bytes = bytes.fromhex('0001000000000100000000ff00000100')[:accepted * 8]
                        self.assertEqual(b''.join(struct.pack('>II', *entry) for entry in path), fixed_bytes)
                        self.assertEqual(actual['path_sha256'], hashlib.sha256(fixed_bytes).hexdigest())
                        self.assertEqual(check.calls, [(True, index) for index in range(accepted + 1)])
                        self.advance_reference(reference, size, length, starts[:accepted + 1])
                        self.require_state(owner, reference)

        def test_supplied_math_callbacks_keep_values_and_rejected_candidate_order(self):
            size, length = 65537, 2
            reference, owner, candidate = fixed_pair(np, native, size, [65536, 256], length)
            self.assertIs(self.configure(candidate, ruler_rows(size)), True)
            calls = []
            logarithm = math.log1p(-1.0 / length)
            def log1p(value):
                calls.append(('log1p', value))
                return -2.0
            def floor(value):
                calls.append(('floor', value))
                return 255
            def checker(need, accepted):
                calls.append(('checker', need, accepted))
                return 'fixed_resource_stop' if accepted == 1 else None
            actual = candidate.draw(length, logarithm, checker, log1p, floor)
            self.assert_result(actual, expected_result(oracle, [(65536, 256)], 'fixed_resource_stop'))
            self.assertEqual(calls, [('log1p', -0.0), ('floor', -2.0 / logarithm), ('checker', True, 0),
                                    ('log1p', -0.0), ('floor', -2.0 / logarithm), ('checker', True, 1)])
            self.advance_reference(reference, size, length, [65536, 256])
            self.require_state(owner, reference)

        def test_math_and_checker_exceptions_keep_consumed_candidate_rng_order(self):
            class CallbackFailure(RuntimeError): pass
            size, length = 65537, 2
            for target in ('log1p', 'floor', 'checker'):
                for ordinal in (1, 2):
                    with self.subTest(target=target, ordinal=ordinal):
                        starts = [65536, 256]
                        reference, owner, candidate = fixed_pair(np, native, size, starts, length)
                        self.assertIs(self.configure(candidate, ruler_rows(size)), True)
                        sentinel = CallbackFailure('fixed packing callback exception')
                        seen, counts = [], {'log1p': 0, 'floor': 0, 'checker': 0}
                        def record(name):
                            seen.append(name)
                            counts[name] += 1
                            if name == target and counts[name] == ordinal: raise sentinel
                        def log1p(value): record('log1p'); return math.log1p(value)
                        def floor(value): record('floor'); return 255
                        def checker(need, accepted):
                            self.assertIs(need, True)
                            self.assertEqual(accepted, counts['checker'])
                            record('checker')
                        with self.assertRaises(CallbackFailure) as failure:
                            self.draw(candidate, length, checker, log1p, floor)
                        self.assertIs(failure.exception, sentinel)
                        expected_order = ['log1p', 'floor', 'checker'] * (ordinal - 1)
                        expected_order += ['log1p', 'floor', 'checker'][:('log1p', 'floor', 'checker').index(target) + 1]
                        self.assertEqual(seen, expected_order)
                        self.advance_reference(reference, size, length, starts[:ordinal])
                        self.require_state(owner, reference)

        def test_length_one_big_start_paths_skip_all_uniform_and_math_callbacks(self):
            size = 65537
            reference, owner, candidate = fixed_pair(np, native, size, [65536, 256, 0], 1)
            self.assertIs(self.configure(candidate, ruler_rows(size)), True)
            def unused(*args): raise AssertionError('Length one consumed a math callback')
            check = oracle.Check(2)
            actual = self.draw(candidate, 1, check, unused, unused)
            path = [(65536, 1), (256, 1)]
            self.assert_result(actual, expected_result(oracle, path, 'fixed_resource_stop'))
            self.assertEqual(actual['path_sha256'], hashlib.sha256(bytes.fromhex('00010000000000010000010000000001')).hexdigest())
            self.advance_reference(reference, size, 1, [65536, 256, 0])
            self.require_state(owner, reference)

        def test_next_draw_after_callback_error_reuses_rng_without_stale_packed_bytes(self):
            size, length = 257, 2
            reference, owner, candidate = fixed_pair(np, native, size, [256, 255, 1, 0, 2], length)
            self.assertIs(self.configure(candidate, ruler_rows(size)), True)
            sentinel = RuntimeError('stop before second accepted segment')
            def raising(need, accepted):
                if accepted == 1: raise sentinel
            with self.assertRaises(RuntimeError) as failure:
                self.draw(candidate, length, raising, math.log1p, lambda value: 0)
            self.assertIs(failure.exception, sentinel)
            self.advance_reference(reference, size, length, [256, 255])
            self.require_state(owner, reference)
            reference_check, actual_check = oracle.Check(1), oracle.Check(1)
            expected, path = oracle.scalar_draw(ruler_rows(size), length, reference, reference_check)
            actual = self.draw(candidate, length, actual_check)
            self.assert_result(actual, expected)
            self.assertEqual(path, [(1, 1)])
            self.assertEqual(actual_check.calls, reference_check.calls)
            self.require_state(owner, reference)

    return PackingBoundaryCases


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--module-name', required=True)
    parser.add_argument('--numpy-root', type=Path)
    args = parser.parse_args()
    binary = args.binary.resolve(strict=True)
    assert re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', args.module_name)
    assert args.module_name not in sys.modules
    if args.numpy_root is not None:
        numpy_root = args.numpy_root.resolve(strict=True)
        assert (numpy_root / 'numpy/__init__.py').is_file()
        sys.path.insert(0, str(numpy_root))
    import numpy as np
    assert np.__version__ == '2.3.4'
    assert hashlib.sha256(BASELINE_SOURCE.read_bytes()).hexdigest() == BASELINE_SOURCE_SHA
    assert hashlib.sha256(BASELINE_C.read_bytes()).hexdigest() == BASELINE_C_SHA
    spec = importlib.util.spec_from_file_location(args.module_name, binary)
    assert spec is not None and spec.loader is not None
    native = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(native)
    assert Path(native.__file__).resolve() == binary
    oracle = load_fixed_cases(native)
    cases = make_cases(oracle, native, np)
    added = [name for name in cases.__dict__ if name.startswith('test_')]
    assert len(added) == 8
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(cases)
    assert suite.countTestCases() == 21
    print(json.dumps({'scope': 'fixed_independent_path_packing_only_no_runtime_or_scientific_admission',
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'reused_oracle_sha256': ORIGINAL_SHA, 'reviewed_baseline_source_sha256': BASELINE_SOURCE_SHA,
        'reviewed_generated_c_sha256': BASELINE_C_SHA,
        'binary': str(binary), 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
        'module_name': args.module_name, 'numpy': np.__version__, 'python': sys.version,
        'base_methods': 13, 'packing_methods': 8, 'sizes': SIZES, 'lengths': LENGTHS,
        'max_accepted_segments_per_large_unit_length_draw': 2}, sort_keys=True), flush=True)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__ == '__main__':
    main()
