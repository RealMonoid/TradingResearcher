"""One fixed existing numeric fixture; attribution only, no study or new world."""
import cProfile
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import pstats
import sys
import time
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CACHE = ROOT / '.trf-runtime/native-call-benchmark-2026-11-02/registry/native-runtime-cache/94c8427a738e281383a83255107595738d82ca2f03d7b8b9430401ca39fccf13'
sys.path[:0] = [str(ROOT), str(ROOT / 'tests'), str(CACHE)]

from bootstrap_oracle import binary_report
from trading_researcher.codec import canonical, digest
from trading_researcher.certification import _runtime_identity
from trading_researcher.evaluation_plans import source_bundle, footprint
from trading_researcher.native_backend import make_draw_factory, INFO
from trading_researcher.native_environment import _loaded_images
from trading_researcher.native_runtime import verify_tree
from trading_researcher.stationary_bootstrap import calculate


def retain(name, value):
    with (HERE / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)


def main():
    assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
    assert not (HERE / 'profile-intent.json').exists()
    assert not (HERE / 'profile-receipt.json').exists()
    baseline_path = ROOT / '.trf-runtime/scientific-profile-2026-11-02/grouped-full-calculator-profile.json'
    baseline = json.loads(baseline_path.read_text(encoding='utf-8'))
    packet = json.loads((ROOT / '.trf-runtime/native-call-benchmark-2026-11-02/prepared-inputs.json').read_text(encoding='utf-8'))
    binding = packet['native']['body']['native_binding']
    expected = packet['native']['body']['source_footprint']
    assert baseline['fixture'] == 'tests/bootstrap_oracle.py:binary_report(1024)'
    assert baseline['result_hash'] == '40b901057a9912ad3bb1f50b9a2d57bf791eeb4375b842b07cd8e7e09b6fdea2'
    assert baseline['limits'] == {'max_seconds': 180, 'max_segments': 100000000}
    assert footprint(source_bundle()) == expected
    assert _runtime_identity() == binding['runtime_manifest']['runtime_identity']
    sampler_sha256 = hashlib.sha256((ROOT / 'trading_researcher/stationary_bootstrap.py').read_bytes()).hexdigest()
    assert sampler_sha256 == 'f6f1b27ca43acde60972caa3af2fbec082e324180b13cb60f4fb64142dfd8d57'
    with zipfile.ZipFile(ROOT / '.trf-runtime/native-call-benchmark-2026-11-02/source.zip') as archive:
        assert all((ROOT / n).read_bytes() == archive.read(n) for n in archive.namelist() if n.startswith('trading_researcher/'))
    intent = {'purpose': 'Attribute ONE complete existing binary_report(1024) native calculation under the original fixed design/180second/100millionsegment limits. No study/world/final/Registry operation or retry. Not a speed comparison or scientific/runtime certificate.',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'baseline_sha256': hashlib.sha256(baseline_path.read_bytes()).hexdigest(),
        'baseline_sampler_sha256': baseline['source_sha256'], 'current_sampler_sha256': sampler_sha256,
        'fixture_source_sha256': {name: hashlib.sha256((ROOT / 'tests' / name).read_bytes()).hexdigest() for name in ('bootstrap_oracle.py', 'bootstrap_support.py')},
        'source_footprint': expected, 'runtime_id': binding['runtime_id'],
        'runtime_manifest_sha256': digest(binding['runtime_manifest']),
        'cache_directory': str(CACHE), 'design': baseline['design'], 'limits': baseline['limits'],
        'expected_result_hash': baseline['result_hash'], 'expected_draws': 59997,
        'instrumentation': 'Existing stdlib cProfile/pstats. Instrumented process images retained separately; no extension of the production host inventory or runtime certificate. Full original per-segment callbacks/checks remain.'}
    retain('profile-intent.json', intent)
    receipt = {'purpose': intent['purpose'], 'status': 'STARTED', 'started_utc': datetime.now(timezone.utc).isoformat()}
    begun = time.perf_counter()
    profiler = cProfile.Profile()
    try:
        verify_tree(CACHE, binding['runtime_manifest'])
        import numpy
        import _trf_stationary_native as core
        assert numpy.__version__ == '2.3.4' and core.implementation_info() == INFO
        assert Path(core.__file__).resolve() == (CACHE / '_trf_stationary_native.cp314-win_amd64.pyd').resolve()
        assert hashlib.sha256(Path(core.__file__).read_bytes()).hexdigest() == '46d1c2efc66e8cd3546e72027970f7951360e6f18dd1f868d82efbe83e78d509'
        receipt['loaded_images_before'] = _loaded_images()
        report = binary_report(1024)
        factory = make_draw_factory(core, numpy)
        selections = []
        def select(rng, rows, length):
            before = rng.getstate()
            engine = factory(rng, rows, length)
            assert rng.getstate() == before
            selections.append({'length': length, 'native': engine is not None})
            return engine
        checksum = hashlib.sha256()
        draws = 0
        with (HERE / 'profile-draws.jsonl').open('xb') as stream:
            def sink(encoded):
                nonlocal draws
                line = encoded + b'\n'
                checksum.update(line)
                assert stream.write(line) == len(line)
                draws += 1
            clock = time.perf_counter()
            result = profiler.runcall(calculate, report, baseline['design'], baseline['limits'],
                                     on_draw_bytes=sink, _draw_factory=select)
            receipt['profiled_calculation_seconds'] = str(time.perf_counter() - clock)
        retain('profile-result.json', result)
        receipt.update(result_sha256=digest(result), draws=draws, draw_stream_sha256=checksum.hexdigest(),
                       native_selections=selections, result_status=result['status'],
                       attempted=[case['attempted'] for case in result['cases']])
        assert receipt['result_sha256'] == baseline['result_hash']
        assert draws == 59997 and receipt['attempted'] == [19999] * 3
        assert selections == [{'length': length, 'native': True} for length in (4, 8, 16)]
        verify_tree(CACHE, binding['runtime_manifest'])
        assert footprint(source_bundle()) == expected
        receipt['loaded_images_after'] = _loaded_images()
        assert receipt['loaded_images_before'] == receipt['loaded_images_after']
        receipt['status'] = 'PASS_COMPLETE_FIXED_FIXTURE_ATTRIBUTION_ONLY'
    except BaseException as exc:
        receipt.update(status='FAILED_RETAINED_NO_RETRY', failure={'type': type(exc).__name__, 'message': str(exc)})
        raise
    finally:
        profiler.dump_stats(str(HERE / 'profile.pstats'))
        rows = [{'file': file, 'line': line, 'function': name, 'primitive_calls': data[0],
                 'calls': data[1], 'self_seconds': data[2], 'cumulative_seconds': data[3]}
                for (file, line, name), data in pstats.Stats(profiler).stats.items()]
        receipt['top_cumulative'] = sorted(rows, key=lambda row: row['cumulative_seconds'], reverse=True)[:45]
        receipt['top_self'] = sorted(rows, key=lambda row: row['self_seconds'], reverse=True)[:45]
        receipt['path_seconds_including_integrity_checks'] = str(time.perf_counter() - begun)
        receipt['ended_utc'] = datetime.now(timezone.utc).isoformat()
        retain('profile-receipt.json', receipt)
        print(json.dumps({key: receipt[key] for key in ('status', 'profiled_calculation_seconds', 'draws') if key in receipt}), flush=True)


if __name__ == '__main__':
    main()
