"""Run unchanged independent calculator assertions with the actual C factory.

Only the test's engine selection is replaced. Frozen expected results, complete
draw counts, fallback inputs, traces, callbacks and all assertions stay intact.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests'))
import test_bootstrap_draw_engine_independent as cases
from trading_researcher.native_backend import make_draw_factory
sys.path.insert(0, str(ROOT / '.trf-runtime/native-call-benchmark-2026-11-02/registry/native-runtime-cache/94c8427a738e281383a83255107595738d82ca2f03d7b8b9430401ca39fccf13'))
import numpy as np


def qualify():
    expected = 'bc8d30775031798454c2b743e6b590940d69b844aac0623af8a29c37fde85e09'
    assert hashlib.sha256(Path(cases.__file__).read_bytes()).hexdigest() == expected
    binary = HERE / '_trf_stationary_pack_probe.cp314-win_amd64.pyd'
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == '7f5b047478274906da5737669d8349e73254854c766e3c0cb1faa1b424a88583'
    spec = importlib.util.spec_from_file_location('_trf_stationary_pack_probe', binary)
    core = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(core)
    factory = make_draw_factory(core, np)
    selected = 0
    declined = 0

    def select(self, rng, rows, length):
        nonlocal selected, declined
        before = rng.getstate()
        rows = tuple(tuple(row) for row in rows)
        engine = None if self.decline else factory(rng, rows, length)
        assert rng.getstate() == before
        self.calls.append({'length': length, 'rows': rows, 'supported': engine is not None,
                           'before': before, 'after': rng.getstate()})
        if engine is None:
            declined += 1
        else:
            selected += 1
        return engine

    suite = unittest.defaultTestLoader.loadTestsFromTestCase(cases.BootstrapDrawEngineIndependentTests)
    started = time.monotonic()
    with patch.object(cases.Factory, '__call__', select):
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    receipt = {'scope': 'Actual native numeric factory substituted only for the test engine; no runtime/study/scientific admission.',
        'independent_case_source_sha256': expected, 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
        'methods': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
        'skipped': len(result.skipped), 'selected_engine_lengths': selected,
        'declined_engine_lengths': declined, 'seconds': str(time.monotonic() - started),
        'status': 'PASS' if result.wasSuccessful() else 'FAIL'}
    (HERE / 'packing-factory-qualification.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps(receipt), flush=True)
    assert result.testsRun == 10 and selected > 0 and declined > 0 and result.wasSuccessful()


if __name__ == '__main__':
    qualify()
