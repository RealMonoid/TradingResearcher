"""Independent AC-N3/N5/N12 process-control and selected transport checks.

Only tiny isolated Python probes execute. Invented native members and the
existing transport fixture are metadata seams, never binary qualification or
numerical calibration. A parent deadline is a process cause, not retry authority
or an aggregate accounting reservation. Legacy launches retain their contract.
"""
from contextlib import ExitStack, redirect_stdout
from copy import deepcopy
import importlib
import io
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from trading_researcher import binance_normalize as launcher
from trading_researcher.codec import Invalid, MAX_BYTES, decode


EXPECTED_POLICY = {'schema': 'native-study-process-control/1',
                   'library_threads': 1, 'priority': 'BELOW_NORMAL'}
EXPECTED_THREADS = {name: '1' for name in (
    'OMP_NUM_THREADS', 'OMP_THREAD_LIMIT', 'OPENBLAS_NUM_THREADS',
    'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS',
    'BLIS_NUM_THREADS')}
EXPECTED_OBSERVATION = {'policy': EXPECTED_POLICY,
                        'thread_environment': EXPECTED_THREADS,
                        'priority_class': 0x4000}


def owner():
    # Deferred import keeps discovery runnable before the new owner exists.
    return importlib.import_module('trading_researcher.study_process_control')


class NativeProcessControlIndependentTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix='trf-process-control-')
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)

    def directory(self, name='child'):
        path = self.root / name
        path.mkdir()
        return path

    def command(self, code):
        return [sys.executable, '-I', '-S', '-B', '-c', code]

    def test_invalid_control_is_rejected_before_output_creation_or_launch(self):
        directory = self.directory()
        with patch.object(launcher.subprocess, 'Popen') as launch:
            with self.assertRaises(Invalid):
                launcher._run_child(self.command('print("{}")'), directory,
                                    timeout=1, _control=object())
        launch.assert_not_called()
        self.assertEqual(list(directory.iterdir()), [])


if __name__ == '__main__':
    unittest.main()
