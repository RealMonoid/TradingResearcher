"""Run one explicit owned implementation qualification, retaining its registry.

This creates no scientific study, final draw, model call or spending grant.
Repeating a key returns its original result; failed attempts are never retried.
"""
import hashlib
import json
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from trading_researcher.coordination import Broker
from trading_researcher.codec import decode


def run(key):
    begun = time.monotonic()
    assert key.isascii() and key.replace('-', '').isalnum()
    receipt_path = HERE / (key + '-receipt.json')
    assert not receipt_path.exists(), 'Retained receipt already exists; inspect it instead of overwriting'
    inputs = ROOT / '.trf-runtime/native-runtime-2026-11-02'
    archive = inputs / 'canonical-native-runtime.zip'
    manifest = decode((inputs / 'canonical-native-runtime-manifest.json').read_bytes())
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == '8c0458b745399a3bc92f912bb129ea1c6969466a0cad3239d5c361c23746dc21'
    broker = Broker(HERE / 'registry')
    receipt = {'scope': 'Owned implementation qualification only; no scientific study or admission.', 'key': key}
    try:
        identity_file = HERE / 'runtime-input-id.json'
        if identity_file.exists():
            runtime_id = json.loads(identity_file.read_text())['runtime_id']
            broker.call(broker.admin_token, 'inspect_native_runtime', runtime_id=runtime_id)
        else:
            source = broker.call(broker.admin_token, 'add_blob_source', path=str(archive), data_class='operations',
                                 description='Pinned canonical NumPy/native bootstrap implementation input')
            package = broker.call(broker.admin_token, 'retain_native_runtime', key='canonical-runtime-input',
                                  archive_id=source['id'], manifest=manifest)
            runtime_id = package['id']
            with identity_file.open('x', encoding='utf-8') as stream:
                json.dump({'runtime_id': runtime_id}, stream)
        certificate = broker.call(broker.admin_token, 'qualify_native_runtime', key=key, runtime_id=runtime_id)
        receipt.update(certificate_id=certificate['id'], status=certificate['body']['status'],
                       failure=certificate['body']['failure'], settlement=certificate['body']['settlement'])
        receipt['inspection'] = broker.call(broker.admin_token, 'inspect_native_runtime_qualification',
                                           qualification_id=certificate['id'])
        assert certificate['body']['status'] == 'CERTIFIED', certificate['body']['failure']
        assert receipt['inspection']['status'] == 'CURRENT', receipt['inspection']
        assert 'numpy' not in sys.modules
        receipt['controller_numpy_imported'] = False
    finally:
        broker.close()
        receipt['seconds'] = str(time.monotonic() - begun)
        with receipt_path.open('x', encoding='utf-8') as stream:
            json.dump(receipt, stream, indent=2)
        print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    assert len(sys.argv) == 2, 'One explicit qualification key is required'
    run(sys.argv[1])
