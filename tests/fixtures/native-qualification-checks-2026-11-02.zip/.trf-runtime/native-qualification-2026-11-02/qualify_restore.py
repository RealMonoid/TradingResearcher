"""Real cache-free backup/restore and selected-path currency, not a study."""
import json
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from trading_researcher.coordination import Broker
from trading_researcher.native_runtime import NativeRuntimes
from trading_researcher.storage import restore_bundle


def run():
    started = time.monotonic()
    receipt_path = HERE / 'restore-v2-receipt.json'
    assert not receipt_path.exists()
    certificate_id = 'ec735540149b75b8f8294012c625637ca09664d1a196485b6721ba7b357f89be'
    original = Broker(HERE / 'registry')
    receipt = {'scope': 'Same certificate and all retained inputs/outputs after cache-free restore; no new conformance/study attempt.'}
    try:
        certificate = original.call(original.admin_token, 'get_artifact', artifact_id=certificate_id)
        receipt['before'] = original.call(original.admin_token, 'inspect_native_runtime_qualification', qualification_id=certificate_id)
        assert receipt['before']['status'] == 'CURRENT'
        backup = HERE / 'backup-v2'
        receipt['backup'] = original.call(original.admin_token, 'backup_bundle', destination=str(backup))
        assert receipt['backup']['status'] == 'PASS'
        assert not (backup / 'native-runtime-cache').exists()
        restored_path = HERE / 'restored-v2'
        receipt['restore'] = restore_bundle(backup, restored_path, original.directory / 'operator.key')
        assert receipt['restore']['status'] == 'PASS'
    finally:
        original.close()
    restored = Broker(restored_path)
    try:
        assert restored.call(restored.admin_token, 'get_artifact', artifact_id=certificate_id) == certificate
        receipt['cache_absent'] = restored.call(restored.admin_token, 'inspect_native_runtime_qualification', qualification_id=certificate_id)
        assert receipt['cache_absent']['status'] == 'STALE'
        assert not (restored.directory / 'native-runtime-cache').exists()
        meter = {'materialized_bytes': 0}
        NativeRuntimes(restored)._materialize(certificate['body']['runtime_id'], meter)
        receipt['materialized_bytes'] = meter['materialized_bytes']
        assert meter['materialized_bytes'] == 56944242
        receipt['after'] = restored.call(restored.admin_token, 'inspect_native_runtime_qualification', qualification_id=certificate_id)
        assert receipt['after']['status'] == 'CURRENT'
        assert receipt['after']['attempts'] == receipt['before']['attempts']
        assert restored.call(restored.admin_token, 'get_artifact', artifact_id=certificate_id) == certificate
        receipt['verify'] = restored.call(restored.admin_token, 'verify')
        assert receipt['verify']['status'] == 'PASS'
        assert 'numpy' not in sys.modules
        receipt['controller_numpy_imported'] = False
        receipt['status'] = 'PASS'
    finally:
        restored.close()
        receipt['seconds'] = str(time.monotonic() - started)
        with receipt_path.open('x', encoding='utf-8') as stream:
            json.dump(receipt, stream, indent=2)
        print(json.dumps({key: value for key, value in receipt.items()
                          if key not in ('before', 'cache_absent', 'after', 'verify')}), flush=True)


if __name__ == '__main__':
    run()
