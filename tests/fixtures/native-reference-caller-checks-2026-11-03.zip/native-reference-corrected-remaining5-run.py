import ast, hashlib, io, json, pathlib, sys, time, unittest
from datetime import datetime, timezone
ROOT=pathlib.Path.cwd(); WORK=ROOT/'.trf-runtime/native-final-calibration-2026-11-03'
FULL=False; PREFIX='native-reference-corrected-remaining5'
paths=sorted(set([p.relative_to(ROOT).as_posix() for p in (ROOT/'trading_researcher').glob('*.py')]+['tests/test_native_reference_caller_independent.py','tests/test_native_reserved_attempts_independent.py','tests/test_native_calibration_resource_owner_independent.py','tests/test_native_study_independent.py','tests/test_native_runtime_independent.py','tests/family_run_support.py','tests/binding_support.py']))
def pins():return {p:{'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest(),'size':(ROOT/p).stat().st_size} for p in paths}
before=pins()
for p in paths:(WORK/(PREFIX+'-'+pathlib.Path(p).name)).write_bytes((ROOT/p).read_bytes())
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(ROOT/'tests'));  import test_native_reference_caller_independent as m
names=['test_reference_is_typed_dependency_and_reserved_seed_inventory_even_before_execution','test_revoked_old_grant_and_corrupt_old_stream_cannot_start_new_reference_work','test_same_key_qualification_alias_and_new_key_preserve_original_immutable_input','test_worker_and_source_forgery_fail_before_reference_lookup_or_cache']
suite=unittest.TestSuite([unittest.TestSuite(m.NativeReferenceCallerIndependentTests(n) for n in names),unittest.defaultTestLoader.loadTestsFromTestCase(m.NativeReferenceEntrypointIndependentTests)])
stream=io.StringIO()
class Result(unittest.TextTestResult):
 def startTest(self,test):super().startTest(test); print('START',test.id(),flush=True)
 def addSuccess(self,test):super().addSuccess(test); print('PASS',test.id(),flush=True)
start=datetime.now(timezone.utc).isoformat(); timer=time.perf_counter()
result=unittest.TextTestRunner(stream=stream,verbosity=2,failfast=True,resultclass=Result).run(suite)
elapsed=time.perf_counter()-timer; raw=stream.getvalue(); (WORK/(PREFIX+'-stdout.txt')).write_text(raw,encoding='utf-8')
receipt={'started_at_utc':start,'finished_at_utc':datetime.now(timezone.utc).isoformat(),'scope':'Genuine temporary completed eight-world/two-target old corpus and native-reference input/resource/transport/custody/accounting owners; invented native qualification/runtime membership and numerical wire responses. No actual32reference/64mode numerical acceptance, Scalar numeric work, native kernel, final series or scientific admission. Failfast selection; full116project and7test/helper source pins.','requested_methods':'all19' if FULL else names,'discovered':suite.countTestCases(),'executed':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'elapsed_seconds':elapsed,'exit_code':0 if result.wasSuccessful() else 1,'pins_before':before,'pins_after':pins(),'raw_stdout_sha256':hashlib.sha256(raw.encode()).hexdigest(),'raw_stdout':raw}
receipt['pins_unchanged']=receipt['pins_before']==receipt['pins_after']
path=WORK/(PREFIX+'-check.json');path.write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(raw,flush=True);print('RECEIPT',path,'SHA256',hashlib.sha256(path.read_bytes()).hexdigest(),flush=True)
sys.exit(receipt['exit_code'])
