"""One bounded import-only observation; not a qualifier or Registry consumer."""
import datetime
import hashlib
import json
from pathlib import Path
import sys
import time


ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent / 'native-host-import-probe-files'
PINNED = Path(__file__).resolve().parent / 'pinned-e2db9c6'
CACHE = ROOT / '.trf-runtime/scalar-final-calibration-2026-11-02/registry/native-runtime-cache/28bd9fecee88635f13be9f6ff9381420bc620b1a3e7b70d068aa56c1db3fe898'
MANIFEST = ROOT / '.trf-runtime/native-packing-adoption-2026-11-02/canonical-native-runtime-v2-manifest.json'
RUNTIME = 'f01a625b5c07ad5a1c0b03349c6d14212ff40aae740e4a581f4be3552c16190f'
sys.path.insert(0, str(PINNED))
from trading_researcher import native_qualification_profile as profile
from trading_researcher.codec import canonical, decode, digest
from trading_researcher.evaluation_plans import footprint
from trading_researcher.study_process_control import ProcessControl, run_controlled_child


CHILD = r'''
import hashlib
import importlib
import importlib.util
import sys
from pathlib import Path
from trading_researcher import native_qualification_profile as profile
from trading_researcher.binding import environment
from trading_researcher.codec import canonical, decode, digest
from trading_researcher.evaluation_plans import footprint
from trading_researcher.native_environment import NativeContext, _loaded_images
from trading_researcher.native_backend import INFO
from trading_researcher.native_runtime import verify_tree
from trading_researcher.study_process_control import ProcessControl, observe_control

root, cache, manifest_path, runtime_id = Path(sys.argv[1]), Path(sys.argv[3]), Path(sys.argv[4]), sys.argv[5]
assert not any(name == 'numpy' or name.startswith('numpy.') for name in sys.modules)
source = profile.capture_source()
expected = footprint(source)
manifest = decode(manifest_path.read_bytes())
assert digest(manifest) == profile.MANIFEST_SHA
verify_tree(cache, manifest)
hosts = profile.host_inputs(source)
assert len(hosts) == 47
control_before = observe_control(ProcessControl().request())
before_imports = _loaded_images()
sys.path.insert(1, str(cache))
sys.path.insert(2, str(root / 'tests'))
numpy = importlib.import_module('numpy')
core = importlib.import_module('_trf_stationary_native')
assert Path(numpy.__file__).resolve().is_relative_to(cache.resolve())
assert Path(core.__file__).resolve().is_relative_to(cache.resolve())
assert core.implementation_info() == INFO
spec = importlib.util.spec_from_file_location('native_loop_cases', root / profile.LOOP_FILE)
loops = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = loops
spec.loader.exec_module(loops)
oracle = loops.load_fixed_cases(core)
cases = loops.make_cases(oracle, core, numpy)
from bootstrap_oracle import binary_report
from trading_researcher.stationary_bootstrap import calculate, randomness
# This is the qualification entry's import/class-definition shape immediately
# before its first environment observation. No case, RNG/draw, calculate,
# binary_report, factory selection or unittest runner is invoked by the probe.
images_before_observation = _loaded_images()
known = {str(Path(item['path']).absolute()).casefold(): item for item in hosts}
def compare(images):
    unknown, changed = [], []
    for image in images:
        if Path(image['path']).is_relative_to(cache):
            continue
        old = known.get(str(Path(image['path']).absolute()).casefold())
        if old is None:
            unknown.append(image)
        elif any(image[key] != old[key] for key in ('sha256', 'size')):
            changed.append({'observed': image, 'old': old})
    return {'unknown': unknown, 'changed': changed}
context = NativeContext(runtime_id, manifest, cache, hosts)
old_observation = {'status': 'ACCEPTED'}
try:
    environment(expected, _native=context)
except Exception as exc:
    old_observation = {'status': 'DENIED', 'type': type(exc).__name__, 'message': str(exc)}
images_after_observation = _loaded_images()
control_after = observe_control(ProcessControl().request())
verify_tree(cache, manifest)
result = {'schema': 'native-host-import-observation/1', 'status': 'PROVISIONAL_OBSERVATION_ONLY',
    'runtime_id': runtime_id, 'runtime_manifest_sha256': digest(manifest),
    'source_footprint': expected, 'old_host_count': len(hosts), 'old_host_images_sha256': digest(hosts),
    'old_host_source_archive_sha256': hashlib.sha256(source['tests/fixtures/native-environment-checks-2026-11-02.zip']).hexdigest(),
    'isolation': {'isolated': sys.flags.isolated, 'no_site': sys.flags.no_site,
                  'ignore_environment': sys.flags.ignore_environment, 'no_bytecode_writes': int(sys.dont_write_bytecode)},
    'process_control': {'before': control_before, 'after': control_after},
    'selected_imports': {'numpy': str(Path(numpy.__file__).resolve()), 'kernel': str(Path(core.__file__).resolve())},
    'loaded_before_imports': before_imports, 'loaded_before_observation': images_before_observation,
    'loaded_after_observation': images_after_observation,
    'before_observation_comparison': compare(images_before_observation),
    'after_observation_comparison': compare(images_after_observation),
    'old_47_environment_observation': old_observation,
    'cache_full_hash_before_import_and_after_observation': 'PASS',
    'scientific_readiness': False,
    'scope': 'Import and loader/file-hash observation only. No scientific draw, conformance test, qualification, Registry/key use, retry or permission change. Does not reconstruct the failed child or certify host membership.'}
print(canonical(result))
'''


def main():
    started = time.monotonic()
    source = profile.capture_source()
    assert not any(name == 'numpy' or name.startswith('numpy.') for name in sys.modules)
    before = footprint(source)
    manifest_raw = MANIFEST.read_bytes()
    assert digest(decode(manifest_raw)) == '20151908bc9fd2b09ac407caebc5d7bbc2f79016315b8b59d736d2427297c848'
    WORK.mkdir(exist_ok=False)
    copied = WORK / 'captured-source'; copied.mkdir()
    for name, raw in source.items():
        path = copied / name
        assert path.resolve().is_relative_to(copied.resolve())
        path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(raw)
    child = WORK / 'observe-child.py'; child.write_text(CHILD, encoding='utf-8')
    bootstrap = "import sys;sys.path.insert(0,sys.argv[1]);exec(compile(open(sys.argv[2],'rb').read(),'<native-host-import-probe>','exec'))"
    command = [sys.executable, '-I', '-S', '-B', '-c', bootstrap, str(copied), str(child), str(CACHE), str(MANIFEST), RUNTIME]
    launch = WORK / 'child'; launch.mkdir()
    result, failure = None, None
    try:
        result = run_controlled_child(command, launch, 90, ProcessControl())
    except BaseException as exc:
        failure = {'type': type(exc).__name__, 'message': str(exc)}
    after = footprint(profile.capture_source())
    record = {'schema': 'independent-native-host-import-probe/1',
        'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'elapsed_seconds': time.monotonic() - started, 'command': command,
        'pinned_source_root': str(PINNED), 'source_before': before, 'source_after': after,
        'source_bytes': sum(map(len, source.values())), 'source_files': len(source),
        'child_script_sha256': hashlib.sha256(child.read_bytes()).hexdigest(),
        'manifest_file_sha256': hashlib.sha256(manifest_raw).hexdigest(),
        'selected_cache': str(CACHE), 'result': result, 'failure': failure,
        'raw_stdout': str(launch / 'child-output.json'), 'raw_stderr': str(launch / 'child-errors.txt'),
        'status': 'PROVISIONAL_OBSERVATION_ONLY', 'scientific_readiness': False}
    output = WORK.parent / 'native-host-import-observation-independent.json'
    output.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'receipt': str(output), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
        'failure': failure, 'source_stable': before == after,
        'comparison': None if result is None else result['after_observation_comparison'],
        'old_47_observation': None if result is None else result['old_47_environment_observation']}))
    return 0 if failure is None and before == after else 1


if __name__ == '__main__':
    raise SystemExit(main())
