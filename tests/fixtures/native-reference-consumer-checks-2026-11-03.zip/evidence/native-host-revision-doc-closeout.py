from pathlib import Path
import json,hashlib,re,zipfile
R=Path.cwd();W=R/'.trf-runtime/native-final-calibration-2026-11-03';Z=R/'tests/fixtures/native-reference-consumer-checks-2026-11-03.zip';P=R/'docs/reviews/implementation-2026-10-25/progress.json'
with zipfile.ZipFile(Z) as z:members={k:z.read(k) for k in z.namelist()}
m=json.loads(members.pop('manifest.json'));old=dict(members)
for f in sorted(W.glob('native-host-*')):
 if f.is_file():members['evidence/'+f.name]=f.read_bytes()
changed=['trading_researcher/native_calibration_runs.py','trading_researcher/native_qualification_profile.py','tests/test_native_host_amendment_independent.py','tests/test_native_host_recovery_independent.py','tests/fixtures/native-host-amendment-2026-11-03.json']
for f in changed:members['host-revision-current/'+f]=(R/f).read_bytes()
m['scope']+=' host-revision-current/ nowretains exact prospectivesource/asset: independent import-only child confirms singleapphelp discrepancy;8hostmetadata+4financial checks and23affectedregressions pass. Old47/ZIP/numeric goldens and everyprior member unchanged. ActualV4 qualification/full64/finalseriesremainpending; nofailedchildexactDLL claim.';m['files']={k:{'sha256':hashlib.sha256(v).hexdigest(),'size':len(v)} for k,v in sorted(members.items())}
with zipfile.ZipFile(Z,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for k,v in sorted(members.items()):z.writestr(k,v)
 z.writestr('manifest.json',json.dumps(m,indent=2).encode())
with zipfile.ZipFile(Z) as z:assert z.testzip() is None and all(z.read(k)==v for k,v in old.items()) and all(len(z.read(k))==v['size'] and hashlib.sha256(z.read(k)).hexdigest()==v['sha256'] for k,v in m['files'].items())
cap={'path':Z.relative_to(R).as_posix(),'sha256':hashlib.sha256(Z.read_bytes()).hexdigest(),'size':Z.stat().st_size,'members':len(members)+1,'all_crc_sha_size_verified':True,'all_preceding_members_preserved':True}
close=json.loads((W/'native-host-revision-source-closeout.json').read_bytes());t=P.read_bytes().decode('utf-8');r=json.loads(t);s=r['scientific_information_profile_2026_11_02'];n=s['native_parallel_calibration_2026_11_03'];h=n['host_input_revision']
s['status']='HOST_INPUT_REVISION_SOFTWARE_CHECKED_ACTUAL_ADMISSION_PENDING';n['status']=s['status'];s['next_action']='Publish/pin the independently checked single-host amendment and exactschema4 haltedV3carry, freshly qualify complete128file current source/48host inputs against unchanged21goldens/streams/runtime, then runall64oldreferencecalls at600souter/630sfullreservation. Preserveallfees/halts/clock; any furtherunknownhost remainsdenied. Only fullacceptance/measureddeadline/source/input/seed/capacity/copies admit original2048worlds/A1-A3. No scientific/2024 admission or budget/A4change.';n['next_action']=s['next_action'];n['code_status']='Source-bound old47/new48host input adapter and exactV4five-setup/Qgapfinancialhandoff checked by8+4new independentmethods,23affectedregressions,actualread-onlyinputs andcentralpreservation/source review. Fresh actualqualification/all64/full2048stillrequired.'
h['status']=close['status'];h['through_utc']=close['at_utc'];h['effort']=close['effort'];h['estimate']='30-90minutes boundedconstruction/checks plusunknownactualqualification/full64; originalA4unchanged.';h['finding']='Independent isolatedcontrolled import-only child reproducesold47denial withONLYapphelp unknown in stablebefore/after snapshots; knownhost descriptorsunchanged. Selectedexactdescriptor+signature supportsone prospectivefixedinput, not a certificate or exactpreviousfailedchild inventory.';h['independent_scope']='8metadata/capture/strictmembership cases plus4genuine financial/controller/copy cases with explicitlyinventedfailedQmetadata;23affectedoldprofile/correction/recoveryregressions. Native/mathfullqualificationnotclaimed.';h['checks']=close['checks'];h['source_pins']=close['source_pins'];h['source_closeout']={'name':'native-host-revision-source-closeout.json','sha256':hashlib.sha256((W/'native-host-revision-source-closeout.json').read_bytes()).hexdigest()};h['source_review']=close['independent_source_review'];h['central_reconciliation']=close['central_reconciliation'];h['actual_input_check']=close['actual_input_check'];h['capture']={'files':128,'bytes':11144999,'maximum_files':128,'maximum_bytes':16777216,'new_project_python_modules':0,'old_host_images':47,'amended_host_images':48,'numerical_profile':'stationary-native-runtime/2','host_input_id':'windows-host-inputs/2026-11-03.1'};h['actual_V4_launched']=False;h['evidence_capsule']=cap;h['concurrent_documents_preserved']=close['concurrent_documents'];h['changed_files']=changed+[cap['path'],'docs/architecture/CURRENT_STATE.md','docs/reviews/integration-research-2026-10-24/IMPLEMENTATION_SEQUENCE_2026-10-25.md','docs/reviews/implementation-2026-10-25/progress.json'];h['unverified']=close['unverified'];h['decision_rule']='Any furtherunqualifiedcomponent remainsdenied; retainfailure and researchtheconcretemembership/choice before a further amendment. No automatic broadening ofsource or scientificcriteria.'
n['reference_clock_correction']['evidence_capsule']['scope']='Historical64member e2db9c6/8982918 checkpoint; currentexpandedcapsule ishost_input_revision.evidence_capsule.'
D=json.JSONDecoder()
def ws(t,i):
 while t[i].isspace():i+=1
 return i
def span(t,path,start=0):
 i=ws(t,ws(t,start)+1)
 while t[i]!='}':
  k,e=D.raw_decode(t,i);a=ws(t,ws(t,e)+1);_,b=D.raw_decode(t,a)
  if k==path[0]:return(a,b) if len(path)==1 else span(t,path[1:],a)
  i=ws(t,b)
  if t[i]==',':i=ws(t,i+1)
 raise KeyError(path)
for k in ['status','next_action','native_parallel_calibration_2026_11_03']:
 a,b=span(t,['scientific_information_profile_2026_11_02',k]);line=t.rfind('\n',0,a)+1;indent=re.match(' *',t[line:]).group();nl='\r\n' if '\r\n' in t[a:b] else '\n';t=t[:a]+json.dumps(s[k],indent=2).replace('\n',nl+indent)+t[b:]
assert json.loads(t)==r;P.write_text(t,encoding='utf-8',newline='')
P=R/'docs/architecture/CURRENT_STATE.md';t=P.read_bytes().decode('utf-8');a=t.index('  Next: focused independent metadata reproduction');b=t.index('\n\n-',a);t=t[:a]+'''  A separate isolated import-only child now reproduces the old47 denial with
  exactly `apphelp.dll` unknown; known host bytes remain unchanged. The source-bound
  single-member amendment preserves the old fixture and historical47 reader;
  current source capture binds128 files and48 selected hosts within existing caps.
  Eight new metadata cases, four genuine financial/controller/copy cases and23
  affected regressions pass. Typed failed qualification in financial fixtures is
  an explicit seam; actual metadata/source preservation and inputs are checked
  separately. Schema/4 carries only the exact five-setup stopped V3 checkpoint,
  preserving all charges, markers, copies and original clock. Only this version
  additionally permits the exact old/new qualifier source; generic guards remain.
  Next: publish/pin, fresh actual full qualification, then all64 references and
  final admission. No V4 process, current certificate or final seed is claimed.
'''.rstrip().replace('\n','\r\n')+t[b:];P.write_text(t,encoding='utf-8',newline='')
P=R/'docs/reviews/integration-research-2026-10-24/IMPLEMENTATION_SEQUENCE_2026-10-25.md';t=P.read_bytes().decode('utf-8');needle='The local Codex connection log also corrects construction-time attribution:';assert t.count(needle)==1;t=t.replace(needle,'''**Host-input software closeout.** The independent controlled import-only child
reproduced the old47 denial with exactly `apphelp.dll` unknown in stable before/
after loader snapshots; known host bytes were unchanged and no draws or test
methods ran. This is contemporary evidence, not the exact failed child's image
inventory. The fixed amendment `windows-host-inputs/2026-11-03.1` records only its
reviewed path/hash/size and independent origin/probe references. The old fixture
and historical47 reader remain intact; current full source captures the amendment
and48 selected hosts. Neither metadata lookup nor constructor certifies it.

Eight independent metadata cases and four genuine financial/controller/copy
cases pass, together with23 affected historical-profile/correction/recovery
regressions. The actual stopped V3 input and source transition pass a read-only
check with primary bytes unchanged. Numerical/failed-Q answers in financial
fixtures are disclosed seams. The original numerical profile2, binaries,21 golden
cases, full result/stream digests and child/replay implementations remain unchanged.
Current capture is128files/11,144,999bytes within unchanged128/16MiB limits.

Schema/4 accepts only this exact five-setup V3 stop, its failed qualification and
inherited complete reference corpus. Existing known-use/carry/one-child/copy/
marker/revocation/no-final checks remain; only this version explicitly permits
the exact old/new qualifier file and fixed amendment. The generic four-file
repair allowance and all earlier stages remain unchanged. The existing consumer
capsule preserves all prior members and these sources/checks. Gross effort since
17:36:39UTC is retained including diagnosis/coordination/rework/checking; the
30-90minute estimate includes construction, with actual qualification/full64
still additional and uncertain. No clock credit, resource or A4 extension follows.

Next: publish/pin, fresh complete current-source qualification against unchanged
numerical goldens, all64 actual references at the checked600/630-second outer
policy, measured final deadline and final source/seed/capacity/copy admission.
Any further unknown host remains denied and requires concrete sourced review;
no automatic append or setup retry follows. V4 actual admission is unverified
at this software checkpoint. User-approved parallel later-data notes remain
preserved in this same plan and handoff; they do not start another workstream.

'''.replace('\n','\r\n')+needle);P.write_text(t,encoding='utf-8',newline='');print(json.dumps({'status':s['status'],'capsule':cap,'new_tests':12,'regressions':23,'concurrent_approved_document_notes_preserved':True}))
