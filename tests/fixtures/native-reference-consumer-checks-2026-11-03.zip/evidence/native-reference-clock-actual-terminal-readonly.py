from pathlib import Path
import datetime,hashlib,json,sqlite3,sys
R=Path.cwd();sys.path.insert(0,str(R))
from trading_researcher.codec import decode,digest
from trading_researcher.native_calibration_resources import NativeResourceHistory
from trading_researcher.native_calibration_runs import NativeCalibrationCopies
W=R/'.trf-runtime/native-final-calibration-2026-11-03';DB=R/'.trf-runtime/scalar-final-calibration-2026-11-02/registry/registry.sqlite3';before=hashlib.sha256(DB.read_bytes()).hexdigest()
POOL='e55f747cbb34e51a52ae6234707da0798c6643753eb15c5d8511480b27edc754'
with sqlite3.connect(DB.as_uri()+'?mode=ro',uri=True) as db:
 def artifact(identity):
  raw=db.execute('SELECT envelope FROM artifacts WHERE id=?',(identity,)).fetchone();assert raw is not None
  env=decode(raw[0]);assert digest(env)==identity;return {'id':identity,**env}
 pool=artifact(POOL);history=NativeResourceHistory(pool);old=artifact(pool['body']['source_correction']['predecessor_pool_id']);oldhistory=NativeResourceHistory(old)
 previous='0'*64;count=0
 for seq,prev,raw,identity in db.execute('SELECT seq,previous_hash,envelope,hash FROM events ORDER BY seq'):
  assert prev==previous and hashlib.sha256((previous+raw).encode()).hexdigest()==identity
  history.apply(decode(raw),artifact);oldhistory.apply(decode(raw),artifact);previous=identity;count+=1
 budget=history.budget();assert budget['halted'] and not budget['outstanding_attempts'] and not budget['usage_uncertain'] and not budget['overrun']
 assert oldhistory.checkpoint=='b908814d78808fe9e7e5cf3721432cc04887fd81418c458a90f3d88afbe88d43'
 assert not list(db.execute("SELECT id FROM artifacts WHERE json_extract(envelope,'$.body.schema') IN ('native-family-calibration-input/1','native-family-calibration-attempt/1')"))
 attempts=[]
 for identity, in db.execute("SELECT id FROM artifacts WHERE json_extract(envelope,'$.body.schema')='native-calibration-acceptance-attempt/1' AND json_extract(envelope,'$.body.resource_pool_id')=?",(POOL,)):
  a=artifact(identity);b=a['body'];attempts.append({'artifact_id':identity,**{k:b.get(k) for k in ('attempt_id','world_id','reference_id','reference_mode','resource_state','settlement','failure','failures','reference_comparison','created_at')},'proof_count':len(b.get('proofs',[])),'output_names':sorted(b.get('output_blobs',{}))})
 assert attempts==[]
 q=artifact('3af1410ff3bafd2d2a564f7ff400be102f2cfe939a9beb294c6a04dc1ab6406b')
 terminal=R/'.trf-runtime/scalar-final-calibration-2026-11-02'/('native-calibration-copies-'+POOL)/'terminal.json';copy=decode(terminal.read_bytes())
 assert copy['status']=='COPY_VERIFIED' and copy['event_prefix']=={'seq':count,'hash':previous} and copy['budget']==budget and copy['resource_checkpoint']==history.checkpoint
 assert copy['sql_fingerprint']==NativeCalibrationCopies._sql_fingerprint(db)
 r={'schema':'native-reference-clock-actual-terminal/1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ACTUAL_V3_HANDOFF_PASSED_HOST_QUALIFICATION_GAP_STOPPED',
  'source_commit':'e2db9c631f86fe7bc1854c3302c1862acc6b4794','exec_session_id':91034,'actual_exit_code':1,'pool_id':POOL,'resource_checkpoint':history.checkpoint,'budget':budget,'last_grant_progress':history.last_grant_progress,
  'carry':pool['body']['carry'],'source_correction':pool['body']['source_correction'],'predecessor_checkpoint_unchanged':oldhistory.checkpoint,
  'qualification':{'artifact_id':q['id'],**{k:q['body'][k] for k in ('status','profile','runtime_id','source_package_id','settlement','failure')}},'acceptance_attempts':attempts,
  'event_prefix':copy['event_prefix'],'terminal_complete_copy':{k:copy[k] for k in ('status','blobs','wall_elapsed_ms','event_prefix')},'terminal_copy_receipt_sha256':hashlib.sha256(terminal.read_bytes()).hexdigest(),
  'native_final_inputs_or_attempts':0,'original_operational_start_utc':pool['body']['source_correction']['operational_start_utc'],
  'scope':'Actual terminal process+known complete resource replay with no pending/nativefinal work; complete-copy proof reused and freshly matched to exact current primary SQL/resource/eventprefix. No new blob copying/hashing or numerical replay.',
  'diagnosis':'Actual same-study exact financial handoff passed; qualification before numeric generation denied an unqualified host image. Current metadata-only host probe finds signed Microsoft apphelp.dll outside the fixed47-image set; generic failed-child error does not identify its exact missing path. No automatic whitelist expansion, retry or restart. No new acceptance/final input or world.'}
assert hashlib.sha256(DB.read_bytes()).hexdigest()==before
r['primary_database_unchanged_during_read_only_reconciliation']=True;r['primary_database_sha256']=before
out=W/'native-reference-clock-actual-terminal.json';assert not out.exists();out.write_text(json.dumps(r,indent=2),encoding='utf-8')
print(json.dumps({'status':r['status'],'receipt_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'resource_checkpoint':history.checkpoint,'budget':budget,'copy':r['terminal_complete_copy'],'attempt_failures':[a['failure'] for a in attempts if a['failure']]},indent=2))
