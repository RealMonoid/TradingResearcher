import datetime,hashlib,io,json,pathlib,sys,time,unittest,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[2]
OUT=ROOT/'.trf-runtime/native-final-calibration-2026-11-03'
sys.path[:0]=[str(ROOT/'tests'),str(ROOT)]
name=sys.argv[1]; names=sys.argv[2:] or ['test_native_source_correction_independent']
helpers=['test_native_reference_clock_correction_independent.py','test_native_dependency_correction_independent.py','test_native_source_correction_independent.py','test_native_calibration_resource_owner_independent.py','test_native_calibration_copies_independent.py','test_native_reference_caller_independent.py','test_native_study_independent.py','test_native_reserved_attempts_independent.py','test_native_runtime_independent.py','family_run_support.py']
files=list((ROOT/'trading_researcher').rglob('*.py'))+[ROOT/'tests'/x for x in helpers]+[ROOT/'tools/calibration/native_parallel.py']
def pins():return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
before=pins()
with zipfile.ZipFile(OUT/(name+'-sources.zip'),'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in files:z.writestr(str(p.relative_to(ROOT)),p.read_bytes())
started=time.monotonic(); stream=io.StringIO(); suite=unittest.defaultTestLoader.loadTestsFromNames(names)
result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite); elapsed=time.monotonic()-started
record={'schema':'independent-test-check/1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Disposable actual financial/Registry/copy and disclosed genuine reference transport fixtures only; no actual production series or numerical qualification.','names':names,'discovered':suite.countTestCases(),'executed':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'exit_code':0 if result.wasSuccessful() else 1,'elapsed_seconds':elapsed,'before':before,'after':pins(),'raw':stream.getvalue(),'failure_details':[{'case':str(c),'traceback':t} for c,t in result.failures+result.errors]}
p=OUT/(name+'.json');p.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(stream.getvalue());print(json.dumps({'receipt':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'executed':result.testsRun,'exit_code':record['exit_code'],'pins_stable':record['before']==record['after']}));sys.exit(record['exit_code'])
