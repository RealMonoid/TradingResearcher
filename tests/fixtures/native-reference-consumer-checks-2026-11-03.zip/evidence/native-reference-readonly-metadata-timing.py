from pathlib import Path
import sys,sqlite3,threading,time,hashlib,json,cProfile,pstats,datetime
R=Path.cwd();W=R/'.trf-runtime/native-final-calibration-2026-11-03';pinned=W/'pinned-51f5d85';sys.path.insert(0,str(pinned))
from trading_researcher.coordination import Broker
from trading_researcher.native_calibration_runs import NativeCalibrationReferences
D=R/'.trf-runtime/scalar-final-calibration-2026-11-02/registry/registry.sqlite3';before=hashlib.sha256(D.read_bytes()).hexdigest()
b=Broker.__new__(Broker);b.directory=D.parent;b.clock=lambda:int(time.time());b._mutex=threading.RLock();b._db=sqlite3.connect(D.as_uri()+'?mode=ro',uri=True,cached_statements=0);b._db.row_factory=sqlite3.Row;b._db.execute('PRAGMA query_only=ON')
runner=NativeCalibrationReferences(b);study=b._artifact('93e219325d0139f7a9ecf1b8b63e4b5d7988347e043d9a080c0764b3b7772f78');p=cProfile.Profile();steps=[]
for name,fn in [('before_execute',lambda:runner._study_before_execute(study)),('canonical_inputs',lambda:runner._study_inputs(None,study['body']['request'])),('after_execute',lambda:runner._study_after_execute(study))]:
 t=time.perf_counter();p.enable();fn();p.disable();steps.append({'step':name,'seconds':time.perf_counter()-t});print(json.dumps(steps[-1]),flush=True)
s=pstats.Stats(p);rows=sorted([{'file':Path(k[0]).name,'line':k[1],'function':k[2],'calls':v[1],'self_seconds':v[2],'cumulative_seconds':v[3]} for k,v in s.stats.items()],key=lambda v:v['cumulative_seconds'],reverse=True)
b._db.close();assert hashlib.sha256(D.read_bytes()).hexdigest()==before
r={'schema':'native-reference-readonly-metadata-timing/1','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':'51f5d856b3feef20fe6dd616774ea1a930ba5878','steps':steps,'profile':rows,'database_sha256':before,'primary_database_unchanged':True,'scope':'One current-source metadata path on SQLite mode=ro/query_only with a Broker allocated without bootstrap or credentials. All called owners real. No reservations, numerical generation, replay, retry, resource mutations or extra qualification. cProfile adds overhead; this is not actual attempt phase timing or serial/parallel throughput.'}
out=W/'native-reference-readonly-metadata-timing.json';assert not out.exists();out.write_text(json.dumps(r,indent=2));print(json.dumps({'receipt_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'steps':steps,'top':rows[:13]}))
