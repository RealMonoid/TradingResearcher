import ast, hashlib, io, json, pathlib, sys, time, unittest
from datetime import datetime, timezone
ROOT=pathlib.Path.cwd(); WORK=ROOT/'.trf-runtime/native-final-calibration-2026-11-03'
PREFIX='native-reserved-corrected-domain'
paths=['tests/test_native_reserved_attempts_independent.py','tests/test_native_calibration_inputs_independent.py','tests/test_native_calibration_resource_owner_independent.py','tests/test_native_study_independent.py','tests/test_native_runtime_independent.py','tests/family_run_support.py','tests/binding_support.py','trading_researcher/native_calibration_runs.py','trading_researcher/native_calibration_resources.py','trading_researcher/calibration_recovery.py','trading_researcher/native_study_runs.py','trading_researcher/study_runs.py','trading_researcher/study_process_control.py','trading_researcher/native_study_pipeline.py','trading_researcher/native_runtime.py','trading_researcher/study_pipeline.py','trading_researcher/family_pipeline.py','trading_researcher/stationary_bootstrap.py','trading_researcher/storage.py','trading_researcher/codec.py']
def pins():return {p:{'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest(),'size':(ROOT/p).stat().st_size} for p in paths}
before=pins()
for p in paths:(WORK/(PREFIX+'-'+pathlib.Path(p).name)).write_bytes((ROOT/p).read_bytes())
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(ROOT/'tests'));  import test_native_reserved_attempts_independent as m
names=['test_healthy_reserved_call_uses_real_transport_full_replay_and_exact_owned_cost_custody','test_replay_clock_preserves_full_generation_then_same_world_retry_matches_full_bytes','test_unavailable_combined_custody_snapshot_still_retains_outputs_and_checks_currency']
suite=unittest.TestSuite(m.NativeReservedAttemptsIndependentTests(n) for n in names)
stream=io.StringIO()
class Result(unittest.TextTestResult):
 def startTest(self,test):super().startTest(test); print('START',test.id(),flush=True)
 def addSuccess(self,test):super().addSuccess(test); print('PASS',test.id(),flush=True)
start=datetime.now(timezone.utc).isoformat(); timer=time.perf_counter()
result=unittest.TextTestRunner(stream=stream,verbosity=2,failfast=True,resultclass=Result).run(suite)
elapsed=time.perf_counter()-timer; raw=stream.getvalue(); (WORK/(PREFIX+'-stdout.txt')).write_text(raw,encoding='utf-8')
receipt={'started_at_utc':start,'finished_at_utc':datetime.now(timezone.utc).isoformat(),'scope':'Genuine temporary Registry/input/resource owners, real native transport/source/stream/custody; invented native qualification/runtime membership and numerical child responses; no actual series or numerical resampling. Failfast selection.','requested_methods':names,'discovered':suite.countTestCases(),'executed':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'elapsed_seconds':elapsed,'exit_code':0 if result.wasSuccessful() else 1,'pins_before':before,'pins_after':pins(),'raw_stdout_sha256':hashlib.sha256(raw.encode()).hexdigest(),'raw_stdout':raw}
receipt['pins_unchanged']=receipt['pins_before']==receipt['pins_after']
path=WORK/(PREFIX+'-check.json');path.write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(raw,flush=True);print('RECEIPT',path,'SHA256',hashlib.sha256(path.read_bytes()).hexdigest(),flush=True)
sys.exit(receipt['exit_code'])
