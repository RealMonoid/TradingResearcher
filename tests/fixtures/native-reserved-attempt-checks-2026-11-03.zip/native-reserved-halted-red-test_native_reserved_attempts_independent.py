"""Independent reserved-native caller controls; no actual series execution.

Disposable Registry reservations/accounting/custody run through their owners.
Qualification, native binary membership and numerical responses are explicitly
synthetic seams. No empirical result or scientific admission is asserted.
"""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import test_native_calibration_resource_owner_independent as financial_support
from trading_researcher import native_calibration_runs
from trading_researcher.codec import Invalid
from trading_researcher.errors import Conflict, Denied
from trading_researcher.evaluation_plans import footprint, source_bundle
from trading_researcher.native_runtime import NativeRuntimes
from trading_researcher.native_study_runs import NativeFamilyCalibrationStudies


class NativeReservedAttemptEntrypointIndependentTests(unittest.TestCase):
    def test_host_only_reserved_attempt_owner_exists_before_domain_cases(self):
        self.assertTrue(callable(getattr(native_calibration_runs, 'NativeCalibrationAttempts', None)),
                        'Reserved native attempt owner absent; zero domain-flow coverage')

    def test_missing_numerical_caller_cannot_authorize_retry_when_previous_generation_is_absent(self):
        # Focused private-method counterexample only: no Broker/ledger or
        # dispatch proof is fabricated by a metadata-only KNOWN_TIMEOUT label.
        caller = native_calibration_runs.NativeCalibrationAttempts.__new__(
            native_calibration_runs.NativeCalibrationAttempts)
        prior = {'body': {'schema': 'native-family-calibration-attempt/1', 'result': None,
                         'resource_state': 'KNOWN_TIMEOUT', 'currency_checked': True,
                         'failure': {'type': 'ChildDeadlineExceeded', 'message': 'Synthetic metadata-only clock'},
                         'settlement': {'usage_known': True}}}
        with self.assertRaises((Invalid, Conflict, Denied)):
            caller._retry_equal(prior, None, [], [], {})


class NativeReservedEarlyHaltIndependentTests(unittest.TestCase):
    def test_halted_pool_cannot_start_pending_final_b_before_any_input_or_cache_work(self):
        # Early negative gate ONLY: this host-private typed final metadata has
        # no input/qualification validity claim. The guard precedes those owners.
        with tempfile.TemporaryDirectory(prefix='trf-native-halted-reservation-') as temporary:
            f = financial_support.RetiredFinancialFixture(Path(temporary))
            try:
                with patch.object(native_calibration_runs.NativeCalibrationResources,
                                  '_read_authority', return_value=deepcopy(f.authority)):
                    manager = native_calibration_runs.NativeCalibrationResources(f.broker)
                    pool = manager.prepare(f.token, {'key': 'early-halt-negative-only'})
                    typed = f.save({'schema': 'native-family-calibration-input/1', 'created_at': 1,
                        'request': {'development_study_id': f.recovery_source['id'],
                                    'native_qualification_id': f.recovery_source['id']},
                        'manifest': f.study['body']['manifest'], 'payload': f.study['body']['payload'],
                        'source_footprint': footprint(source_bundle()), 'scientific_readiness': False,
                        'native_binding': {'fixture': 'typed metadata only; never qualified'}},
                        refs=[f.recovery_source['id']],
                        authority='conditional_native_joint_family_calibration_not_scientific_admission')
                    tasks = sorted(world['id'] for world in typed['body']['manifest']['worlds'])
                    manager.bind_inventory(f.token, {'pool_id': pool['id'], 'key': 'early-halt-final',
                        'phase': 'final', 'task_ids': tasks, 'execution_deadline_ms': 10000,
                        'attempt_compute_ms': 15000, 'attempt_storage_bytes': 256 * 1048576,
                        'max_attempts': 2, 'expected_checkpoint': manager.inspect(f.token, pool['id'])['resource_checkpoint']},
                        input_id=typed['id'])
                    for index in range(2):
                        manager.reserve(f.token, {'pool_id': pool['id'], 'phase': 'final', 'task_id': tasks[index],
                            'attempt_id': format(index + 1, '032x'),
                            'expected_checkpoint': manager.inspect(f.token, pool['id'])['resource_checkpoint']})
                    manager.stop(f.token, pool['id'], 'Independent stop before B dispatch')
                    before = manager.inspect(f.token, pool['id'])
                    caller = native_calibration_runs.NativeCalibrationAttempts(f.broker)
                    with patch.object(NativeFamilyCalibrationStudies, '_study_before_execute',
                                      side_effect=AssertionError('Halted task entered input validation')) as inputs, \
                            patch.object(NativeRuntimes, '_materialize',
                                      side_effect=AssertionError('Halted task entered native cache')) as cache:
                        rejected = False
                        try:
                            caller.execute(f.token, pool['id'], format(2, '032x'), _cancel=None)
                        except (Invalid, Denied):
                            rejected = True
                        inputs.assert_not_called(); cache.assert_not_called()
                        self.assertTrue(rejected)
                    self.assertEqual(manager.inspect(f.token, pool['id']), before)
            finally:
                f.broker.close()


if __name__ == '__main__':
    unittest.main()
