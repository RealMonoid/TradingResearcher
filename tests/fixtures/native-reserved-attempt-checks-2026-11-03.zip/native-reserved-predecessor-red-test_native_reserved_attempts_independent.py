"""Independent reserved-native caller controls; no actual series execution.

Disposable Registry reservations/accounting/custody run through their owners.
Qualification, native binary membership and numerical responses are explicitly
synthetic seams. No empirical result or scientific admission is asserted.
"""
import unittest

from trading_researcher import native_calibration_runs
from trading_researcher.codec import Invalid
from trading_researcher.errors import Conflict, Denied


class NativeReservedAttemptEntrypointIndependentTests(unittest.TestCase):
    def test_host_only_reserved_attempt_owner_exists_before_domain_cases(self):
        self.assertTrue(callable(getattr(native_calibration_runs, 'NativeCalibrationAttempts', None)),
                        'Reserved native attempt owner absent; zero domain-flow coverage')

    def test_missing_numerical_caller_cannot_authorize_retry_when_previous_generation_is_absent(self):
        # Focused private-method counterexample only: no Broker/ledger or
        # dispatch proof is fabricated by a metadata-only KNOWN_TIMEOUT label.
        caller = native_calibration_runs.NativeCalibrationAttempts.__new__(
            native_calibration_runs.NativeCalibrationAttempts)
        prior = {'body': {'schema': 'native-family-calibration-attempt/1', 'result': None,
                         'resource_state': 'KNOWN_TIMEOUT', 'currency_checked': True,
                         'failure': {'type': 'ChildDeadlineExceeded', 'message': 'Synthetic metadata-only clock'},
                         'settlement': {'usage_known': True}}}
        with self.assertRaises((Invalid, Conflict, Denied)):
            caller._retry_equal(prior, None, [], [], {})


if __name__ == '__main__':
    unittest.main()
