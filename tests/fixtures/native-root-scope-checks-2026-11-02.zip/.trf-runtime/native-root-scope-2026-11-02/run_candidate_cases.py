"""Run unchanged independent oracle/behavior cases against an isolated module."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import time
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'tests')]
assert hashlib.sha256((ROOT / 'trading_researcher/native_runtime.py').read_bytes()).hexdigest() == '4f3a2097380a640c14dfeaa89c9e12a35aee54f7768aba251a795c21e8382e74'
assert hashlib.sha256((ROOT / 'tests/test_native_tree_verification_independent.py').read_bytes()).hexdigest() == '918cb779a49b05fc31f76ffa7e162dae7e62567d61c3ec3c6cf3a3f07d6ce78f'
assert hashlib.sha256((ROOT / 'tests/test_native_cache_root_independent.py').read_bytes()).hexdigest() == '8d63503a27d9256ac6eab5f47202980ca32c1ec70b7a1ac1042ddbadbbd843f1'
import trading_researcher.native_runtime
import test_native_tree_verification_independent as old
import test_native_cache_root_independent as added
spec = importlib.util.spec_from_file_location('trading_researcher.root_scope_candidate', HERE / 'candidate_native_runtime.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
old.runtime = module
new_cases = added.make_cases(module)
suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(old.NativeTreeVerificationIndependentTests),
                           unittest.defaultTestLoader.loadTestsFromTestCase(new_cases)])
assert suite.countTestCases() == 19
start = time.monotonic()
log = io.StringIO()
r = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
receipt = {'scope':'15unchangedactive behavior methods plus3newmethods; one unchanged explicit old-unselected implementation counter remains skipped. Each method retains frozenoracle and selectedcandidate assertions. No Registry/qualifier/world/numeric operation.',
           'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped),
           'seconds':str(time.monotonic()-start),'stderr':log.getvalue(),
           'new_case_observations':new_cases.observations,
           'candidate_sha256':hashlib.sha256((HERE / 'candidate_native_runtime.py').read_bytes()).hexdigest()}
(HERE / 'candidate-cases.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
(HERE / 'candidate-cases-stderr.txt').write_text(log.getvalue(),encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('stderr','new_case_observations')}))
print(log.getvalue(), end='')
assert r.wasSuccessful() and r.testsRun == 19 and len(r.skipped) == 1
