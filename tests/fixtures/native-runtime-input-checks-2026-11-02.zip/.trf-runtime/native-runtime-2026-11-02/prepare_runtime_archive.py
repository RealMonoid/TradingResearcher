"""Preserve acquired NumPy and the unchanged qualification candidate as inputs.

No installation, execution, study selection or certification is performed.
Explicit upstream directory entries must all be derivable from retained files.
The original wheel remains an exact member as well as the bound provenance.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
import time
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from trading_researcher.certification import _runtime_identity
from trading_researcher.codec import canonical, digest
from trading_researcher.native_runtime import validate_archive

BUILD = ROOT / '.trf-runtime/native-build-tools-2026-11-02'
NAME = 'numpy-2.3.4-cp314-cp314-win_amd64.whl'
PIN = '3da3491cee49cf16157e70f607c03a217ea6647b1cea4819c4f48e53d49139b9'
BINARY = '_trf_mt_probe.cp314-win_amd64.pyd'
BINARY_PIN = '8b0c3f65afde2bdb534289dc3efbbaf568776aad9cade02929d872a48309c4a2'


def prepare():
    started = time.monotonic()
    wheel = HERE / NAME
    assert hashlib.sha256(wheel.read_bytes()).hexdigest() == PIN
    assert hashlib.sha256((BUILD / BINARY).read_bytes()).hexdigest() == BINARY_PIN
    build_receipt = json.loads((BUILD / 'build-receipt.json').read_text())
    build_licenses = [HERE / 'Cython-COPYING.txt', HERE / 'Cython-LICENSE.txt']
    assert build_licenses and all(path.is_file() for path in build_licenses)
    own = {
        BINARY: BUILD / BINARY,
        'provenance/' + NAME: wheel,
        'provenance/owned-adapter.pyx': BUILD / '_trf_mt_probe.pyx',
        'provenance/build-receipt.json': BUILD / 'build-receipt.json',
        'provenance/build-requirements.lock': BUILD / 'build-requirements.lock',
        'provenance/cython-notice-acquisition.json': HERE / 'cython-notice-acquisition.json',
    }
    for index, path in enumerate(build_licenses):
        own[f'provenance/Cython-{index}-LICENSE.txt'] = path
    target = HERE / 'native-probe-runtime.zip'
    files = {}

    def retain(archive, name, raw):
        assert name not in files
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 2, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, raw)
        files[name] = {'sha256': hashlib.sha256(raw).hexdigest(), 'size': len(raw)}

    with zipfile.ZipFile(wheel) as source:
        names = [item.filename for item in source.infolist() if not item.is_dir()]
        parents = {parent.as_posix() + '/' for name in names for parent in PurePosixPath(name).parents
                   if parent.as_posix() != '.'}
        directories = {item.filename for item in source.infolist() if item.is_dir()}
        assert directories <= parents, 'An upstream empty directory requires explicit treatment'
        header = source.read('numpy/_core/include/numpy/random/bitgen.h')
        assert hashlib.sha256(header).hexdigest() == build_receipt['bitgen_header_sha256']
        with zipfile.ZipFile(target, 'x') as output:
            for name in sorted(names):
                retain(output, name, source.read(name))
            for name, path in sorted(own.items()):
                retain(output, name, path.read_bytes())
    licenses = [name for name in files if PurePosixPath(name).name.casefold().startswith(('license', 'copying', 'notice'))
                and not name.startswith('provenance/')]
    manifest = {'schema': 'native-runtime-files/1', 'runtime_identity': _runtime_identity(),
        'dependencies': {
            'numpy': {'version': '2.3.4', 'distribution_sha256': PIN, 'license_files': licenses},
            'owned-adapter-probe': {'version': 'qualification-only/1',
                'distribution_sha256': files['provenance/owned-adapter.pyx']['sha256'],
                'license_files': [name for name in own if 'LICENSE' in name]}},
        'files': files}
    (HERE / 'native-probe-runtime-manifest.json').write_text(canonical(manifest), encoding='utf-8')
    receipt = {'scope': 'Retained input archive only; no execution, actual study binding or certification.',
        'utc': datetime.now(timezone.utc).isoformat(), 'archive_sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
        'archive_bytes': target.stat().st_size, 'manifest_sha256': digest(manifest),
        'manifest_bytes': len(canonical(manifest).encode()), 'files': len(files),
        'unpacked_bytes': sum(item['size'] for item in files.values()),
        'original_wheel_sha256': PIN, 'omitted_redundant_directory_entries': len(directories),
        'preservation': 'Every upstream regular file retained byte-for-byte; every directory derives from them; original wheel also retained byte-for-byte; original header equals the compilation header.'}
    try:
        validate_archive(target.read_bytes(), manifest)
    except BaseException as error:
        receipt['failure'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        receipt['seconds'] = str(time.monotonic() - started)
        (HERE / 'native-probe-runtime-preparation.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
        print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    prepare()
