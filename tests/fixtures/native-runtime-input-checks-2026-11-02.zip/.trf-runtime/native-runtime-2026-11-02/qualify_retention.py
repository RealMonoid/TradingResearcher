"""Actual retained runtime bytes, isolated fixed cases and cache-free restoration.

Temporary operator registries only. The original independent expectations stay
unchanged; the sole generated source edit selects the retained binary by argv.
This is no scientific study or environment/admission certificate.
"""
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from trading_researcher.coordination import Broker
from trading_researcher.codec import decode, digest
from trading_researcher.native_runtime import NativeRuntimes, verify_tree
from trading_researcher.storage import restore_bundle


def qualify():
    started = time.monotonic()
    manifest = decode((HERE / 'native-probe-runtime-manifest.json').read_bytes())
    archive = HERE / 'native-probe-runtime.zip'
    expected_size = sum(item['size'] for item in manifest['files'].values())
    original = ROOT / '.trf-runtime/native-build-tools-2026-11-02/draw_independent_cases.py'
    raw = original.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == '342dd443823df5015109768428e15a425b5fba113d5abee8f27bf94ac9dcc0a9'
    source = raw.decode()
    before = "BINARY = HERE / '_trf_mt_probe.cp314-win_amd64.pyd'"
    assert source.count(before) == 1
    source = source.replace(before, 'BINARY = Path(sys.argv.pop(1))')
    generated = HERE / 'isolated_draw_independent_cases.py'
    generated.write_bytes(source.encode('utf-8'))
    difference = ''.join(difflib.unified_diff(raw.decode().splitlines(keepends=True),
        source.splitlines(keepends=True), fromfile='original-independent-cases',
        tofile='selected-retained-binary'))
    (HERE / 'isolated-case-selection.diff').write_text(difference, encoding='utf-8')
    receipt = {'scope': 'Technical retention/cache/isolation probe only; not actual study integration, '
                        'complete native transitive dependency closure or scientific certification.',
               'utc': datetime.now(timezone.utc).isoformat(), 'manifest_sha256': digest(manifest),
               'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
               'generated_cases_sha256': hashlib.sha256(generated.read_bytes()).hexdigest(),
               'binary_selection_diff': difference, 'checks': []}
    try:
        with tempfile.TemporaryDirectory(prefix='trf-native-retention-') as temporary:
            directory = Path(temporary)
            broker = Broker(directory / 'registry')
            try:
                source_artifact = broker.call(broker.admin_token, 'add_blob_source', path=str(archive),
                    data_class='operations', description='Retained qualification-only NumPy/adapter input; not a certificate')
                args = {'key': 'fixed-runtime-input', 'archive_id': source_artifact['id'], 'manifest': manifest}
                package = broker.call(broker.admin_token, 'retain_native_runtime', **args)
                assert broker.call(broker.admin_token, 'retain_native_runtime', **args) == package
                assert broker.call(broker.admin_token, 'inspect_native_runtime', runtime_id=package['id']) == package
                receipt['runtime_id'] = package['id']
                meter = {'materialized_bytes': 0}
                cache = NativeRuntimes(broker)._materialize(package['id'], meter)
                assert meter['materialized_bytes'] == expected_size and meter['accounting_complete']
                receipt['checks'].append({'stage': 'retention_and_first_materialization', 'bytes': meter['materialized_bytes']})
                binary = cache / '_trf_mt_probe.cp314-win_amd64.pyd'
                bootstrap = '''import hashlib,json,runpy,sys
from pathlib import Path
cache,script,binary=sys.argv[1:]
sys.path.insert(0,cache)
sys.argv=[script,binary]
try:
 runpy.run_path(script,run_name='__main__')
finally:
 selected=Path(cache).resolve()
 loaded={}
 for name,module in tuple(sys.modules.items()):
  filename=getattr(module,'__file__',None)
  if filename and (name.split('.')[0]=='numpy' or name=='_trf_mt_probe'):
   path=Path(filename).resolve()
   assert path.is_relative_to(selected),(name,str(path))
   loaded[path.relative_to(selected).as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest()
 assert '_trf_mt_probe.cp314-win_amd64.pyd' in loaded
 assert sys.flags.isolated==sys.flags.no_site==sys.flags.ignore_environment==1
 assert sys.dont_write_bytecode
 print(json.dumps({'isolated_module_files':loaded,'isolation':True}),flush=True)
'''
                command = [sys.executable, '-I', '-S', '-B', '-c', bootstrap,
                           str(cache), str(generated), str(binary)]
                child = subprocess.run(command, cwd=directory, capture_output=True, text=True, timeout=30)
                (HERE / 'isolated-loop-stdout.txt').write_text(child.stdout, encoding='utf-8')
                (HERE / 'isolated-loop-stderr.txt').write_text(child.stderr, encoding='utf-8')
                receipt['child_exit_code'] = child.returncode
                assert child.returncode == 0, child.stderr
                observation = json.loads(child.stdout.splitlines()[-1])
                for name, checksum in observation['isolated_module_files'].items():
                    assert manifest['files'][name]['sha256'] == checksum
                receipt['isolated_module_count'] = len(observation['isolated_module_files'])
                assert 'Ran 13 tests' in child.stderr and '\nOK\n' in child.stderr
                verify_tree(cache, manifest)
                hit = {'materialized_bytes': 0}
                assert NativeRuntimes(broker)._materialize(package['id'], hit) == cache
                assert hit['materialized_bytes'] == 0
                receipt['checks'].append({'stage': 'isolated_13_fixed_cases_then_verified_cache_hit', 'bytes': 0})
                destination = directory / 'backup'
                assert broker.call(broker.admin_token, 'backup_bundle', destination=str(destination))['status'] == 'PASS'
                restored = directory / 'restored'
                restore_bundle(destination, restored, broker.directory / 'operator.key')
                other = Broker(restored)
                try:
                    assert other.call(other.admin_token, 'inspect_native_runtime', runtime_id=package['id']) == package
                    restored_meter = {'materialized_bytes': 0}
                    rebuilt = NativeRuntimes(other)._materialize(package['id'], restored_meter)
                    assert rebuilt.is_relative_to(restored) and restored_meter['materialized_bytes'] == expected_size
                    verify_tree(rebuilt, manifest)
                    assert other.call(other.admin_token, 'verify')['status'] == 'PASS'
                    receipt['checks'].append({'stage': 'cache_free_restore_and_rebuild', 'bytes': restored_meter['materialized_bytes']})
                finally:
                    other.close()
            finally:
                broker.close()
        receipt['status'] = 'PASS'
    except BaseException as error:
        receipt['failure'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        receipt['seconds'] = str(time.monotonic() - started)
        (HERE / 'retention-qualification.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
        print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    qualify()
