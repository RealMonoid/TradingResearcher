"""Independent one-shot pre-final source-correction controls.

Disposable actual Registry/ledger/full-copy paths use explicitly synthetic
financial history and trusted fixture pins. No actual Registry, native/scalar
numerical work, certificate use or study restart is authorized by these tests.
"""
from contextlib import contextmanager
from copy import deepcopy
import hashlib
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import test_native_calibration_resource_owner_independent as financial_support
from trading_researcher import family_study, native_calibration_controller as controller
from trading_researcher.codec import Invalid, canonical, decode, digest
from trading_researcher.errors import Conflict, Denied
from trading_researcher.evaluation_plans import footprint, source_bundle
from trading_researcher.storage import restore_bundle

from trading_researcher import native_calibration_runs as owner


MIB = 1048576
ERRORS = (Invalid, Conflict, Denied, OSError)
PROJECT = Path(__file__).resolve().parents[1]
OLD_COORDINATION = 'd335e3ec64c2c82a6bcf8ad56ff3a8059c1590bd272b727d253a5d662769982b'
FIXED_COORDINATION = '25c67fa1d48371108aa1e91f630d953cc5e7e33e5615f503feadb851e3782dfc'
FAILURES = [('InterfaceError', 'bad parameter or other API misuse')] * 3 + [
    ('Denied', 'Artifact unavailable')] * 2 + [('Invalid', 'Expecting value: line 1 column 1 (char 0)')]


def previous_source():
    """Historical source transport only; archived code is never executed."""
    source = source_bundle()
    old = (PROJECT / '.trf-runtime/native-final-calibration-2026-11-03/native-broker-read-red-coordination.py').read_bytes()
    assert hashlib.sha256(old).hexdigest() == OLD_COORDINATION
    assert hashlib.sha256(source['trading_researcher/coordination.py']).hexdigest() == FIXED_COORDINATION
    return {**source, 'trading_researcher/coordination.py': old}


@contextmanager
def historical_source(source):
    with patch.object(owner, 'LOADED_SOURCE', footprint(source)), \
            patch.object(owner, 'source_bundle', return_value=source):
        yield


class CorrectionFixture:
    """Actual immutable financial/copy owners; synthetic pre-child failures.

    The pin seam substitutes fixture IDs, keeping the exact archived/current
    coordination SHA pair. This small fixture's reference is metadata only;
    separate genuine-reference cases exercise actual corpus preparation.
    """
    def __init__(self, root, *, broker=None, authority=None, reference=None,
                 old_source=None, variant=None):
        self.root = Path(root)
        self.financial = None
        if broker is None:
            self.financial = financial_support.RetiredFinancialFixture(self.root)
            broker, authority = self.financial.broker, self.financial.authority
        self.broker, self.token = broker, broker.admin_token
        self.authority = deepcopy(authority)
        self.old_source = old_source or previous_source()
        if variant == 'forbidden_source':
            self.old_source = dict(self.old_source)
            self.old_source['trading_researcher/codec.py'] += b'\n# Unsupported historical semantic change.\n'
        self.authority_patch = patch.object(owner.NativeCalibrationResources, '_read_authority',
                                           side_effect=lambda: deepcopy(self.authority))
        self.authority_patch.start()
        try:
            with historical_source(self.old_source):
                self.manager = owner.NativeCalibrationResources(broker)
                driver = self.root / 'fixture-native-driver.py'
                driver.write_bytes(b'# Pinned synthetic driver; never executed.\n')
                self.control = controller.NativeCalibrationController(broker, self.root / 'old-controller', driver_file=driver)
                self.pool = self.control.prepare(self.token, 'independent-pre-final-old-pool')
                self.source_result = broker._artifact(self.control.binding['source_result_id'])
                if reference is None:
                    f = self.financial
                    profile = deepcopy(f.study['body']['manifest']['profile'])
                    profile.update(worlds_per_cell=1, targets=[15, 16])
                    manifest = family_study.make_manifest(f.study['body']['manifest']['assigned'], profile)
                    reference = f.save({'schema': 'native-calibration-reference-input/1', 'created_at': 1,
                        'request': {'key': 'synthetic-pre-child-reference',
                            'development_study_id': f.recovery_source['id'],
                            'native_qualification_id': f.recovery_source['id']},
                        'payload': deepcopy(f.study['body']['payload']), 'manifest': manifest,
                        'source_footprint': footprint(self.old_source), 'references': {},
                        'native_binding': {'runtime_id': f.recovery_source['id']},
                        'process_control': {'schema': 'native-study-process-control/1',
                            'library_threads': 1, 'priority': 'BELOW_NORMAL'},
                        'scientific_readiness': False}, refs=[f.recovery_source['id']])
                self.reference = reference
                self.copies = owner.NativeCalibrationCopies(broker)
                self.bookings = {label: self.copies.book(self.token, self.pool['id'], label)
                                 for label in ('prepared', 'terminal')}
                tasks = owner.NativeCalibrationReferences.tasks(reference)
                self.inventory = self.manager.bind_inventory(self.token, {
                    'key': 'pre-child-acceptance', 'pool_id': self.pool['id'], 'phase': 'acceptance',
                    'task_ids': sorted(tasks), 'execution_deadline_ms': 10000,
                    'attempt_compute_ms': 15000, 'attempt_storage_bytes': 256 * MIB,
                    'max_attempts': 1, 'expected_checkpoint': self.view()['resource_checkpoint']}, input_id=reference['id'])
                selected = sorted(task for task, value in tasks.items() if value['mode'] == 'parallel')[:6]
                assert len(selected) == 6
                reservations = [self.manager.reserve(self.token, {'pool_id': self.pool['id'],
                    'phase': 'acceptance', 'task_id': task, 'attempt_id': format(index + 100, '032x'),
                    'expected_checkpoint': self.view()['resource_checkpoint']}) for index, task in enumerate(selected)]
                self.failed = []
                for index, reservation in enumerate(reservations):
                    if variant == 'pending' and index == 5:
                        continue
                    task = tasks[reservation['task_id']]
                    failure = dict(zip(('type', 'message'), FAILURES[index]))
                    if variant == 'wrong_failure' and index == 5:
                        failure['message'] = 'A different unsupported protocol failure'
                    settlement = {'attempt_id': reservation['attempt_id'], 'compute_ms': 11 + index,
                        'storage_bytes': MIB, 'usage_known': not (variant == 'unknown' and index == 5)}
                    if variant == 'overrun' and index == 5:
                        settlement['compute_ms'] = reservation['compute_ms'] + 1
                    self.failed.append(self.manager.settle(self.token, self.pool['id'], {
                        'resource_pool_id': self.pool['id'], 'phase': 'acceptance',
                        'task_id': reservation['task_id'], 'attempt_id': reservation['attempt_id'],
                        'study_id': reference['id'], 'reference_id': reference['id'],
                        'world_id': task['world_id'], 'reference_mode': task['mode'],
                        'resource_state': 'FAILED', 'currency_checked': True,
                        'failure': failure, 'failures': [failure], 'settlement': settlement,
                        'result': None, 'replay_result': None, 'proofs': [], 'output_blobs': {},
                        'custody': {'schema': 'native-attempt-custody/1', 'binding': {}, 'phases': []}}))
                self.receipt_path = self.copies.receipt_path(self.pool['id'], 'terminal')
                self.backup, self.restored = self.root / 'old-terminal-backup', self.root / 'old-terminal-restore'
                if variant not in ('pending', 'unknown', 'overrun'):
                    self.receipt = self.copies.create(self.token, self.pool['id'], 'terminal',
                        backup_directory=self.backup, restore_directory=self.restored, receipt_path=self.receipt_path)
            self.original_pool_bytes = canonical(broker._artifact(self.pool['id']))
            self.before = deepcopy(self.view())
            self.pins = {**dict(owner.SOURCE_CORRECTION), 'predecessor_pool_id': self.pool['id'],
                'expected_checkpoint': self.before['resource_checkpoint'], 'reference_id': reference['id'],
                'source_result_id': self.source_result['id']}
            self.args = {'key': 'one-independent-correction', 'predecessor_pool_id': self.pool['id'],
                'expected_checkpoint': self.pins['expected_checkpoint'], 'terminal_receipt_path': str(self.receipt_path)}
            self.operator_key = self.root / 'fixture-operator.key'
            self.operator_key.write_bytes((broker.directory / 'operator.key').read_bytes())
        except BaseException:
            self.close()
            raise

    def view(self):
        return self.manager.inspect(self.token, self.pool['id'])

    def correct(self, **changes):
        with patch.object(owner, 'SOURCE_CORRECTION', self.pins):
            return self.manager.correct_source(self.token, {**self.args, **changes})

    def close(self):
        self.authority_patch.stop()
        self.broker.close()


class NativeSourceCorrectionFinancialIndependentTests(unittest.TestCase):
    def fixture(self, **options):
        temporary = tempfile.TemporaryDirectory(prefix='trf-native-source-correction-')
        self.addCleanup(temporary.cleanup)
        result = CorrectionFixture(Path(temporary.name), **options)
        self.addCleanup(result.close)
        return result

    def test_restoring_old_terminal_prefix_cannot_mint_a_second_successor_or_forget_first_fee(self):
        f = self.fixture()
        child = f.correct()
        after = f.manager.inspect(f.token, child['id'])
        self.assertEqual(after['budget']['charged_storage_bytes'], f.before['budget']['charged_storage_bytes'] + MIB)
        original, retained = f.broker.directory, f.root / 'retained-primary-after-source-correction'
        self.assertTrue(original.resolve().is_relative_to(f.root.resolve()))
        self.assertTrue(retained.resolve().is_relative_to(f.root.resolve()))
        f.broker.close()
        original.rename(retained)
        self.assertEqual(restore_bundle(f.backup, original, f.operator_key)['status'], 'PASS')
        f.broker = financial_support.Broker(original)
        f.token = f.broker.admin_token
        f.manager = owner.NativeCalibrationResources(f.broker)
        before = f.view()
        with self.assertRaises(ERRORS):
            f.correct()
        self.assertEqual(f.view(), before)
        self.assertEqual(len(f.manager._objects('native-calibration-resource-pool/1')), 1)
        self.assertTrue((retained / 'registry.sqlite3').is_file())


class NativeSourceCorrectionEntrypointIndependentTests(unittest.TestCase):
    def test_correction_reference_owner_exists_before_domain_cases(self):
        self.assertTrue(callable(getattr(owner, 'NativeCalibrationCorrectionReferences', None)),
                        'Correction reference entrypoint absent; zero correction domain-flow coverage')


if __name__ == '__main__':
    unittest.main()
