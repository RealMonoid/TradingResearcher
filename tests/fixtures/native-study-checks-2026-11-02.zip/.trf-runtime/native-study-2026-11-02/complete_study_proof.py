"""Complete the retained fixed engineering inventory; preserve failed driver v1."""
import hashlib
import json
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from trading_researcher.coordination import Broker
from trading_researcher.codec import digest
from trading_researcher.evaluation_plans import source_bundle, footprint
from trading_researcher.storage import restore_bundle


def run():
    target = HERE / 'actual-v1'
    receipt_path = target / 'completion-receipt.json'
    assert not receipt_path.exists()
    original = json.loads((target / 'receipt.json').read_text())
    attempts = {(a['kind'], a['engine']): a for a in original['attempts']}
    intent = {'purpose': 'Complete ALL remaining three fixed family worlds, then cache-free single-world restore; no selective search for native observations.',
              'prior_failure': original['failure'], 'budget_change': False,
              'source_footprint': footprint(source_bundle()), 'native_family_worlds': 3,
              'additional_original_scalar_single_worlds': 1, 'restored_native_single_worlds': 1}
    with (target / 'completion-intent.json').open('x') as stream:
        json.dump(intent, stream, indent=2)
    started = time.monotonic()
    receipt = {'intent': intent, 'pairs': []}
    broker = Broker(target / 'registry')
    def op(operation, **args):
        return broker.call(broker.admin_token, operation, **args)
    def body(identity):
        return op('get_artifact', artifact_id=identity)['body']
    def checked(study_id, operation):
        view = op(operation, study_id=study_id)
        record = body(view['attempt_artifact_ids'][-1])
        assert record['failure'] is None and record['outcome']['state'] in ('VERIFIED', 'INFORMATION_GAP')
        assert len(record['proofs']) == 2 and record['scientific_readiness'] is False
        assert record['output_blobs']['generate/stream.jsonl.gz'] == record['output_blobs']['replay/expected-stream.jsonl.gz']
        return record, view
    def same(left, right):
        assert left['result'] == right['result']
        assert left['output_blobs']['generate/stream.jsonl.gz'] == right['output_blobs']['generate/stream.jsonl.gz']
    try:
        family_scalar = attempts['family', 'scalar']['study_id']
        family_native = attempts['family', 'native']['study_id']
        scalar = op('get_artifact', artifact_id=family_scalar)
        native = op('get_artifact', artifact_id=family_native)
        assert scalar['body']['manifest'] == native['body']['manifest']
        assert len(native['body']['manifest']['worlds']) == 4
        same(body(attempts['family', 'scalar']['attempt_id']), body(attempts['family', 'native']['attempt_id']))
        receipt['first_family_gap_equal'] = True
        engine_uses = 0
        for world in native['body']['manifest']['worlds'][1:]:
            left, _ = checked(family_scalar, 'advance_family_study')
            right, view = checked(family_native, 'advance_native_family_study')
            assert left['world_id'] == right['world_id'] == world['id']
            same(left, right)
            engines = right['proofs'][0]['draw_engines']
            engine_uses += sum(item['native'] for item in engines)
            receipt['pairs'].append({'world_id': world['id'], 'result_sha256': digest(left['result']),
                'stream': left['output_blobs']['generate/stream.jsonl.gz'], 'draw_engines': engines,
                'scalar_settlement': left['settlement'], 'native_settlement': right['settlement']})
        assert engine_uses > 0, 'Complete fixed family fixture never invoked its native numerical engine'
        receipt['family_engine_uses'] = engine_uses
        assert view['status'] == 'COMPLETE' and view['scientific_readiness'] is False
        receipt['family_view'] = view
        single_native = attempts['information', 'native']['study_id']
        single_study = op('get_artifact', artifact_id=single_native)
        certificate_id = single_study['body']['request']['native_qualification_id']
        certificate = op('get_artifact', artifact_id=certificate_id)
        left, _ = checked(attempts['information', 'scalar']['study_id'], 'advance_information_study')
        receipt['single_reference_settlement'] = left['settlement']
        before = op('inspect_native_information_study', study_id=single_native)
        receipt['before_restore'] = before
        receipt['backup'] = op('backup_bundle', destination=str(target / 'study-backup'))
        key = broker.directory / 'operator.key'
        broker.close()
        restore_bundle(target / 'study-backup', target / 'restored', key)
        broker = Broker(target / 'restored')
        assert not (broker.directory / 'native-runtime-cache').exists()
        assert op('inspect_native_runtime_qualification', qualification_id=certificate_id)['status'] == 'STALE'
        assert op('inspect_native_information_study', study_id=single_native) == before
        right, after = checked(single_native, 'advance_native_information_study')
        same(left, right)
        receipt['restored_result_sha256'] = digest(right['result'])
        receipt['restored_attempt'] = right
        receipt['after_restore'] = after
        assert op('get_artifact', artifact_id=single_native) == single_study
        assert op('get_artifact', artifact_id=certificate_id) == certificate
        assert op('inspect_native_runtime_qualification', qualification_id=certificate_id)['status'] == 'CURRENT'
        assert op('verify')['status'] == 'PASS'
        assert footprint(source_bundle()) == intent['source_footprint']
        assert 'numpy' not in sys.modules and '_trf_stationary_native' not in sys.modules
        receipt['controller_numpy_imported'] = False
        receipt['status'] = 'PASS'
    except BaseException as exc:
        receipt['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        raise
    finally:
        broker.close()
        receipt['seconds'] = str(time.monotonic() - started)
        with receipt_path.open('x') as stream:
            json.dump(receipt, stream, indent=2)
        print(json.dumps({key: value for key, value in receipt.items()
                          if key in ('status', 'failure', 'seconds', 'family_engine_uses')}), flush=True)


if __name__ == '__main__':
    run()
