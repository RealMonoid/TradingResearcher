"""Complete both existing fixed inventories; never search for a favorable mask."""
import json
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from trading_researcher.coordination import Broker
from trading_researcher.codec import digest
from trading_researcher.evaluation_plans import source_bundle, footprint


def run():
    target = HERE / 'actual-v2'
    receipt_path = target / 'completion-receipt.json'
    assert not receipt_path.exists()
    prior = json.loads((target / 'receipt.json').read_text())
    assert prior['failure']['type'] == 'AssertionError'
    receipt = {'purpose': 'Complete every existing fixed single3/family4 world, preserving first gap and all original source/profile/caps; no new candidate or selective stop.', 'pairs': []}
    started = time.monotonic()
    broker = Broker(target / 'restored')
    def op(operation, **args):
        return broker.call(broker.admin_token, operation, **args)
    def artifact(identity):
        return op('get_artifact', artifact_id=identity)
    try:
        schemas = {'information-study-input/1': ('information', 'scalar'),
                   'native-information-study-input/1': ('information', 'native'),
                   'family-study-input/1': ('family', 'scalar'),
                   'native-family-study-input/1': ('family', 'native')}
        studies = {}
        for identity, schema in broker._db.execute("SELECT id,json_extract(envelope,'$.body.schema') FROM artifacts"):
            if schema in schemas:
                assert schemas[schema] not in studies
                studies[schemas[schema]] = artifact(identity)
        assert set(studies) == set(schemas.values())
        intent = {'source_footprint': footprint(source_bundle()), 'prior_failure': prior['failure'],
            'budgets_unchanged': True, 'studies': {kind + '/' + mode: {'id': item['id'],
                'world_ids': [w['id'] for w in item['body']['manifest']['worlds']],
                'budget': item['body']['manifest']['profile']['budget']} for (kind, mode), item in studies.items()}}
        assert len(intent['studies']['information/native']['world_ids']) == 3
        assert len(intent['studies']['family/native']['world_ids']) == 4
        with (target / 'completion-intent.json').open('x') as stream:
            json.dump(intent, stream, indent=2)
        receipt['intent'] = intent
        for kind in ('information', 'family'):
            scalar, native = studies[kind, 'scalar'], studies[kind, 'native']
            assert scalar['body']['manifest'] == native['body']['manifest']
            seen = {}
            for mode in ('scalar', 'native'):
                study = studies[kind, mode]
                suffix = ('native_' if mode == 'native' else '') + kind + '_study'
                view = op('inspect_' + suffix, study_id=study['id'])
                existing = {artifact(i)['body']['world_id']: artifact(i)['body'] for i in view['attempt_artifact_ids']}
                for world in study['body']['manifest']['worlds']:
                    if world['id'] not in existing:
                        assert view['status'] == 'READY' and view['next_world_id'] == world['id']
                        view = op('advance_' + suffix, study_id=study['id'])
                        existing[world['id']] = artifact(view['attempt_artifact_ids'][-1])['body']
                    body = existing[world['id']]
                    assert body['failure'] is None and body['outcome']['state'] in ('VERIFIED', 'INFORMATION_GAP')
                    assert body['world_id'] == world['id'] and len(body['proofs']) == 2
                    assert body['output_blobs']['generate/stream.jsonl.gz'] == body['output_blobs']['replay/expected-stream.jsonl.gz']
                    assert body['scientific_readiness'] is False and body['result']['classification_permitted'] is False
                    print(json.dumps({'kind': kind, 'mode': mode, 'world_id': world['id'],
                                      'state': body['outcome']['state']}), flush=True)
                assert view['status'] == 'COMPLETE' and view['scientific_readiness'] is False
                assert artifact(study['id']) == study
                seen[mode] = existing
                receipt[kind + '_' + mode + '_view'] = view
            uses = 0
            for world in native['body']['manifest']['worlds']:
                left, right = (seen[mode][world['id']] for mode in ('scalar', 'native'))
                assert left['result'] == right['result']
                stream = left['output_blobs']['generate/stream.jsonl.gz']
                assert stream == right['output_blobs']['generate/stream.jsonl.gz']
                engines = right['proofs'][0]['draw_engines']
                uses += sum(value['native'] for value in engines)
                receipt['pairs'].append({'kind': kind, 'world_id': world['id'],
                    'result_sha256': digest(left['result']), 'stream': stream, 'draw_engines': engines,
                    'scalar_settlement': left['settlement'], 'native_settlement': right['settlement']})
            receipt[kind + '_native_engine_uses'] = uses
        assert receipt['information_native_engine_uses'] > 0 and receipt['family_native_engine_uses'] > 0
        receipt['current_qualification'] = op('inspect_native_runtime_qualification', qualification_id=prior['qualification']['id'])
        assert receipt['current_qualification']['status'] == 'CURRENT'
        assert op('verify')['status'] == 'PASS'
        assert footprint(source_bundle()) == intent['source_footprint']
        assert 'numpy' not in sys.modules and '_trf_stationary_native' not in sys.modules
        receipt['controller_numpy_imported'] = False
        receipt['status'] = 'PASS'
    except BaseException as exc:
        receipt['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        raise
    finally:
        broker.close()
        receipt['seconds'] = str(time.monotonic() - started)
        with receipt_path.open('x') as stream:
            json.dump(receipt, stream, indent=2)
        print(json.dumps({k:v for k,v in receipt.items() if k in
            ('status', 'failure', 'seconds', 'information_native_engine_uses', 'family_native_engine_uses')}), flush=True)


if __name__ == '__main__':
    run()
