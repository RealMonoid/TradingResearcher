"""Bounded actual synthetic caller/restore proof; never final calibration."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import time
from zipfile import ZipFile, ZIP_DEFLATED

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'tests')]
from family_run_support import FamilyFixture
from test_information_study import profile
from trading_researcher.coordination import Broker
from trading_researcher.codec import decode, digest
from trading_researcher.evaluation_plans import source_bundle, footprint
from trading_researcher.native_qualification_profile import capture_source
from trading_researcher.storage import restore_bundle


def run(version):
    assert version.isascii() and version.replace('-', '').isalnum()
    target = HERE / version
    target.mkdir(exist_ok=False)
    begun = time.monotonic()
    receipt = {'scope': 'Fixed invented development inputs, real owned qualification and scalar/native reserved callers; no final world/model/market access.'}
    broker = None
    try:
        source = capture_source()
        receipt['source_footprint'] = footprint(source)
        with ZipFile(target / 'source.zip', 'x', ZIP_DEFLATED) as archive:
            for name, raw in source.items():
                archive.writestr(name, raw)
        fixture = FamilyFixture()
        try:
            execution = fixture.execution
            family_plan, family_diagnostic = fixture.plan, fixture.diagnostics
            single_plan = fixture.op('prepare_evaluation_plan', key='native-single-proof',
                compiled_id=execution['body']['compiled_id'], primary_count=1,
                dependence=deepcopy(family_plan['body']['request']['dependence']))
            single_diagnostic = fixture.op('prepare_information_diagnostics', key='native-single-proof',
                plan_id=single_plan['id'], execution_id=execution['id'], lags=[1, 2], limits={'max_seconds': 60})
            backup = target / 'base-backup'
            fixture.op('backup_bundle', destination=str(backup))
            restore_bundle(backup, target / 'registry', fixture.broker.directory / 'operator.key')
        finally:
            fixture.close()
        broker = Broker(target / 'registry')
        def op(operation, **args):
            return broker.call(broker.admin_token, operation, **args)
        inputs = ROOT / '.trf-runtime/native-runtime-2026-11-02'
        raw = inputs / 'canonical-native-runtime.zip'
        manifest = decode((inputs / 'canonical-native-runtime-manifest.json').read_bytes())
        assert hashlib.sha256(raw.read_bytes()).hexdigest() == '8c0458b745399a3bc92f912bb129ea1c6969466a0cad3239d5c361c23746dc21'
        archive_source = op('add_blob_source', path=str(raw), data_class='operations', description='Fixed pinned native proof input')
        runtime = op('retain_native_runtime', key='fixed-native-proof', archive_id=archive_source['id'], manifest=manifest)
        certificate = op('qualify_native_runtime', key='fixed-study-source-proof', runtime_id=runtime['id'])
        receipt['qualification'] = {'id': certificate['id'], 'status': certificate['body']['status'],
                                    'settlement': certificate['body']['settlement'], 'failure': certificate['body']['failure']}
        assert certificate['body']['status'] == 'CERTIFIED', certificate['body']['failure']
        assert op('inspect_native_runtime_qualification', qualification_id=certificate['id'])['status'] == 'CURRENT'
        estimate = {'world_time_rows': 3, 'observed_compute_ms': 1, 'observed_storage_bytes': 1,
                    'qualification': 'Fixed engineering proof estimate; unauthenticated, no performance claim.'}
        cost = op('add_source', data_class='development', body={'schema': 'development-study-cost-estimate/1', **estimate})
        studies = {}
        receipt['attempts'] = []
        for kind, plan, diagnostic in (('information', single_plan, single_diagnostic), ('family', family_plan, family_diagnostic)):
            config = profile()
            config.update(targets=[3], worlds_per_cell=1, seed=8126,
                          cost_estimate={'source_ref': cost['id'], **estimate})
            config['budget'].update(max_compute_ms=360000, attempt_compute_ms=120000,
                max_storage_bytes=2*1024**3, attempt_storage_bytes=256*1024**2, max_attempts=1)
            if kind == 'family':
                config.update(responses=['a', 'b'], patterns=[[0, 0], [0, 1], [1, 1], [2, 2]])
            request = {'plan_id': plan['id'], 'execution_id': execution['id'], 'diagnostics_id': diagnostic['id'], 'profile': config}
            scalar = op('prepare_' + kind + '_study', key='scalar-' + kind, **request)
            native = op('prepare_native_' + kind + '_study', key='native-' + kind,
                        native_qualification_id=certificate['id'], **request)
            assert native['body']['manifest'] == scalar['body']['manifest']
            studies[kind] = native
            observed = []
            for selected, study in (('scalar', scalar), ('native', native)):
                operation = 'advance_' + ('native_' if selected == 'native' else '') + kind + '_study'
                view = op(operation, study_id=study['id'])
                attempt = op('get_artifact', artifact_id=view['attempt_artifact_ids'][-1])
                body = attempt['body']
                receipt['attempts'].append({'kind': kind, 'engine': selected, 'study_id': study['id'],
                    'attempt_id': attempt['id'], 'state': body['outcome']['state'], 'failure': body['failure'],
                    'settlement': body['settlement'], 'draw_engines': [p.get('draw_engines') for p in body['proofs']],
                    'stream_encoding': [p.get('stream_encoding') for p in body['proofs']]})
                assert body['failure'] is None and body['outcome']['state'] in ('VERIFIED', 'INFORMATION_GAP')
                assert len(body['proofs']) == 2 and body['scientific_readiness'] is False
                stream = body['output_blobs']['generate/stream.jsonl.gz']
                assert stream == body['output_blobs']['replay/expected-stream.jsonl.gz']
                observed.append((body['result'], stream))
                if selected == 'native':
                    assert any(item['native'] for item in body['proofs'][0]['draw_engines'])
            assert observed[0] == observed[1], 'Full scalar/native world result or stream differs'
        receipt['backup'] = op('backup_bundle', destination=str(target / 'study-backup'))
        receipt['before_restore'] = {kind: op('inspect_native_' + kind + '_study', study_id=study['id']) for kind, study in studies.items()}
        key = broker.directory / 'operator.key'
        broker.close(); broker = None
        restore_bundle(target / 'study-backup', target / 'restored', key)
        broker = Broker(target / 'restored')
        assert not (broker.directory / 'native-runtime-cache').exists()
        assert op('inspect_native_runtime_qualification', qualification_id=certificate['id'])['status'] == 'STALE'
        before = op('inspect_native_information_study', study_id=studies['information']['id'])
        assert before == receipt['before_restore']['information']
        after = op('advance_native_information_study', study_id=studies['information']['id'])
        body = op('get_artifact', artifact_id=after['attempt_artifact_ids'][-1])['body']
        receipt['restored_attempt'] = {'study_id': studies['information']['id'], 'artifact_id': after['attempt_artifact_ids'][-1],
            'failure': body['failure'], 'settlement': body['settlement'], 'state': body['outcome']['state'],
            'proofs': body['proofs'], 'budget': after['budget']}
        assert body['failure'] is None and len(body['proofs']) == 2
        assert op('get_artifact', artifact_id=studies['information']['id']) == studies['information']
        assert op('get_artifact', artifact_id=certificate['id']) == certificate
        assert op('inspect_native_runtime_qualification', qualification_id=certificate['id'])['status'] == 'CURRENT'
        assert op('verify')['status'] == 'PASS'
        assert 'numpy' not in sys.modules and '_trf_stationary_native' not in sys.modules
        assert footprint(source_bundle()) == {k:v for k,v in receipt['source_footprint'].items() if k.startswith('trading_researcher/')}
        receipt['controller_numpy_imported'] = False
        receipt['status'] = 'PASS'
    except BaseException as exc:
        receipt['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        raise
    finally:
        if broker is not None:
            broker.close()
        receipt['seconds'] = str(time.monotonic() - begun)
        (target / 'receipt.json').write_text(json.dumps(receipt, indent=2))
        print(json.dumps({k:v for k,v in receipt.items() if k not in ('source_footprint','restored_attempt','before_restore')}), flush=True)


if __name__ == '__main__':
    assert len(sys.argv) == 2
    run(sys.argv[1])
