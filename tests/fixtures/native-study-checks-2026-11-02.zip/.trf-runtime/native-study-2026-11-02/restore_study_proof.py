"""One restore-only recovery after retained Windows publication failure."""
import json
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from trading_researcher.coordination import Broker
from trading_researcher.codec import digest
from trading_researcher.evaluation_plans import source_bundle, footprint
from trading_researcher.storage import restore_bundle


def run():
    target = HERE / 'actual-v1'
    path = target / 'restore-recovery-receipt.json'
    assert not path.exists() and not (target / 'restored').exists()
    assert not list(target.glob('restore-pending-*'))
    completion = json.loads((target / 'completion-receipt.json').read_text())
    assert completion['failure']['type'] == 'PermissionError'
    assert completion['family_engine_uses'] == 8
    source = footprint(source_bundle())
    assert source == completion['intent']['source_footprint']
    original = json.loads((target / 'receipt.json').read_text())
    native_id = next(a['study_id'] for a in original['attempts'] if (a['kind'], a['engine']) == ('information', 'native'))
    scalar_id = next(a['study_id'] for a in original['attempts'] if (a['kind'], a['engine']) == ('information', 'scalar'))
    started = time.monotonic()
    receipt = {'purpose': 'Restore existing complete backup once in fresh process; preserve prior failure and every original attempt. No new original world, certificate, seed, profile or budget.'}
    broker = None
    try:
        receipt['restore'] = restore_bundle(target / 'study-backup', target / 'restored', target / 'registry/operator.key')
        broker = Broker(target / 'restored')
        def op(operation, **args):
            return broker.call(broker.admin_token, operation, **args)
        study = op('get_artifact', artifact_id=native_id)
        certificate_id = study['body']['request']['native_qualification_id']
        certificate = op('get_artifact', artifact_id=certificate_id)
        assert not (broker.directory / 'native-runtime-cache').exists()
        assert op('inspect_native_runtime_qualification', qualification_id=certificate_id)['status'] == 'STALE'
        before = op('inspect_native_information_study', study_id=native_id)
        assert before == completion['before_restore']
        scalar_view = op('inspect_information_study', study_id=scalar_id)
        scalar = op('get_artifact', artifact_id=scalar_view['attempt_artifact_ids'][-1])['body']
        after = op('advance_native_information_study', study_id=native_id)
        native = op('get_artifact', artifact_id=after['attempt_artifact_ids'][-1])['body']
        receipt['attempt_id'] = after['attempt_artifact_ids'][-1]
        receipt['settlement'] = native['settlement']
        receipt['failure'] = native['failure']
        assert native['failure'] is None and len(native['proofs']) == 2
        assert native['result'] == scalar['result']
        assert native['output_blobs']['generate/stream.jsonl.gz'] == scalar['output_blobs']['generate/stream.jsonl.gz']
        assert native['output_blobs']['generate/stream.jsonl.gz'] == native['output_blobs']['replay/expected-stream.jsonl.gz']
        receipt['result_sha256'] = digest(native['result'])
        receipt['before'] = before
        receipt['after'] = after
        assert op('get_artifact', artifact_id=native_id) == study
        assert op('get_artifact', artifact_id=certificate_id) == certificate
        assert op('inspect_native_runtime_qualification', qualification_id=certificate_id)['status'] == 'CURRENT'
        assert op('verify')['status'] == 'PASS'
        assert footprint(source_bundle()) == source
        assert 'numpy' not in sys.modules and '_trf_stationary_native' not in sys.modules
        receipt['controller_numpy_imported'] = False
        receipt['status'] = 'PASS'
    except BaseException as exc:
        receipt['error'] = {'type': type(exc).__name__, 'message': str(exc)}
        raise
    finally:
        if broker is not None:
            broker.close()
        receipt['seconds'] = str(time.monotonic() - started)
        with path.open('x') as stream:
            json.dump(receipt, stream, indent=2)
        print(json.dumps({key: value for key, value in receipt.items() if key not in ('before', 'after')}), flush=True)


if __name__ == '__main__':
    run()
