import hashlib, json, pathlib, re, subprocess, sys, time
root=pathlib.Path.cwd()
work=root/'.trf-runtime/outcome-reservations-2026-11-02'
cases={
 'existing-freeze':('test_scientific_freeze_independent.py',25),
 'family-binding':('test_scientific_family_binding_independent.py',7),
 'existing-owned-plan':('test_scientific_freeze.py',3),
 'reservation-caller':('test_outcome_reservation_caller_independent.py',17),
}
label=sys.argv[1]; pattern,expected=cases[label]
pins={'trading_researcher/scientific_freeze.py':'9c9629635ae90561640c5b7f0a285b41e2e38be9dd284e0f7388193f7e4cd55b',
 'trading_researcher/outcome_reservations.py':'ee6e992cabbbbba13f13d568e451d1b5b248dc38bace19a3b2d930dd3f713d3'}
pins['trading_researcher/outcome_reservations.py']='ee6e992cabbbbba13f13d568e451d1b5b248dc38bace19a3b5d4cf6c67468137'
pins['docs/architecture/14_RETAIL_RESEARCH_CONTRACT.md']='e8513ced048dd3c60f30490736e666cadf4d3da0929002b4923a8d70ac31a76d'
def observed(): return {n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in pins}
assert observed()==pins
f=root/'tests'/pattern; test_hash=hashlib.sha256(f.read_bytes()).hexdigest()
command=[sys.executable,'-B','-m','unittest','discover','-s','tests','-p',pattern]
start=time.monotonic(); result=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',errors='replace'); elapsed=time.monotonic()-start
count=re.search(r'Ran (\d+) tests?',result.stderr)
record={'command':command,'exit_code':result.returncode,'seconds':str(elapsed),'expected_distinct_methods':expected,
 'executed_distinct_methods':None if count is None else int(count.group(1)), 'source_sha256':pins,
 'executed_test_sha256':test_hash,'source_unchanged':observed()==pins,
 'test_unchanged':hashlib.sha256(f.read_bytes()).hexdigest()==test_hash,'stdout':result.stdout,'stderr':result.stderr}
(work/(label+'-final-check.json')).write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:record[k] for k in ['exit_code','seconds','executed_distinct_methods','expected_distinct_methods','source_unchanged','test_unchanged']}),flush=True)
if result.returncode: print(result.stderr[-2200:],flush=True)
assert record['source_unchanged'] and record['test_unchanged']
assert record['executed_distinct_methods']==expected
sys.exit(result.returncode)
