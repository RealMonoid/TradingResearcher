"""One fixed approved scalar calibration; observers never renew authority."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import time
import uuid

WORK = Path(__file__).resolve().parent
HOST = WORK / 'host'
PRIMARY = WORK / 'registry'
DEVELOPMENT = '37208f834cf223fc3a94a4aa55ddf620d40c6b5f42bbd956d0936e69d507c9ab'
CALCULATOR = '4251242fe7a807ffe7d3568d7df56efdd91c35359375901e5f32c3c5b9b89558'
ASSESSMENT = '666817e89edc7b8751e7aa77ed330e1754f2886bb42b38563858d97dbd9a0127'
APPROVAL_HASH = '0b0475cab83f5d0c839ee2de9afba67a3b83eb5eb933ca583e251ceead20647a'
OPERATOR_HASH = 'cf51ab733329ddcf02fdd3f4884e4ba25cf2422e8f51d164ee26f3e9aae2d5ef'
KEY = 'scalar-final-2048-20261102-approved-once-v1'
SEED = 2026110227
SELF_HASH = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
sys.path.insert(0, str(HOST))
from trading_researcher.binding import require, write_file
from trading_researcher.codec import Invalid, MAX_BYTES, canonical, decode, digest
from trading_researcher.coordination import Broker
from trading_researcher.evaluation_plans import source_bundle, footprint
from trading_researcher.family_study import count_plan
from trading_researcher.family_study_runs import FamilyCalibrationStudies
from trading_researcher.storage import restore_bundle, _hash_file


def utc():
    return datetime.now(timezone.utc).isoformat()


def _execution_state(flags):
    """Use the current thread's Windows request; change no power-plan setting."""
    import ctypes
    from ctypes import wintypes

    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    operation = kernel.SetThreadExecutionState
    operation.argtypes = [wintypes.DWORD]
    operation.restype = wintypes.DWORD
    return int(operation(flags))


def check_observed_prefix(view):
    """Only deny a forgotten observed identity; never grant from local counters.

    Registry history remains authoritative. Missing observations cannot establish
    unused history, and this check cannot detect loss before observation or loss
    of both stores. A stale restored primary must be reconciled, not replayed.
    """
    path = WORK / 'observations.jsonl'
    if not path.exists():
        return
    try:
        attempts = set(view['attempt_artifact_ids'])
        grants = set(view['continuation_ids'])
        with path.open('r', encoding='utf-8') as stream:
            while raw := stream.readline(MAX_BYTES + 1):
                item = decode(raw)
                require(type(item) is dict and type(item['study_id']) is str and
                        item['study_id'] == view['study_id'], 'Observed study identity differs')
                last = item['last_attempt_id']
                require(last is None or (type(last) is str and last in attempts),
                        'Current Registry has forgotten an observed attempt')
                prior = item['continuation_ids']
                require(type(prior) is list and all(type(value) is str and value in grants for value in prior),
                        'Current Registry has forgotten an observed continuation')
    except (KeyError, TypeError, ValueError) as exc:
        raise Invalid('Malformed or contradicted observed prefix; no automatic recovery reset') from exc


def save(name, value, *, frozen=False):
    path = WORK / name
    raw = (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()
    if frozen:
        if path.exists():
            require(path.read_bytes() == raw, 'Frozen operator record differs: ' + name)
        else:
            with path.open('xb') as stream:
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
    else:
        temporary = path.with_suffix(path.suffix + '.tmp')
        write_file(temporary, raw)
        temporary.replace(path)


def host_and_approval():
    require(PRIMARY.drive.upper() == 'C:' and PRIMARY.is_dir() and
            (PRIMARY / 'registry.sqlite3').is_file() and (PRIMARY / 'operator.key').is_file(),
            'Existing approved C: primary required; never initialize or restore a replacement automatically')
    require(digest(footprint(source_bundle())) == ASSESSMENT, 'Isolated assessment host changed')
    approval_path = HOST / 'docs/reviews/implementation-2026-10-25/calibration-resource-approval-2026-11-02.json'
    raw = approval_path.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == APPROVAL_HASH, 'Exact direct resource approval required')
    approval = decode(raw)
    require(approval['limits'] == {'aggregate_compute_ms':648000000,
        'aggregate_logical_bytes':107374182400,'additional_grants_max':179,
        'attempt_compute_ms':300000,'attempt_storage_bytes':268435456,'max_attempts':1},
        'Resource authority differs')
    require(approval['physical_question']['selected_volume'] == 'C:' and
            approval['physical_question']['minimum_initial_free_bytes'] == 60 * 1024**3,
            'Selected physical target differs')
    operator_path = WORK / 'finite_family.py'
    require(_hash_file(operator_path)[0] == OPERATOR_HASH, 'Qualified consuming operator differs')
    require(_hash_file(Path(__file__))[0] == SELF_HASH, 'Loaded run driver changed')
    spec = importlib.util.spec_from_file_location('approved_scalar_finite_operator', operator_path)
    operator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(operator)
    return operator, approval_path


def request_for(broker):
    development = broker.call(broker.admin_token, 'get_artifact', artifact_id=DEVELOPMENT)
    common = []
    for spec in range(2):
        for pattern, kinds in enumerate((('joint_miscoverage','false_support'),
                ('joint_miscoverage','false_support','detection/response-1'),
                ('joint_miscoverage','boundary_decisive'),
                ('joint_miscoverage','detection/response-0','detection/response-1'))):
            common.extend(f'spec-{spec}/pattern-{pattern}/{kind}' for kind in kinds)
    return {'key':KEY,'development_study_id':DEVELOPMENT,'time_rows':4096,'seed':SEED,
        'budget':{'max_compute_ms':3600000,'max_storage_bytes':4*1024**3,
            'attempt_compute_ms':300000,'attempt_storage_bytes':268435456,'max_attempts':1},
        'cost_estimate':development['body']['request']['profile']['cost_estimate'],
        'applicability':{
            'heavy_tail':{'status':'not_applicable','cohort_ids':[],
                'reason':'This fixed conditional law generates bounded binary responses. It does not represent or qualify heavy-tailed market inputs or market-process adequacy.'},
            'overlap':{'status':'not_applicable','cohort_ids':[],
                'reason':'The fixed law has one-step binary outcomes, not overlapping longer-horizon market labels. Signed serial dependence is included; raw-input dependence and applicability to market claims remain unqualified.'},
            'common_shock':{'status':'included','cohort_ids':sorted(common),
                'reason':'Both frozen signed second-order stress laws use common_share1/2 for the shared-template response family; all20criterion cohorts retain that declared stress. This is not independently qualified market applicability.'}}}


def checked_capsule(broker, study, request):
    body = study['body']
    require(body['request'] == request and body['schema'] == 'family-calibration-input/1',
            'Original owned final request differs')
    require(digest(body['source_footprint']) == CALCULATOR and
            digest(body['assessment_source_footprint']) == ASSESSMENT,
            'Retained calculation and current assessment source bindings differ')
    manifest = body['manifest']
    require(len(manifest['worlds']) == 2048 and manifest['profile']['targets'] == [4096] and
            manifest['profile']['worlds_per_cell'] == 256 and
            manifest['profile']['responses'] == ['a','b'] and
            manifest['profile']['patterns'] == [[0,0],[0,2],[1,1],[2,2]], 'Fixed final inventory differs')
    assigned = manifest['assigned']
    require(assigned['primary_count'] == 2 and assigned['instruments'] == 1 and
            assigned['base_length'] == 8 and assigned['horizon_bars'] == 1 and
            assigned['delta'] == {'numerator':'1','denominator':'20'} and
            assigned['direction'] == 'positive', 'Fixed estimator assignment differs')
    owner = FamilyCalibrationStudies(broker)
    development, _ = owner._development(request)
    require(manifest['profile']['specifications'] == development['body']['manifest']['profile']['specifications'],
            'Original stress specifications changed')
    plan = count_plan(manifest, request['applicability'])
    require(len(plan['cohorts']) == 20 and digest(plan) == body['count_plan_hash'], 'Fixed complete count plan differs')
    owner._study_before_execute(study)
    owner._load_study_source(study)
    return owner


def prepare(broker, operator, approval_path):
    require(shutil.disk_usage(PRIMARY).free >= 60 * 1024**3, 'Initial60GiB capacity unavailable')
    request = request_for(broker)
    save('request.json', request, frozen=True)
    # The existing public owner performs actual complete development, source,
    # count-envelope, applicability and recorded-seed collision admission.
    study = broker.call(broker.admin_token, 'prepare_family_calibration', **request)
    checked_capsule(broker, study, request)
    view = broker.call(broker.admin_token, 'inspect_family_calibration', calibration_id=study['id'])
    check_observed_prefix(view)
    require(view['status'] == 'READY' and not view['attempt_artifact_ids'] and
            not view['continuation_ids'], 'Prepare recovery proof only before the first numerical attempt')
    backup = WORK / 'prepared-backup'
    restored = WORK / 'prepared-restore'
    if not backup.exists():
        require(broker.call(broker.admin_token,'backup_bundle',destination=str(backup))['status']=='PASS',
                'Complete prepared backup failed')
    if not restored.exists():
        require(restore_bundle(backup,restored,PRIMARY/'operator.key')['status']=='PASS',
                'Complete prepared restore failed')
    recovered = None
    try:
        recovered = Broker(restored)
        require(recovered.call(recovered.admin_token,'verify')['status']=='PASS','Restored integrity failed')
        require(recovered.call(recovered.admin_token,'get_artifact',artifact_id=study['id'])==study,
                'Restored final capsule differs')
        require(recovered.call(recovered.admin_token,'inspect_family_calibration',calibration_id=study['id'])==view,
                'Restored zero-attempt inventory or historical charges differ')
        original = broker.call(broker.admin_token,'get_artifact',artifact_id=DEVELOPMENT)
        require(recovered.call(recovered.admin_token,'get_artifact',artifact_id=DEVELOPMENT)==original,
                'Restored original development differs')
    finally:
        if recovered is not None:
            recovered.close()
    proof={'schema':'prepared-family-recovery/1','status':'PASS','calibration_id':study['id'],
        'artifact_hash':digest(study),'initial_attempts':0,'initial_grants':0,
        'backup_manifest':{'path':str((backup/'manifest.json').resolve()),
            'sha256':_hash_file(backup/'manifest.json')[0]},
        'restored_database':{'path':str((restored/'registry.sqlite3').resolve()),
            'sha256':_hash_file(restored/'registry.sqlite3',limit=None)[0]}}
    save('prepared-recovery.json',proof,frozen=True)
    body=study['body']
    binding={'schema':'finite-family-run-binding/1','calibration_id':study['id'],
        'artifact_hash':digest(study),'request_hash':digest(request),'manifest_hash':digest(body['manifest']),
        'approval_path':str(approval_path.resolve()),'approval_sha256':APPROVAL_HASH,
        'assessment_footprint':body['assessment_source_footprint'],
        'calculation_footprint':body['source_footprint'],'runtime_identity':body['runtime_identity'],
        'registry_path':str(PRIMARY.resolve()),'recovery_path':str((WORK/'prepared-recovery.json').resolve()),
        'recovery_sha256':_hash_file(WORK/'prepared-recovery.json')[0],
        'driver_files':{str(Path(__file__).resolve()):SELF_HASH,
                        str((WORK/'finite_family.py').resolve()):OPERATOR_HASH}}
    save('bound-run.json',binding,frozen=True)
    save('prepared-view.json',view,frozen=True)
    return binding,view


def observe(kind, view, started, **details):
    item={'at_utc':utc(),'kind':kind,'pid':os.getpid(),'study_id':view['study_id'],
        'wall_elapsed_ms':int((time.monotonic()-started)*1000),'status':view['status'],
        'recorded_worlds':view['summary']['recorded_worlds'],'attempts':len(view['attempt_artifact_ids']),
        'last_attempt_id':view['attempt_artifact_ids'][-1] if view['attempt_artifact_ids'] else None,
        'charged_compute_ms':view['budget']['charged_compute_ms'],
        'charged_storage_bytes':view['budget']['charged_storage_bytes'],
        'max_compute_ms':view['budget']['max_compute_ms'],'max_storage_bytes':view['budget']['max_storage_bytes'],
        'continuation_ids':view['continuation_ids'],**details}
    with (WORK/'observations.jsonl').open('a',encoding='utf-8') as stream:
        stream.write(json.dumps(item)+'\n');stream.flush();os.fsync(stream.fileno())
    save('latest.json',{'observation':item,'view':view})
    print(json.dumps(item),flush=True)


def terminal_copies(broker, session):
    retained=broker._db.execute('SELECT COALESCE(SUM(size),0) FROM blobs').fetchone()[0]
    retained+=(PRIMARY/'registry.sqlite3').stat().st_size
    require(shutil.disk_usage(PRIMARY).free>=6*1024**3+2*retained,
            'Insufficient space for both complete terminal copies and reserve')
    backup=WORK/('terminal-backup-'+session)
    restored=WORK/('terminal-restore-'+session)
    result=broker.call(broker.admin_token,'backup_bundle',destination=str(backup))
    require(result['status']=='PASS','Complete terminal backup failed')
    recovered=None
    try:
        result=restore_bundle(backup,restored,PRIMARY/'operator.key')
        require(result['status']=='PASS','Complete terminal restore failed')
        recovered=Broker(restored)
        require(recovered.call(recovered.admin_token,'verify')['status']=='PASS','Terminal restore integrity failed')
        binding=decode((WORK/'bound-run.json').read_bytes())
        identity=binding['calibration_id']
        require(recovered.call(recovered.admin_token,'get_artifact',artifact_id=identity)==
                broker.call(broker.admin_token,'get_artifact',artifact_id=identity),'Terminal capsule differs')
        require(recovered.call(recovered.admin_token,'inspect_family_calibration',calibration_id=identity)==
                broker.call(broker.admin_token,'inspect_family_calibration',calibration_id=identity),
                'Terminal history/charges/count interpretation differ')
        return {'status':'PASS','backup':str(backup),'restored':str(restored)}
    finally:
        if recovered is not None:
            recovered.close()


def main():
    require(len(sys.argv)==2 and sys.argv[1] in ('prepare','run'), 'Only fixed prepare/run modes are supported')
    phase=sys.argv[1];started=time.monotonic();session=uuid.uuid4().hex
    broker=None;view=None;original_error=None;power_attempted=False
    terminal={'session':session,'started_at_utc':utc(),'phase':phase,
        'driver_sha256':SELF_HASH,'operator_sha256':OPERATOR_HASH,'scientific_readiness':False,'n_min':None}
    try:
        operator,approval_path=host_and_approval()
        power_attempted=True
        require(bool(_execution_state(0x80000001)), 'Windows execution-state acquisition failed')
        broker=Broker(PRIMARY)
        if phase=='prepare':
            if (WORK/'stop-after-current-world.request').exists():
                terminal['status']='STOPPED_AT_SAFE_BOUNDARY_BY_OPERATOR'
                return
            binding,view=prepare(broker,operator,approval_path)
            terminal['status']='PREPARED_AND_FULLY_RESTORED_ZERO_ATTEMPTS'
        else:
            binding=decode((WORK/'bound-run.json').read_bytes())
            request=decode((WORK/'request.json').read_bytes())
            require(request==request_for(broker),'Original fixed request changed')
            require(binding['approval_sha256']==APPROVAL_HASH and
                    binding['driver_files'].get(str(Path(__file__).resolve()))==SELF_HASH and
                    binding['driver_files'].get(str((WORK/'finite_family.py').resolve()))==OPERATOR_HASH,
                    'Original sealed driver/approval binding differs')
            study=broker.call(broker.admin_token,'get_artifact',artifact_id=binding['calibration_id'])
            checked_capsule(broker,study,request)
            view=broker.call(broker.admin_token,'inspect_family_calibration',calibration_id=study['id'])
            check_observed_prefix(view)
            observe('started_or_same_series_resumed',view,started)
            for _ in range(2048+179+1):
                check_observed_prefix(view)
                if (WORK/'stop-after-current-world.request').exists():
                    terminal['status']='STOPPED_AT_SAFE_BOUNDARY_BY_OPERATOR'
                    break
                result=operator.consume_next(broker,binding)
                view=result['view']
                observe('complete' if result['request'] is None else result['request']['op'],
                        view,started,result_id=result['result_id'])
                if result['request'] is None:
                    terminal['status']='COMPLETE_FIXED_INVENTORY_COUNTS_ONLY'
                    break
            else:
                raise RuntimeError('Finite operator action bound exhausted; no renewed authority')
        terminal['view']=view
    except BaseException as exc:
        original_error=exc
        terminal.update(status='STOPPED_RETAINED_STATE',failure_type=type(exc).__name__,failure=str(exc)[:2000])
        if broker is not None and (WORK/'bound-run.json').is_file():
            try:
                identity=decode((WORK/'bound-run.json').read_bytes())['calibration_id']
                view=broker.call(broker.admin_token,'inspect_family_calibration',calibration_id=identity)
                terminal['view']=view
            except BaseException as diagnostic:
                terminal['inspection_failure']=type(diagnostic).__name__+': '+str(diagnostic)[:1000]
        raise
    finally:
        if broker is not None:
            if phase=='run' and view is not None:
                try:
                    terminal['complete_terminal_copies']=terminal_copies(broker,session)
                except BaseException as backup_error:
                    terminal['terminal_copy_failure']=type(backup_error).__name__+': '+str(backup_error)[:1500]
            try:
                broker.close()
            except BaseException as close_error:
                terminal['close_failure']=type(close_error).__name__+': '+str(close_error)[:1000]
        if power_attempted:
            try:
                require(bool(_execution_state(0x80000000)), 'Windows execution-state release failed')
            except BaseException as power_error:
                terminal['power_clear_failure']=type(power_error).__name__+': '+str(power_error)[:1000]
        operational_failure=any(key in terminal for key in
            ('terminal_copy_failure','close_failure','power_clear_failure'))
        if operational_failure:
            terminal['count_status_before_operational_failure']=terminal.get('status')
            terminal['status']='STOPPED_OPERATIONAL_CLOSEOUT_FAILED'
        terminal['finished_at_utc']=utc();terminal['wall_seconds']=time.monotonic()-started
        save('terminal-'+session+'.json',terminal,frozen=True)
        print(json.dumps({k:v for k,v in terminal.items() if k!='view'}),flush=True)
        if operational_failure and original_error is None:
            raise RuntimeError('Operational closeout failed; retain the same series and repair without rerunning worlds')


if __name__=='__main__':
    main()
