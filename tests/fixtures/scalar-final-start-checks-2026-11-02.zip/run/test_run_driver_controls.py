"""Work-item driver controls with no Registry, numerical or Win32 operations.

Import loads pinned host definitions only. Every main/prepare invocation below
uses a fake Broker, fake consumer, file-only owned TemporaryDirectory, and a
mocked _execution_state function. These are orchestration and observer-denial
cases; the genuine consumer/Registry qualification is a separate retained suite.
"""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, call, patch


DRIVER_FILE = Path(__file__).with_name('run_once.py')
spec = importlib.util.spec_from_file_location('fixed_scalar_driver_control_cases', DRIVER_FILE)
driver = importlib.util.module_from_spec(spec)
saved_path = list(sys.path)
try:
    spec.loader.exec_module(driver)
finally:
    sys.path[:] = saved_path

from trading_researcher.codec import Invalid


STUDY = 'a' * 64
ATTEMPT = 'b' * 64
GRANT = 'c' * 64
ACQUIRE = 0x80000001
CLEAR = 0x80000000


def view(*, attempts=(), grants=(), status='READY'):
    return {'study_id': STUDY, 'status': status,
        'attempt_artifact_ids': list(attempts), 'continuation_ids': list(grants),
        'summary': {'recorded_worlds': len(attempts), 'complete': status == 'COMPLETE'},
        'budget': {'charged_compute_ms': 17 * len(attempts),
            'charged_storage_bytes': 1234 + len(attempts) * 1048576,
            'max_compute_ms': 3600000, 'max_storage_bytes': 4294967296},
        'scientific_readiness': False, 'n_min': None}


def observation(*, study=STUDY, last=None, grants=()):
    return {'study_id': study, 'last_attempt_id': last, 'continuation_ids': list(grants)}


class ObservedPrefixIndependentTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        work = patch.object(driver, 'WORK', self.root)
        work.start()
        self.addCleanup(work.stop)
        self.path = self.root / 'observations.jsonl'

    def write_records(self, records):
        self.path.write_text(''.join(json.dumps(record) + '\n' for record in records), encoding='utf-8')

    def test_missing_observation_file_does_not_infer_or_override_owned_history(self):
        current = view(attempts=[ATTEMPT], grants=[GRANT])
        retained = deepcopy(current)
        driver.check_observed_prefix(current)
        self.assertEqual(retained, current)
        self.assertFalse(self.path.exists(), 'Checking must not manufacture an observer history')

    def test_honest_membership_prefix_ignores_observer_counts_status_and_allowance(self):
        current = view(attempts=[ATTEMPT, 'd' * 64], grants=[GRANT])
        records = [observation(), observation(last=ATTEMPT, grants=[GRANT])]
        records[-1].update(status='COMPLETE', recorded_worlds=10**9, attempts=-100,
            charged_compute_ms=-1, charged_storage_bytes=-1,
            max_compute_ms=10**30, max_storage_bytes=10**30)
        self.write_records(records)
        retained, raw = deepcopy(current), self.path.read_bytes()
        driver.check_observed_prefix(current)
        self.assertEqual(retained, current)
        self.assertEqual(raw, self.path.read_bytes())

    def test_old_observed_attempt_or_grant_cannot_be_forgotten_by_prepared_zero_restore(self):
        current = view()
        for record in (observation(last=ATTEMPT), observation(grants=[GRANT]),
                       observation(study='f' * 64)):
            self.write_records([observation(), record])
            with self.subTest(record=record), self.assertRaises(Invalid):
                driver.check_observed_prefix(current)
        self.assertEqual(view(), current)

    def test_malformed_json_nonobjects_missing_membership_keys_and_field_types_deny(self):
        records = [None, [], 'text', {}, {'study_id': STUDY},
            {'study_id': STUDY, 'last_attempt_id': None},
            {'last_attempt_id': None, 'continuation_ids': []},
            {**observation(), 'last_attempt_id': False},
            {**observation(), 'last_attempt_id': []},
            {**observation(), 'continuation_ids': None},
            {**observation(), 'continuation_ids': GRANT},
            {**observation(), 'continuation_ids': [True]},
            {**observation(), 'study_id': None}]
        for record in records:
            self.write_records([record])
            with self.subTest(record=record), self.assertRaises(Invalid):
                driver.check_observed_prefix(view())
        for raw in ('not json\n', '{"study_id":\n', '\n'):
            self.path.write_text(raw, encoding='utf-8')
            with self.subTest(raw=raw), self.assertRaises(Invalid):
                driver.check_observed_prefix(view())


class FakeBroker:
    def __init__(self):
        self.admin_token = 'synthetic-operator-only'
        self.current = view()
        self.study = {'id': STUDY, 'body': {'scope': 'Orchestration fixture, no calibration'}}
        self.operations = []
        self.close_error = None
        self.closed = 0

    def call(self, token, operation, **args):
        if token != self.admin_token:
            raise AssertionError('Unexpected fake authentication')
        self.operations.append((operation, deepcopy(args)))
        if operation in ('get_artifact', 'prepare_family_calibration'):
            return deepcopy(self.study)
        if operation == 'inspect_family_calibration':
            return deepcopy(self.current)
        raise AssertionError('Unexpected real-like operation in driver control fixture: ' + operation)

    def close(self):
        self.closed += 1
        if self.close_error is not None:
            raise self.close_error


class RunDriverControlsIndependentTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.primary = self.root / 'fake-registry-no-database'
        self.broker = FakeBroker()
        self.broker_factory = Mock(return_value=self.broker)
        self.consumer = Mock(side_effect=self.complete)
        self.operator = SimpleNamespace(consume_next=self.consumer)
        self.power = Mock(side_effect=lambda flags: flags)
        self.copies = Mock(return_value={'status': 'PASS', 'scope': 'Fake closeout, no file copies'})
        self.request = {'scope': 'Synthetic fixed request; never submitted to a real Registry'}
        self.binding = {'calibration_id': STUDY, 'approval_sha256': driver.APPROVAL_HASH,
            'driver_files': {str(Path(driver.__file__).resolve()): driver.SELF_HASH,
                             str((self.root / 'finite_family.py').resolve()): driver.OPERATOR_HASH}}
        self.prepare = Mock(return_value=(self.binding, deepcopy(self.broker.current)))
        contexts = [patch.object(driver, 'WORK', self.root),
            patch.object(driver, 'PRIMARY', self.primary),
            patch.object(driver, 'Broker', self.broker_factory),
            patch.object(driver, 'host_and_approval', return_value=(self.operator, self.root / 'approval.json')),
            patch.object(driver, 'request_for', return_value=deepcopy(self.request)),
            patch.object(driver, 'checked_capsule', return_value=None),
            patch.object(driver, 'terminal_copies', self.copies),
            patch.object(driver, '_execution_state', self.power),
            patch('builtins.print')]
        for context in contexts:
            context.start()
            self.addCleanup(context.stop)
        driver.save('request.json', self.request, frozen=True)
        driver.save('bound-run.json', self.binding, frozen=True)

    def complete(self, broker, binding):
        self.assertIs(broker, self.broker)
        self.assertEqual(self.binding, binding)
        broker.current = view(attempts=[ATTEMPT], status='COMPLETE')
        return {'request': None, 'view': deepcopy(broker.current), 'result_id': None}

    def main(self, phase='run', *, fake_prepare=True):
        with patch.object(sys, 'argv', [str(DRIVER_FILE), phase]):
            if phase == 'prepare' and fake_prepare:
                with patch.object(driver, 'prepare', self.prepare):
                    return driver.main()
            return driver.main()

    def terminal(self):
        files = list(self.root.glob('terminal-*.json'))
        self.assertEqual(1, len(files), 'Every attempted session must retain one complete terminal receipt')
        return json.loads(files[0].read_text(encoding='utf-8'))

    def assert_power_released(self):
        self.assertEqual([call(ACQUIRE), call(CLEAR)], self.power.call_args_list)

    def test_run_holds_thread_execution_state_and_always_clears(self):
        self.main()
        self.assert_power_released()
        self.assertEqual(1, self.consumer.call_count)
        self.assertEqual(1, self.broker.closed)
        terminal = self.terminal()
        self.assertEqual('COMPLETE_FIXED_INVENTORY_COUNTS_ONLY', terminal['status'])
        self.assertIs(terminal['scientific_readiness'], False)
        self.assertIsNone(terminal['n_min'])

    def test_prepare_holds_thread_execution_state_and_clears_without_any_consume(self):
        self.main('prepare')
        self.assert_power_released()
        self.consumer.assert_not_called()
        self.prepare.assert_called_once()
        self.copies.assert_not_called()
        self.assertEqual(1, self.broker.closed)
        self.assertEqual('PREPARED_AND_FULLY_RESTORED_ZERO_ATTEMPTS', self.terminal()['status'])

    def test_zero_execution_state_acquisition_denies_before_broker_and_still_clears(self):
        self.power.side_effect = lambda flags: 0 if flags == ACQUIRE else CLEAR
        with self.assertRaises(Invalid):
            self.main()
        self.broker_factory.assert_not_called()
        self.consumer.assert_not_called()
        self.assertEqual(0, self.broker.closed)
        self.assert_power_released()
        self.assertEqual('STOPPED_RETAINED_STATE', self.terminal()['status'])

    def test_raised_execution_state_acquisition_still_clears_before_returning_original_error(self):
        original = OSError('Synthetic Win32 acquisition error; no real OS call')

        def fail_acquire(flags):
            if flags == ACQUIRE:
                raise original
            return CLEAR

        self.power.side_effect = fail_acquire
        with self.assertRaises(OSError) as raised:
            self.main()
        self.assertIs(original, raised.exception)
        self.broker_factory.assert_not_called()
        self.consumer.assert_not_called()
        self.assert_power_released()
        self.assertEqual('STOPPED_RETAINED_STATE', self.terminal()['status'])

    def test_host_auth_failure_before_power_attempt_never_calls_windows_or_broker(self):
        original = ValueError('Synthetic approval/source rejection')
        with patch.object(driver, 'host_and_approval', side_effect=original):
            with self.assertRaises(ValueError) as raised:
                self.main()
        self.assertIs(original, raised.exception)
        self.power.assert_not_called()
        self.broker_factory.assert_not_called()
        self.consumer.assert_not_called()
        self.assertEqual('STOPPED_RETAINED_STATE', self.terminal()['status'])

    def test_terminal_copy_failure_changes_exit_status_preserves_counts_and_writes_receipt(self):
        self.copies.side_effect = OSError('Synthetic complete terminal backup failure')
        with self.assertRaises(RuntimeError):
            self.main()
        terminal = self.terminal()
        self.assertEqual('STOPPED_OPERATIONAL_CLOSEOUT_FAILED', terminal['status'])
        self.assertEqual('COMPLETE_FIXED_INVENTORY_COUNTS_ONLY',
                         terminal['count_status_before_operational_failure'])
        self.assertIn('Synthetic complete terminal backup failure', terminal['terminal_copy_failure'])
        self.assertEqual('COMPLETE', terminal['view']['status'])
        self.assertEqual(1, self.broker.closed)
        self.assert_power_released()

    def test_broker_close_failure_is_nonzero_and_does_not_erase_numerical_status(self):
        self.broker.close_error = OSError('Synthetic writer close failure')
        with self.assertRaises(RuntimeError):
            self.main()
        terminal = self.terminal()
        self.assertEqual('STOPPED_OPERATIONAL_CLOSEOUT_FAILED', terminal['status'])
        self.assertEqual('COMPLETE_FIXED_INVENTORY_COUNTS_ONLY',
                         terminal['count_status_before_operational_failure'])
        self.assertIn('Synthetic writer close failure', terminal['close_failure'])
        self.assertEqual(1, self.broker.closed)
        self.assert_power_released()

    def test_zero_power_clear_is_nonzero_after_close_and_complete_receipt(self):
        self.power.side_effect = lambda flags: ACQUIRE if flags == ACQUIRE else 0
        with self.assertRaises(RuntimeError):
            self.main()
        terminal = self.terminal()
        self.assertEqual('STOPPED_OPERATIONAL_CLOSEOUT_FAILED', terminal['status'])
        self.assertEqual('COMPLETE_FIXED_INVENTORY_COUNTS_ONLY',
                         terminal['count_status_before_operational_failure'])
        self.assertEqual(1, self.broker.closed)
        self.assert_power_released()

    def test_original_exception_survives_multiple_closeout_failures_without_retry(self):
        original = ValueError('Original synthetic consuming failure')
        self.consumer.side_effect = original
        self.copies.side_effect = OSError('Synthetic backup failure after original error')
        self.broker.close_error = OSError('Synthetic close failure after original error')
        self.power.side_effect = lambda flags: ACQUIRE if flags == ACQUIRE else 0
        with self.assertRaises(ValueError) as raised:
            self.main()
        self.assertIs(original, raised.exception)
        self.assertEqual(1, self.consumer.call_count)
        terminal = self.terminal()
        self.assertEqual('STOPPED_OPERATIONAL_CLOSEOUT_FAILED', terminal['status'])
        self.assertEqual('ValueError', terminal['failure_type'])
        self.assertEqual(str(original), terminal['failure'])
        self.assertIn('terminal_copy_failure', terminal)
        self.assertIn('close_failure', terminal)
        self.assert_power_released()

    def test_observed_old_attempt_denies_before_start_observation_or_consume(self):
        raw = (json.dumps(observation(last=ATTEMPT)) + '\n').encode()
        path = self.root / 'observations.jsonl'
        path.write_bytes(raw)
        with self.assertRaises(Invalid):
            self.main()
        self.consumer.assert_not_called()
        self.assertEqual(raw, path.read_bytes())
        self.assertEqual(view(), self.broker.current)
        self.assertEqual('STOPPED_RETAINED_STATE', self.terminal()['status'])
        self.assert_power_released()

    def test_prepare_observed_old_grant_denies_before_any_backup_or_recovery_proof(self):
        path = self.root / 'observations.jsonl'
        path.write_text(json.dumps(observation(grants=[GRANT])) + '\n', encoding='utf-8')
        with patch.object(driver.shutil, 'disk_usage', return_value=SimpleNamespace(free=1 << 50)):
            with self.assertRaises(Invalid):
                self.main('prepare', fake_prepare=False)
        self.consumer.assert_not_called()
        self.assertFalse((self.root / 'prepared-recovery.json').exists())
        self.assertEqual(1, self.broker_factory.call_count)
        self.assertNotIn('backup_bundle', [operation for operation, _ in self.broker.operations])
        self.assert_power_released()

    def test_new_contradictory_observer_after_one_action_denies_before_next_consume(self):
        def first_action(broker, binding):
            if self.consumer.call_count != 1:
                raise AssertionError('Observer-prefix contradiction did not fence the next action')
            broker.current = view(attempts=[ATTEMPT], status='RESOURCE_STOP')
            with (self.root / 'observations.jsonl').open('a', encoding='utf-8') as stream:
                stream.write(json.dumps(observation(last='f' * 64)) + '\n')
            return {'request': {'op': 'advance_family_calibration'},
                    'view': deepcopy(broker.current), 'result_id': ATTEMPT}

        self.consumer.side_effect = first_action
        with self.assertRaises(Invalid):
            self.main()
        self.assertEqual(1, self.consumer.call_count)
        terminal = self.terminal()
        self.assertEqual('STOPPED_RETAINED_STATE', terminal['status'])
        self.assertEqual([ATTEMPT], terminal['view']['attempt_artifact_ids'])
        self.assertEqual([], terminal['view']['continuation_ids'])
        self.assert_power_released()

    def test_graceful_stop_sentinel_keeps_same_series_and_dispatches_no_new_action(self):
        sentinel = self.root / 'stop-after-current-world.request'
        sentinel.write_text('Operator pause at the next safe boundary.\n', encoding='utf-8')
        binding = (self.root / 'bound-run.json').read_bytes()
        self.main()
        self.consumer.assert_not_called()
        self.assertEqual('STOPPED_AT_SAFE_BOUNDARY_BY_OPERATOR', self.terminal()['status'])
        self.assertEqual(view(), self.broker.current)
        self.assertTrue(sentinel.exists(), 'Only an explicit operator resume removes the stop request')
        self.assertEqual(binding, (self.root / 'bound-run.json').read_bytes())
        self.assert_power_released()

    def test_new_sentinel_after_one_action_stops_before_the_next_consume(self):
        def one_action(broker, binding):
            if self.consumer.call_count != 1:
                raise AssertionError('Driver dispatched after the requested safe boundary')
            broker.current = view(attempts=[ATTEMPT], status='RESOURCE_STOP')
            (self.root / 'stop-after-current-world.request').write_text('pause\n', encoding='utf-8')
            return {'request': {'op': 'advance_family_calibration'},
                    'view': deepcopy(broker.current), 'result_id': ATTEMPT}

        self.consumer.side_effect = one_action
        self.main()
        self.assertEqual(1, self.consumer.call_count)
        terminal = self.terminal()
        self.assertEqual('STOPPED_AT_SAFE_BOUNDARY_BY_OPERATOR', terminal['status'])
        self.assertEqual([ATTEMPT], terminal['view']['attempt_artifact_ids'])
        self.assertEqual([], terminal['view']['continuation_ids'])
        self.assert_power_released()


if __name__ == '__main__':
    unittest.main()
