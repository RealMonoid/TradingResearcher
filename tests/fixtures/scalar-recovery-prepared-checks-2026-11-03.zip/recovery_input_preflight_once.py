"""Construction-only intended-use inspection; never prepares or runs a world."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import sys
import time

REPO = Path(r'C:\Users\monoi\Documents\ChatGPT\Trading Research Framework')
WORK = REPO / '.trf-runtime/scalar-final-calibration-2026-11-02'
HOST = WORK / 'recovery-host'
sys.path.insert(0, str(HOST))
from tools.calibration import scalar_recovery_run as driver
from trading_researcher.calibration_recovery import CalibrationRecovery, TERMS
from trading_researcher.coordination import Broker
from trading_researcher.codec import digest
from trading_researcher.evaluation_plans import footprint


def inventory(db):
    return {table: db.execute('SELECT COUNT(*) FROM ' + table).fetchone()[0]
            for table in ('artifacts', 'events', 'blobs')}


started = datetime.now(timezone.utc).isoformat()
clock = time.perf_counter()
broker = None
record = {'schema': 'actual-scalar-recovery-input-preflight/1',
    'started_at_utc': started, 'phase': 'METADATA_ONLY_BEFORE_PREPARE',
    'actual_numerical_attempts': 0, 'scientific_readiness': False, 'n_min': None}
try:
    # Explicit URI mode is required; omission failed before opening any DB.
    ro = sqlite3.connect((WORK / 'registry/registry.sqlite3').as_uri() + '?mode=ro', uri=True)
    before = inventory(ro)
    ro.close()
    authority = driver.host_and_authority()
    broker = Broker(WORK / 'registry')
    owner = CalibrationRecovery(broker, authority)
    approvals = owner._approval_bytes()
    original = owner._original(approvals, capture=True)
    study = original['study']
    body = study['body']
    budget = original['budget']
    controller = footprint(original['controller'])
    assert digest(controller) == driver.CONTROLLER
    assert digest(study) == '1326e62710c575a4d90f94ddbc158d032b3788379c524aa06662f9082d1db768'
    states = {key: sum(a['body']['outcome']['state'] == key for a in original['attempts'])
              for key in ('VERIFIED', 'INFORMATION_GAP', 'MODEL_GAP', 'TECHNICAL_FAILURE')}
    assert states == {'VERIFIED': 19, 'INFORMATION_GAP': 0, 'MODEL_GAP': 0, 'TECHNICAL_FAILURE': 1}
    assert len(original['history'].grants) == 1
    assert not broker._db.execute("SELECT 1 FROM artifacts WHERE "
        "json_extract(envelope,'$.body.schema') LIKE 'calibration-recovery-%' LIMIT 1").fetchone()
    fee = 2 * (sum(map(len, original['controller'].values()))
               + sum(map(len, original['assessment'].values()))
               + sum(map(len, approvals.values()))) + 3 * 1048576
    assert budget['charged_storage_bytes'] + fee <= budget['max_storage_bytes'] <= TERMS['aggregate_logical_bytes']
    assert budget['max_compute_ms'] <= TERMS['aggregate_compute_ms']
    assert len(body['manifest']['worlds']) == 2048
    committed = broker._db.execute('SELECT COALESCE(SUM(size),0) FROM blobs').fetchone()[0]
    committed += (WORK / 'registry/registry.sqlite3').stat().st_size
    remaining = 2048 - states['VERIFIED'] - states['INFORMATION_GAP']
    required = 6 * 1024**3 + 2 * committed + 3 * remaining * 7525747
    free = shutil.disk_usage(WORK / 'registry').free
    assert remaining == 2029 and free >= max(60 * 1024**3, required)
    hashes = {path.relative_to(HOST).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
              for path in (HOST / 'tools/calibration/scalar_recovery_run.py',
                           HOST / 'tools/calibration/finite_family_recovery.py',
                           HOST / 'tools/calibration/finite_family.py')}
    pin = {'schema': 'scalar-recovery-host-source-pin/1',
        'git_commit': 'ff0fc34f120013d8254ae44ee532deed890c7208', 'host': str(HOST),
        'controller_footprint_sha256': digest(controller), 'source_files': controller,
        'driver_files': hashes, 'approval_sha256': authority['approval_sha256'],
        'original_approval_sha256': authority['original_approval_sha256'],
        'scope': 'Checked construction inputs; no scientific admission or host runtime certificate.'}
    (WORK / 'recovery-host-source-pin.json').write_text(json.dumps(pin, indent=2) + '\n', encoding='utf-8')
    record.update(status='PASS_BEFORE_PREPARE_NO_NEW_WORLD', authority_binding=authority,
        study_id=study['id'], artifact_hash=digest(study), original_checkpoint=original['history'].checkpoint,
        original_attempt_ids=[a['id'] for a in original['attempts']],
        original_continuation_ids=[a['id'] for a in original['history'].grants], states=states, budget=budget,
        setup_storage_bytes=fee, world_inventory_sha256=digest(body['manifest']['worlds']),
        planned_worlds=2048, remaining_executions_including_named_retry=remaining,
        count_plan_hash=body['count_plan_hash'], request_hash=digest(body['request']),
        manifest_hash=digest(body['manifest']), recipe_hash=body['manifest']['recipe_hash'],
        case_blob=body['payload']['case_blob'], calculation_source_files=len(body['source_footprint']),
        calculation_source_footprint_sha256=digest(body['source_footprint']),
        old_assessment_source_files=len(original['assessment']),
        old_assessment_bytes=sum(map(len, original['assessment'].values())),
        controller_source_files=len(controller), controller_source_bytes=sum(map(len, original['controller'].values())),
        controller_footprint_sha256=digest(controller), failed_generation_request_hash=original['generation']['request_hash'],
        failed_generation_stream=original['generation']['stream_blob'],
        failed_generation_result_hash=digest(original['generation']['result']),
        physical={'free_bytes': free, 'committed_primary_bytes': committed,
                  'required_free_bytes': required, 'minimum_initial_free_bytes': 60 * 1024**3},
        inventory_before_broker=before, inventory_after_preflight=inventory(broker._db),
        host_source_pin_sha256=hashlib.sha256((WORK / 'recovery-host-source-pin.json').read_bytes()).hexdigest(),
        helper_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        source_and_input_checks='Existing owner methods unpatched; no recovery preparation, continuation or numerical transport. Broker startup is not claimed byte-read-only.')
except BaseException as exc:
    record.update(status='FAIL_BEFORE_PREPARE', failure_type=type(exc).__name__, failure=str(exc))
    raise
finally:
    if broker is not None:
        broker.close()
    record.update(finished_at_utc=datetime.now(timezone.utc).isoformat(), seconds=time.perf_counter() - clock)
    (WORK / 'recovery-actual-input-preflight.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: record[key] for key in ('status', 'phase', 'actual_numerical_attempts', 'seconds')}))
