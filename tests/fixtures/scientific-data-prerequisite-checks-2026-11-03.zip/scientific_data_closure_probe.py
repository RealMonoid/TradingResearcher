"""One genuine synthetic fixture: metadata sizes only, no scientific admission."""
from contextlib import ExitStack
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time
from unittest.mock import patch

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
sys.path.insert(1, str(ROOT))
import test_protected_plan_binding as support
from trading_researcher import data_use
from trading_researcher.evaluation_plans import source_bundle, footprint
from trading_researcher.outcome_reservations import reservation_for_plans

OUTPUT = WORK / 'scientific-data-closure-measurement.json'
MAX_METADATA = 16 * 1024 * 1024
MAX_NODES = 4096
MAX_ENVELOPE = 1024 * 1024


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')


def sha(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def persist(report):
    OUTPUT.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')


def announce(phase, **details):
    print(json.dumps({'phase': phase, **details}), flush=True)


def metadata_guards(broker):
    stack = ExitStack()
    for name in ('_load_reference_data', '_scan_data'):
        stack.enter_context(patch.object(broker, name, side_effect=AssertionError('Metadata measurement expanded rows')))
    for name in ('trading_researcher.expressions.ReferenceEngine._calculate',
                 'trading_researcher.outcomes.materialize_reference',
                 'trading_researcher.binding.run_child',
                 'trading_researcher.evaluation_plans.run_plan_child',
                 'trading_researcher.features.run_validation',
                 'trading_researcher.certification.run_reference_validation',
                 'trading_researcher.binance_normalize._run_child'):
        stack.enter_context(patch(name, side_effect=AssertionError('Metadata measurement calculated/replayed')))
    return stack


def traverse(broker, roots):
    pending, artifacts, exposure, blobs, edges = list(roots), {}, set(roots), set(), {}
    total, largest, schema_counts = 0, (0, None), {}
    while pending:
        identity = pending.pop()
        if identity in artifacts:
            continue
        if len(artifacts) >= MAX_NODES:
            raise RuntimeError('Probe metadata node bound reached; no truncated closure will be reported')
        artifact = broker._artifact(identity)
        envelope = {key: value for key, value in artifact.items() if key != 'id'}
        size = len(encoded(envelope))
        total += size
        if total > MAX_METADATA:
            raise RuntimeError('Probe16MiB metadata bound reached; no truncated closure will be reported')
        if size > largest[0]:
            largest = size, identity
        artifacts[identity] = artifact
        schema = artifact['body'].get('schema', '<untyped>') if isinstance(artifact['body'], dict) else '<nonobject>'
        schema_counts[schema] = schema_counts.get(schema, 0) + 1
        exposure.update(artifact['exposure'])
        blobs.update(artifact.get('blob_refs', []))
        children = set(artifact['source_refs'])
        technical = broker._technical_dependencies(artifact)
        if technical is not None:
            children.update(technical)
        for ref in artifact['exposure']:
            if broker._db.execute('SELECT 1 FROM artifacts WHERE id=?', (ref,)).fetchone():
                children.add(ref)
        edges[identity] = children
        pending.extend(children)
    exposure.update(artifacts)
    registered = {}
    for identity in blobs:
        row = broker._db.execute('SELECT size FROM blobs WHERE sha256=?', (identity,)).fetchone()
        if row is None:
            raise RuntimeError('Transitive committed blob metadata is missing')
        registered[identity] = row[0]
    return {'artifacts': artifacts, 'exposure': exposure, 'blobs': blobs, 'edges': edges,
            'envelope_sum': total, 'largest': largest, 'schema_counts': schema_counts,
            'registered_blob_bytes': sum(registered.values())}


def envelope(schema, body, refs, exposure, blobs=()):
    return {'version': 'local-artifact/1', 'creator': 'controller', 'origin': 'controller',
            'data_class': 'assessment', 'source_refs': sorted(set(refs)),
            'exposure': sorted(set(exposure)), 'blob_refs': sorted(set(blobs)),
            'authority': 'SIZE_MODEL_ONLY_NO_ALLOCATION_OR_SCIENTIFIC_AUTHORITY',
            'body': {'schema': schema, **body}}


def measure(broker, request, plans, compiled, assessments):
    roots = [request[key] for key in ('campaign_id', 'selection_record_ref', 'reservation_spec_ref')]
    roots.extend(request['plan_ids'])
    with metadata_guards(broker):
        graph = traverse(broker, roots)
        reservation = reservation_for_plans(broker, broker._binding_owner(broker.admin_token), request['plan_ids'])
        observations = [broker._inspect_evaluation_plan(broker._binding_owner(broker.admin_token), p['id']) for p in plans]
    all_ids, exp, blob_ids = sorted(graph['artifacts']), sorted(graph['exposure']), sorted(graph['blobs'])
    targets = {ref for children in graph['edges'].values() for ref in children}
    direct = sorted(set(roots) | (set(all_ids) - targets))
    with metadata_guards(broker):
        repeated = traverse(broker, direct)
    assert set(repeated['artifacts']) == set(all_ids)
    assert repeated['exposure'] == set(exp) and repeated['blobs'] == set(blob_ids)
    index = {'schema': 'PROPOSED-scientific-freeze-closure/2',
             'artifact_ids': all_ids, 'exposure_ids': exp, 'blob_ids': blob_ids,
             'counts': {'artifacts': len(all_ids), 'exposure': len(exp), 'blobs': len(blob_ids)},
             'digests': {'artifacts': sha(all_ids), 'exposure': sha(exp), 'blobs': sha(blob_ids)},
             'direct_roots': direct}
    files = plans[0]['body']['source_files']
    source_hashes = plans[0]['body']['source_footprint']
    own_blobs = sorted({descriptor['sha256'] for descriptor in files.values()})
    # These are serialized size models only, never Registry writes or a host
    # qualification. Actual findings/observations are retained without pruning.
    admission = {'qualification': 'SIZE_MODEL_ONLY_NOT_SCIENTIFIC_ADMISSION',
                 'plan_observations': observations, 'outcome_reservation': reservation,
                 'data_findings_size_model': [a['body']['findings'] for a in assessments]}
    capsule = envelope('PROPOSED-scientific-freeze-input/2',
        {'request': request, 'created_at': 0, 'checker_sha256': SOURCE_PIN,
         'source_files': files, 'source_footprint': source_hashes,
         'runtime_identity': compiled[0]['body']['environment']['identity'],
         'closure_index': index, 'scientific_readiness': False, 'frozen': False, 'allocation_reserved': False},
        direct, exp, own_blobs)
    capsule_id = sha(capsule)
    attempt = envelope('PROPOSED-scientific-freeze-attempt/2',
        {'input_id': capsule_id, 'status': 'ADMISSION_GAP', 'admission': admission,
         'closure_index_hash': sha(index), 'scientific_readiness': False, 'frozen': False,
         'allocation_reserved': False}, [capsule_id, *direct], [*exp, capsule_id])
    signature = {'campaign_id': request['campaign_id'], 'role': request['role'],
                 'plan_ids': request['plan_ids'], 'closure_index': index, 'admission': admission}
    allocation = envelope('PROPOSED-scientific-allocation/2',
        {'signature': signature, 'primary_count': len(plans), 'scientific_readiness': False,
         'qualification': 'HYPOTHETICAL_COMMIT_SIZE_ONLY'}, [capsule_id, *direct], [*exp, capsule_id])
    allocation_id = sha(allocation)
    trials = [envelope('PROPOSED-scientific-trial/2',
        {'allocation_id': allocation_id, 'plan_id': plan['id'], 'compiled_id': comp['id'],
         'claim_id': sha(comp['body']['compilation_input']['candidate']),
         'scientific_readiness': False, 'qualification': 'HYPOTHETICAL_COMMIT_SIZE_ONLY'},
        [allocation_id, *direct], [*exp, capsule_id]) for plan, comp in zip(plans, compiled)]
    trial_ids = [sha(t) for t in trials]
    manifest = envelope('PROPOSED-frozen-manifest/2',
        {'request': request, 'input_id': capsule_id, 'allocation_id': allocation_id,
         'trial_ids': trial_ids, 'closure_index': index, 'admission': admission,
         'scientific_readiness': False, 'qualification': 'HYPOTHETICAL_COMMIT_SIZE_ONLY'},
        [capsule_id, allocation_id, *trial_ids, *direct], [*exp, capsule_id])
    records = {'capsule': capsule, 'attempt': attempt, 'allocation': allocation, 'manifest': manifest}
    wire = {name: {'bytes': len(encoded(value)), 'fits_1MiB': len(encoded(value)) <= MAX_ENVELOPE,
                   'direct_refs': len(value['source_refs']), 'direct_blobs': len(value['blob_refs'])}
            for name, value in records.items()}
    wire['trials'] = {'count': len(trials), 'bytes_each': [len(encoded(t)) for t in trials],
                      'total_bytes': sum(len(encoded(t)) for t in trials),
                      'max_direct_refs': max(len(t['source_refs']) for t in trials)}
    return {'status': 'COMPLETE_UNTRUNCATED_METADATA_TRAVERSAL', 'family_members': len(plans),
        'request': request, 'direct_request_root_occurrences': len(roots), 'direct_request_roots': sorted(set(roots)),
        'counts': index['counts'], 'set_digests': index['digests'],
        'artifact_ids': all_ids, 'exposure_ids': exp, 'blob_ids': blob_ids,
        'unresolved_exposure_ids': sorted(set(exp) - set(all_ids)),
        'canonical_stored_envelope_sum_bytes': graph['envelope_sum'],
        'canonical_stored_envelope_max_bytes': graph['largest'][0],
        'largest_envelope_artifact_id': graph['largest'][1],
        'schema_counts': graph['schema_counts'], 'registered_transitive_blob_bytes': graph['registered_blob_bytes'],
        'max_original_direct_source_refs': max(len(a['source_refs']) for a in graph['artifacts'].values()),
        'max_original_direct_blob_refs': max(len(a.get('blob_refs', [])) for a in graph['artifacts'].values()),
        'source_capture_files': len(files), 'source_capture_bytes': sum(d['size'] for d in files.values()),
        'proposed_roots': direct, 'independent_retraversal_exact_for_artifacts_exposure_blobs': True,
        'proposed_complete_index_bytes': len(encoded(index)), 'proposed_index_fits_1MiB': len(encoded(index)) <= MAX_ENVELOPE,
        'proposed_serialized_record_models': wire,
        'record_model_limit': 'Proposed wire-size calculations using actual complete metadata/sets, not persisted records, a production schema or a qualified admission. Actual data-findings arrays are included as an explicit conservative model, not a new data pass.',
        'actual_condition_expressions': [c['body']['compilation_input']['candidate']['condition_ast']['expression'] for c in compiled],
        'compiled_condition_hashes': [sha(c['body']['compilation_input']['candidate']['condition_ast']) for c in compiled]}


if __name__ == '__main__':
    started = time.monotonic()
    source_before = footprint(source_bundle())
    SOURCE_PIN = source_before['trading_researcher/scientific_freeze.py']
    assert SOURCE_PIN == '969f8be6f564824f5e25c9eed199e28f8bf23e5a3ab02c389c7f62209368f885'
    report = {'schema': 'scientific-data-closure-measurement/1', 'status': 'CONSTRUCTING_ONE_SYNTHETIC_FIXTURE',
        'started_at_utc': datetime.now(timezone.utc).isoformat(), 'source_pin': SOURCE_PIN,
        'source_footprint_hash': sha(source_before), 'phases': [],
        'scope': 'One genuine existing synthetic protected fixture. Constructor certification/replay and its tiny synthetic development execution explicitly authorized as fixture setup; no additional replay/row expansion in metadata traversal, no real protected inputs or study execution.',
        'provider_document_exception': 'Only the existing invented fixture provider-document pins are substituted; no real licensing/PIT/scientific acceptance is inferred.'}
    persist(report)
    cls = support.ProtectedPlanTests
    constructed = False
    try:
        phase = time.monotonic()
        announce('constructor_started')
        cls.setUpClass()
        constructed = True
        f = cls.base
        report['phases'].append({'phase': 'existing_genuine_fixture_constructor', 'seconds': time.monotonic() - phase})
        announce('constructor_complete', seconds=time.monotonic() - phase)
        checksum = hashlib.sha256(b'Synthetic provider-document fixture\n').hexdigest()
        with patch.object(data_use, 'REVIEWED_DOCUMENTS', {name: checksum for name in data_use.REVIEWED_DOCUMENTS}):
            def make_plan(compiled, label, primary_count):
                assessment = f.op('assess_data_use', compiled_id=compiled['id'])
                assert assessment['body']['status'] == 'QUALIFIED_PRIVATE_PLAN_DATA'
                plan = f.op('prepare_evaluation_plan', key=label, compiled_id=compiled['id'],
                    primary_count=primary_count, data_use_assessment_id=assessment['id'],
                    dependence={'base_length': 4, 'rationale': 'Existing synthetic declaration; no scientific adequacy.',
                        'development_refs': [cls.diagnostic['id']],
                        'randomness': {'algorithm': 'fixture-generator', 'version': '1', 'seed': 17}})
                assert plan['body']['status'] == 'POLICY_DRAFT'
                return assessment, plan

            one_assessment, one_plan = make_plan(cls.compiled, 'closure-measurement-original-single', 2)
            anchor = f.op('add_source', body={'purpose': 'Existing-style synthetic campaign/selection/reservation anchor'}, data_class='development')
            request = {'key': 'closure-measurement-single', 'campaign_id': anchor['id'], 'role': 'primary',
                'plan_ids': [one_plan['id']], 'selection_record_ref': anchor['id'], 'reservation_spec_ref': anchor['id']}
            phase = time.monotonic()
            report['one_plan'] = measure(f.broker, request, [one_plan], [cls.compiled], [one_assessment])
            report['phases'].append({'phase': 'one_plan_metadata_measurement', 'seconds': time.monotonic() - phase})
            report['status'] = 'ONE_PLAN_MEASURED_CONSTRUCTING_EIGHT_DISTINCT_MEMBERS'
            persist(report)
            announce('one_plan_measured', counts=report['one_plan']['counts'])
            plans, compiles, assessments = [], [], []
            for index in range(8):
                phase = time.monotonic()
                if index == 0:
                    compiled = cls.compiled
                else:
                    f.base.base = deepcopy(f.base.base)
                    f.base.base['candidate']['condition_ast']['expression']['right']['value'] = str(101 + index)
                    case = f.formalize()
                    compiled = f.compile(case, cls.private)
                    assert compiled['body']['status'] == 'COMPILED'
                assessment, plan = make_plan(compiled, 'closure-measurement-family-' + str(index), 8)
                compiles.append(compiled); assessments.append(assessment); plans.append(plan)
                report['phases'].append({'phase': 'actual_family_member_' + str(index), 'seconds': time.monotonic() - phase})
                persist(report)
                announce('family_member_prepared', member=index + 1, seconds=time.monotonic() - phase)
            assert len({c['id'] for c in compiles}) == 8
            assert len({sha(c['body']['compilation_input']['candidate']['condition_ast']) for c in compiles}) == 8
            anchors = [f.op('add_source', body={'purpose': 'Synthetic complete family ' + name}, data_class='development')['id']
                       for name in ('campaign', 'selection', 'reservation')]
            request = {'key': 'closure-measurement-distinct-eight', 'campaign_id': anchors[0], 'role': 'primary',
                'plan_ids': [p['id'] for p in plans], 'selection_record_ref': anchors[1], 'reservation_spec_ref': anchors[2]}
            phase = time.monotonic()
            report['eight_plan'] = measure(f.broker, request, plans, compiles, assessments)
            report['phases'].append({'phase': 'eight_plan_metadata_measurement', 'seconds': time.monotonic() - phase})
            report['family_scope'] = 'Eight actual owned distinct AST1 condition thresholds101..108, separately formalized/compiled/data-qualified/planned; same full development/private sources and no ancestry pruning. Not eight independently discovered hypotheses, meaning-certified scientific claims or worst-case independent data-source universes.'
            report['status'] = 'COMPLETE_ONE_AND_EIGHT_PLAN_MEASUREMENTS'
            announce('eight_plan_measured', counts=report['eight_plan']['counts'])
    except BaseException as exc:
        report['status'] = 'STOPPED_INCOMPLETE_MEASUREMENT'
        report['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
        raise
    finally:
        phase = time.monotonic()
        cls.doClassCleanups()
        report['cleanup_seconds'] = time.monotonic() - phase
        report['total_seconds'] = time.monotonic() - started
        report['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
        report['source_unchanged'] = footprint(source_bundle()) == source_before
        report['metadata_probe_bounds'] = {'nodes': MAX_NODES, 'sum_envelope_bytes': MAX_METADATA,
            'on_overflow': 'Fail incomplete; never return a truncated closure'}
        persist(report)
        announce('finished', status=report['status'], seconds=report['total_seconds'], source_unchanged=report['source_unchanged'])
